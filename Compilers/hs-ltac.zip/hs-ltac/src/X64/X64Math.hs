module X64.X64Math(x64IMathRR) where

import System.IO

import Ltac
import X64.X64Registers

-- Handles integer math
intMathInstr mathType
    | mathType == "mul" = "imul"
    | mathType == "mod" = "div"
    | otherwise = mathType

x64IMathRR ln writer = do
    let mathType = arg1 ln
    let instr = intMathInstr mathType
    let reg1 = x64IntReg (read (arg2 ln) :: Int)
    let reg2 = x64IntReg (read (arg3 ln) :: Int)
    hPutStrLn writer ("\t" ++ instr ++ " " ++ reg1 ++ ", " ++ reg2)
