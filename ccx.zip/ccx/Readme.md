## CCX

CCX is a concept for a new programming language. The programming language is meant to be a replacement for C. It seeks to address the short comings of C while also retaining its portability and features that make it so suitable for low-level programming.

This project is currently a concept and paused. There are two compilers in development:

* ccx-c -> A compiler written in C
* main -> A slightly more complete version written in C++

The C version has a fair amount of frontend infastructure in place, but no backend. The C++ version can parse almost the entire grammar, and has some of the backend in place. Originally, I was using LLIR, but because of some bugs, I'm thinking about using LLVM just to get something working that can be used to test the language.

