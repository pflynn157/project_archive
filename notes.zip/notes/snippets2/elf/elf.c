#include <stdio.h>
#include <elf.h>

int main(int argc, char *argv[]) {
    // The ELF header
    Elf64_Ehdr header;
    header.e_ident[0] = 0x7f;
    header.e_ident[1] = 'E';
    header.e_ident[2] = 'L';
    header.e_ident[3] = 'F';
    header.e_ident[4] = 2;          //64-bit object
    header.e_ident[5] = 1;          //Little-endian encoding
    header.e_ident[6] = EV_CURRENT;
    header.e_ident[7] = ELFOSABI_LINUX;
    header.e_ident[8] = 0;
    
    header.e_type = ET_EXEC;
    header.e_machine = EM_X86_64;
    header.e_version = 1;
    
    header.e_entry = 4194430;       // Entry point
    header.e_phoff = 64;            // Program header start
    header.e_shoff = 0;
    
    header.e_flags = 0;             // Flags
    header.e_ehsize = 64;           // Header size
    header.e_phentsize = 56;        // Program header size
    header.e_phnum = 1;             // 1 program header
    
    header.e_shentsize = 0;
    header.e_shnum = 0;
    header.e_shstrndx = 0;
    
    // The program header
    Elf64_Phdr ph;
    ph.p_type = 1;
    ph.p_flags = 5;
    ph.p_offset = 126;
    ph.p_vaddr = 4194430;
    ph.p_paddr = 0;
    ph.p_filesz = 132;
    ph.p_memsz = 132;
    ph.p_align = 1;
    
    // Write the file
    FILE *writer = fopen("out.bin", "w");
    fwrite(&header, sizeof(Elf64_Ehdr), 1, writer);
    fwrite(&ph, sizeof(Elf64_Phdr), 1, writer);
    fclose(writer);
    
    return 0;
}
