//
// Copyright 2021 Patrick Flynn
// This file is part of uds-wordpad.
// uds-wordpad is licensed under the BSD-3 license. See the COPYING file for more information.
//
#pragma once

#include <QToolBar>
#include <QToolButton>

#include <actions.hpp>

class MainToolbar : public QToolBar {
    Q_OBJECT
public:
    MainToolbar();
    ~MainToolbar();
private:
    Actions *actions;
    QToolButton *newFile, *openFile, *saveFile, *saveFileAs;
    QToolButton *cut, *copy, *paste;
    QToolButton *undo, *redo;
};

