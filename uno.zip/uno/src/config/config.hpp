#pragma once

#include <string>
#include <map>

#include "conf_lex.hpp"

struct ServerConfig {
    std::map<std::string, std::string> router;
    bool singleFile = false;
};

class ConfigParser {
public:
    explicit ConfigParser(std::string basePath);
    ServerConfig *getConfig();
protected:
    void parseRouter();
    void parseGenerator();
    
    ServerConfig *config;
    Config::Scanner *scanner;
};
