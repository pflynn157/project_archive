#pragma once

#include <stdio.h>

typedef enum {
    None,
    Eof,
    
    // Keywords
    Func,
    Return,
    Var,
    
    // Types
    I32,
    
    // Symbols
    LCBrace,
    RCBrace,
    LParen,
    RParen,
    SemiColon,
    Colon,
    Plus,
    Assign,
    Comma,
    
    // Expressions
    Id,
    IntL
} Token;

typedef struct {
    Token type;
    char *buffer;
    size_t buffer_length;
} TokenRef;

typedef struct {
    FILE *file;
    size_t current_line;
    char *buffer;
    size_t buffer_index;
    
    // Used for retrieving token values
    char *last_buffer;
    size_t last_buffer_length;
    
    // Token stack
    TokenRef **token_stack;
    size_t token_stack_top;
} Scanner;

void lex_init(const char *input, Scanner *scanner);
void lex_destroy(Scanner *scanner);
Token lex_get_next(Scanner *scanner);
char *lex_get_buffer(Scanner *scanner);
int lex_get_int_buffer(Scanner *scanner);

// lex_debug.c
void lex_debug(Token token, Scanner *scanner);

