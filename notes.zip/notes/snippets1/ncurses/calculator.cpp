#include <ncurses.h>
#include <string>

int current_ln = 3;

//Draws the screen
void draw_screen() {
	//Title
	attron(A_BOLD);
	attron(COLOR_PAIR(3));
	
	std::string title = "Calculator";
	printw(title.c_str());
	
	for (int i = title.length(); i<COLS; i++) {
		printw(" ");
	}
	
	attroff(A_BOLD);
	
	//Menu bar
	std::string menu = "F1: Quit";
	printw(menu.c_str());
	
	for (int i = menu.length(); i<COLS; i++) {
		printw(" ");
	}
	
	attroff(COLOR_PAIR(3));
	
	mvprintw(current_ln, 0, "");
}

//The prompt loop
void prompt() {
	attron(A_BOLD);
	attron(COLOR_PAIR(1));
	
	std::string prob = "Enter problem> ";
	mvprintw(current_ln, 0, prob.c_str());
	
	int key;
	while (key != KEY_F(1)) {
		if (key == '\n') {
			current_ln+=2;
			mvprintw(current_ln, 0, prob.c_str());
		} else if (key != 0) {
			printw("%c", key);
		}
		
		key = getch();
	}
	
	attroff(COLOR_PAIR(1));
	attroff(A_BOLD);
}

int main(int argc, char **argv) {
	initscr();
	noecho();
	keypad(stdscr, true);
	start_color();
	
	init_pair(1, COLOR_WHITE, COLOR_BLACK);
	init_pair(2, COLOR_WHITE, COLOR_BLUE);
	init_pair(3, COLOR_YELLOW, COLOR_BLUE);
	
	draw_screen();
	prompt();
	
	endwin();
	return 0;
}
