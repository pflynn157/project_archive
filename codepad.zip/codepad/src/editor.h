#pragma once

#include <gtk/gtk.h>
#include <gtksourceview/gtksource.h>

typedef struct
{
    GtkWidget *editor;
    GtkWidget *scrollView;
    GtkSourceFile *srcFile;
    int modified;
} Editor;

Editor *create_editor();
void set_editor_syntax_highlighter(Editor *edit, const char *id);
void editor_load_file(Editor *edit, const char *path);
void editor_save_file(Editor *edit);

