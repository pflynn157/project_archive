#pragma once

#include "ast.h"

void print_data_type(DataType type);
void print_node(struct Node *node);
void print_statement(struct Statement *stmt, int out_terminal);
void print_function(struct Function *func);
void print_tree(AstTree *tree);

