
## VHDL Project Base

This is a template for VHDL projects. Hopefully it will be useful to others besides myself. It contains a AND, OR, and NOT gates as circuits, and a few example tests. I use GHDL as my compiler. See the makefile for more information; you can extend it as needed.

### Credits

Although I did a lot of modifications to adapt it to my purposes, this is not completely my own work. Here are the credits.

The core infastructure and the idea came from here: https://github.com/pvarin/SampleVHDL.

The automated example for the AND gate is from the GHDL docs.
