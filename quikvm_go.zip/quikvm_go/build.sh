#!/bin/bash
cd assembler
go build -o quikasm
cd ..

cd vm
go build -o quikvm
cd ..
