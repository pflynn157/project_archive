package main

import (
	"os"
	"bufio"
	//"fmt"
)

func main() {
	//Get the path and open the file
	if len(os.Args) != 3 {
		println("Error: No input or output file specified!")
		os.Exit(1)
	}
	
	path := os.Args[1]
	out_path := os.Args[2]
	
	file, err := os.Open(path)
	if err != nil {
		println("Fatal error: Unable to open input file.")
		os.Exit(1)
	}
	
	defer file.Close()
	
	//Create and setup our assembler object
	var asm Assembler
	asm.Setup(out_path)
	
	//Control variables
	in_str := false
	
	//Now, read the file and pass into the assembler
	reader := bufio.NewScanner(file)
	for reader.Scan() {
		current := reader.Text()
		
		if current == "sec str" {
			in_str = true
			asm.InsertByte(0xF3)
		} else if current == "sec data" {
			in_str = false
			asm.InsertByte(0xF4)
		} else {
			if in_str {
				asm.WriteString(current)
			} else {
				asm.WriteData(current)
			}
		}
	}
	
	//We're done, close up everything
	asm.WriteOut()
}
