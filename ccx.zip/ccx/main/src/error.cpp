#include <iostream>

#include "error.hpp"

ErrorManager::ErrorManager(Scanner *scanner) {
    this->scanner = scanner;
}

ErrorManager::~ErrorManager() {
}

void ErrorManager::addSyntaxError(std::string message) {
    Error err;
    err.message = "Syntax Error: " + message;
    err.location = scanner->getLine();
    err.details = scanner->getRawBuffer();
    errors.push_back(err);
}

void ErrorManager::print() {
    for (auto err : errors) {
        std::cout << "[" << err.location << "] " << err.message << std::endl;
        std::cout << err.details << std::endl << std::endl;
    }
}

