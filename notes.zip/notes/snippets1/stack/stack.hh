#pragma once

//Our class structure
class Stack {
public:
	explicit Stack(int s);
	void push(int no);
	int pop();
	int peek();
	int size();
private:
	int* stack;		//The array
	int sz;			//The maximum size
	int top;		//The current top of the stack
};
