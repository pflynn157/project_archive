//
// Copyright 2021 Patrick Flynn
// This file is part of uds-wordpad.
// uds-wordpad is licensed under the BSD-3 license. See the COPYING file for more information.
//
#include <QFileDialog>
#include <QColorDialog>
#include <QColor>
#include <QtGlobal>
#include <cstdlib>

#include <actions.hpp>
#include <global.hpp>

void Actions::newFile() {
    win->getTabWidget()->addUntitledTab();
}

void Actions::openFile() {
#if QT_VERSION >= QT_VERSION_CHECK(5, 14, 0)
    QString file_types = "Rich Text Files (*.txt *.md *.html *.htm *.rst)";
#else
    QString file_types = "Rich Text Files (*.txt *.html *.htm *.rst)";
#endif

    QString fileName = QFileDialog::getOpenFileName(nullptr, "Open File",
        getenv("HOME"), file_types);
    if (fileName.isNull())
        return;
        
    win->getTabWidget()->addTabFromFile(fileName);
}

void Actions::saveFile() {
    Editor *edit = win->getTabWidget()->getCurrentWidget();
    if (edit->isUntitled()) {
        saveFileAs();
    } else {
        edit->saveFile();
    }
}

void Actions::saveAll() {
    TabWidget *tabs = win->getTabWidget();
    for (int i = 0; i<tabs->count(); i++) {
        tabs->setCurrentIndex(i);
        saveFile();
    }
}

void Actions::saveFileAs() {
#if QT_VERSION >= QT_VERSION_CHECK(5, 14, 0)
    QString file_types = "Rich Text Files (*.txt *.md *.html *.htm *.rst)";
#else
    QString file_types = "Rich Text Files (*.txt *.html *.htm *.rst)";
#endif

    QString fileName = QFileDialog::getSaveFileName(nullptr, "Save File",
        getenv("HOME"), file_types);
    if (fileName.isNull())
        return;
        
    QString name = QFileInfo(fileName).fileName();
    
    Editor *edit = win->getTabWidget()->getCurrentWidget();
    edit->setFile(fileName, name);
    edit->saveFile();
    
    win->setCurrentFile(fileName);
    
    TabWidget *tabs = win->getTabWidget();
    tabs->setTabText(tabs->currentIndex(), name);
}

void Actions::printCurrent() {
    Editor *edit = win->getTabWidget()->getCurrentWidget();
    edit->printPage();
}

void Actions::exportCurrentPDF() {
    Editor *edit = win->getTabWidget()->getCurrentWidget();
    edit->exportPDF();
}

void Actions::changeTextFG() {
    QColor color = QColorDialog::getColor(Qt::black);
    
    Editor *edit = win->getTabWidget()->getCurrentWidget();
    edit->setTextColor(color);
}

void Actions::toggleBold() {
    Editor *edit = win->getTabWidget()->getCurrentWidget();
    edit->toggleBold();
}

void Actions::toggleItalic() {
    Editor *edit = win->getTabWidget()->getCurrentWidget();
    edit->toggleItalic();
}

void Actions::toggleUnderline() {
    Editor *edit = win->getTabWidget()->getCurrentWidget();
    edit->toggleUnderline();
}

void Actions::cut() {
    Editor *edit = win->getTabWidget()->getCurrentWidget();
    edit->cut();
}

void Actions::copy() {
    Editor *edit = win->getTabWidget()->getCurrentWidget();
    edit->copy();
}

void Actions::paste() {
    Editor *edit = win->getTabWidget()->getCurrentWidget();
    edit->paste();
}

void Actions::selectAll() {
    Editor *edit = win->getTabWidget()->getCurrentWidget();
    edit->selectAll();
}

void Actions::undo() {
    Editor *edit = win->getTabWidget()->getCurrentWidget();
    edit->undo();
}

void Actions::redo() {
    Editor *edit = win->getTabWidget()->getCurrentWidget();
    edit->redo();
}

