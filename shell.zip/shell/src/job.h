#pragma once

#include <list.h>

void run_job(StrList *list);
