#include "window.hpp"

Window::Window() {
    this->setWindowTitle("Graphine");
    this->resize(900, 600);
    
    canvas = new Canvas;
    this->setCentralWidget(canvas);
}

Window::~Window() {
}

void Window::setCanvas(std::vector<Element *> elements) {
    if (!canvas) return;
    canvas->setElements(elements);
}
