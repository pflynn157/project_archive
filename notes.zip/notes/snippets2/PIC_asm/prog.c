extern void print_int(int x);
extern void print_char(char c);
extern void println(char *str);

int main() {
	print_int(12);
	print_int(13);
	print_char('A');
	
	println("Hello!");
	
	return 0;
}
