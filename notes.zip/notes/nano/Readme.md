## Nano

This contains my nano configuration
