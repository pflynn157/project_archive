#include <iostream>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <cstdlib>
#include <thread>

#include "server.hpp"

int socketd;

//The server init function
Server::Server(int port, std::string basePath, ServerConfig *config) {
    this->basePath = basePath;
    if (basePath[basePath.length()-1] != '/') {
        this->basePath += "/";
    }
    
    if (config) this->config = config;

	socketd = socket(AF_INET, SOCK_STREAM, 0);
	if (socketd == -1) {
		std::cout << "Error: Unable to create socket." << std::endl;
		std::exit(1);
	}
	
	server.sin_family = AF_INET;
	server.sin_addr.s_addr = INADDR_ANY;
	server.sin_port = htons(port);
}

//The main server run function
void Server::run() {
	struct sockaddr_in client;

	int one = 1;
	setsockopt(socketd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
	
	if (bind(socketd, (struct sockaddr *)&server, sizeof(server)) < 0) {
		std::cout << "Bind failed." << std::endl;
		std::exit(1);
	}
	
	listen(socketd, 3);
	
	std::cout << "Bind complete." << std::endl;
	std::cout << "Listening for connections..." << std::endl;
	
	int c = sizeof(struct sockaddr_in);
	int nsocketd;
	
	while ((nsocketd = accept(socketd, (struct sockaddr *)&client, (socklen_t*)&c))) {
		std::cout << "New connection!" << std::endl;
		
		std::thread thread(&Server::rcv_data, this, nsocketd);
		thread.join();
	}
	
	if (nsocketd < 0) {
		std::cout << "Error: Connection failed." << std::endl;
		std::exit(1);
	}
	
	close(nsocketd);
	close(socketd);
}

//The receiving function started by each thread of the server
void Server::rcv_data(int nsocketd) {
	char buf[100];
	recv(nsocketd, buf, 100, 0);
		
	std::cout << std::endl << "Reply:" << std::endl;
	std::string data = std::string(buf);
	std::cout << data << std::endl;
	
	auto request = parse_request(data);
	/*auto path = "." + request.path;
	if (path == "./") {
		path = "./index.html";
	}*/
    std::string path = findPath(request.path);
	
	send_response(nsocketd, path);
	close(nsocketd);
}
