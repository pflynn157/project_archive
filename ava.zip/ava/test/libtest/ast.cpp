#include <iostream>

#include "ast.hpp"

void AstProgram::print() {
    std::cout << "program " << name << ";" << std::endl;
}

void AstOne::print() {
    std::cout << "1";
}

