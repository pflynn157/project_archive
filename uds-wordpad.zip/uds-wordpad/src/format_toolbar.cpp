//
// Copyright 2021 Patrick Flynn
// This file is part of uds-wordpad.
// uds-wordpad is licensed under the BSD-3 license. See the COPYING file for more information.
//
#include <QPixmap>
#include <QStringList>

#include <format_toolbar.hpp>
#include <actions.hpp>
#include <global.hpp>

FormatToolbar::FormatToolbar() {
    textStyle = new QComboBox;
    textColor = new QToolButton;
    bold = new QToolButton;
    italic = new QToolButton;
    underline = new QToolButton;
    
    QStringList items = QStringList() << "Title" << "Subtitle"
        << "Heading 1" << "Heading 2" << "Heading 3" << "Heading 4"
        << "Paragraph" << "Block Quote";
    textStyle->addItems(items);
    
    textColor->setIcon(QPixmap(":/icons/format-text-color.svg"));
    bold->setIcon(QPixmap(":/icons/format-text-bold.svg"));
    italic->setIcon(QPixmap(":/icons/format-text-italic.svg"));
    underline->setIcon(QPixmap(":/icons/format-text-underline.svg"));
    
    bold->setCheckable(true);
    italic->setCheckable(true);
    underline->setCheckable(true);
    
    actions = new Actions;
    connect(textColor, &QToolButton::clicked, actions, &Actions::changeTextFG);
    connect(bold, &QToolButton::clicked, actions, &Actions::toggleBold);
    connect(italic, &QToolButton::clicked, actions, &Actions::toggleItalic);
    connect(underline, &QToolButton::clicked, actions, &Actions::toggleUnderline);
    
    connect(textStyle, SIGNAL(textActivated(QString)), this, SLOT(onCurrentChanged(QString)));
    
    this->addWidget(textStyle);
    this->addWidget(textColor);
    this->addWidget(bold);
    this->addWidget(italic);
    this->addWidget(underline);
}

FormatToolbar::~FormatToolbar() {
    delete textStyle;
    delete textColor;
    delete bold;
    delete italic;
    delete underline;
    delete actions;
}

void FormatToolbar::updateFormat(bool isBold, bool isItalic, bool isUnderline) {
    bold->setChecked(isBold);
    italic->setChecked(isItalic);
    underline->setChecked(isUnderline);
}

void FormatToolbar::onCurrentChanged(QString item) {
    Editor *edit = win->getTabWidget()->getCurrentWidget();
    QString text = edit->textCursor().selectedText();
    
    if (item == "Title") {
        edit->insertHtml("<h1>" + text + "</h1>");
    } else if (item == "Subtitle") {
        edit->insertHtml("<h2>" + text + "</h2>");
    } else if (item == "Heading 1") {
        edit->insertHtml("<h3>" + text + "</h3>");
    } else if (item == "Heading 2") {
        edit->insertHtml("<h4>" + text + "</h4>");
    } else if (item == "Heading 3") {
        edit->insertHtml("<h5>" + text + "</h5>");
    } else if (item == "Heading 4") {
        edit->insertHtml("<h6>" + text + "</h6>");
    } else if (item == "Paragraph") {
        edit->insertHtml("<p>" + text + "</p>");
    } else if (item == "Block Quote") {
        edit->insertHtml("<blockquote>" + text + "</blockquote>");
    }
}

