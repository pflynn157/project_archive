#pragma once

void qkbk_iadd(char *n1, char *n2, char *rval);
void qkbk_isub(char *n1, char *n2, char *rval);
void qkbk_imul(char *n1, char *n2, char *rval);
void qkbk_idiv(char *n1, char *n2, char *rval);
void qkbk_imod(char *n1, char *n2, char *rval);
