## QuikVM

### What is it?
This is a simple virtual machine program; its inspired by the Java Virtual Machine. This program has its own instruction set, assembler, and of course, the virtual machine itself. The instruction set is fairly limited, but I plan on expanding it. Basically, it supports most integer operations, including math, variables, IO, and so forth. Flow control, some string operations, and a few other things are supported as well.

I designed this program mainly to be the runtime environment for future compiler projects until I'm ready to dive into assembly code. I also plan on using this to construct optimization programs and some other things. Its also good if you want to experiment a little bit with assembly level programming without having to worry about registers. I also just wanted to make a virtual machine because I think they are kinda cool...

The assembler and VM are both written in C++. The VM is a stack-based, single thread machine. You can use the makefile to build it. Its licensed under the BSD-3 license.

### Instructions
Integers:   
* i_load (number)   
* i_add   
* i_sub   
* i_mul   
* i_div   
* i_mod   
* i_print   
* i_input   
* i_var (name)   
* i_store (name)   
* i_load_var (name)   

Strings:   
* s_load (string)   
* s_print   

Labels:   
* lbl (name)   

Flow control:   
* jmp (name)   
* je (name)   
* jne (name)   

Comparison:   
* i_cmp (number)   

Exit:   
* exit   

