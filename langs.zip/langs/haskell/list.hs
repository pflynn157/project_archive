--list.hs
module Main(main) where

dspList :: [Int] -> [Int]
dspList [] = []
dspList (2:xs) = []
dspList (x:xs) = (x+1) : dspList xs

-- Gets the first part of a string
getFirst :: String -> String
getFirst [] = []
getFirst (' ':str) = []
getFirst (s:str) = s : getFirst str

-- Gets the second part of a string
getSecond :: Bool -> String -> String
getSecond _ [] = []
getSecond _ (' ':str) = getSecond True str
getSecond False (s:str) = s: getSecond False str
getSecond True (s:str) = s : getSecond True str

--entry :: IO
main = do
    putStrLn "Enter a command:"
    ln <- getLine
    putStrLn ("Your entry: " ++ ln)
    
    let cmd = getFirst ln
    putStrLn ("Your command: " ++ cmd)
    
    let args = getSecond False ln
    putStrLn $ "Your arguments: " ++ ln
    
