#include <iostream>
#include <cstdio>

#include <elf.hpp>

extern int pass1(const char *path);
extern void pass2(const char *path, FILE *f);

int main(int argc, char *argv[]) {
    if (argc == 1) {
        std::cout << "Error: No input files" << std::endl;
        return 1;
    }
    
    // Prepare the output
    FILE *file;
    file = fopen("a.out", "w");
    
    // Create the ELF header
    auto elf = new ElfFile("first.c");
    
    auto symtab = new ElfSymTab();
    elf->addSection(symtab);
    
    auto strtab = new ElfStrTab();
    elf->addSection(strtab);
    
    // Pass 1
    int code_size = pass1(argv[1]);
    
    auto text = new ElfText(code_size);
    elf->addSection(text);
    
    // Finish writing the ELF file
    elf->addFunction("_start", 0);
    elf->write(file);
    
    // Assemble
    pass2(argv[1], file);
    
    // Clean everything up
    fclose(file);
    
    return 0;
}
