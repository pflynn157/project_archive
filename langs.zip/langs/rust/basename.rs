use std::env;
use std::process;

//Returns the base of a path
fn get_basename(line:String) -> String {
	if line == "/" {
		return "/".to_string();
	}

	let mut result = String::new();
	let len = line.len();
	let mut index = 0;
	let mut last = 0;
	
	//First, find the last slash in a string
	for c in line.chars() {
		if c == '/' {
			last = index;
		}
		index += 1;
	}
	
	if last > 0 {
		index = last + 1;
	} else {
		index = 0;
	}
	
	//Build the string from the last slash
	while index < len {
		let c = line.chars().nth(index).unwrap();
		result.push_str(&c.to_string());
		index += 1;
	}
	
	result
}

//Returns a basename without a suffix
fn rm_suffix(line:String, suffix:String) -> String {
	let len = line.len();
	let s_len = suffix.len();
	
	if s_len > len {
		return line;
	}
	
	let start = len-s_len;
	let mut index = start;
	let mut sf = String::new();
	
	while index < len {
		let c = line.chars().nth(index).unwrap();
		sf.push_str(&c.to_string());
		index += 1;
	}
	
	if suffix == sf {
		let mut result = String::new();
	
		let end = start;
		index = 0;
		
		for c in line.chars() {
			if index == end {
				break;
			}
			
			result.push_str(&c.to_string());
			index += 1;
		}
		
		return result;
	}
	
	line
}

//Our help function
fn help() {
	println!("Usage:");
	println!("basename STRING [SUFFIX]");
	println!("basename [OPTION] STRING");
	println!("");
	println!("Arguments:");
	println!("\t-a, --multiple -> Take multiple inputs (don't use the last as a suffix).");
	println!("\t-s, --suffix -> Specify the suffix, followed by the input string.");
	println!("\t-h, --help -> Display this message and exit.");
	process::exit(1);
}

//Our main function
fn main() {
	let args:Vec<String> = env::args().collect();
	let len = args.len();
	
	if len <= 1 {
		println!("basename: Missing argument");
		println!("See \"basename --help\" for valid usage.");
		process::exit(1);
	}
	
	let mut input = args.iter().nth(1).unwrap().to_string();
	let mut suffix = String::new();
	
	if len >= 3 {
		suffix = args.iter().nth(2).unwrap().to_string();
	}
	
	//The help option
	if input == "-h" || input == "--help" {
		help();
		
	//Get the basename of all following arguments
	} else if input == "-a" || input == "--multiple" {
		if len == 2 {
			println!("Error: No paths specified.");
			process::exit(1);
		}
		
		let mut index = 2;
		while index < len {
			let current = args.iter().nth(index).unwrap().to_string();
			let result = get_basename(current);
			print!("{} ", result);
			index += 1;
		}
		
		println!("");
		process::exit(0);
		
	// -s
	} else if input == "-s" || input == "--suffix" {
		input = args.iter().nth(3).unwrap().to_string();
		suffix = args.iter().nth(2).unwrap().to_string();
	}
	
	//Do it...
	let mut result = get_basename(input);
	result = rm_suffix(result, suffix);
	
	println!("{}", result);
}
