//math.go
//This solves RPN problems
package main

import "strconv"

func solve_rpn(problem string) int {
//First, break up the problem
	current := ""
	var items [20]string
	size := 0
	
	for _, c := range problem {
		if c == ' ' {
			items[size] = current
			size++
			current = ""
			continue
		}
		
		current += string(c)
	}
	
	//Solve
	for x := 0; x<size; x++ {
		item := items[x]
		
		if item == "+" || item == "-" || item == "*" || item == "/" {
			no2Str := pop()
			no1Str := pop()
			
			no1, _ := strconv.Atoi(no1Str)
			no2, _ := strconv.Atoi(no2Str)
			var answer int
			
			if item == "+" {
				answer = no1+no2
			} else if item == "-" {
				answer = no1-no2
			} else if item == "*" {
				answer = no1*no2
			} else if item == "/" {
				answer = no1/no2
			}
			
			answerStr := strconv.Itoa(answer)
			push(answerStr)
		} else {
			push(item)
		}
	}
	
	//Get and return the answer
	answerStr := pop()
	answer, _ := strconv.Atoi(answerStr)
	return answer
}
