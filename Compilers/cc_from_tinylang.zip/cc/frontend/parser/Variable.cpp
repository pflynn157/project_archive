//
// Copyright 2021 Patrick Flynn
// This file is part of the Tiny Lang compiler.
// Tiny Lang is licensed under the BSD-3 license. See the COPYING file for more information.
//
#include <iostream>
#include <string>
#include <vector>

#include <parser/Parser.hpp>
#include <ast.hpp>

// Builds a variable declaration
// A variable declaration is composed of an Alloca and optionally, an assignment
bool Parser::buildVariableDec(AstBlock *block, Token typeToken) {
    Token token = scanner->getNext();
    int ptrLevel = 0;
    while (token.type != Id && token.type != Eof) {
        if (token.type == Mul) {
            ++ptrLevel;
        }
        
        token = scanner->getNext();
    }
    
    if (token.type != Id) {
        syntax->addError(scanner->getLine(), "Expected variable name.");
        return false;
    }
    
    std::string name = token.id_val;
    vars.push_back(name);
    
    
    // Set the data type
    DataType dataType = DataType::Void;
    DataType subType = DataType::Void;
    
    switch (typeToken.type) {
        case Char: dataType = DataType::I8; break;
        case Short: dataType = DataType::I16; break;
        case Int: dataType = DataType::I32; break;
        
        default: {
            syntax->addError(scanner->getLine(), "Invalid data type.");
            return false;
        }
    }
    
    if (ptrLevel == 1) {
        subType = dataType;
        dataType = DataType::Ptr;
    } else if (ptrLevel > 1) {
        dataType = DataType::Ptr;
        subType = DataType::Ptr;
    }
    
    // Create the declaration
    token = scanner->getNext();
    if (token.type == LBracket) {
        // TODO
    }
    
    AstVarDec *vd = new AstVarDec(name, dataType);
    vd->setPtrType(subType);
    block->addStatement(vd);
    
    auto typePair = std::pair<DataType, DataType>(dataType, subType);
    typeMap[name] = typePair;
     
    // Otherwise, we have a regular variable
    if (token.type == Assign) {
        AstExprStmt *va = new AstExprStmt;
        if (!buildExpression(va, dataType)) return false;
        
        AstExpression *expr = checkAssignExpression(va->getExpression(), dataType, block);
        va->clearExpressions();
        
        AstAssignOp *assign = new AstAssignOp;
        assign->setLVal(new AstID(name));
        assign->setRVal(expr);
        va->addExpression(assign);
        
        va->setDataType(dataType);
        block->addStatement(va);
    } else if (token.type != SemiColon) {
        syntax->addError(scanner->getLine(), "Invalid token.");
        return false;
    }
    
    return true;
}

// Builds a variable assignment
bool Parser::buildVariableAssign(AstBlock *block, Token idToken) {
    if (!isVar(idToken.id_val)) {
        syntax->addError(scanner->getLine(), "Undeclared variable.");
        return false;
    }

    DataType dataType = typeMap[idToken.id_val].first;
    AstExprStmt *va = new AstExprStmt;
    if (!buildExpression(va, dataType)) return false;
    
    AstExpression *expr = checkAssignExpression(va->getExpression(), dataType, block);
    va->clearExpressions();
    
    AstAssignOp *assign = new AstAssignOp;
    assign->setLVal(new AstID(idToken.id_val));
    assign->setRVal(expr);
    va->addExpression(assign);
    
    va->setDataType(dataType);
    block->addStatement(va);
    
    if (va->getExpressionCount() == 0) {
        syntax->addError(scanner->getLine(), "Invalid variable assignment.");
        return false;
    }
    
    return true;
}

// Builds an array assignment
bool Parser::buildArrayAssign(AstBlock *block, Token idToken) {
    DataType dataType = typeMap[idToken.id_val].second;
    AstArrayAssign *pa = new AstArrayAssign(idToken.id_val);
    pa->setDataType(typeMap[idToken.id_val].first);
    pa->setPtrType(dataType);
    block->addStatement(pa);
    
    if (!buildExpression(pa, DataType::I32, RBracket)) return false;
    
    Token token = scanner->getNext();
    if (token.type != Assign) {
        syntax->addError(scanner->getLine(), "Expected \'=\' after array assignment.");
        return false;
    }
    
    if (!buildExpression(pa, dataType)) return false;

    return true;
}

// Builds a constant variable
bool Parser::buildConst(bool isGlobal) {
    /*Token token = scanner->getNext();
    std::string name = token.id_val;
    
    // Make sure we have a name for our constant
    if (token.type != Id) {
        syntax->addError(scanner->getLine(), "Expected constant name.");
        return false;
    }
    
    // Syntax check
    token = scanner->getNext();
    if (token.type != Colon) {
        syntax->addError(scanner->getLine(), "Expected \':\' in constant expression.");
        return false;
    }
    
    // Get the data type
    token = scanner->getNext();
    DataType dataType = DataType::Void;
    
    switch (token.type) {
        case Char: dataType = DataType::I8; break;
        case Short: dataType = DataType::I16; break;
        case Int: dataType = DataType::I32; break;
        
        default: {
            syntax->addError(scanner->getLine(), "Unknown data type.");
            return false;
        }
    }
    
    // Final syntax check
    token = scanner->getNext();
    if (token.type != Assign) {
        syntax->addError(scanner->getLine(), "Expected \'=\' after const assignment.");
        return false;
    }
    
    // Build the expression. We create a dummy statement for this
    AstExpression *expr = nullptr;
    if (!buildExpression(nullptr, dataType, SemiColon, EmptyToken, &expr, true)) return false;
    
    // Put it all together
    if (isGlobal) {
        globalConsts[name] = std::pair<DataType, AstExpression*>(dataType, expr);
    } else {
        localConsts[name] = std::pair<DataType, AstExpression*>(dataType, expr);
    }
    */
    return true;
}
