## TSH

TSH (short for Tiny Shell- yeah highly original) is a simple Unix shell written in C. I started the project about two months ago to work on my C skills and learn more about how processes on Linux work.

TSH features:   

* Run commands (arguments obviously supported)
* Command-line editing (backspace detection and functionality)
* Environment variable parsing
* Set environment variables (set command)
* Environment navigation (cd command)

### Feature Work

I don't have an immediate plans to work on this, but I would like to get it a little more functional in the future. I think one big issue that will have to be addressed is memory leaks- I think it leaks a lot of memory.

Stay tuned!

