int main() {
    return 4-;
}