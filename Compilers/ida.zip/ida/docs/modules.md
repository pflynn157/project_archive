## Modules

The Ida module system is very simple. A module can be relative to the current directory, or system-wide in /usr/lib/ida. A Ida module is simple a header file (.ih) with all the declarations. They are in the folder path specified by the user's file.

