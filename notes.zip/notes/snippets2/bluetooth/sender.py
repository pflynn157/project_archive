from socket import *
import time

def get_first(ln):
	ret = ""
	for c in ln:
		if c == ' ':
			break
		else:
			ret += c
	return ret
	
def get_second(ln):
	ret = ""
	found = False
	
	for c in ln:
		if c == ' ':
			if found:
				ret += c
			else:
				found = True
		else:
			if found:
				ret += c
	
	return ret

macAddr = "B8:27:EB:89:61:0F"
port = 3

socketd = socket(AF_BLUETOOTH, SOCK_STREAM, BTPROTO_RFCOMM)
socketd.connect((macAddr, port))

commands = [
	"INC THR 40",
	"PAUSE 2",
	"NTRL THR"
]

socketd.send(bytes("SETUP", 'UTF-8'))
input()

for ln in commands:
	if get_first(ln) == "PAUSE":
		tm = get_second(ln)
		time.sleep(int(tm))
	else:
		socketd.send(bytes(ln, 'UTF-8'))
	
socketd.close()
