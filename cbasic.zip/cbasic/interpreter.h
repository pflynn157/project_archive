#ifndef INTERPRETER_H
#define INTERPRETER_H

int interpret(char *line);

#endif
