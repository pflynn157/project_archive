int main() {
    return 2 * (3 + 4);
}