import pigpio
import time

def led_toggle(state):
	pi = pigpio.pi()
	
	pi.set_mode(16, pigpio.OUTPUT)
	pi.write(16, state)
	
	pi.stop()
	
def led_blink(count, duration):
	for i in range(0, count):
		led_toggle(1)
		time.sleep(duration)
		led_toggle(0)
		time.sleep(duration)
