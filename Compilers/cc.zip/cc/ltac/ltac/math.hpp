#pragma once

#include "ltac.hpp"

// Integer addition
class LtacI32Math : public LtacInstr {
public:
    explicit LtacI32Math(int r1, int r2) {
        this->r1 = r1;
        this->r2 = r2;
    }
    
    int getPos1() { return r1; }
    int getPos2() { return r2; }
    
    std::string printInstr();
protected:
    // If the values are -1, we pop from the stack
    int r1 = -1;
    int r2 = -1;
    std::string op = "add";
};

// Integer addition
class LtacI32Add : public LtacI32Math {
public:
    LtacI32Add(int r1, int r2) : LtacI32Math(r1, r2) {
        this->type = LtacType::I32Add;
        this->op = "add";
    }
};

// Integer subtraction
class LtacI32Sub: public LtacI32Math {
public:
    LtacI32Sub(int r1, int r2) : LtacI32Math(r1, r2) {
        this->type = LtacType::I32Sub;
        this->op = "sub";
    }
};

// Integer multiplication
class LtacI32Mul : public LtacI32Math {
public:
    LtacI32Mul(int r1, int r2) : LtacI32Math(r1, r2) {
        this->type = LtacType::I32Mul;
        this->op = "mul";
    }
};
