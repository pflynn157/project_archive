#pragma once

#include <vector>
#include <string>
#include <cstdio>

#include <elf.h>

class ElfSection;
class ElfStrTab;
class ElfSymTab;

// Represents an ELF file
class ElfFile {
public:
    ElfFile(std::string file_name);
    void addSection(ElfSection *section);
    void addFunction(std::string name, int pos);
    void write(FILE *file);
protected:
    void writeDefaultHeaders(FILE *file);
    void writeShStrtab(FILE *file, int size, int offset);
private:
    std::vector<ElfSection *> sections;
    
    std::string file_name = "";
    ElfSymTab *symtab;
    ElfStrTab *strtab;
};

// Represents the ELF section types
enum class ElfSectionType {
    None,
    Strtab,
    Symtab,
    Text,
    Data
};

// Represents a general section
class ElfSection {
public:
    explicit ElfSection(int type);
    explicit ElfSection(std::string name, int type);
    ElfSectionType getSecType();
    std::string getName();
    std::string getLink();
    int getType();
    int getFlags();
    int getAlign();
    
    virtual int getSize() { return size; }
    virtual int getEntrySize() { return 0; }
    virtual int getInfo() { return 0; }
    virtual void writeContent(FILE *file) {}
protected:
    ElfSectionType secType = ElfSectionType::None;
    std::string name;
    std::string link_to = "";
    int type = 0;
    int flags = 0;
    int align = 1;
    int size = 0;
};

// Represents the text section
class ElfText : public ElfSection {
public:
    ElfText(int code_size);
};

// Represents the strtab section
class ElfStrTab : public ElfSection {
public:
    ElfStrTab();
    void addString(std::string str);
    int getSize();
    void writeContent(FILE *file);
private:
    std::vector<std::string> strings;
};

// Represents the symtab section
class ElfSymTab : public ElfSection {
public:
    ElfSymTab();
    void addSectionSymbol(int pos);
    void addGlobalSymbol(int name_pos, int pos, int section);
    
    int getInfo();
    int getSize();
    int getEntrySize();
    void writeContent(FILE *file);
private:
    std::vector<Elf64_Sym> symbols;
    int info_pos = 0;
};

