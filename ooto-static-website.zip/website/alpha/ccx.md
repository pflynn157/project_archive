---
layout: page
title: CCX
permalink: /alpha/ccx
---

Coming soon! See the code: [https://gitlab.com/ootoalpha/as](https://gitlab.com/ootoalpha/ccx).

