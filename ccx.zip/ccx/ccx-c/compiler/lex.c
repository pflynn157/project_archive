#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "lex.h"

// Forward declarations
// J'aime le C
int lex_is_symbol(char c);
Token lex_get_symbol(char c, Scanner *scanner);
int lex_is_whitespace(char c);
int lex_is_keyword(char *buffer);
Token lex_get_keyword(char *buffer);
int lex_is_int(char *buffer);

void lex_init(const char *input, Scanner *scanner) {
    scanner->file = fopen(input, "r");
    scanner->current_line = 0;
    scanner->buffer = malloc(sizeof(char)*1024);        // TODO: We will need checks for this
    scanner->buffer_index = 0;
    
    scanner->last_buffer = malloc(sizeof(char)*1024);
    scanner->last_buffer_length = 0;
    
    scanner->token_stack = malloc(sizeof(TokenRef*)*10);
    for (int i = 0; i<10; i++) {
        scanner->token_stack[i] = malloc(sizeof(TokenRef));
    }
    scanner->token_stack_top = 0;
}

void lex_destroy(Scanner *scanner) {
    fclose(scanner->file);
    
    if (scanner->buffer) free(scanner->buffer);
    if (scanner->last_buffer) free(scanner->last_buffer);
    
    for (int i = 0; i<10; i++) {
        if (scanner->token_stack[i]) free(scanner->token_stack[i]);
    }
    free(scanner->token_stack);
    
    free(scanner);
}

Token lex_get_next(Scanner *scanner) {
    if (scanner->token_stack_top > 0) {
        int top = scanner->token_stack_top - 1;
        TokenRef *sym_token = scanner->token_stack[top];
        scanner->token_stack_top = top;
        return sym_token->type;
    }

    if (feof(scanner->file)) {
        return Eof;
    }
    
    char c = 0;
    while (!feof(scanner->file)) {
        c = fgetc(scanner->file);
        
        if (lex_is_symbol(c) || lex_is_whitespace(c)) {
            if (lex_is_symbol(c)) {
                if (strlen(scanner->buffer) == 0) {
                    return lex_get_symbol(c, scanner);
                } else {
                    int top = scanner->token_stack_top;
                    TokenRef *sym_token = scanner->token_stack[top];
                    sym_token->type = lex_get_symbol(c, scanner);
                    scanner->token_stack_top += 1;
                }
            }
            
            if (strlen(scanner->buffer) == 0) continue;
            
            Token token = None;
            
            // Now, check the buffer
            if (lex_is_keyword(scanner->buffer)) {
                token = lex_get_keyword(scanner->buffer);
            
            // Check literals
            } else if (lex_is_int(scanner->buffer)) {
                token = IntL;
            
            // Otherwise, default to identifier
            } else {
                token = Id;
            }
            
            // Copy the buffer
            memset(scanner->last_buffer, 0, 1024);
            strcpy(scanner->last_buffer, scanner->buffer);
            scanner->last_buffer_length = scanner->buffer_index;
            
            // Zero everything out
            memset(scanner->buffer, 0, 1024);
            scanner->buffer_index = 0;
            
            // Return
            return token;
        } else {
            scanner->buffer[scanner->buffer_index] = c;
            ++scanner->buffer_index;
        }
    }
    
    return Eof;
}

char *lex_get_buffer(Scanner *scanner) {
    return scanner->last_buffer;
}

int lex_get_int_buffer(Scanner *scanner) {
    return atoi(scanner->last_buffer);
}

//
// Private lexical utility functions
//
int lex_is_symbol(char c) {
    switch (c) {
        case '{':
        case '}':
        case '(':
        case ')':
        case ':':
        case ';':
        case ',':
        case '+': return 1;
        
        default: return 0;
    }
    
    return 0;
}

Token lex_get_symbol(char c, Scanner *scanner) {
    switch (c) {
        case '{': return LCBrace;
        case '}': return RCBrace;
        case '(': return LParen;
        case ')': return RParen;
        case ';': return SemiColon;
        case ',': return Comma;
        case '+': return Plus;
        
        
        case ':': {
            char c2 = fgetc(scanner->file);
            if (c2 == '=') {
                return Assign;
            } else {
                ungetc(c2, scanner->file);
                return Colon;
            }
        }
        
        default: return 0;
    }
    
    return 0;
}

int lex_is_whitespace(char c) {
    switch (c) {
        case ' ':
        case '\n':
        case '\t': return 1;
        
        default: return 0;
    }
    
    return 0;
}

int lex_is_keyword(char *buffer) {
    if (strcmp(buffer, "func") == 0) return 1;
    else if (strcmp(buffer, "return") == 0) return 1;
    else if (strcmp(buffer, "var") == 0) return 1;
    else if (strcmp(buffer, "i32") == 0) return 1;

    return 0;
}

Token lex_get_keyword(char *buffer) {
    if (strcmp(buffer, "func") == 0) return Func;
    else if (strcmp(buffer, "return") == 0) return Return;
    else if (strcmp(buffer, "var") == 0) return Var;
    else if (strcmp(buffer, "i32") == 0) return I32;
    
    return None;
}

int lex_is_int(char *buffer) {
    for (size_t i = 0; i<strlen(buffer); i++) {
        if (!isdigit(buffer[i])) return 0;
    }
    return 1;
}

