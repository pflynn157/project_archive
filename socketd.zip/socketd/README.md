## socketd

Socketd is a simple UTP library. It supports two way communication between two IP addresses. You are free to specify the port. See the test file in the lib/ folder to understand how it works. This library doesn't really work too well with GUI applications, but it seems suited well enough for CLI and backend applications. If you must use it with a GUI app, you may want to use some kind of IPC. 

Documentation will come soon. It works on Linux and FreeBSD. I'm not 100% sure about other operating systems; I doubt it will work on Windows, but it should work on any Unix system.

The chat folder contains a simple chat program for instant messaging between two computers. Its console-based only.
