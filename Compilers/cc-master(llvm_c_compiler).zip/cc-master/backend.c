#include <llvm-c/Core.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "backend.h"
#include "compiler.h"
#include "ast.h"
#include "var_table.h"

VarTable *var_table;

// Utility functions
int ssa_loco = 0;

LLVMValueRef get_register(LLVMTypeRef var_type, LLVMBuilderRef builder)
{
    char var_name[5];
    snprintf(var_name, 5, "%d", ssa_loco);
    ++ssa_loco;
    
    LLVMValueRef var = LLVMBuildAlloca(builder, var_type, var_name);
    return var;
}

LLVMTypeRef get_type(DataType type, LLVMContextRef context)
{
    switch (type)
    {
        case Void: return LLVMVoidTypeInContext(context);
        case Int: return LLVMInt32TypeInContext(context);
    }
}

LLVMValueRef build_expr(struct Node *expr, LLVMTypeRef var_type, LLVMContextRef context, LLVMBuilderRef builder)
{
    LLVMValueRef dest;

    switch (expr->type)
    {
        case IntL:
        {
            LLVMValueRef val = LLVMConstInt(var_type, expr->ival, 1);
            dest = val;
        }
        break;
        
        case Id:
        {
            dest = var_table_get(var_table, expr->sval);
            if (dest == NULL)
                dest = get_register(var_type, builder);
            
            dest = LLVMBuildLoad(builder, dest, expr->sval);
        }
        break;
        
        case Plus: break;
        case Sub: break;
    }
    
    return dest;
}

void build_var_assign(struct Statement *stmt, LLVMContextRef context, LLVMBuilderRef builder)
{
    struct Node *expr = stmt->operand->rval;
    struct Node *lval = stmt->operand->lval;
    
    LLVMTypeRef var_type = var_table_get_type(var_table, lval->sval);
    LLVMValueRef var = var_table_get(var_table, lval->sval);
        
    LLVMValueRef dest = build_expr(expr, var_type, context, builder);
    LLVMBuildStore(builder, dest, var);
}

// A variable declaration could have one of two structures
// Statement
//      lval -> ID
// OR
// Statement
//      operand -> Assign
//          lval -> ID
//          rval -> Something else
void build_var_dec(struct Statement *stmt, LLVMContextRef context, LLVMBuilderRef builder)
{
    struct Node *name_node = stmt->operand;
    int build_assign = 0;
    
    if (name_node->type == Assign)
    {
        name_node = name_node->lval;
        build_assign = 1;
    }
    
    char *var_name = name_node->sval;
    LLVMTypeRef var_type = get_type(stmt->ival, context);
    
    LLVMValueRef var = LLVMBuildAlloca(builder, var_type, var_name);
    
    VarEntry *entry = malloc(sizeof(VarEntry));;
    entry->name = strdup(name_node->sval);
    entry->var = var;
    entry->var_type = var_type;
    var_table_add(var_table, entry);
    
    if (build_assign)
    {
        struct Node *expr = stmt->operand->rval;
        
        LLVMValueRef dest = build_expr(expr, var_type, context, builder);
        LLVMBuildStore(builder, dest, var);
    }
}

void build_statement(struct Statement *stmt, LLVMContextRef context, LLVMBuilderRef builder)
{
    switch (stmt->type)
    {
        case VarDec: build_var_dec(stmt, context, builder); break;
        case VarAssign: build_var_assign(stmt, context, builder); break;
        
        // Build a return statement
        case Ret: {
            struct Node *operand = stmt->operand;
            
            LLVMTypeRef i32_type = get_type(Int, context);
            LLVMValueRef val = build_expr(operand, i32_type, context, builder);
            
            LLVMBuildRet(builder, val);
        } break;
        
        // Build a return-void statement
        case RetVoid: LLVMBuildRetVoid(builder); break;
    }
}

// The main function for the backend
void build_backend(AstTree *tree, LLVMContextRef context, LLVMModuleRef mod, LLVMBuilderRef builder)
{
    struct Function **funcs = tree->func_list;
    
    for (int i = 0; i<tree->func_count; i++)
    {
        if (var_table) var_table_clear(var_table);
        var_table = var_table_create();
        
        struct Function *current = funcs[i];
        
        LLVMTypeRef type = get_type(current->type, context);
        LLVMTypeRef func_type = LLVMFunctionType(type, NULL, 0, 0);
        LLVMValueRef func = LLVMAddFunction(mod, current->name, func_type);
        
        if (current->is_extern)
        {
            LLVMSetLinkage(func, LLVMExternalLinkage);
            continue;
        }
        
        LLVMBasicBlockRef block = LLVMAppendBasicBlockInContext(context, func, "entry");
        LLVMPositionBuilderAtEnd(builder, block);
        
        struct Statement **lines = current->block->line_list;
        for (int j = 0; j<current->block->line_count; j++)
        {
            struct Statement *stmt = lines[j];
            build_statement(stmt, context, builder);
        }
        
    }
    
    if (var_table) var_table_clear(var_table);
}
