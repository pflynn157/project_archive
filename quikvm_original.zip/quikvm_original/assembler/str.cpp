#include <string>

#include "str.hh"

//Get the first part of the string
std::string get_first(std::string input) {
	std::string ret = "";
	
	for (char c : input) {
		if (c == ' ') {
			break;
		}
		
		ret += c;
	}
	
	return ret;
}

//Get second part of the string
std::string get_second(std::string input) {
	std::string ret = "";
	bool found = false;
	
	for (char c : input) {
		if (c == ' ' && !found) {
			found = true;
			continue;
		}
		
		if (found) ret += c;
	}
	
	return ret;
}

//Gets the basename of a file path
std::string get_base(std::string input) {
	std::string ret = "";
	int start = 0;
	
	for (int i = input.length()-1; i>=0; i--) {
		if (input[i] == '/') {
			start = i+1;
			break;
		}
	}
	
	for (int i = start; i<input.length(); i++) {
		if (input[i] == '.') {
			break;
		}
		ret += input[i];
	}
	
	return ret;
}

//Remove quotes from a string
std::string rm_quotes(std::string input) {
	std::string ret = "";
	
	for (int i = 1; i<input.length()-1; i++) {
		ret += input[i];
	}
	
	return ret;
}

