## AST

This is the documentation for what each AST type holds.

#### AstList (reference as "children" from node)
* elements -> The list of AstNode's
* loco -> (Current top of the list-> Use as length in loop)

#### Function Declaration (FuncDec)
* str_val1 -> Function name
* int_val1 -> Return type 

#### Function Call
* str_val1 -> Function name

#### Variable (Var)
* str_val1 -> Variable name
* int_val1 -> Variable type
* int_val2 -> Whether it is a variable declaration (boolean)

#### Integer (Int)
* int_val1 -> Value

#### String
* str_val1 -> Value
