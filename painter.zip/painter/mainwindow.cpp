#include <QOpenGLWidget>
#include <QMouseEvent>

#include "mainwindow.h"

MainWindow::MainWindow() {
    this->resize(700,600);
    this->setStyleSheet("background-color:white");

   /* QPainter painter(this);

    this->repaint();*/
}

void MainWindow::paintEvent(QPaintEvent *) {
    QPainter painter(this);

    if (drawInProg) {
        painter.setBrush(Qt::white);
        painter.drawRect(inProg);
    }

    painter.setBrush(Qt::green);

    for (QRect r : rects) {
        painter.drawRect(r);
    }

    painter.setBrush(Qt::black);
    painter.drawText(10,10,"Hello!");
}

void MainWindow::mousePressEvent(QMouseEvent *event) {
    if (event->button()==Qt::LeftButton) {
        x1 = event->x();
        y1 = event->y();
        drawInProg = true;
    } else if (event->button()==Qt::RightButton) {
        QPixmap p = this->grab();
            QOpenGLWidget *glWidget  = this->findChild<QOpenGLWidget*>();
            if(glWidget){
                QPainter painter(&p);
                QPoint d = glWidget->mapToGlobal(QPoint())-this->mapToGlobal(QPoint());
                painter.setCompositionMode(QPainter::CompositionMode_SourceAtop);
                painter.drawImage(d, glWidget->grabFramebuffer());
                painter.end();
            }
        p.save("./test.png","PNG");
    }
}

void MainWindow::mouseMoveEvent(QMouseEvent *event) {
    if (/*event->button()==Qt::LeftButton &&*/ drawInProg) {
        int w = event->x()-x1;
        int h = event->y()-y1;
        QRect r(x1,y1,w,h);
        inProg = r;
        this->repaint();
    }
}

void MainWindow::mouseReleaseEvent(QMouseEvent *event) {
    if (event->button()==Qt::LeftButton) {
        int w = event->x()-x1;
        int h = event->y()-y1;
        QRect r(x1,y1,w,h);
        rects << r;
        drawInProg = false;
        this->repaint();
    }
}
