#pragma once

void disassemble(const char *path);
