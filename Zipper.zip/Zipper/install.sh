#!/bin/bash
cp share/zipper.desktop /usr/share/applications
cp build/src/Zipper /usr/local/bin
update-desktop-database
