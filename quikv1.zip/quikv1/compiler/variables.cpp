// Copyright 2019 Patrick Flynn
//
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, 
//	this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, this 
//	list of conditions and the following disclaimer in the documentation and/or 
//	other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors may 
//	be used to endorse or promote products derived from this software 
//	without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#include <iostream>

#include <strutils.hh>
#include <types.hh>
#include <error.hh>

#include "variables.hh"

//Holds declared variables
std::vector<Var> vars;

//Checks to see if a var exists in the list
bool is_var(std::string name) {
	bool found = false;
	
	for (auto v : vars) {
		if (v.name == name) {
			found = true;
			break;
		}
	}
	
	return found;
}

//Loads variable declarations
std::vector<String> load_vars(std::vector<String> contents) {
	auto tmp = contents;
	contents.clear();
	
	std::vector<String> bottom;
	int index = 1;
	
	//Iterate through our contents
	for (auto s : tmp) {
		std::string current = s.str;
		std::string second = get_second(current, ' ');
		
		//First, load inline strings
		if (is_str(second)) {
			std::string ln = get_first(current, ' ');
			ln += " ";
			
			std::string var_n = "s_str_" + std::to_string(index);
			std::string var_d = var_n + " str " + second;
			
			String s2;
			s2.str = var_d;
			contents.push_back(s2);
			index++;
			
			ln += var_n;
			s2.str = ln;
			bottom.push_back(s2);
			
			Var v;
			v.name = var_n;
			v.val = second;
			v.type = DataType::STR;
			vars.push_back(v);
			
			continue;
		}
		
		//Now go through and search for variable declarations
		std::string first = get_first(current, ' ');
		if (first == "var") {
			second = clr_spaces(second);
			
			std::string name = get_first(second, '=');
			std::string val = get_second(second, '=');
			std::string ln = name + " ";
			
			auto type = get_datatype(val);
			
			if (type == DataType::INT || type == DataType::BOOL) {
				ln += "int";
			} else if (type == DataType::DEC) {
				ln += "dec";
			} else if (type == DataType::CHAR) {
				ln += "char";
			} else if (type == DataType::STR) {
				ln += "str";
			} else {
				type_error(s);
			}
			
			ln += " " + val;
			
			String s2;
			s2.str = ln;
			contents.push_back(s2);
			
			Var v;
			v.name = name;
			v.val = val;
			v.type = type;
			vars.push_back(v);
			
			continue;
		}

		bottom.push_back(s);
	}
	
	//Merge the bottom with the rest of it
	String s3;
	s3.str = "$";
	contents.push_back(s3);
	
	for (auto s : bottom) {
		contents.push_back(s);
	}
	
	return contents;
}

//Handles variable re-assignments
std::vector<String> handle_reassigns(std::vector<String> contents) {
	auto tmp = contents;
	contents.clear();
	
	//Separate the data and variable parts
	std::vector<std::string> data;
	bool include = false;
	
	for (auto s : tmp) {
		if (s.str == "$" && !include) {
			include = true;
			contents.push_back(s);
			continue;
		}
		
		if (include) data.push_back(s.str);
		else contents.push_back(s);
	}
	
	//Iterate through the data part
	for (auto s : data) {
		if (!contains(s, '=')) {
			String s2;
			s2.str = s;
			contents.push_back(s2);
			continue;
		}
		
		//Collect data
		std::string ln = clr_spaces(s);
		std::string var = get_first(ln, '=');
		std::string args = get_second(ln, '=');
		Var v;
		
		for (auto cv : vars) {
			if (cv.name == var) {
				v = cv;
				break;
			}
		}
		
		//Non-existent var, exit
		if (v.name == "") {
			std::cout << "Error: Unknown variable: " << var << std::endl;
			std::exit(1);
		}
		
		//Check for addition
		if (contains(args, '+')) {
			std::string p1 = get_first(args, '+');
			std::string p2 = get_second(args, '+');
			
			std::string ln = "add " + p1 + ", " + p2;
			
			String s2;
			s2.str = ln;
			contents.push_back(s2);
			
			ln = "add_store " + var;
			s2.str = ln;
			contents.push_back(s2);
		}
	}
	
	return contents;
}

//Handles all variable operations
std::vector<String> handle_vars(std::vector<String> contents) {
	contents = load_vars(contents);
	contents = handle_reassigns(contents);
	return contents;
}
