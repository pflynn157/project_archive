// Copyright 2018 Patrick Flynn
//
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, 
//	this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, this 
//	list of conditions and the following disclaimer in the documentation and/or 
//	other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors may 
//	be used to endorse or promote products derived from this software 
//	without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#include <X11/Xlib.h>
#include <iostream>

#include "manager.hh"
#include "frame.hh"

#define MAX(a, b) ((a) > (b) ? (a) : (b))

int errorHandler(Display * d, XErrorEvent * e) {
	std::cout << "[Error] " << e->error_code << std::endl;
	return 0;
}

Manager::Manager() {
	display = XOpenDisplay(0x0);
	if (!display) {
		std::cerr << "[Error] Could not open display." << std::endl;
	}
	
	root = XDefaultRootWindow(display);
	XSelectInput(display,root,SubstructureRedirectMask | SubstructureNotifyMask);
	
	XSetErrorHandler(errorHandler);
	
	XGrabKey(display, XKeysymToKeycode(display, XStringToKeysym("Q")), ControlMask,
            DefaultRootWindow(display), True, GrabModeAsync, GrabModeAsync);
    XGrabButton(display, 1, ControlMask, DefaultRootWindow(display), True,
        ButtonPressMask|ButtonReleaseMask|PointerMotionMask, GrabModeAsync, GrabModeAsync, None, None);
	XGrabButton(display, 3, ControlMask, DefaultRootWindow(display), True,
        ButtonPressMask|ButtonReleaseMask|PointerMotionMask, GrabModeAsync, GrabModeAsync, None, None);
        
	windows = new std::vector<WinGroup>();
}

void Manager::run() {
	XWindowAttributes attr;
    XButtonEvent start;
    XEvent ev;
    start.subwindow = None;
    
	while(true) {
		XNextEvent(display, &ev);
        if (ev.type == KeyPress && ev.xkey.subwindow != None) {
            std::cout << "Key!" << std::endl;
            
            Window win = ev.xkey.subwindow;
            for (int i = 0; i<windows->size(); i++) {
            	WinGroup current = windows->at(i);
            	if (current.frame==win || current.child==win) {
					unmapNotify(win);
				}
            }
        } else if(ev.type == ButtonPress && ev.xbutton.subwindow != None)
        {
            XGetWindowAttributes(display, ev.xbutton.subwindow, &attr);
            start = ev.xbutton;
            
            for (int i = 0; i<windows->size(); i++) {
            	WinGroup current = windows->at(i);
            	if (current.frame==start.subwindow) {
            		Window close = current.close;
            		
            		XWindowAttributes attrC;
            		XGetWindowAttributes(display,close,&attrC);
            		
            		if (attrC.x+3==attr.x && attrC.y+3==attr.y) {
            			std::cout << "Close!" << std::endl;
            		}
            	}
            }
        }
        else if(ev.type == MotionNotify && start.subwindow != None)
        {
            int xdiff = ev.xbutton.x_root - start.x_root;
            int ydiff = ev.xbutton.y_root - start.y_root;
            XMoveResizeWindow(display, start.subwindow,
                attr.x + (start.button==1 ? xdiff : 0),
                attr.y + (start.button==1 ? ydiff : 0),
                MAX(1, attr.width + (start.button==3 ? xdiff : 0)),
                MAX(1, attr.height + (start.button==3 ? ydiff : 0)));
             
            Window child;   
         	for (int i = 0; i<windows->size(); i++) {
         		WinGroup current = windows->at(i);
         		if (current.frame==start.subwindow) {
					child = current.child;
					break;
				}
         	}
         	
         	XWindowAttributes attr;
            XGetWindowAttributes(display,start.subwindow,&attr);
            if (start.button==3) {
            	XResizeWindow(display,child,attr.width,attr.height);
            }
        }
        else if(ev.type == ButtonRelease) {
            start.subwindow = None;
		} else if (ev.type==CreateNotify) {
		} else if (ev.type==MapRequest) {
			mapRequest(ev.xmaprequest);
		} else if (ev.type==ConfigureRequest) {
			configureRequest(ev.xconfigurerequest);
		} else if (ev.type==UnmapNotify) {
			unmapNotify(ev.xunmap);
		}
	}
}

void Manager::mapRequest(const XMapRequestEvent &event) {
	Window win = event.window;
	
	Frame *frame = new Frame(display,win);
	Window f = frame->getWindow();
	
	WinGroup g;
	g.frame = f;
	g.child = win;
	g.close = frame->getClose();
	windows->push_back(g);
}

void Manager::configureRequest(const XConfigureRequestEvent &event) {
	XWindowChanges changes;
	changes.x = event.x;
	changes.y = event.y;
	changes.width = event.width;
	changes.height = event.height;
	changes.border_width = event.border_width;
	changes.sibling = event.above;
	changes.stack_mode = event.detail;
	XConfigureWindow(display, event.window, event.value_mask, &changes);
}

void Manager::unmapNotify(const XUnmapEvent &event) {
	unmapNotify(event.window);
}

void Manager::unmapNotify(const Window window) {
	Window win = window;

	if (win==root || windows->size()==0 || !win) {
		return;
	}

	Window frame;
	for (int i = 0; i<windows->size(); i++) {
		WinGroup current = windows->at(i);
		if (current.child==win) {
			frame = current.frame;
			windows->erase(windows->begin()+i);
			break;
		}
	}

	if (!frame) {
		return;
	}
	
	XUnmapWindow(display,frame);
	XDestroyWindow(display,frame);
}
