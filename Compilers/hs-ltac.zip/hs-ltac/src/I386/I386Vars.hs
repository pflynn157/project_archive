module I386.I386Vars(i386IStoreI,
    i386ILdrI,
    i386ILdrV,
    i386IStr) where

import System.IO

import Ltac
import I386.I386Registers

-- Store integer constant to variable
i386IStoreI ln writer = do
    let pos = arg1 ln
    let val = arg2 ln
    hPutStrLn writer ("\tmov DWORD PTR [ebp-" ++ pos ++ "], " ++ val)
    
-- Loads an integer constant to a register
i386ILdrI ln writer = do
    let regNo = read (arg1 ln) :: Int
    let reg = i386IntReg regNo
    let val = arg2 ln
    hPutStrLn writer ("\tmov " ++ reg ++ ", " ++ val)
    
-- Loads an integer variable to a register
i386ILdrV ln writer = do
    let regNo = read (arg1 ln) :: Int
    let reg = i386IntReg regNo
    let pos = arg2 ln
    hPutStrLn writer ("\tmov " ++ reg ++ ", DWORD PTR [ebp-" ++ pos ++ "]")
    
-- Stores a register to an integer variable
i386IStr ln writer = do
    let regNo = read (arg1 ln) :: Int
    let reg = i386IntReg regNo
    let pos = arg2 ln
    hPutStrLn writer ("\tmov DWORD PTR [ebp-" ++ pos ++ "], " ++ reg)
