## uds-wordpad

UDS Wordpad is a simple word-processor like application for editing rich text. Currently, it supports plain text and a subset of HTML. Printing and exporting to PDFs are supported. The application is written in C++ and uses the Qt5 Framework.

Note: If you are using a version of Qt 5.14 or greater, then Github-style Markdown is also supported. Otherwise, it is automatically disabled at build time.

