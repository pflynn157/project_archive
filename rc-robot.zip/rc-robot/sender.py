from socket import *

macAddr = "B8:27:EB:89:61:0F"
port = 3

socketd = socket(AF_BLUETOOTH, SOCK_STREAM, BTPROTO_RFCOMM)
socketd.connect((macAddr, port))

while 1:
	text = input()
	socketd.send(bytes(text, 'UTF-8'))
	if text == "exit":
		break
		
	data = socketd.recv(1024)
	if data:
		print(data.decode());
	
socketd.close()
