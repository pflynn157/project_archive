A set of programs that are helping me to learn different programming languages.

If you are learning, hopefully these will help you to. I'll maybe post some helpful links later.
