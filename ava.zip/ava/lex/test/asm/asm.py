base_path = "./base"
output_path = "./src"

keywords = [
    ("mov", "Mov"), ("int", "Int"), ("syscall", "Syscall"), ("ret", "Ret")
]

symbols = [
    (",", "Comma"), (":", "Colon"), (".", "Dot")
]

single_comments = [ ";" ]

multi_comments = []
