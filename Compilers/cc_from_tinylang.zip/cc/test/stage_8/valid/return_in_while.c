int main() {
    while (1) {
        return 2;
    }
}