// This tests iterating through a 3D array
#include <cstdio>
#include <Kokkos_Core.hpp>

const unsigned int ROWS = 4;
const unsigned int COLS = 6;
const unsigned int COUNT = 3;

int main (int argc, char* argv[]) {

  int num1[ROWS][COUNT][COLS];
  int *num2 = (int *)malloc(sizeof(int)*ROWS*COUNT*COLS);
  
  for (int i = 0; i<ROWS; i++) {
    for (int j = 0; j<COUNT; j++) {
      for (int k = 0; k<COLS; k++) {
        num1[i][j][k] = k;
      }
    }
  }

  Kokkos::initialize (argc, argv);

  {
    Kokkos::parallel_for("loop1", Kokkos::MDRangePolicy<Kokkos::Rank<3>>({0,0,0},{ROWS,COUNT,COLS}),
      KOKKOS_LAMBDA(const int i, const int j, const int k) {
        num2[i*COLS*j+k] = k;
    });
  }
  
  puts("NUM1");
  for (int i = 0; i<ROWS; i++) {
    for (int j = 0; j<COUNT; j++) {
      for (int k = 0; k<COLS; k++) {
        printf("%d ", num1[i][j][k]);
      }
      printf(" | ");
    }
    puts("");
  }
  puts("===========================================");
  puts("NUM2");
  for (int i = 0; i<ROWS; i++) {
    for (int j = 0; j<COUNT; j++) {
      for (int k = 0; k<COLS; k++) {
        printf("%d ", num2[i*COLS*j+k]);
      }
      printf(" | ");
    }
    puts("");
  }

  Kokkos::finalize ();
  return 0;
}
