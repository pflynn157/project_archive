package main

import "fmt"
import "os"

func main() {
	if len(os.Args) == 1 {
		println("Error: Please specify a number.")
		os.Exit(1)
	}
	
	fmt.Println("Your number is: ", os.Args[1])
}
