#!/bin/bash
mkdir -p /usr/local/share/symbolc/lib
cp ./*.sym /usr/local/share/symbolc/lib
