// Copyright 2017 Patrick Flynn
//
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, 
//	this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, this 
//	list of conditions and the following disclaimer in the documentation and/or 
//	other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors may 
//	be used to endorse or promote products derived from this software 
//	without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#include <QFile>
#include <QTextStream>
#include <QString>

#include "key_parser.hh"
#include "file_parser.hh"

using namespace CppLib;

KeyParser::KeyParser(QString file, bool preserveWhitespace = false) {
    fileName = file;
    pWhitespace = preserveWhitespace;
    content = FileParser::fileContent(fileName);
    if (preserveWhitespace==false) {
        for (int i = 0; i<content->size(); i++) {
            QString str = QString(content->at(i)).trimmed();
            content->replace(i,str);
        }
    }
}

KeyParser::KeyParser(QString file) : KeyParser(file,false) { }

void KeyParser::write() {
    QFile file(fileName);
    if (file.open(QFile::ReadWrite)) {
        QTextStream writer(&file);
        for (int i = 0; i<content->size(); i++) {
            writer << content->at(i)+"\n";
        }
        writer << "\n";
        file.close();
    }
}

void KeyParser::addKey(QString keyName, QString keyContent) {
    if (!keyExists(keyName)) {
        QString str = keyName;
        str+="=";
        content->push_back(str);
    }
    editKey(keyName,keyContent);
}

void KeyParser::editKey(QString keyName, QString keyContent) {
    if (!keyExists(keyName)) {
        addKey(keyName,keyContent);
    }
    for (int i = 0; i<content->size(); i++) {
        QString current = content->at(i);
        if (firstHalf(current)==keyName) {
            current=keyName+"="+keyContent;
            content->replace(i,current);
        }
    }
}

void KeyParser::deleteKey(QString keyName) {
    if (!keyExists((keyName))) {
        return;
    }
    for (int i = 0; i<content->size(); i++) {
        if (firstHalf(content->at(i))==keyName) {
            content->removeAt(i);
        }
    }
}

QString KeyParser::value(QString keyName) {
    if (keyExists(keyName)) {
        for (int i = 0; i<content->size(); i++) {
            QString str = content->at(i);
            if (firstHalf(str)==keyName) {
                return secondHalf(str);
            }
        }
    } else {
        return "";
    }
}

QStringList *KeyParser::allKeys() {
    QStringList *keys = new QStringList;
    for (int i = 0; i<content->size(); i++) {
        keys->push_back(firstHalf(content->at(i)));
    }
    return keys;
}

bool KeyParser::keyExists(QString keyName) {
    bool found = false;
    QStringList *all = allKeys();
    for (int i = 0; i<all->length(); i++) {
        if (firstHalf(all->at(i))==keyName) {
            found = true;
        }
    }
    return found;
}

QString KeyParser::firstHalf(QString line) {
    QString str = "";
    for (int i = 0; i<line.length(); i++) {
        if (line.at(i)=='=') {
            break;
        }
        str+=line.at(i);
    }
    return str;
}

QString KeyParser::secondHalf(QString line) {
    QString str = "";
    for (int i = 0; i<line.length(); i++) {
        if (line.at(i)=='=') {
            for (int j = i+1; j<line.length(); j++) {
                str+=line.at(j);
            }
        }
    }
    return str;
}
