from socket import *

macAddr = "B8:27:EB:89:61:0F"
port = 3

socketd = socket(AF_BLUETOOTH, SOCK_STREAM, BTPROTO_RFCOMM)
socketd.connect((macAddr, port))

while 1:
	text = input()
	if text == "quit":
		break
	socketd.send(bytes(text, 'UTF-8'))

#commands = [
#	"INC THR 50",
#	"PAUSE 3"
#	"NTRL THR"
#]

#socketd.send(bytes("SETUP", 'UTF-8'))
#input()
#
#for ln in commands:
#	socketd.send(bytes(ln, 'UTF-8'))
	
socketd.close()
