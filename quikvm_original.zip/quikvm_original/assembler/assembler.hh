#pragma once

void build(const char *path);
