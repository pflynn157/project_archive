#include <iostream>
#include <string>
#include <climits>

#include "type.hh"

int main() {
	std::cout << "To simply get type, enter a value." << std::endl;
	std::cout << "To declare a variable and get type, enter <var name>=<value>" << std::endl;
	std::cout << "Do not use spaces except in value name." << std::endl << std::endl;
	
	std::cout << "INT MAX: " << INT_MAX << std::endl;
	std::cout << std::endl;
	
	for (;;) {
		std::cout << "> ";
		std::string ln = "";
		
		std::getline(std::cin, ln);
		auto type = inferType(ln);
		
		if (ln == "exit") {
			break;
		}
		
		switch (type) {
			case DataType::INT: std::cout << "Integer!" << std::endl; break;
			case DataType::DEC: std::cout << "Decimal!" << std::endl; break;
			case DataType::BOOL: std::cout << "Boolean!" << std::endl; break;
			case DataType::CHAR: std::cout << "Char!" << std::endl; break;
			case DataType::STR: std::cout << "String!" << std::endl; break;
			case DataType::NONE:
			default: std::cout << "Unknown type!" << std::endl;
		}
	}
	
	return 0;
}
