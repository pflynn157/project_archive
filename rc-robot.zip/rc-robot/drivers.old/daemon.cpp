#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "daemon.hh"

void sleep(int sec) {
	sec *= 1000000;
	usleep(sec);
}

void start_daemon() {
	pid_t pid;
	pid = fork();
	
	//An error occurred, so exit...
	if (pid < 0) {
		exit(0);
	}
	
	//Success, let the child take over
	if (setsid() < 0) {
		exit(EXIT_FAILURE);
	}
	
	//Connect signals
	signal(SIGCHLD, SIG_IGN);
	signal(SIGHUP, SIG_IGN);
	
	//Fork for a second time
	pid = fork();
	
	//An error occurred
	if (pid < 0) {
		exit(EXIT_FAILURE);
	}
	
	//Success, let the parent process exit
	if (pid > 0) {
		exit(0);
	}
	
	umask(0);
	chdir("/");
	
	//Close all open file descriptors
	int x;
	for (x = sysconf(_SC_OPEN_MAX); x>=0; x--) {
		close(x);
	}
}
