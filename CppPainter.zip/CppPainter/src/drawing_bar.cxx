#include <QColorDialog>

#include "drawing_bar.hh"
#include "window.hh"

DrawingBar::DrawingBar()
    : rect(new QToolButton),
      ellipse(new QToolButton),
      colorChooser(new QToolButton)
{
    rect->setIcon(QPixmap(":/icons/draw-rectangle.svg"));
    ellipse->setIcon(QPixmap(":/icons/draw-ellipse.svg"));
    colorChooser->setIcon(QPixmap(":/icons/color-management.svg"));

    connect(rect,&QToolButton::clicked,this,&DrawingBar::onRectClicked);
    connect(ellipse,&QToolButton::clicked,this,&DrawingBar::onEllipseClicked);
    connect(colorChooser,&QToolButton::clicked,this,&DrawingBar::onColorChooserClicked);

    this->addWidget(rect);
    this->addWidget(ellipse);
    this->addWidget(colorChooser);
}

DrawingBar::~DrawingBar() {
    delete rect;
    delete ellipse;
}

void DrawingBar::onRectClicked() {
    Window::canvasBg->getCanvas()->setShapeType(ShapeType::RECT);
}

void DrawingBar::onEllipseClicked() {
    Window::canvasBg->getCanvas()->setShapeType(ShapeType::ELLIPSE);
}

void DrawingBar::onColorChooserClicked() {
    QColorDialog dialog;
    dialog.setWindowTitle("Choose Fill Color");
    if (dialog.exec()) {
        QColor c = dialog.currentColor();
        Window::canvasBg->getCanvas()->setCurrentColor(c);
    }
}
