// Copyright 2019 Patrick Flynn
//
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, 
//	this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, this 
//	list of conditions and the following disclaimer in the documentation and/or 
//	other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors may 
//	be used to endorse or promote products derived from this software 
//	without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#include <iostream>
#include <string>
#include <cstdlib>
#include <fstream>

#include <loader.hh>

#include "variables.hh"
#include "labels.hh"
#include "intel_i386.hh"
#include "bytecode.hh"
#include "syntax.hh"

int main(int argc, char *argv[]) {
	if (argc == 1) {
		std::cout << "Fatal error: No input file specified." << std::endl;
		std::exit(1);
	}
	
	//Get the input file and determine the output
	std::string input_file = std::string(argv[1]);
	std::string output_base = "";
	
	int start = 0;
	
	for (int i = input_file.length()-1; i>=0; i--) {
		if (input_file[i] == '/') {
			start = i;
			break;
		}
	}
	
	for (int i = start+1; i<input_file.length(); i++) {
		if (input_file[i] == '.') {
			break;
		}
		
		output_base += input_file[i];
	}
	
	//Parse our arguments to determine any options
	// 1st argument must be file
	// If no other arguments, intermediate is assummed
	std::string format = "qsm";		//QSM, elf32, bc
	bool syntax_only = false;		//If true, we only do a syntax check on the file
	
	if (argc > 2) {
		for (int i = 2; i<argc; i++) {
			std::string current = std::string(argv[i]);
			
			if (current == "-f" || current == "--format") {
				if (i+1 >= argc) {
					std::cout << "No format specified." << std::endl;
					std::cout << "Syntax: -f, --format <qsm, elf32, bc>" << std::endl;
					std::exit(1);
				}
				
				format = std::string(argv[i+1]);
				i+=2;
			} else if (current == "-sc" || current == "--syntax-check") {
				syntax_only = true;
			} else {
				std::cout << "Error: Bad CMD option" << std::endl;
				std::exit(1);
			}
		}
	}
	
	//Load file
	auto contents = load_file(input_file, false);

	//Perform syntax checks
	end_check(contents);
	cmd_check(contents);
	
	if (syntax_only) {
		std::exit(0);
	}
	
	//Generate the intermediate file
	contents = handle_vars(contents);
	contents = handle_labels(contents);

	String s;
	s.str = "$";
	contents.push_back(s);
	
	//Generate the proper output format
	if (format == "qsm") {
		std::string qsm_file = output_base + ".qsm";
		std::ofstream writer(qsm_file.c_str());
		
		for (auto s : contents) {
			writer << s.str << std::endl;
		}
		
		writer.close();
	} else if (format == "elf32") {
		i386_assemble(contents, output_base);
	} else if (format == "bc") {
		bytecode_assemble(contents, output_base);
	} else if (format == "vv") {
		for (auto s : contents) {
			std::cout << "DB: " << s.str << std::endl;
		}
	}

	return 0;
}
