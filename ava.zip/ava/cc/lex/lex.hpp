#pragma once

#include <fstream>
#include <string>
#include <stack>

#include <ava/lex.hpp>

// Represents a token
enum TokenType {
    EmptyToken,
    Eof,
    
    Auto,
    Break,
    Case,
    Char,
    Const,
    Continue,
    Default,
    Do,
    Double,
    Else,
    Enum,
    Extern,
    Float,
    For,
    Goto,
    If,
    Int,
    Long,
    Register,
    Return,
    Short,
    Signed,
    Sizeof,
    Static,
    Struct,
    Switch,
    Typedef,
    Union,
    Unsigned,
    Void,
    Volatile,
    While,
    SemiColon,
    Assign,
    Eq,
    LParen,
    RParen,
    LCBrace,
    RCBrace,
    Add,
    AddEq,
    Inc,
    Sub,
    SubEq,
    Dec,
    Arrow,
    Mul,
    MulEq,
    Div,
    DivEq,
    Mod,
    ModEq,
    And,
    AndEq,
    LAnd,
    Or,
    OrEq,
    LOr,
    Xor,
    XorEq,
    Lsh,
    LshEq,
    Lt,
    Le,
    Rsh,
    RshEq,
    Gt,
    Ge,
    Ne,
    Not,
    Colon,
    QMark,
    Dot,
    LBracket,
    RBracket,
    
    // Literals
    Id,
    String,
    CharL,
    Int32
};

// The main lexical analysis class
class Scanner : public BaseScanner {
public:
    explicit Scanner(std::string input);
    ~Scanner();
    
    void rewind(Token token) override;
    Token getNext() override;
    
    std::string getRawBuffer() override;
    int getLine() override { return currentLine; }
    
    bool isEof() override { return reader.eof(); }
    bool isError() override { return error; }
private:
    std::stack<Token> token_stack;
    
    // Control variables for the scanner
    std::string rawBuffer = "";
    std::string buffer = "";
    bool inQuote = false;
    int currentLine = 1;
    bool skipNextLineCount = false;
    
    // Functions
    bool isSymbol(char c);
    TokenType getKeyword();
    TokenType getSymbol(char c);
    bool isInt();
    bool isHex();
};

