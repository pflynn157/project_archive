// Copyright 2019 Patrick Flynn
//
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, 
//	this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, this 
//	list of conditions and the following disclaimer in the documentation and/or 
//	other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors may 
//	be used to endorse or promote products derived from this software 
//	without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#include <iostream>
#include <cstdlib>
#include <fstream>

#include "intel_i386.hh"
#include "variables.hh"

#include <strutils.hh>
#include <types.hh>

//std::vector<Var> vars;

//Builds the .data section
std::vector<std::string> i386_build_data(std::vector<std::string> contents) {
	auto tmp = contents;
	contents.clear();
	contents.push_back("section .data");
	
	//TODO: See if we can come up with something nicer
	bool write_int = false;
	bool write_dec = false;
	bool write_char = false;
	
	for (auto s : tmp) {
		std::string name = get_first(s, ' ');
		std::string ln = "\t" + name;
		std::string second = get_second(s, ' ');
		
		std::string type = get_first(second, ' ');
		std::string val = get_second(second, ' ');
		
		/*Var v;
		v.name = name;
		v.val = val;*/
		
		if (val == "true") {
			val = "1";
		} else if (val == "false") {
			val = "0";
		}
		
		if (type == "int") {
			ln += " dd ";
			write_int = true;
			//v.type = DataType::INT;
		} else if (type == "dec") {
			ln += " dq ";
			write_dec = true;
			//v.type = DataType::DEC;
		} else if (type == "char") {
			ln += " db ";
			write_char = true;
			//v.type = DataType::CHAR;
		} else if (type == "str") {
			ln += " db ";
			val += ",10,0";
			//v.type = DataType::STR;
		} else {
			std::cout << "Error: Unknown type" << std::endl;
			std::exit(1);
		}
		
		ln += val;
		contents.push_back(ln);
		//vars.push_back(v);
	}
	
	if (write_int) {
		contents.push_back("\tpfd db \'%d\',10,0");
	}
	
	if (write_dec) {
		contents.push_back("\tpff db \'%f\',10,0");
	}
	
	if (write_char) {
		contents.push_back("\tpfc db \'%c\',10,0");
	}
	
	return contents;
}

//Builds the .text section
std::vector<std::string> i386_build_text(std::vector<std::string> contents) {
	auto tmp = contents;
	contents.clear();
	
	//Set things up
	contents.push_back("section .text");
	contents.push_back("\tglobal _start");
	contents.push_back("\textern printf");
	
	bool in_main = false;
	
	//Iterate through our contents
	for (auto s : tmp) {
		auto cmd = get_first(s, ' ');
		auto arg = get_second(s, ' ');
		
		//Handle println
		if (cmd == "println") {
			//Find our variable
			Var v;
			for (auto cv : vars) {
				if (cv.name == arg) {
					v = cv;
					break;
				}
			}
			
			//Push according to data type
			std::string ln = "";
			
			if (v.type == DataType::INT) {
				ln = "\tpush dword [" + arg + "]\n";
				ln += "\tpush dword pfd";
			} else if (v.type == DataType::DEC) {
				ln = "\tpush dword [" + arg + "+4]\n";
				ln += "\tpush dword [" + arg + "]\n";
				ln += "\tpush dword pff";
			} else if (v.type == DataType::CHAR) {
				ln = "\tpush dword [" + arg + "]\n";
				ln += "\tpush dword pfc";
			} else if (v.type == DataType::STR) {
				ln = "\tpush dword " + arg;	
			}
		
			ln += "\n\tcall printf";
			
			if (!in_main) {
				ln = "\tpush eax\n" + ln;
				
				if (v.type == DataType::INT || v.type == DataType::CHAR) {
					for (int i = 0; i<3; i++) {
						ln += "\n\tpop eax";
					}
				} else if (v.type == DataType::DEC) {
					for (int i = 0; i<4; i++) {
						ln += "\n\tpop eax";
					}
				} else {
					ln += "\n\tadd esp, 2*4";
				}
			}
			
			contents.push_back(ln);
			
		//Handle exit
		} else if (cmd == "exit") {
			continue;
			
		//Handle add
		} else if (cmd == "add") {
			arg = clr_spaces(arg);
			std::string p1 = get_first(arg, ',');
			std::string p2 = get_second(arg, ',');
			
			if (is_var(p1)) {
				p1 = "[" + p1 + "]";
			}
			
			if (is_var(p2)) {
				p2 = "[" + p2 + "]";
			}
		
			std::string ln = "\tmov eax, " + p1;
			ln += "\n\tmov ebx, " + p2;
			ln += "\n\tadd eax, ebx";
			
			contents.push_back(ln);
		
		//Handle add_store
		} else if (cmd == "add_store") {
			if (!is_var(arg)) {
				std::cout << "Error: No such variable: " << arg << std::endl;
				std::exit(1);
			}
			
			std::string ln = "\tmov [" + arg + "], eax";
			contents.push_back(ln);
		
		//Handle everything else
		} else {
			std::string ln = s;
			if (s[s.length()-1] != ':') {
				ln = "\t"+s;
			}
			contents.push_back(ln);
		}
		
		if (s == "_start:") {
			in_main = true;
		}
	}
	
	std::string ln = "\tmov eax, 1\n";
	ln += "\tmov ebx, 0\n";
	ln += "\tint 0x80\n";
	contents.push_back(ln);
	
	return contents;
}

//The main assembly calling function
void i386_assemble(std::vector<String> contents, std::string outfile) {
	std::vector<std::string> ret;
	std::vector<std::string> tmp;
	
	//Iterate through each layer and assembly each section
	int layer = 1;
	
	//TODO: Add bss section
	for (auto s : contents) {
		if (s.str == "$") {
			if (layer == 1) {
				ret = i386_build_data(tmp);
			} else if (layer == 2) {
				auto text = i386_build_text(tmp);
				ret.push_back("");
				
				for (auto s2 : text) {
					ret.push_back(s2);
				}
			}
		
			tmp.clear();
			layer++;
			continue;
		}
		
		tmp.push_back(s.str);
	}
	
	//db
	/*for (auto s : ret) {
		std::cout << "ASM: " << s << std::endl;
	}*/
	
	//Write the assembly to a file
	std::string asm_file = outfile+".asm";
	std::ofstream writer(asm_file.c_str());	

	for (auto s : ret) {
		writer << s << std::endl;
	}
	
	writer.close();
	
	//Now assemble it
	//TODO: Replace this; this is ugly
	std::string asm_cmd = "nasm -f elf "+asm_file;
	
	std::string ld_cmd = "ld -m elf_i386 \"-L/usr/lib32\" -dynamic-linker /lib/ld-linux.so.2 -s ";
	ld_cmd += outfile + ".o -o " + outfile + " -lc";
	
	std::string rm_cmd = "rm " + outfile + ".o";
	
	system(asm_cmd.c_str());
	system(ld_cmd.c_str());
	system(rm_cmd.c_str());
}
