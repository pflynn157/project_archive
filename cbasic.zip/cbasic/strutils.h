#ifndef STRUTILS_H
#define STRUTILS_H

char *trim(char *str);
char *str_first(char *str);
char *str_second(char *str);

#endif
