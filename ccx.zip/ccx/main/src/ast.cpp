#include <iostream>

#include "ast.hpp"

////
//// Debug code
////
std::string printDataType(DataType type) {
    switch (type) {
        case DataType::U8: return "u8";
        case DataType::I8: return "i8";
        case DataType::U16: return "u16";
        case DataType::I16: return "i16";
        case DataType::U32: return "u32";
        case DataType::I32: return "i32";
        case DataType::U64: return "u64";
        case DataType::I64: return "i64";
        case DataType::U128: return "u128";
        case DataType::I128: return "i128";
        case DataType::W1: return "w1";
        case DataType::W2: return "w2";
        case DataType::W4: return "w4";
        case DataType::W8: return "w8";
        case DataType::Long: return "long";
        
        default: {}
    }
    return "void";
}

bool AstExpression::isBinaryOp() {
    switch (type) {
        case AstType::Assign:
        case AstType::Add:
        case AstType::Sub:
        case AstType::Mul:
        case AstType::Div:
        case AstType::Mod:
        case AstType::And:
        case AstType::Or:
        case AstType::Xor:
        case AstType::Eq:
        case AstType::Ne:
        case AstType::Gt:
        case AstType::Lt:
        case AstType::Ge:
        case AstType::Le: return true;
        
        default: {}
    }
    return false;
}

void AstExprList::print() {
    std::cout << "[";
    for (int i = 0; i<list.size(); i++) {
        list.at(i)->print();
        if (i + 1 < list.size()) std::cout << ", ";
    }
    std::cout << "]";
}

AstBinaryOp::AstBinaryOp(AstType type) : AstExpression(type) {
    switch (type) {
        case AstType::Assign: precedence = 15; break;
        case AstType::Add: precedence = 6; break;
        case AstType::Sub: precedence = 6; break;
        case AstType::Mul: precedence = 5; break;
        case AstType::Div: precedence = 5; break;
        case AstType::Mod: precedence = 5; break;
        case AstType::And: precedence = 11; break;
        case AstType::Or: precedence = 13; break;
        case AstType::Xor: precedence = 12; break;
        case AstType::Eq: precedence = 10; break;
        case AstType::Ne: precedence = 10; break;
        case AstType::Gt: precedence = 9; break;
        case AstType::Lt: precedence = 9; break;
        case AstType::Ge: precedence = 9; break;
        case AstType::Le: precedence = 9; break;
        
        default: {}
    }
}

void AstBinaryOp::print() {
    std::cout << "(";
    lval->print();
    
    switch (type) {
        case AstType::Assign: std::cout << ":= "; break;
        case AstType::Add: std::cout << " + "; break;
        case AstType::Sub: std::cout << " - "; break;
        case AstType::Mul: std::cout << " * "; break;
        case AstType::Div: std::cout << " / "; break;
        case AstType::Mod: std::cout << " % "; break;
        case AstType::And: std::cout << " & "; break;
        case AstType::Or: std::cout << " | "; break;
        case AstType::Xor: std::cout << " ^ " ; break;
        case AstType::Eq: std::cout << " == "; break;
        case AstType::Ne: std::cout << " != "; break;
        case AstType::Gt: std::cout << " > "; break;
        case AstType::Lt: std::cout << " < "; break;
        case AstType::Ge: std::cout << " >= "; break;
        case AstType::Le: std::cout << " <= "; break;
        
        default: {}
    }
    
    rval->print();
    std::cout << ")";
}

void AstStatement::print() {
    switch (type) {
        case AstType::Return: std::cout << "Return "; break;
        case AstType::VarDec: std::cout << "VarDec "; break;
        case AstType::VarAssign: std::cout << "VarAssign "; break;
        case AstType::Syscall: std::cout << "SYSCALL "; break;
        case AstType::ArrayAssign: std::cout << "ArrayAssign "; break;
        case AstType::Break: std::cout << "Break "; break;
        case AstType::Continue: std::cout << "Continue "; break;
        
        default: {}
    }
    
    std::cout << printDataType(dataType) << " ";
    
    if (expr) expr->print();
    
    std::cout << ";";
}

AstBlockStmt::~AstBlockStmt() {
    if (block) delete block;
}

void AstBlockStmt::print() {
    switch (type) {
        case AstType::While: std::cout << "While "; break;
        
        default: {}
    }
    
    if (expr) expr->print();
    
    std::cout << " {" << std::endl;
    block->print(8);
    for (int i = 0; i<4; i++) std::cout << " ";
    std::cout << "}";
}

AstForStmt::~AstForStmt() {
    if (init) delete init;
    if (cmp) delete cmp;
    if (inc) delete inc;
}

void AstForStmt::print() {
    std::cout << "FOR ";
    init->print();
    std::cout << "; ";
    cmp->print();
    std::cout << "; ";
    inc->print();
    std::cout << "{ " << std::endl;
    
    block->print(8);
    for (int i = 0; i<4; i++) std::cout << " ";
    std::cout << "}";
}

AstCondStmt::~AstCondStmt() {
    for (auto stmt : branches) delete stmt;
}

void AstCondStmt::print() {
    switch (type) {
        case AstType::If: std::cout << "IF "; break;
        case AstType::Elif: std::cout << "Elif "; break;
        case AstType::Else: std::cout << "Else "; break;
        
        default: {}
    }
    
    if (expr) expr->print();
    
    std::cout << " {" << std::endl;
    block->print(8);
    for (int i = 0; i<4; i++) std::cout << " ";
    std::cout << "}";
    for (auto br : branches) br->print();
}

void AstArrayDec::print() {
    std::cout << "ARRAY " << printDataType(dataType) << " " << name;
    if (stackArray) std::cout << "[";
    else std::cout << "(";
    if (expr) expr->print();
    if (stackArray) std::cout << "]";
    else std::cout << ")";
}

AstBlock::~AstBlock() {
    for (auto stmt : block) {
        if (stmt) delete stmt;
    }
}

void AstBlock::print(int indent) {
    for (auto stmt : block) {
        for (int i = 0; i<indent; i++) std::cout << " ";
        stmt->print();
        std::cout << std::endl;
    }
}

void AstFunction::print() {
    std::cout << "FUNC " << name << "() : " << printDataType(dataType) << " {" << std::endl;
    block->print();
    std::cout << "}" << std::endl << std::endl;
}

void AstFile::print() {
    std::cout << "FILE: " << name << std::endl;
    std::cout << std::endl;
    
    for (auto func : functions) func->print();
}

