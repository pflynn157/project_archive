#pragma once

typedef struct
{
    char **items;
    int size;
    int max_size;
} StrList;

StrList *str_list_create(int size);
StrList *str_list_create_empty();
void str_list_add(StrList *list, const char *item);
void str_list_display(StrList *list);
