module I386.I386Math(i386IMathRR) where

import System.IO

import Ltac
import I386.I386Registers

-- Handles integer math
intMathInstr mathType
    | mathType == "mul" = "imul"
    | mathType == "mod" = "div"
    | otherwise = mathType

i386IMathRR ln writer = do
    let mathType = arg1 ln
    let instr = intMathInstr mathType
    let reg1 = i386IntReg (read (arg2 ln) :: Int)
    let reg2 = i386IntReg (read (arg3 ln) :: Int)
    hPutStrLn writer ("\t" ++ instr ++ " " ++ reg1 ++ ", " ++ reg2)
