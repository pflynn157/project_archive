#include <stdio.h>

#include "ast.h"
#include "debug.h"

extern void parse(const char *path, Ast *tree);

int main(int argc, char **argv)
{
    Ast *ast = create_ast("mod1");
    parse("./test.c", ast);
    
    print_ast(ast);
    
    return 0;
}

