// Very simple test of kokkos that uses a functor.  In a nutshell,
// given the potential for different compilation units, kitsune does
// not support this construct and it should fall back to the standard
// C++ code gen paths. 
#include <cstdio>
#include <cstdlib>
#include <Kokkos_Core.hpp>

const unsigned int NUM = 5;

int main (int argc, char* argv[]) {
  srand(time(NULL));

  Kokkos::initialize (argc, argv);
  
  Kokkos::View<int **> num1("num1", NUM, NUM);
  Kokkos::View<int **> num2("num2", NUM, NUM);
  Kokkos::View<int **> result("result1", NUM, NUM);
  
  for (int i = 0; i<NUM; i++) {
    for (int j = 0; j<NUM; j++) {
        num1(i, j) = rand() % 101;
        num2(i, j) = rand() % 51;
        result(i, j) = 0;
    }
  }

  {
    Kokkos::parallel_for("loop1", Kokkos::MDRangePolicy<Kokkos::Rank<2>>({0,0},{NUM,NUM}),
      KOKKOS_LAMBDA(const int i, const int j) {
        result(i, j) = num1(i, j) * num2(i, j);
    });
  }
  
  for (int i = 0; i<5; i++) {
    printf("(%d / %d = %d) ", num1(i, 0), num2(i, 0), result(i, 0));
  }
  puts("");

  //Kokkos::finalize ();
  return 0;
}
