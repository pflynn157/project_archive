#include <stdint.h>

#include <io.h>
#include <string.h>
#include <fs.h>

int verify(FILE input) {
    uint16_t signature = 0;
    read(input, &signature, sizeof(uint16_t));
    
    if (signature != 0xA1A2) {
        print("%d\n", signature);
        println("Invalid signature.");
        return 0;
    }

    return 1;
}

int main(int argc, char *argv[]) {
    if (argc == 1) {
        println("Fatal: No input specified.");
        return 1;
    }
    
    char *input = argv[1];
    print("Reading: %s\n", input);
    
    FILE file = open(input);
    if (file < 0) {
        println("Fatal: Unable to open file.");
        return 1;
    }
    
    if (!verify(file)) {
        println("Fatal: File verification failed.");
        return 1;
    }
    
    close(file);
    
    return argc;
}

