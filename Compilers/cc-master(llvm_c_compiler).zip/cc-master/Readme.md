## cc

This is the start of a simple C compiler. I'm doing this project mainly to learn LLVM and improve my C skills, so don't expect too much from this.

### Structure

The parser is written using Flex and Bison. The backend uses LLVM. The AST, debugging utilities, and everything else that glues these two parts together are my work. The code should still be really easy to understand. At the time of writing, the AST is in `ast.c`; the `compiler.c` file creates and invokes the LLVM environment and calls the assembler and linker; the `backend.c` is in charge of translating the AST to LLVM; the `debug.c` unwrites the AST and prints it to the screen.

### Status

Currently, this compiler does very, very little. The actual AST is mostly complete; as far as parsing goes, most variable expressions and statements are working. The LLVM portion can translate a few smaller variable expressions, but that's currently it.

I published this since all the core infastructure is in; however, I'm probably going to pause development for a little bit because I want to explore a few other areas.
