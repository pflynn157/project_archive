
## Ida Examples

This is a collection of example programs for my Ida programming language. They serve two purposes: First, as an example of what the language can currently do. Second, I am developing them to test the language itself and the compiler.

You need to build and install the compiler and standard library, which is in a separate repository. The build script assumes everything is installed. I will eventually replace with a Makefile or something better, but for now, the script is sufficient.

The coreutils binaries are renamed (so echo.ls is built as echo2); that way, you can add the build directory to the PATH if you so wish.

These programs only work on Linux for x86-64.

