## Examples

This folder contains examples for extcc-specific languages and functions. Tests for existing and extcc functions can be found in the test folder.

The LLVM folder contains example output from the corresponding LTAC-Assembly files in the test folder.
