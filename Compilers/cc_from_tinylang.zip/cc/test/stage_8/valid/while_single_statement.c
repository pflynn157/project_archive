int main() {
    int a = 0;

    while (a < 5)
        a = a + 2;

    return a;
}