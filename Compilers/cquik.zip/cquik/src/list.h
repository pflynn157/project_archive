#pragma once

#include <ast.h>

void stack_push(AstLinkedList *stack, AstNode *node);
AstNode *stack_top(AstLinkedList *stack);
void stack_pop(AstLinkedList *stack);

void list_add_end(AstLinkedList *list, AstNode *node);
void list_copy(AstLinkedList *list1, AstLinkedList *list2);
