#include <iostream>

#include <unparser/Unparser.hpp>
#include <ast/ast.hpp>

void unparse(AstTree *file, Unparser lang) {
    switch (lang) {
        case Unparser::Cpp: {
            std::cout << "Unparsing to C++..." << std::endl;
            unparse_cpp(file);
        } break;
        
        case Unparser::Ada: {
            std::cout << "Unparsing to Ada..." << std::endl;
            unparse_ada(file);
        } break;
        
        default: {
            std::cout << "Warning: Unsupported unparser language." << std::endl;
        }
    }
}

