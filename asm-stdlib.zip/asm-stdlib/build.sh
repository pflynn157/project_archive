#!/bin/bash
if [ ! -d ./build ] ; then
	mkdir build
fi

as lib/io.asm -o build/io.o
as lib/string.asm -o build/string.o
as lib/alloc.asm -o build/alloc.o

as bin/mkdir.asm -o build/mkdir.o
as bin/cmd-arg.asm -o build/cmd-arg.o
as bin/alloc_test.asm -o build/alloc_test.o

cd build

LIB="io.o string.o alloc.o"

ld -m elf_x86_64 mkdir.o $LIB -o mkdir
ld -m elf_x86_64 cmd-arg.o $LIB -o cmd-arg
ld -m elf_x86_64 alloc_test.o $LIB -o alloc_test

cd ..
