int main() {
    int x = 20;
    return x + 10;
}
