#include <QOpenGLWidget>
#include <QMouseEvent>

#include "canvas.hh"

Canvas::Canvas() {
    path = "";
    this->setFixedSize(600,500);
    this->setStyleSheet("background-color:white;");
}

void Canvas::save() {
    if (isUntitled()) {
        return;
    }

    QPixmap p = this->grab();
    QOpenGLWidget *glWidget  = this->findChild<QOpenGLWidget*>();
    if(glWidget){
        QPainter painter(&p);
        QPoint d = glWidget->mapToGlobal(QPoint())-this->mapToGlobal(QPoint());
        painter.setCompositionMode(QPainter::CompositionMode_SourceAtop);
        painter.drawImage(d, glWidget->grabFramebuffer());
        painter.end();
    }
    p.save(path,"PNG");
}

void Canvas::setPath(QString p) {
    path = p;
}

bool Canvas::isUntitled() {
    if (path=="") {
        return true;
    }
    return false;
}

void Canvas::setShapeType(ShapeType type) {
    shape = type;
}

void Canvas::setCurrentColor(QColor color) {
    currentColor = color;
}

void Canvas::setImage(QImage img) {
    bg = img;
}

void Canvas::paintEvent(QPaintEvent *) {
    QPainter painter(this);

    painter.drawImage(0,0,bg);

    if (drawInProg) {
        painter.setBrush(Qt::white);

        if (shape==ShapeType::RECT) {
            painter.drawRect(inProg);
        } else if (shape==ShapeType::ELLIPSE) {
            painter.drawEllipse(inProg);
        }
    }

    for (ShapeData d : rects) {
        painter.setBrush(d.color);
        painter.drawRect(d.r);
    }

    for (ShapeData d : ellipses) {
        painter.setBrush(d.color);
        painter.drawEllipse(d.r);
    }
}

void Canvas::mousePressEvent(QMouseEvent *event) {
    if (event->button()==Qt::LeftButton) {
        x1 = event->x();
        y1 = event->y();
        drawInProg = true;
    }
}

void Canvas::mouseMoveEvent(QMouseEvent *event) {
    if (drawInProg) {
        int w = event->x()-x1;
        int h = event->y()-y1;
        QRect r(x1,y1,w,h);
        inProg = r;
        this->repaint();
    }
}

void Canvas::mouseReleaseEvent(QMouseEvent *event) {
    if (event->button()==Qt::LeftButton) {
        int w = event->x()-x1;
        int h = event->y()-y1;

        ShapeData d;
        d.color = currentColor;

        QRect r(x1,y1,w,h);
        d.r = r;

        if (shape==ShapeType::RECT) {
            rects << d;
        } else if (shape==ShapeType::ELLIPSE) {
            ellipses << d;
        }

        drawInProg = false;
        this->repaint();
    }
}
