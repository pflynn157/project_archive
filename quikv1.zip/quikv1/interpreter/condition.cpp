// Copyright 2019 Patrick Flynn
//
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, 
//	this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, this 
//	list of conditions and the following disclaimer in the documentation and/or 
//	other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors may 
//	be used to endorse or promote products derived from this software 
//	without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#include <string>
#include <iostream>

#include "condition.hh"
#include "strutils.hh"
#include "types.hh"
#include "vars.hh"
#include "interpreter.hh"
#include "loop.hh"

//A universal comparing function
template<typename T>
bool compare(T p1, T p2, std::string op) {
	if (op == "==") {
		return (p1 == p2);
	} else if (op == "!=") {
		return (p1 != p2);
	} else if (op == ">") {
		return (p1 > p2);
	} else if (op == "<") {
		return (p1 < p2);
	} else if (op == ">=") {
		return (p1 >= p2);
	} else if (op == "<=") {
		return (p1 <= p2);
	}
	return false;
}

//Evaluates a conditional statement to true or false
bool evaluate(std::string ln, bool global) {
	//First, break up the string
	std::string part1, part2, op = "";
	bool found = false;
	
	for (int i = 0; i<ln.length(); i++) {
		char c = ln[i];
		if (c == '=' || c == '!' || c == '>'
			|| c == '<') {
			op += c;
			
			char c2 = ln[i+1];
			if (c2 == '=') {
				op += c2;
				i++;
			}
			
			found = true;
			continue;
		}
		
		if (found) {
			part2 += c;
		} else {
			part1 += c;
		}
	}
	
	//Check to see if either part is a variable
	if (is_var(part1)) {
		part1 = var_val(part1);
	}
	
	if (is_var(part2)) {
		part2 = var_val(part2);
	}
	
	//If we have just part 1, then we have an infinite loop
	//If that's the case, just return true
	if (op == "" && part2 == "") {
		return true;
	}
	
	//Infer the datatype of each part
	DataType type1 = get_datatype(part1);
	DataType type2 = get_datatype(part2);
	
	//Compare strings
	if (type1 == DataType::STR || type2 == DataType::STR) {
		return compare<std::string>(part1, part2, op);
	}
	
	//Compare integers
	if (type1 == DataType::INT) {
		int p1 = std::stoi(part1);
		int p2 = 0;
	
		if (type2 == DataType::BOOL) {
			if (part2 == "true") p2 = 1;
			else if (part2 == "false") p2 = 0;
		} else if (type2 == DataType::CHAR) {
			char c = part2[0];
			p2 = (int)c;
		} else {
			p2 = std::stoi(part2);
		}
		
		return compare<int>(p1, p2, op);
	}
	
	//Compare decimals
	if (type1 == DataType::DEC) {
		double p1 = std::stod(part1);
		double p2 = 0;
		
		if (type2 == DataType::BOOL) {
			if (part2 == "true") p2 = 1;
			else if (part2 == "false") p2 = 0;
		} else if (type2 == DataType::CHAR) {
			char c = part2[0];
			p2 = (double)c;
		} else {
			p2 = std::stod(part2);
		}
		
		return compare<double>(p1, p2, op);
	}
	
	//Compare booleans
	if (type1 == DataType::BOOL) {
		bool p1 = true;
		bool p2 = true;
		
		if (part1 == "false") {
			p1 = false;
		}
		
		if (part2 != "") {
			if (type2 == DataType::BOOL) {
				if (part2 == "false") {
					p2 = false;
				}
			} else {
				if (type2 == DataType::CHAR) {
					char c = part2[0];
					p2 = (bool)c;
				} else {
					int c = std::stoi(part2);
					p2 = (bool)c;
				}
			}
		}
	
		return compare<bool>(p1, p2, op);
	}
	
	//Compare chars
	if (type1 == DataType::CHAR) {
		part1 = rm_first_last(part1);
		part2 = rm_first_last(part2);
		char p1 = part1[0];
		char p2 = part2[0];
		
		if (type2 == DataType::INT) {
			int c = std::stoi(part2);
			p2 = (char)c;
		} else if (type2 == DataType::DEC) {
			double c = std::stod(part2);
			p2 = (char)c;
		} else if (type2 == DataType::BOOL) {
			if (part2 == "false") {
				p2 = 0;
			} else {
				p2 = 1;
			}
		}
	
		return compare<char>(p1, p2, op);
	}
	
	return false;
}

//Parses and runs a conditional statement
void parse_condition(std::vector<String> body, bool global) {
	//First, break up the statement
	std::vector<Statement> statements;
	Statement current;
	int layer = 1;
	bool found_first = false;
	
	for (String str : body) {
		std::string sv = str.str;
		std::string cmd = get_first(sv, ' ');
		
		if (cmd == "if") {
			if (found_first) {
				layer++;
				current.content.push_back(str);
			} else {
				found_first = true;
				std::string header = get_second(sv, ' ');
				header = rm_first_last(header);
				header = clr_spaces(header);
				
				current.header = header;
			}
		} else if (cmd == "elif") {
			if (layer == 1) {
				statements.push_back(current);
				current.content.clear();
				
				std::string header = get_second(sv, ' ');
				header = rm_first_last(header);
				header = clr_spaces(header);
				
				current.header = header;
			} else {
				current.content.push_back(str);
			}
		} else if (cmd == "else") {
			if (layer == 1) {
				statements.push_back(current);
				current.content.clear();

				current.header = "";
			} else {
				current.content.push_back(str);
			}
		} else if (cmd == "end") {
			layer--;
			current.content.push_back(str);
		} else {
			current.content.push_back(str);
		}
	}
	
	statements.push_back(current);
	
	//Now iterate through the statements until one evaluates to true
	for (Statement s : statements) {
		if (s.header == "") {
			for (String str : s.content) {
				interpret(str, global);
			}
			return;
		} else {
			if (evaluate(s.header, global)) {
				for (String str : s.content) {
					interpret(str, global);
				}
				return;
			}
		}
	}
}
