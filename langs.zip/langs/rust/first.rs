use std::io;

fn main() {
	println!("What is your name?");
	
	let mut name = String::new();
	io::stdin().read_line(&mut name).expect("Invalid input.");
	name = name.trim().to_string();
	
	//Reverse the string
	let mut len = name.len();
	let mut reversed = String::new();
	
	while len > 0 {
		let c = name.chars().nth(len-1).unwrap().to_string();
		reversed.push_str(&c);
		len -= 1;
	}
	
	println!("Hello, {}!", name);
	println!("Reversed: {}!", reversed);
}
