#pragma once

// Represents node type
typedef enum
{
    None,

    Scope,

    FuncDec,
    While,
    IfBlock,
    ElifBlock,
    ElseBlock,

    FuncCall,
    Cond,
    Return,

    Var,

    Int,
    String
} AstType;

typedef enum
{
    T_Void,
    T_Int,
    T_Float,
    T_String
} DataType;

struct AstList;

// Represents an AST node
typedef struct
{
    AstType type;
    struct AstList *children;

    const char *str_val1;
    int int_val1;
    int int_val2;
} AstNode;

// Holds a collection of AstNode's
struct AstList
{
    AstNode **elements;
    int loco;
    int size;
};

// Ast list functions
struct AstList *create_list();
void ast_list_add_element(struct AstList *list, AstNode *node);

// AST functions
AstNode *ast_create_node(AstType type);
AstNode *ast_create_func(const char *name, DataType type);
AstNode *ast_create_func_call(const char *name);
AstNode *ast_create_var(const char *name, DataType type);
AstNode *ast_create_int(int i);
AstNode *ast_create_string(const char *str);
void ast_add_child(AstNode *parent, AstNode *child);

// Debug functions
void print_datatype(DataType type);
void ast_print(AstNode *tree, int indent);
