#include <iostream>

#include "writer.hh"

int main(int argc, char *argv[]) {
	BinWriter writer("out.bin");
	
	//Start address: 2^22 + 120
	//The header
	writer.write_int(0x464c457F);		//Magic number
	writer.write_byte(0x02);			//64-bit
	writer.write_byte(0x01);			//LSB encoding
	writer.write_byte(0x01);			//ELF version 1
	writer.write_byte(0x00);			//OS ABI- 3 for Linux
	writer.write_byte(0);				//ABI version
	
	for (int i = 0; i<7; i++)
		writer.write_byte(0);
	
	writer.write_short(0x02);			//Object type- 2 is executable
	writer.write_short(0x3e);			//Architecture type
	writer.write_int(1);				//ELF version
	
	writer.write_int64(4194430);		//Start address to execute
	writer.write_int64(64);				//Program header start
	
	writer.write_int64(0);				//Section header table offset
	writer.write_int(0);
	writer.write_short(64);				//ELF header size
	writer.write_short(56);				//Program header size
	writer.write_short(1);				//1 program header
	
	//Sections
	writer.write_short(0);
	writer.write_short(0);
	writer.write_short(0);
	
//==================================================
	//The program header
	//First 2 fields-> 4-bytes; rest are 8-byte
	writer.write_int(1);
	writer.write_int(5);
	
	writer.write_int64(126);		//The index of the ELF where the segment starts
	
	writer.write_int64(4194430);		//Virtual program start- byte 120
	writer.write_int64(0);				//Physical address- ignore
	
	writer.write_int64(132);			//Size of file image in bytes
	writer.write_int64(132);			//Size of the segment in memory);
	writer.write_int64(1);
	
//===================================================
	//Some data
	writer.write_str("Hello\n");

	//The executable code
	//Print string and exit with code 5
	//mov eax, 4
	writer.write_byte(0xB8);
	writer.write_int(4);
	
	//mov ebx, 1
	writer.write_byte(0xBB);
	writer.write_int(1);
	
	//mov ecx, 120 (address of our string)
	writer.write_byte(0xB9);
	writer.write_int(4194424);
	
	//mov edx, 5
	writer.write_byte(0xBA);
	writer.write_int(6);
	
	//int 0x80
	writer.write_byte(0xCD);
	writer.write_byte(0x80);
	
	//=========================================
	//mov eax, 1
	writer.write_byte(0xB8);
	writer.write_int(1);
	
	//mov ebx, 5
	writer.write_byte(0xBB);
	writer.write_int(5);
	
	//int 0x80
	writer.write_byte(0xCD);
	writer.write_byte(0x80);
	

	writer.write();
	return 0;
}
