#include <stdio.h>
#include <immintrin.h>

int main() {
    // The mask
    int mask[8] = { 0, 0, -1, -1, 0, 0, -1, -1 };
    int *mask_full = malloc(sizeof(int)*32);
    for (int i = 0; i<32; i+=8) {
        for (int j = 0; j<8; j++) mask_full[i+j] = mask[j];
    }
    
    // The elements
    float *elements = malloc(sizeof(float)*32);
    for (int i = 0; i<32; i++) elements[i] = (float)i;
    
    float *elements2 = malloc(sizeof(float)*32);
    for (int i = 0; i<32; i++) elements2[i] = 0;
    
    // Do the fun
    for (int i = 0; i<32; i+=16) {
        __m256i m1 = _mm256_loadu_si256((__m256i *)&mask_full[i]);
        __m256i m2 = _mm256_loadu_si256((__m256i *)&mask_full[i+8]);
        
        __m256 vec1 = _mm256_maskload_ps(&elements[i], m1);
        __m256 vec2 = _mm256_maskload_ps(&elements[i+8], m2);
        
        __m512 vec = _mm512_setzero_ps();
        vec = _mm512_insertf32x8(vec, vec1, 0);
        vec = _mm512_insertf32x8(vec, vec2, 1);
        
        _mm512_storeu_ps(&elements[i], vec);
        
        /*_mm256_maskstore_ps(&elements2[i], m1, vec1);
        _mm256_maskstore_ps(&elements2[i+8], m2, vec2);*/
    }
    
    // Print
    for (int i = 0; i<32; i++) {
        printf("%.2f ", elements2[i]);
    }
    puts("");
    
    return 0;
}
