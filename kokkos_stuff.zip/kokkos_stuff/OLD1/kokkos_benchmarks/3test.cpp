// Very simple test of kokkos that uses a functor.  In a nutshell,
// given the potential for different compilation units, kitsune does
// not support this construct and it should fall back to the standard
// C++ code gen paths. 
#include <cstdio>
#include <cstdlib>
#include <Kokkos_Core.hpp>
#include <time.h>

const unsigned int NUM = 500;

int main (int argc, char* argv[]) {
  srand(time(NULL));

  Kokkos::initialize (argc, argv);
  
  Kokkos::View<int ***> num1("num1", NUM, NUM, NUM);
  Kokkos::View<int ***> num2("num2", NUM, NUM, NUM);
  Kokkos::View<int ***> result1("result1", NUM, NUM, NUM);
  Kokkos::View<int ***> result2("result2", NUM, NUM, NUM);
  
  for (int i = 0; i<NUM; i++) {
    for (int j = 0; j<NUM; j++) {
      for (int k = 0; k<NUM; k++) {
        num1(i, j, k) = rand() % 51;
        num2(i, j, k) = rand() % 51;
      }
    }
  }
  
  //
  // Serial
  //
  clock_t time_serial;
  time_serial = clock();
  {
    for (int i = 0; i<NUM; i++) {
      for (int j = 0; j<NUM; j++) {
        for (int k = 0; k<NUM; k++) {
          result1(i, j, k) = num1(i, j, k) * num2(i, j, k);
        }
      }
    }
  }
  time_serial = clock() - time_serial;
  double time_serial_taken = ((double)time_serial)/CLOCKS_PER_SEC;

  //
  // Parallel
  //
  clock_t time;
  time = clock();
  {
    Kokkos::parallel_for("loop1", Kokkos::MDRangePolicy<Kokkos::Rank<3>>({0,0,0},{NUM,NUM,NUM}),
      KOKKOS_LAMBDA(const int i, const int j, const int k) {
        result2(i, j, k) = num1(i, j, k) * num2(i, j, k);
    });
  }
  time = clock() - time;
  double time_taken = ((double)time)/CLOCKS_PER_SEC;
  
  //
  // Check
  //
  printf("Serial (s): %f\n", time_serial_taken);
  printf("Time (s): %f\n", time_taken);
  
  int errors = 0;
  for (int i = 0; i<NUM; i++) {
    for (int j = 0; j<NUM; j++) {
      for (int k = 0; k<NUM; k++) {
        if (result1(i,j,k) != result2(i,j,k)) ++errors;
      }
    }
  }
  printf("Errors: %d\n", errors);

  //Kokkos::finalize ();
  return 0;
}
