#pragma once

#include <string>

#include <ast.hpp>

extern void parse(const char *path, AstTree *tree);

AstTree *buildAst(std::string path, std::string name);
void printAst(AstTree *ast, std::string output);