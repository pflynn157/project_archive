package main

//Get the first part of a string
func GetFirst(str string, s byte) string {
	var ret string
	ret = ""
	
	for _, c := range str {
		if byte(c) == s {
			break
		}
		
		ret += string(c)
	}
	
	return ret
}
