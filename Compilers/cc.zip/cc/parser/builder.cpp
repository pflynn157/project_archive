#include <builder.hpp>

// Setup the AST builder
AstBuilder::AstBuilder(std::string name) {
    tree = new AstTree(name);
    
    top = new AstScope;
    tree->addChild(top);
}

// Returns the abstract syntax tree
AstTree *AstBuilder::getTree() {
    return tree;
}

void AstBuilder::incPtr() {
    ++ptrLevel;
}

int AstBuilder::getPtrLevel() {
    return ptrLevel;
}

// Set the current function type
// TODO: Add pointers
void AstBuilder::setFuncType(DataType type) {
    funcType = type;
    /*if (ptrLevel > 0) {
        funcTypeFlags |= Ptr;
        ptrLevel = 0;
    }*/
}

// Add function argument
// TODO: Add pointers
void AstBuilder::addFuncArg(std::string name, DataType type) {
    if (type == DataType::None) {
        currentFuncArgs.push_back(new AstVArg);
    } else {
        currentFuncArgs.push_back(new AstArg(name, type, 0));
    }
}

// Build function declaration
// TODO: Remove the position requirement for scope and function arguments
void AstBuilder::buildFuncDec(std::string name, bool isExtern) {
    if (isExtern) funcTypeFlags |= Extern;

    auto func = new AstFunc(name, funcType, funcTypeFlags);
    top->addChild(func);
    
    if (!isExtern) {
        auto scope = new AstScope;
        scope->addChildren(currentBlock);
        func->addChild(scope);
        
        currentBlock.clear();
        
        if (funcType == DataType::Void) {
            auto ret = new AstRet;
            scope->addChild(ret);
        }
    }
    
    if (currentFuncArgs.size() > 0) {
        auto argsList = new AstArgList;
        argsList->addChildren(currentFuncArgs);
        func->addChild(argsList);
        
        currentFuncArgs.clear();
    }
    
    funcTypeFlags = None;
    ptrLevel = 0;
}

// Adds a void-return statement
void AstBuilder::addRet() {
    auto ret = new AstRet;
    currentBlock.push_back(ret);
    
    if (currentArgs.size() > 0) {
        ret->addChildren(currentArgs);
        currentArgs.clear();
    }
}

// Set the variable type
void AstBuilder::setVarType(DataType type) {
    varType = type;
}

// Creates a variable declaration
// The "setLast" param will mark the last node in 
//     the tree as a variable declaration
void AstBuilder::addVarDec(std::string name, bool setLast) {
    if (setLast) {
        auto var = static_cast<AstVar *>(currentBlock.back());
        var->setDeclaration(true);
        var->setPtr(ptrLevel);
    } else {
        auto var = new AstVar(name, true, varType, varTypeFlags);
        var->setPtr(ptrLevel);
        currentBlock.push_back(var);
    }
        
    ptrLevel = 0;
    varType = DataType::None;
    varTypeFlags = None;
}

// Adds a variable-assignment statement
void AstBuilder::addVarAssign(std::string name) {
    auto var = new AstVar(name, false, varType, varTypeFlags);
    var->addChildren(currentArgs);
    currentBlock.push_back(var);
                             
    currentArgs.clear();
    varType = DataType::None;    
    varTypeFlags = None;
}

// Create a function call
void AstBuilder::addFuncCall(std::string name) {
    auto fc = new AstFuncCall(name);
    fc->addChildren(currentArgs);
    currentBlock.push_back(fc);
    
    currentArgs.clear();
}

// Creates a conditional statement
void AstBuilder::addCond() {
    this->pushCurrentBlock();
    
    auto cond = new AstCond;
    cond->addChildren(currentArgs);
    currentBlock.push_back(cond);
    currentArgs.clear();
}

// Creates a conditional block
void AstBuilder::addCondStatement(AstType type) {
    auto cond = new AstCond;
    
    if (type != AstType::Else) {
        cond = static_cast<AstCond *>(currentBlock.front());
        currentBlock.erase(currentBlock.begin());
    }
                                                
    auto condStm = new AstNode;
    switch (type) {
        case AstType::While: condStm = new AstWhile(cond); break;
        case AstType::If: condStm = new AstIf(cond); break;
        case AstType::Elif: condStm = new AstElif(cond); break;
        case AstType::Else: condStm = new AstElse;
     } 
     
    condStm->addChildren(currentBlock);
                                    
    currentBlock = blockStack.top();
    blockStack.pop();
    currentBlock.push_back(condStm);
}

// Add an argument to an expression
void AstBuilder::addArgument(AstNode *node) {
    currentArgs.push_back(node);
    
    if (node->getType() == AstType::Ptr)
        ptrLevel = 0;
}

// Pushes the current block
void AstBuilder::pushCurrentBlock() {
    auto block2 = currentBlock;
    blockStack.push(block2);
    currentBlock.clear();
}
