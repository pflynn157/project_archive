// Copyright 2019 Patrick Flynn
//
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, 
//	this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, this 
//	list of conditions and the following disclaimer in the documentation and/or 
//	other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors may 
//	be used to endorse or promote products derived from this software 
//	without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#include <iostream>
#include <vector>

#include "io.hh"
#include "strutils.hh"
#include "types.hh"
#include "vars.hh"
#include "array.hh"
#include "error.hh"

//Our output function
int print(std::string ln, bool nl) {
	std::string to_print = "";

	//Check to see if we have just a string
	if (is_str(ln)) {
		to_print = rm_first_last(ln);
		output(to_print, nl);
		return 0;
	}
	
	//Check to see if we are printing a variable
	Var v = get_var(ln);
	if (v.name != "") {
		to_print = v.val;
		if (v.type == DataType::STR || v.type == DataType::CHAR) {
			to_print = rm_first_last(v.val);
		}
	
		output(to_print, nl);
		return 0;
	}
	
	//Check to see if we are printing an array
	Array arr = get_arr(ln);
	if (arr.name != "") {
		std::string out = arr_to_str(arr.name);
		output(out, nl);
		return 0;
	}
	
	//Check to see if we are printing multiple things
	if (contains(ln, '+')) {
		std::vector<std::string> parts;
		std::string current = "";
		bool in_q = false;
		
		for (char c : ln) {
			if (c == '+' && !in_q) {
				current = trim(current);
				parts.push_back(current);
				current = "";
			} else if (c == '\"') {
				current += c;
				in_q = !in_q;
			} else {
				current += c;
			}
		}
		
		if (current != "") {
			current = trim(current);
			parts.push_back(current);
		}
		
		for (std::string s : parts) {
			print(s, false);
		}
		
		if (nl) {
			std::cout << std::endl;
		}
		
		return 0;
	}
	
	return 1;
}

void output(std::string ln, bool nl) {
	std::cout << ln;
	if (nl) {
		std::cout << std::endl;
	}
}

//Our input function
void input(String line, bool global) {
	std::string ln = get_second(line.str, ' ');

	if (!is_var(ln)) {
		err_extra = "Please specify a valid variable.";
		syntax_err(line, "You can only write input to a variable.");
	}

	std::string input = "";
	std::getline(std::cin, input);
	
	Var v = get_var(ln);
	v.val = input;
	
	if (v.type == DataType::STR) {
		v.val = "\"" + input + "\"";
	} else {
		DataType type = get_datatype(input);
		if (type != v.type) {
			err_extra = "You entered: " + input;
			rt_err(line, "The input value must match the array's datatype.");
		}
	}
	
	add_var(v, global);
}
