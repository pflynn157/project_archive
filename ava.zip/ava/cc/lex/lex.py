
keywords = [
    ("auto", "Auto"), ("break", "Break"), ("case", "Case"), ("char", "Char"),
    ("const", "Const"), ("continue", "Continue"), ("default", "Default"), ("do", "Do"),
    ("double", "Double"), ("else", "Else"), ("enum", "Enum"), ("extern", "Extern"),
    ("float", "Float"), ("for", "For"), ("goto", "Goto"), ("if", "If"),
    ("int", "Int"), ("long", "Long"), ("register", "Register"), ("return", "Return"),
    ("short", "Short"), ("signed", "Signed"), ("sizeof", "Sizeof"), ("static", "Static"),
    ("struct", "Struct"), ("switch", "Switch"), ("typedef", "Typedef"), ("union", "Union"),
    ("unsigned", "Unsigned"), ("void", "Void"), ("volatile", "Volatile"), ("while", "While"),
    ("sizeof", "Sizeof")
]

symbols = [
    (";", "SemiColon"), ("=", "Assign"),
    ("(", "LParen"), (")", "RParen"), ("{", "LCBrace"), ("}", "RCBrace"),
    ("+", "Add"), ("-", "Sub"), ("*", "Mul"), ("/", "Div"), ("%", "Mod"),
    ("&", "And"), ("|", "Or"), ("^", "Xor"), ("<<", "Lsh"), (">>", "Rsh"),
    ("+=", "AddEq"), ("-=", "SubEq"), ("*=", "MulEq"), ("/=", "DivEq"), ("%=", "ModEq"),
    ("&=", "AndEq"), ("|=", "OrEq"), ("^=", "XorEq"), ("<<=", "LshEq"), (">>=", "RshEq"),
    ("==", "Eq"), ("!=", "Ne"), (">", "Gt"), ("<", "Lt"), (">=", "Ge"), ("<=", "Le"),
    ("!", "Not"), ("&&", "LAnd"), ("||", "LOr"),
    (":", "Colon"), ("?", "QMark"),
    ("++", "Inc"), ("--", "Dec"),
    (".", "Dot"), ("->", "Arrow"),
    ("[", "LBracket"), ("]", "RBracket")
]

single_comments = [ "//" ]

multi_comments = [ ("*/", "*/") ]
