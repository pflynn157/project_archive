#include <iostream>
#include <string>
#include <vector>
#include <stdio.h>

#include "shell.hh"
#include "interpreter.hh"

#include <strutils.hh>
#include <error.hh>

//Control variables
std::vector<std::string> history;
bool in_func = false;

//Prints the help for our shell-specific functions
void print_help() {
	std::cout << "The following functions are specific to shell mode:" << std::endl;
	std::cout << "\trecord -> Record all entered commands." << std::endl;
	std::cout << "\tstop -> Stop recording and write file." << std::endl;
	std::cout << "\tfile -> Load a Quik file." << std::endl;
	std::cout << "\thistory -> Control history settings." << std::endl << std::endl;
	std::cout << "To exit shell mode, type \"exit\"" << std::endl << std::endl;
}

//Our main shell mode function
void shell_mode() {
	//Make sure the interpreter knows we're in shell mode
	is_shm = true;

	//Print opening messages
	std::cout << "Quik version 1.0" << std::endl;
	std::cout << "Author: Patrick Flynn" << std::endl;
	std::cout << "You are in interactive mode" << std::endl << std::endl;
	std::cout << "For special shell mode functions, type \"help\"" << std::endl;
	
	//Run the shell loop
	std::string ln = "";
	for (;;) {
		std::cout << "> ";
		std::getline(std::cin, ln);
		
		history.push_back(ln);
		
		if (ln == "help") {
			print_help();
		} else if (ln == "record") {
		
		} else if (ln == "stop") {
		
		} else if (ln == "file") {
		
		} else if (ln == "history") {
		
		} else if (ln == "exit") {
			break;
		} else if (get_first(ln, ' ') == "func") {
			in_func = true;
		} else if (ln == "end" && in_func) {
			in_func = false;
		} else {
			String s;
			s.str = ln;
			s.ln_no = 0;
			interpret(s, true);
		}
	}
}
