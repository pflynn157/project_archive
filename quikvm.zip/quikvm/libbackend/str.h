#pragma once

void qkbk_print_str(char *str);
void qkbk_print_nl();
