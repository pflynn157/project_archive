#pragma once

#include <QFrame>
#include <QVBoxLayout>

#include "canvas.hh"

class CanvasBg : public QFrame {
    Q_OBJECT
public:
    CanvasBg();
    ~CanvasBg();
    Canvas *getCanvas();
    void newImage(int width, int height);
    void newImage();
private:
    QVBoxLayout *layout;
    Canvas *canvas;
};
