#include <stdio.h>

#include <compiler.h>
#include <ltac/ltac.h>

#include <amd64/amd64.h>

ArchType arch_type;

// Initialize the compiler system
void compiler_init(ArchType type)
{
    arch_type = type;
}

// Generate the assembly
void compiler_run(LtacFile *file)
{
    switch (arch_type)
    {
        case Amd64: amd64_assemble(file); break;
        default: puts("Fatal: Unknown architecture");
    }
}

// Build the final executable
void compiler_build()
{
    amd64_build("out.asm");
}
