#!/usr/bin/python3
import RPi.GPIO as GPIO
import time

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD)

redPin = 36
yellowPin = 38
greenPin = 40

GPIO.setup(redPin, GPIO.OUT)
GPIO.setup(yellowPin, GPIO.OUT)
GPIO.setup(greenPin, GPIO.OUT)

GPIO.output(redPin, GPIO.HIGH)
GPIO.output(yellowPin, GPIO.LOW)
GPIO.output(greenPin, GPIO.LOW)

for i in range(3):
    print("Red")
    GPIO.output(redPin, GPIO.HIGH)
    time.sleep(5)
    GPIO.output(redPin, GPIO.LOW)

    print("Green")
    GPIO.output(greenPin, GPIO.HIGH)
    time.sleep(5)
    GPIO.output(greenPin, GPIO.LOW)
    

    print("Yellow")
    GPIO.output(yellowPin, GPIO.HIGH)
    time.sleep(3)
    GPIO.output(yellowPin, GPIO.LOW)

GPIO.output(redPin, GPIO.LOW)
GPIO.output(yellowPin, GPIO.LOW)
GPIO.output(greenPin, GPIO.LOW)
