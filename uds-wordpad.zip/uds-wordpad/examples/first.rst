<!DOCTYPE HTML>
<html>
    <head></head>
    <body>
        <h1>Hello!</h1>
        <h2>H2</h2>
        <h3>H3</h3>
        <h4>H4</h4>
        <hr />
        <br />
        <br />
        
        <p>This is a paragraph with <b>Bold</b> text and <i>italics</i> test.</p>
        
        <code>
        This is code
        </code>
        
        <br /><br />
        
        <p>This is a list:</p>
        <ul>
            <li>Item 1</li>
            <li>Item 2</li>
            <li>Item 3</li>
        </ul>
        
        <br /><br />
        
        <p>This is another list:</p>
        <ol>
            <li>Item 1</li>
            <li>Item 2</li>
            <li>Item 3</li>
        </ol>
    </body>
</html>
