#pragma once

#include <string>
#include <vector>

class ByteReader {
public:
	explicit ByteReader(std::string path);
	bool isHeaderValid();
	void loadAll();
private:
	std::vector<unsigned char> buffer;
	std::vector<unsigned char> strpoolv;
	std::vector<unsigned char> instructions;
};
