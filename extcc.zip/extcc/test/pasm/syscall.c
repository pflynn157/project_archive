void _start() {
	syscall(60, 23);
}
