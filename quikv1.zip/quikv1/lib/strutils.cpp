// Copyright 2019 Patrick Flynn
//
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, 
//	this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, this 
//	list of conditions and the following disclaimer in the documentation and/or 
//	other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors may 
//	be used to endorse or promote products derived from this software 
//	without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#include "strutils.hh"

//Checks to see if a string contains a character
bool contains(std::string str, char c) {
	for (char s : str) {
		if (s == c) {
			return true;
		}
	}
	
	return false;
}

//Trims a string
std::string trim(std::string ln) {
	//Trim the string from the front
	std::string tmp1 = "";
	bool found = false;
	
	for (char c : ln) {
		if ((c == ' ' || c == '\t') && !found) {
			continue;
		} else {
			found = true;
			tmp1 += c;
		}
	}
	
	//Trim the string from the back
	int stop = tmp1.length() - 1;
	
	for (int i = tmp1.length()-1; i>=0; i--) {
		char c = tmp1[i];
	
		if (c != ' ' && c != '\t') {
			stop = i;
			break;
		}
	}
	
	//Build the final string
	std::string ret = "";
	
	for (int i = 0; i<=stop; i++) {
		ret += tmp1[i];
	}
	
	return ret;
}

//Get the first part of a string
std::string get_first(std::string ln, char tk) {
	std::string ret = "";
	
	for (char c : ln) {
		if (c == tk) {
			break;
		}
		ret += c;
	}
	
	return ret;
}

//Get the second half of a string
std::string get_second(std::string ln, char tk) {
	std::string ret = "";
	bool found = false;
	
	for (char c : ln) {
		if (c == tk) {
			if (found) {
				ret += c;
			} else {
				found = true;
			}
		} else {
			if (found) {
				ret += c;
			}
		}
	}
	
	return ret;
}

//Checks to see if given input is a string
bool is_str(std::string ln) {
	int len = ln.length();
	if (ln[0] == '\"' && ln[len-1] == '\"') {
		return true;
	}
	
	return false;
}

//Check to see if given input is a char
bool is_char(std::string ln) {
	int len = ln.length();
	if (ln[0] == '\'' && ln[len-1] == '\'') {
		return true;
	}
	
	return false;
}

//Removes the quotes from the beginning and end of a string
std::string rm_first_last(std::string ln) {
	return ln.substr(1, ln.length()-2);
}

//Removes spaces for parsing
std::string clr_spaces(std::string ln) {
	std::string ret = "";
	bool in_quote = false;
	
	for (char c : ln) {
		if (c == ' ' || c == '\t') {
			if (in_quote) {
				ret += c;
			}
			continue;
		} else if (c == '\"' || c == '\'') {
			in_quote = !in_quote;
		}
		
		ret += c;
	}
	
	return ret;
}
