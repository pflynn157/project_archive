const express = require("express");
const morgan = require("morgan");
const ejs = require("ejs");
const methodOverride = require("method-override");

const firebaseApp = require("./firebase.js");
const router = require("./router.js");

const app = express();
let port = 3000;
let host = "localhost";
app.set("view engine", "ejs");

app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));
app.use(morgan('tiny'));
app.use(methodOverride("_method"));

// Set things up
app.use("/", router);

app.listen(port, host, () => {
    console.log("Server is running on port: ", port);
});
