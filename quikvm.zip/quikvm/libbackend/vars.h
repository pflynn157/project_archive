#pragma once

void qkbk_new_ivar(char *name, int val);
void qkbk_print_iconst(int val);
void qkbk_print_ivar(char *name);

void qkbk_new_dvar(char *name, double val);
void qkbk_print_dconst(double val);
void qkbk_print_dvar(char *name);
