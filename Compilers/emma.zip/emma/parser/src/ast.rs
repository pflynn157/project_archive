
// Represents AST statement types
#[derive(PartialEq, Clone)]
pub enum AstStmtType {
    VarDec,
    
    FuncCall,
    Return,
    
    If,
    Elif,
    Else,
}

// Represents AST argument types
#[derive(Clone)]
pub enum AstArgType {
    IntL,
    StringL,
    Id,
    
    OpAdd,
    OpMul,
    OpEq,
}

// Represents a data type
#[derive(Clone)]
pub enum DataType {
    Void,
    Int,
}

// Represents the top of an AST tree
pub struct AstTree {
    pub file_name : String,
    pub functions : Vec<AstFunc>,
}

// Represents a function in a tree
pub struct AstFunc {
    pub name : String,
    pub is_extern : bool,
    pub block : Vec<AstStmt>,
}

// Represents a statement
#[derive(Clone)]
pub struct AstStmt {
    pub stmt_type : AstStmtType,
    pub name : String,
    pub data_type : DataType,
    
    pub sub_statements : Vec<AstStmt>,
    pub args : Vec<AstArg>,
}

// Represents an argument
// Arguments are constants, variables, operators, etc
#[derive(Clone)]
pub struct AstArg {
    pub arg_type : AstArgType,
    pub str_val : String,
    pub i32_val : i32,
    
    pub lval : Option<Box<AstArg>>,
    pub rval : Option<Box<AstArg>>,
}

// Tree implementation
impl AstTree {
    pub fn print(&self) {
        println!("Tree: {}", self.file_name);
    
        for func in self.functions.iter() {
            func.print();
        }
    }
}

// Function implementation
impl AstFunc {
    pub fn print(&self) {
        print!("  ");
        if self.is_extern {
            print!("EXTERN ");
        }
        
        println!("FUNC {}", self.name);
        
        for stmt in self.block.iter() {
            stmt.print();
        }
    }
}

// Statement implementation
impl AstStmt {
    pub fn print(&self) {
        print!("    ");
        
        match &self.stmt_type {
            AstStmtType::VarDec => print!("VAR DEC {} ", self.name),
            AstStmtType::If => print!("IF "),
            AstStmtType::Elif => print!("ELIF "),
            AstStmtType::Else => print!("ELSE "),
            AstStmtType::FuncCall => print!("FUNC CALL {} ", self.name),
            AstStmtType::Return => print!("RETURN "),
        }
        
        match &self.data_type {
            DataType::Void => println!(""),
            DataType::Int => println!("INT"),
        }
        
        if self.args.len() > 0 {
            print!("        ARG ");
            
            for arg in self.args.iter() {
                arg.print();
            }
            
            println!("");
        }
    }
}

// Argument implementation
impl AstArg {
    pub fn print(&self) {
        if self.lval.is_some() {
            print!("(");
            
            let arg = self.lval.as_ref().unwrap();
            arg.print();
        }
        
        match &self.arg_type {
            AstArgType::IntL => print!(" {} ", self.i32_val),
            AstArgType::StringL => print!(" \"{}\" ", self.str_val),
            AstArgType::Id => print!(" {} ", self.str_val),
            AstArgType::OpAdd => print!(" + "),
            AstArgType::OpMul => print!(" * "),
            AstArgType::OpEq => print!(" == "),
        }
        
        if self.rval.is_some() {
            let arg = self.rval.as_ref().unwrap();
            arg.print();
            
            print!(")");
        }
    }
}

// Helper functions
pub fn create_extern_func(name : String) -> AstFunc {
    AstFunc {
        name : name,
        is_extern : true,
        block : Vec::new(),
    }
}

pub fn create_func(name : String) -> AstFunc {
    AstFunc {
        name : name,
        is_extern : false,
        block : Vec::new(),
    }
}

pub fn create_stmt(stmt_type : AstStmtType) -> AstStmt {
    AstStmt {
        stmt_type : stmt_type,
        name : String::new(),
        data_type : DataType::Void,
        
        sub_statements : Vec::new(),
        args : Vec::new(),
    }
}

pub fn create_int(val : i32) -> AstArg {
    AstArg {
        arg_type : AstArgType::IntL,
        str_val : String::new(),
        i32_val : val,
        
        lval : None,
        rval : None,
    }
}

pub fn create_string(val : String) -> AstArg {
    AstArg {
        arg_type : AstArgType::StringL,
        str_val : val,
        i32_val : 0,
        
        lval : None,
        rval : None,
    }
}

pub fn create_arg(arg_type : AstArgType) -> AstArg {
    AstArg {
        arg_type : arg_type,
        str_val : String::new(),
        i32_val : 0,
        
        lval : None,
        rval : None,
    }
}

