#pragma once

#include <QFrame>
#include <QPainter>
#include <QVector>
#include <QImage>

enum ShapeType {
    RECT = 1,
    ELLIPSE = 2
};

struct ShapeData {
    QRect r;
    QColor color;
};

class Canvas : public QFrame {
    Q_OBJECT
public:
    Canvas();
    void save();
    void setPath(QString p);
    bool isUntitled();
    void setShapeType(ShapeType type);
    void setCurrentColor(QColor color);
    void setImage(QImage img);
protected:
    void paintEvent(QPaintEvent *);
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
private:
    QString path = "";
    QImage bg;
    int x1, y1;
    QVector<ShapeData> rects;
    QVector<ShapeData> ellipses;
    QRect inProg;
    QColor currentColor = Qt::blue;
    ShapeType shape = ShapeType::ELLIPSE;
    bool drawInProg = false;
};
