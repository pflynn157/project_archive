#include <ltac_build.hpp>
#include <ltac/math.hpp>
#include <ltac/var.hpp>

#include <config.hpp>

// Variable declarations
int LtacBuilder::buildVarDec(std::string name, DataType dataType, int flags, int ptrLevel) {
    int size = 0;

    switch (dataType) {
        case DataType::Char: {
            if (ptrLevel > 0)
                size = PTR_SIZE;
            else
                size = CHAR_SIZE; 
        } break;
        
        case DataType::Int: {
            if (ptrLevel > 0)
                size = PTR_SIZE;
            else
                size = INT_SIZE;
        } break;
        
        case DataType::Float: size = FLOAT_SIZE; break;
        default: size = 0;
    }
    
    stackPos += size;
    
    Var v;
    v.pos = stackPos;
    v.type = dataType;
    v.ptrLevel = ptrLevel;
    vars[name] = v;
    
    return stackPos;
}

void LtacBuilder::buildVarDec(AstVar *var) {
    buildVarDec(var->getName(), var->getDataType(), var->getTypeFlags(), var->ptrLevel());
    
    if (var->getChildren().size() > 0)
        buildVarAssign(var);
}

// Variable assignments
void LtacBuilder::buildVarAssign(AstVar *var) {
    if (var->getChildren().size() > 1) {
    
        switch (var->getDataType()) {
        
            case DataType::Int: {
                buildIVarMath(var); 
                
                // Store the final result
                int dest = vars[var->getName()].pos;
                auto str = new LtacStrI32(0, dest);
                file->addCode(str);
            } break;
            
            //TODO: Add rest
        }
        
        return;
    }
    
    auto first = var->getChildren()[0];
    
    // Build it
    switch (first->getType()) {
        // Integers
        case AstType::Int: {
            auto i = static_cast<AstInt *>(first);
            int val = i->getVal();
            int pos = vars[var->getName()].pos;
            
            auto instr = new LtacMovI32(pos, val);
            file->addCode(instr);
            
            if (var->ptrLevel() > 0)
                instr->setPtr(true);
        } break;
        
        // Other variables
        case AstType::Id: {
            auto id = static_cast<AstId *>(first);
            
            Var srcVar = vars[id->getVal()];
            
            int srcPos = srcVar.pos;
            int destPos = vars[var->getName()].pos;
            
            switch (srcVar.type) {
                case DataType::Char: break;
                
                case DataType::Int: {
                    auto instr = new LtacMovV32(destPos, srcPos);
                    file->addCode(instr);
                 } break;
                 
                case DataType::Float: break;
            }
        } break;
        
        // References
        case AstType::Ref: {
            auto ref = static_cast<AstRef *>(first);
            
            int srcPos = vars[ref->getVal()].pos;
            int destPos = vars[var->getName()].pos;
            
            auto str = new LtacStrRef(destPos, srcPos);
            file->addCode(str);
        } break;
        
        // Pointers
        case AstType::Ptr: {
            auto p = static_cast<AstPtr *>(first);
            
            int srcPos = vars[p->getVal()].pos;
            int destPos = vars[var->getName()].pos;
                
            auto ld = new LtacLdPtr32(srcPos, p->getPtr(), 0);
            file->addCode(ld);
            
            auto str = new LtacStrI32(0, destPos);
            file->addCode(str);
        } break;
    }
}

// Builds integer math statement
void LtacBuilder::buildIVarMath(AstNode *var) {
    auto children = var->getChildren();
    int str_index = 0;
    
    // Iterate through the children
    // If we have a value, we store and increase the store index
    // When we find an operator, we decrement the store index
    for (auto current : children) {
        switch (current->getType()) {
            
            case AstType::Int: {
                auto i = static_cast<AstInt *>(current);
                
                auto ld = new LtacLdI32(str_index, i->getVal());
                file->addCode(ld);
                ++str_index;
            } break;
            
            case AstType::Id: {
                auto id = static_cast<AstId *>(current);
                int pos = vars[id->getVal()].pos;
                
                auto ld = new LtacLdV32(str_index, pos);
                file->addCode(ld);
                ++str_index;
            } break;
            
            case AstType::Ptr: {
                auto p = static_cast<AstPtr *>(current);
                int pos = vars[p->getVal()].pos;
                
                auto ld = new LtacLdPtr32(pos, p->getPtr(), str_index);
                file->addCode(ld);
                ++str_index;
            } break;
            
            case AstType::MathOp: {
                auto mathOp = static_cast<AstMathOp *>(current);
                
                int r1 = str_index - 2;
                int r2 = str_index - 1;
                --str_index;
                
                switch (mathOp->getOpType()) {
                    case MathType::Add: file->addCode(new LtacI32Add(r1, r2)); break;
                    case MathType::Sub: file->addCode(new LtacI32Sub(r1, r2)); break;
                    case MathType::Mul: file->addCode(new LtacI32Mul(r1, r2)); break;
                    case MathType::Div: break;
                }
            } break;
        }
    }
}
