#!/usr/bin/python3
import RPi.GPIO as GPIO
import time

#Pin numbers
ds1 = 3         #pin 2
st_cp1 = 5      #pin 3
sh_cp1 = 7      #pin 4

ds2 = 36		#pin 21
st_cp2 = 38		#pin 20
sh_cp2 = 40		#pin 16

setBtn = 12             #pin 18
goBtn = 10              #pin 15

beepPin = 32            #pin 12

#Setup
GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)

# Setup up the first segment
GPIO.setup(ds1, GPIO.OUT)
GPIO.setup(st_cp1, GPIO.OUT)
GPIO.setup(sh_cp1, GPIO.OUT)

# Setup the second segment
GPIO.setup(ds2, GPIO.OUT)
GPIO.setup(st_cp2, GPIO.OUT)
GPIO.setup(sh_cp2, GPIO.OUT)

# Setup the buttons
GPIO.setup(setBtn, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
GPIO.setup(goBtn, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

# Setup the beep
GPIO.setup(beepPin, GPIO.OUT, initial=GPIO.HIGH)

#Set initial states
GPIO.setup(ds1, GPIO.LOW)
GPIO.setup(st_cp1, GPIO.LOW)
GPIO.setup(sh_cp1, GPIO.LOW)

GPIO.setup(ds2, GPIO.LOW)
GPIO.setup(st_cp2, GPIO.LOW)
GPIO.setup(sh_cp2, GPIO.LOW)

#The write code for the first display
def write_dsp1(data):
    for bit in range(0, 8):
        GPIO.output(ds1, 0x80 & (data << bit))
        GPIO.output(sh_cp1, GPIO.HIGH)
        time.sleep(0.001)
        GPIO.output(sh_cp1, GPIO.LOW)
    GPIO.output(st_cp1, GPIO.HIGH)
    time.sleep(0.001)
    GPIO.output(st_cp1, GPIO.LOW)

#The write code for the second display
def write_dsp2(data):
    for bit in range(0, 8):
        GPIO.output(ds2, 0x80 & (data << bit))
        GPIO.output(sh_cp2, GPIO.HIGH)
        time.sleep(0.001)
        GPIO.output(sh_cp2, GPIO.LOW)
    GPIO.output(st_cp2, GPIO.HIGH)
    time.sleep(0.001)
    GPIO.output(st_cp2, GPIO.LOW)
    
def dspInt(no):
    numbers = [0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F]
    no_str = str(no)
    
    d1 = 0
    d2 = 0

    if len(no_str) == 1:
        d1 = 0
        d2 = int(no_str)
    else:
        d1 = int(no_str[0])
        d2 = int(no_str[1])

    hex1 = numbers[d1]
    hex2 = numbers[d2]

    write_dsp1(hex1)
    write_dsp2(hex2)

start = 0

def set_clicked(channel):
    global start
    start += 1
    dspInt(start)

def go_clicked(channel):
    global start
    while start >= 0:
        dspInt(start)
        start -= 1
        time.sleep(1)

    for i in range(3):
        GPIO.output(beepPin, GPIO.LOW)
        time.sleep(0.3)
        GPIO.output(beepPin, GPIO.HIGH)
        time.sleep(0.3)

GPIO.add_event_detect(setBtn, GPIO.RISING, callback=set_clicked, bouncetime=200)
GPIO.add_event_detect(goBtn, GPIO.RISING, callback=go_clicked, bouncetime=200)

def run():
    while True:
        pass

try:
    run()
except KeyboardInterrupt:
    write_dsp1(0x3F)
    write_dsp2(0x3F)
    GPIO.cleanup()
