#!/bin/bash
cd ./test

./test_compiler.sh ../build/src/tlc 1 2 3 4 5 6
#./test_compiler.sh ../build/src/tlc 6

cd ..
