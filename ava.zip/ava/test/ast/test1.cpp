#include <iostream>
#include <string>

#include <ava/ast.hpp>
#include <ava/ast_builder.hpp>

/* Build this program:
int main() {
    return x;
}

Goal: find enclosing information of x.
x -> return
return -> main
main -> global scope
*/
AstTree *buildTree() {
    AstTree *tree = new AstTree("test1");
    
    AstFunction *func = new AstFunction("main");
    func->setDataType(AstBuilder::buildInt32Type());
    tree->addGlobalStatement(func);
    
    AstReturnStmt *ret = new AstReturnStmt;
    AstID *x = new AstID("x");
    ret->setExpression(x);
    func->getBlock()->addStatement(ret);
    
    return tree;
}

int main(int argc, char *argv[]) {
    AstTree *tree1 = buildTree();
    
    tree1->print();
    delete tree1;
    
    return 0;
}

