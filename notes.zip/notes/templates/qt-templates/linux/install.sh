#!/bin/bash
echo "Installing..."

APP_NAME=uds_app

if [ ! -d /opt/uds/bin ] ; then
    mkdir -p /opt/uds/bin
fi

if [ ! -d /opt/uds/icons/apps ] ; then
    mkdir -p /opt/uds/icons/apps
fi

install $APP_NAME /opt/uds/bin
install $APP_NAME.svg /opt/uds/icons/apps
install $APP_NAME.desktop /usr/share/applications

update-desktop-database
ldconfig

echo "Done"

