## Symbol

### Introduction
Symbol is a simple, rather useless, programming language that I created. symbolc is the compiler for the language. Symbol has no purpose, really, as a programming language. It is primarily a learning exercise for me to create a language parser and a compiler. This gives you a rundown on how the language works.

### The language
Symbol is somewhat C-like. It is a structured language that is compiled into assembly, and then binary format.

#### Functions
Functions are designated by the dollar sign character ('$'). To define a function, simply begin with the dollar sign, followed by a name. Note that parameters are not supported yet. The main function is always designated like this: $~. All programs must have the main function. Function bodies are designated by curly braces Functions that contain raw assembly code start like this: $asm. These functions have no name; as a result, any assembly code must be in an assembly function. Assembly code here is simply read an inserted directly into the generated assembly file.   

To call other functions, simply type in the function name, followed by a semicolon.   

It is highly recommended that you always return from a function. If you don't, you may experience wierd behavior. Returning is designated by the caret symbol (^). Simply put the caret on its own line, and make it the last line in your function.   

To exit the program all together, use a semicolon. Semicolons are also used to end statements, so if you wish to exit, the semicolon must be on its own line.

#### Statements
Statements simply span a single line and end with a semicolon. This is where you can do whatever.

#### Comments
Comments are designated by the at sign (@). A comment must be on its own line. Comments are currently ignored by the symbol compiler (although we may copy them over to the assembly file later).

#### Whitespace
Whitespace generally doesn't matter. However, you should observe a few conventions. First, statements must be on their own line. Even though you end a statement with a semicolon, you cannot put another statement on the same line (the semicolon is there so trailing whitespace is not copied).    

Generally, leading whitespace in the form of spaces or tabs (such as indentation) is find, but all other is not.

#### Conditionals
Symbol has a degree of support for conditionals. However, this support is very limited. Conditionals can have only one statement in their body, they cannot be nested, and only two levels are supported (if->else; no else if).   

To write a conditional, start with 'if', followed by the comparison statement in brackets. A list of allowed operators is below. End with a semicolon, and move to the next line. Start this line with a colon, and include whatever you want. End with a semicolon, and move to the next line. Then use 'else', followed by a semicolon. Move to the next line. Use a colon, and insert your else statement, ending with a semicolon. Finally, move to the next line, and all 'endif', followed by a semicolon.   

Operators:   
1. > (Greater than)   
2. < (Less than)   
3. = (Equal to-> Note the one equal sign, not the double like in other languages)   
4. ! (Not equal to-> This must go between the two comparisons)   

The current limitations of conditionals can be partially solved by creating and calling functions.

#### Loops
Symbol has very basic support of loops. In fact, the only way to currently loop is to use the "loop" keyword, followed by a number and a semicolon. The number, as you might have guessed, is the number of times to run the loop.    
Unlike conditionals, loops support multiple lines of body. Simply begin each line of the loop's body with a colon AND a space.

#### Variables
Symbol now has basic variable support. However, it is limited. Variables are created by a pound sign ('#'), followed by the name. Then, set the value by using this operator: '<'. At this point, variables are only good for comparisons. They cannot be reset or used anywhere else.

#### Including files
You can include library files like in other languages. To do so, simply start with a forward slash (/), followed by the module name.
