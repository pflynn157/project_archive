#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <Kokkos_Core.hpp>

const size_t SIZE = 16;

int main(int argc, char **argv) {
    Kokkos::initialize(argc, argv);
    
    // Init arrays
    Kokkos::View<int*> num1("num1", SIZE);
    Kokkos::View<int*> num2("num2", SIZE);
    Kokkos::View<int*> result("result", SIZE);
    
    // Fill the arrays
    Kokkos::parallel_for("Init", SIZE, KOKKOS_LAMBDA(const size_t i) {
        printf("%d ", i);
        num1(i) = rand() % 10;
        num2(i) = rand() % 10;
    });
    puts("");
    
    // Dump
    for (int i = 0; i<SIZE*2; i++) printf("-");
    puts("");
    for (int i = 0; i<SIZE; i++) printf("%d ", num1(i));
    puts("");
    for (int i = 0; i<SIZE; i++) printf("%d ", num2(i));
    puts("");
    puts("");
    
    // Now, add
    Kokkos::parallel_for("Add", SIZE, KOKKOS_LAMBDA(const size_t i) {
        result[i] = num1[i] + num2[i];
    });
    
    // dump again
    for (int i = 0; i<SIZE; i++) printf("%d ", result(i));
    puts("");
    
    return 0;
}

