// struct.hpp
// This represents structural elements in an LTAC file
#pragma once

#include <string>
#include <vector>

#include "ltac.hpp"
#include "types.hpp"
#include "var.hpp"

// Represents an LTAC file (which holds all other subdata)
class LtacFile {
public:
    LtacFile(std::string name) {
        this->name = name;
    }
    
    // Helper functions
    void addCode(LtacInstr *instr) { 
        code.push_back(instr);
    }
    
    void addData(LtacData *d) {
        data.push_back(d);
    }
    
    std::vector<LtacInstr *> getCode() {
        return code;
    }
    
    std::vector<LtacData *> getData() {
        return data;
    }
    
    void setName(std::string name) { this->name = name; }
    std::string getName() { return name; }
protected:
    std::vector<LtacInstr *> code;
    std::vector<LtacData *> data;
private:
    std::string name;
};

// Represents a label
class LtacLabel : public LtacInstr {
public:
    LtacLabel(std::string name) : LtacInstr(LtacType::Label) {
        this->name = name;
    }
    
    void setName(std::string name) { this->name = name; }
    std::string getName() { return name; }
    
    std::string printInstr();
private:
    std::string name = "";
};

// The ldarg command- Used for loading function arguments
class LtacLdArg : public LtacInstr {
public:
    explicit LtacLdArg(int pos, LtacType type) : LtacInstr(type) {
        this->pos = pos;
    }
    
    void setType(LtacType type) { this->type = type; }
    int getPos() { return pos; }
    
    std::string printInstr();
protected:
    int pos = 0;
};

// Represents a function call
class LtacFuncCall : public LtacInstr {
public:
    explicit LtacFuncCall(std::string name) : LtacInstr(LtacType::FuncCall) {
        this->name = name;
    }
    
    explicit LtacFuncCall() : LtacInstr(LtacType::Syscall) {}
    
    void setName(std::string name) { this->name = name; }
    std::string getName() { return name; }
        
    void addIArg(int i) { 
        args.push_back(new LtacInt(i)); 
    }
    
    void addSArg(std::string s) {
        args.push_back(new LtacString(s));
    }
    
    void addVar32(int pos) {
        args.push_back(new LtacVar32(pos));
    }
    
    void addPtr(int pos) {
        args.push_back(new LtacPtr(pos));
    }
    
    std::vector<LtacInstr *> getArgs() {
        return args;
    }
        
    std::string printInstr();
protected:
    std::vector<LtacInstr *> args;
    std::string name = "";
};

// Represents a system call
class LtacSyscall : public LtacFuncCall {
public:
    LtacSyscall() {}
    std::string printInstr();
};

// Represents a function return
class LtacRet : public LtacInstr {
public:
    LtacRet() : LtacInstr(LtacType::Ret) {}
    std::string printInstr();
};

