#include <vector>
#include <fstream>
#include <iostream>

#include "bytecode.hh"

#include <strutils.hh>

//Numerical vars
struct NVar {
	std::string name;
	int loco;
};

std::vector<NVar> nvars;

//Encodes a string into our array
void encode(std::vector<char> *bytes, std::string msg) {
	for (char c : msg) {
		bytes->push_back(c);
	}
}

//Builds and encodes variables
void build_vars(std::vector<char> *bytes, std::vector<std::string> contents) {
	bytes->push_back(0xAA);
	bytes->push_back(contents.size());
	
	for (auto str : contents) {
		std::string name = get_first(str, ' ');
		std::string second = get_second(str, ' ');
		std::string type = get_first(second, ' ');
		std::string val = get_second(second, ' ');
		
		if (type == "int") {
			bytes->push_back(0xA1);
		} else if (type == "dec") {
			bytes->push_back(0xA2);
		} else if (type == "char") {
			bytes->push_back(0xA3);
		} else if (type == "str") {
			bytes->push_back(0xA4);
		} else if (type == "bool") {
			bytes->push_back(0xA5);
		}
		
		encode(bytes, val);
		bytes->push_back(0xFF);
	}
	
	bytes->push_back(0xFF);
}

//The main bytecode assembly function
void bytecode_assemble(std::vector<String> contents, std::string outfile) {
	std::vector<char> bytes;
	
	//Generate the header
	bytes.push_back(0xAA);
	std::string header = "QUIK";
	encode(&bytes, header);
	bytes.push_back(0xFF);
	
	//Split the content list into the variable and the code sections
	bool in_code = false;
	
	std::vector<std::string> vars;
	std::vector<std::string> code;
	
	for (auto s : contents) {
		if (s.str == "$") {
			in_code = true;
			continue;
		}
		
		if (in_code) code.push_back(s.str);
		else vars.push_back(s.str);
	}
	
	//Build everything
	build_vars(&bytes, vars);
	
	//Write the file
	std::string bcfile = outfile + ".qkb";
	std::ofstream writer(bcfile.c_str(), std::ios_base::binary);
	
	for (char c : bytes) {
		writer << c;
	}
	
	writer.close();
}
