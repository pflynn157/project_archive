#pragma once

#include <string>

#include <Value.hpp>

class Value;

enum Opcode {
    NOP,

    RET,
    RETVOID
};

class Instruction : public Value {
public:
    explicit Instruction(Opcode opcode, std::string name) : Value(name) {
        this->opcode = opcode;
        if (name == "") {
            canReturn = false;
        }
    }

    void SetCanReturn(bool can) {
        this->canReturn = can;
    }

    void SetArg1(Value *value) {
        this->arg1 = value;
    }

    void SetArg2(Value *value) {
        this->arg2 = value;
    }

    Value *GetArg1() { return arg1; }
    Value *GetArg2() { return arg2; }

    void dump();
private:
    Value *arg1 = nullptr;
    Value *arg2 = nullptr;
    Opcode opcode = NOP;
    bool canReturn = true;
};
