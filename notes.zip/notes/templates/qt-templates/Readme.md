## Qt Project Templates

This contains project templates for new Qt5 and Qt6 applications.
