#pragma once

#include <string>
#include <vector>

#include <Function.hpp>

class Function;

class Unit {
public:
    explicit Unit(std::string name) {
        this->name = name;
    }

    void AddFunction(Function *func) {
        functions.push_back(func);
    }

    void dump();
private:
    std::string name = "";
    std::vector<Function *> functions;
};
