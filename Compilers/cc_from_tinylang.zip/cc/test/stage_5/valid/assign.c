int main() {
    int a;
    a = 2;
    return a;
}