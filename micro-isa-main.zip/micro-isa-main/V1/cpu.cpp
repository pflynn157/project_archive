#include <cstdio>

#include "cpu.hpp"

CPU::CPU() {
    registers = new uint8_t[9];
    pc = 0;
    for (int i = 0; i<9; i++) registers[i] = 0;
    
    // TEMP
    memory = new uint16_t[65400];
    memory[0] = 0x21;       // li 4
    memory[1] = 0x3C;       // movu r1
    memory[2] = 0x19;       // li 3
    memory[3] = 0xA0;       // add r5
    memory[4] = 0x01;       // li 0
    memory[5] = 0x3C;       // movu r1
    memory[6] = 0x01;       // li 0
    memory[7] = 0xAC;       // movd r5
    memory[8] = 0x3C;       // movu r1
    memory[9] = 0x09;       // li 1
    memory[10] = 0x38;      // cmpne
    memory[11] = 0x12;      // br 2
    memory[12] = 0x5C;      // movu r2
    memory[13] = 0x7C;      // movu r3
    memory[14] = 0x9C;      // movu r4
}

//
// The main run loop
//
void CPU::run() {
    while (pc < 15) {
        fetch();
        decode();
        execute();
        store();
    }
}

//
// Fetch stage
//
void CPU::fetch() {
    reset();
    instr = memory[pc];
    ++pc;
}

//
// Decode stage
//
void CPU::decode() {
    opcode = instr & 0x03;
    
    printf("--------\nOpcode: %X\n", opcode); // db
    
    switch (opcode) {
        case 0b00: {
            alu_op = (instr & 0x1C) >> 2;
            rd = (instr & 0xE0) >> 5;
        
            printf("ALU_OP: %x\n", alu_op);
            printf("Rd: %x\n", rd);
        } break;
        
        case 0b01: {
            ctrl = (instr & 0x04) >> 2;
            imm = (instr & 0xF8) >> 3;
            
            printf("CTRL: %x\n", ctrl);
            printf("IMM: %x\n", imm);
        } break;
        
        case 0b10: {
            ctrl = (instr & 0x04) >> 2;
            imm = (instr & 0xF8) >> 3;
            
            printf("BR CTRL: %x\n", ctrl);
            printf("BR IMM: %x\n", imm);
        } break;
        
        case 0b11: {} break;
        
        default: {}
    }
}

//
// The execute stage
//
void CPU::execute() {
    switch (opcode) {
        // ALU
        case 0b00: {
            uint8_t src1 = registers[0];
            uint8_t src2 = registers[1];
            
            // ADD
            if (alu_op == 0) {
                registers[rd] = src1 + src2;
            
            // MOVD
            } else if (alu_op == 3) {
                registers[0] = registers[rd];
            
            // CMP
            } else if (alu_op == 6) {
                //if (src1 == src2) cmp_reg = 2;
                //else if (src1 > src2) cmp_reg = 3;
                //else if (src1 < src2) cmp_reg = 1;
                //cmp_reg = 1;
                if (rd == 0 && (src1 == src2)) cmp_reg = 1;
                else if (rd == 1 && (src1 != src2)) cmp_reg = 1;
                else if (rd == 2 && (src1 > src2)) cmp_reg = 1;
                else if (rd == 3 && (src1 < src2)) cmp_reg = 1;
                else cmp_reg = 0;
              
            // MOVU
            } else if (alu_op == 7) {
                registers[rd] = src1;
            }
        } break;
        
        // L/S
        case 0b01: {
            if (ctrl == 0) {
                registers[0] = imm;
            } else if (ctrl == 1) {
            
            }
        } break;
        
        // B/J
        case 0b10: {
            if (ctrl == 0) {
                if (cmp_reg == 1) {
                    pc += imm;
                }
            } else {
            
            }
        } break;
        
        // M
        case 0b11: {} break;
        
        default: {}
    }
}

//
// The store stage
//
void CPU::store() {

}

//
// Resets all control signals
//
void CPU::reset() {
    instr = 0;
    opcode = 0;
    ctrl = 0;
    rs1 = 0;
    rs2 = 0;
    rd = 0;
    alu_op = 0;
    imm = 0;
}

