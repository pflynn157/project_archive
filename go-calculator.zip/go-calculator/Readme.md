## calculator

This is a simple program for efficiently calculating long chain problems. It is written in Go; to build, simply run "go build"
