#pragma once

#include <QWidget>
#include <QPainter>
#include <QVector>

class MainWindow : public QWidget {
    Q_OBJECT
public:
    MainWindow();
protected:
    void paintEvent(QPaintEvent *);
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
private:
    int x1, y1;
    QVector<QRect> rects;
    QRect inProg;
    bool drawInProg = false;
};
