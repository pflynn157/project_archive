//OUTPUT
//Hello, world!
//END

//RET 0

extern void puts(char *str);
extern void exit(int rc);

void main() {
    puts("Hello, world!");
    exit(0);
}
