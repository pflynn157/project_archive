#include <stdio.h>

void main() {
	unsigned char h1 = 0xA1;
	unsigned char h2 = 0xA2;
	
	unsigned char hb1 = (h1>>4)&0xF;
	
	printf("H1: %x\n", h1);
	printf("H2: %x\n\n", h2);
	printf("HB1: %x\n", hb1);
}
