#!/bin/bash

echo ""
echo "Running all tests..."
echo ""

for d in test/*; do
    for input in $d/*.tl; do
        name=`basename $input .tl`
        echo $name
        
        #Compile each
        build/ccx2 $d/$name.tl
        gcc $d/$name.c -o ./test.bin
        
        ./first.bin
        RET1=$?
        
        ./test.bin
        RET2=$?
        
        rm first.bin
        rm test.bin
        
        if [[ $RET1 == $RET2 ]] ; then
            echo "Pass"
            echo ""
        else
            echo "Fail"
            echo "Expected: $RET2"
            echo "Actual: $RET1"
            echo ""
        fi
    done
done

echo ""
echo "Done"
echo ""
