//
// Copyright 2021 Patrick Flynn
// This file is part of the Tiny Lang compiler.
// Tiny Lang is licensed under the BSD-3 license. See the COPYING file for more information.
//
#include <iostream>
#include <string>
#include <cstdio>

#include <preproc/Preproc.hpp>
#include <parser/Parser.hpp>
#include <ast/ast.hpp>
#include <utils.hpp>

#include <compiler/Compiler.hpp>
#include <unparser/Unparser.hpp>

bool isError = false;

AstTree *getAstTree(std::string input, bool testLex, bool printAst, bool emitDot) {
    Parser *frontend = new Parser(input);
    AstTree *tree;
    
    if (testLex) {
        frontend->debugScanner();
        isError = false;
        return nullptr;
    }
    
    if (!frontend->parse()) {
        delete frontend;
        isError = true;
        return nullptr;
    }
    
    tree = frontend->getTree();
    
    delete frontend;
    remove(input.c_str());
    
    if (printAst) {
        tree->print();
        return nullptr;
    }
    
    if (emitDot) {
        tree->dot();
        return nullptr;
    }
    
    return tree;
}

int main(int argc, char **argv) {
    if (argc == 1) {
        std::cerr << "Error: No input file specified." << std::endl;
        return 1;
    }
    
    // Compiler (codegen) flags
    CFlags flags;
    
    // Other flags
    std::string input = "";
    bool emitPreproc = false;
    bool testLex = false;
    bool printAst = false;
    bool emitDot = false;
    bool unparser = false;
    Unparser unparse_lang;
    
    for (int i = 1; i<argc; i++) {
        std::string arg = argv[i];
        
        if (arg == "-E") {
            emitPreproc = true;
        } else if (arg == "--test-lex") {
            testLex = true;
        } else if (arg == "--ast") {
            printAst = true;
        } else if (arg == "--dot") {
            emitDot = true;
        } else if (arg == "--llvm") {
            flags.printLLVM = true;
        } else if (arg == "--emit-llvm") {
            flags.emitLLVM = true;
        } else if (arg == "-o") {
            flags.name = get_name(argv[i+1]);
            flags.path = get_path(argv[i+1]);
            i += 1;
        } else if (arg == "--unparse:cpp") {
            unparser = true;
            unparse_lang = Unparser::Cpp;
        } else if (arg == "--unparse:ada") {
            unparser = true;
            unparse_lang = Unparser::Ada;
        } else if (arg[0] == '-') {
            std::cerr << "Invalid option: " << arg << std::endl;
            return 1;
        } else {
            input = arg;
        }
    }
    
    std::string newInput = preprocessFile(input, emitPreproc);
    if (newInput == "") {
        return 1;
    }
    
    AstTree *tree = getAstTree(newInput, testLex, printAst, emitDot);
    if (tree == nullptr) {
        if (isError) return 1;
        return 0;
    }

    // Compile
    if (unparser) {
        unparse(tree, unparse_lang);
    } else {
        Compiler *compiler = new Compiler(tree, flags);
        compiler->compile();
    }
    
    return 0;
}

