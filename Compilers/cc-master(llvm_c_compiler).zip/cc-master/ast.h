#pragma once

typedef enum
{
    Void,
    Char,
    Short,
    Int,
    Long,
    Float,
    Double
} DataType;

typedef enum
{
    CharL,
    IntL,
    FloatL,
    StringL,
    Id,
    
    Plus,
    Sub,
    Mul,
    Div,
    
    Pointer,
    AddrOf,
    Negate,
    
    Assign
} NodeType;

typedef enum
{
    VarDec,
    VarAssign,
    Ret,
    RetVoid
} StmtType;

struct Node
{
    NodeType type;
    char *sval;
    int ival;
    double flt_val;
    
    struct Node *lval;
    struct Node *rval;
};

struct Statement
{
    StmtType type;
    int ival;
    struct Node *operand;
};

struct Block
{
    struct Statement **line_list;
    int line_count;
    int line_max;
};

struct Function
{
    DataType type;
    char *name;
    int is_extern;
    struct Block *block;
    struct Block *param_block;
};

typedef struct
{
    const char *module_name;
    
    struct Function **func_list;
    int func_count;
    int func_max;
} AstTree;

struct Node *create_op_node(NodeType type, struct Node *lval, struct Node *rval);
struct Node *create_id_node(char *val);
struct Node *ast_create_char_node(char val);
struct Node *create_int_node(int val);
struct Node *ast_create_float_node(double val);
struct Node *ast_create_string_node(char *val);

struct Statement *create_stmt(StmtType type, struct Node *operand);
struct Statement *create_typed_stmt(StmtType type, int data_type, struct Node *operand);

struct Block *create_block();
struct Block *ast_reset_block(struct Block *original);
void ast_add_statement(struct Block *block, struct Statement *stmt);

struct Function *create_function(DataType data_type, char *name, struct Block *param_block, struct Block *block);
struct Function *create_extern_function(DataType data_type, char *name, struct Block *param_block);

AstTree *create_tree(const char *mod_name);
void ast_add_function(AstTree *tree, struct Function *func);

void ast_destroy_node(struct Node *node);
void ast_destroy_block(struct Block *block);
void ast_destroy_tree(AstTree *tree);

