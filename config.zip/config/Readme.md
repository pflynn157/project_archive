## config

These are my personal configs and alias's for my systems.
