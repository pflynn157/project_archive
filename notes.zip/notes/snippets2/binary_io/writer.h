#pragma once

#include <stdio.h>

void write_byte(unsigned char byte, FILE *writer);
void write_short(short val, FILE *writer);
void write_int(int val, FILE *writer);
void write_str(const char *str, FILE *writer);
