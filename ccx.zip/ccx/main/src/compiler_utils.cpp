#include "compiler.hpp"
#include "ast.hpp"

#include <llir/llir.hpp>
#include <llir/irbuilder.hpp>

LLIR::Type *Compiler::translateType(DataType type) {
    switch (type) {
        case DataType::U8:
        case DataType::I8:
        case DataType::W1: return LLIR::Type::createI8Type();
        
        case DataType::U16:
        case DataType::I16:
        case DataType::W2: return LLIR::Type::createI16Type();
        
        case DataType::U32:
        case DataType::I32:
        case DataType::W4: return LLIR::Type::createI32Type();
        
        case DataType::U64:
        case DataType::I64:
        case DataType::Long:
        case DataType::W8: return LLIR::Type::createI64Type();
        
        //U128, I128,
        
        default: {}
    }
    
    return LLIR::Type::createVoidType();
}

