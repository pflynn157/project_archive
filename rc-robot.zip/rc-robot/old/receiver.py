#!/usr/bin/python3
# This is the main part of the program
# It receives and translates all incoming commands
import RPi.GPIO as GPIO
from socket import *
import time

from setup import Setup
from esc import Esc
from servo import Servo

def get_first(ln):
	ret = ""
	for c in ln:
		if c == ' ':
			break
		else:
			ret += c
	return ret
	
def get_second(ln):
	ret = ""
	found = False
	
	for c in ln:
		if c == ' ':
			if found:
				ret += c
			else:
				found = True
		else:
			if found:
				ret += c
	
	return ret
	
svr = None
ec = None
n_throttle = 1500.0
n_steering = 7.0
throttle = n_throttle
steering = n_steering
break_sp = 600

def interpret(d):
	global svr
	global ec
	global throttle
	global steering

	data = d.decode()
	first = get_first(data)
	second = get_second(data)
	
	if first == "IP":
		print("Ip address")
		
	# The Logic for the setup command
	elif first == "SETUP":
		Setup().init()
		
		svr = Servo()
		svr.init()
		svr.steer(6)
		
		ec = Esc()
		ec.init()
		ec.set_neutral()
	
	#The logic for our test functions
	elif first == "TEST":
		print("Running test...")
		
	#The logic for the INC function
	elif first == "INC":
		part1 = get_first(second)
		part2 = get_second(second)
		amount = float(part2)
		
		if part1 == "THR":
			print("THR INC: "+str(amount))
			throttle += amount
			ec.set_speed(throttle)
		elif part1 == "STR":
			print("STR INC: "+str(amount))
			steering += amount
			svr.steer(steering)
	
	#The logic for the DEC function
	elif first == "DEC":
		part1 = get_first(second)
		part2 = get_second(second)
		amount = float(part2)
		
		if part1 == "THR":
			print("THR DEC: "+str(amount))
			throttle -= amount
			ec.set_speed(throttle)
		elif part1 == "STR":
			print("STR DEC: "+str(amount))
			steering -= amount
			svr.steer(steering)
	
	#The command for the neutral command		
	elif first == "NTRL":
		global n_throttle
		global n_steering
	
		if second == "THR":
			ec.set_speed(n_throttle)
		elif second == "STR":
			svr.steer(n_steering)
		
	#Used for the break
	elif first == "BREAK":
		ec.set_speed(break_sp)
		
	#Unknown command
	else:
		print("What???")

def run():
	host = "192.168.254.15"
	port = 8100
	buf = 1024

	address = (host, port)
	sockfd = socket(AF_INET, SOCK_DGRAM)
	sockfd.bind(address)

	print("Ready to go...")

	while True:
		(data, address) = sockfd.recvfrom(buf)
		if data == b"STOP":
			break
		elif get_first(data.decode()) == "PAUSE":
			tm = get_second(data.decode())
			time.sleep(int(tm))
			continue
		interpret(data)
		
	sockfd.close()
	
def run_bt():
	macAddr = "B8:27:EB:89:61:0F"
	port = 3
	bklog = 1
	size = 1024

	socketd = socket(AF_BLUETOOTH, SOCK_STREAM, BTPROTO_RFCOMM)
	socketd.bind((macAddr, port))
	socketd.listen(bklog)
	client, addr = socketd.accept()
	
	print("[Bluetooth] Ready to go...")

	try:
		while True:
			data = client.recv(size)
			if data:
				if data == b"STOP":
					break
				elif get_first(data.decode()) == "PAUSE":
					tm = get_second(data.decode())
					time.sleep(int(tm))
					continue
				interpret(data)
	finally:
		print("Closing...")
		client.close()
		socketd.close()
	
run_bt()
