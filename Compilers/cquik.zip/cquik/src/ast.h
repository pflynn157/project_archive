#pragma once

typedef enum {
    None,
    
    Scope,
    FuncDec,
    End,
    
    Syscall,
    
    IntL
} AstType;

struct AstListNode;

typedef struct
{
    struct AstListNode *head;
} AstLinkedList;

typedef struct {
    AstType type;
    AstLinkedList *children;
    
    int i_val1;
    
    const char *str_val1;
} AstNode;

struct AstListNode 
{
    AstNode *element;
    struct AstListNode *next;
};

AstNode *ast_create_node(AstType type);
AstNode *ast_create_func(const char *name);
AstNode *ast_create_int(int val);

void ast_add_child(AstNode *child, AstNode *parent);

void ast_print(AstNode *tree, int indent);
