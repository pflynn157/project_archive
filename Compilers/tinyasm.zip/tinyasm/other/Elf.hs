module Main(main) where

import System.IO
import Data.Binary

import Writer

writeBuf writer 7 = return()
writeBuf writer i = do
    writeByte writer 0x00
    writeBuf writer (i + 1)

main = do
    writer <- openBinaryFile "out.bin" WriteMode
    
    -- The header
    writeInt writer 0x464c457F          -- The Magic number
    writeByte writer 0x02               -- 64-bit
    writeByte writer 0x01               -- LSB encoding
    writeByte writer 0x01               -- ELF version 1
    writeByte writer 0x00               -- OS ABI version
    writeByte writer 0x00               -- ABI version
    
    writeBuf writer 0                   -- The buffer
    
    writeShort writer 0x01              -- Object type- 2 is executable, 1 is relocatable
    writeShort writer 0x3e              -- Architecture type
    writeInt writer 1                   -- ELF version
    
    writeInt64 writer 0                 -- Start address to execute
    writeInt64 writer 0                 -- Program header start
    
    writeInt64 writer 64                 -- Section header table offset
    writeInt writer 0
    writeShort writer 64                -- ELF header size
    writeShort writer 0                 -- Program header size
    writeShort writer 0                 -- Number of program header
    
    --The sections
    writeShort writer 64                -- Size of section headers
    writeShort writer 5                 -- Number of section headers
    writeShort writer 1                 -- String table index
    
-- ================================================================
    -- Null header
    writeInt writer 0                   -- Name
    writeInt writer 0                   -- SHUT_NULL
    writeInt64 writer 0                 -- No flags
    writeInt64 writer 0                 -- No address
    writeInt64 writer 0                 -- No offset
    writeInt64 writer 0                 -- No size
    writeInt writer 0                   -- No link info
    writeInt writer 0                   -- No aux infor
    writeInt64 writer 0                 -- No alignment
    writeInt64 writer 0                 -- No entries
    
-- ================================================================
    -- String table header (.shstrtab)
    writeInt writer 1                   -- Name
    writeInt writer 0x3                 -- SHUT_STRTAB
    writeInt64 writer 0                 -- No flags
    writeInt64 writer 0                 -- No address
    writeInt64 writer 384               -- Offset
    writeInt64 writer 32               -- No size
    writeInt writer 0                   -- No link info
    writeInt writer 0                   -- No aux infor
    writeInt64 writer 1                 -- No alignment
    writeInt64 writer 0                 -- No entries
    
-- ================================================================
    -- Text header (.text)
    writeInt writer 11                   -- Name
    writeInt writer 0x1                -- SHUT_STRTAB
    writeInt64 writer 6                 -- No flags
    writeInt64 writer 0                 -- No address
    writeInt64 writer 531               -- Offset
    writeInt64 writer 12                -- Size
    writeInt writer 0                   -- No link info
    writeInt writer 0                   -- No aux infor
    writeInt64 writer 16                 -- No alignment
    writeInt64 writer 0                 -- No entries
    
-- ================================================================
    -- Symbol table header
    writeInt writer 25                   -- Name
    writeInt writer 0x2                 -- SHUT_STRTAB
    writeInt64 writer 0                 -- No flags
    writeInt64 writer 0                 -- No address
    writeInt64 writer 417                 -- Offset
    writeInt64 writer 96                 -- Size
    writeInt writer 4                   -- No link info
    writeInt writer 3                   -- No aux infor
    writeInt64 writer 8                 -- No alignment
    writeInt64 writer 24                 -- Entry size
    
-- ================================================================
    -- String table header for the symbol table
    writeInt writer 17                   -- Name
    writeInt writer 0x3                 -- SHUT_STRTAB
    writeInt64 writer 0                 -- No flags
    writeInt64 writer 0                 -- No address
    writeInt64 writer 513                 -- Offset
    writeInt64 writer 18                 -- Size
    writeInt writer 0                   -- No link info
    writeInt writer 0                   -- No aux infor
    writeInt64 writer 1                 -- No alignment
    writeInt64 writer 0                 -- No entries
    
-- ================================================================
    -- The string table
    writeByte writer 0
    writeStr writer ".shstrtab\0"
    writeStr writer ".text\0"
    writeStr writer ".strtab\0"
    writeStr writer ".symtab\0"

-- ================================================================
    -- The symbol table (entries are 24-bytes long each)
    
    --Entry 0 (null entry)
    writeInt writer 0               -- Symbol name
    writeByte writer 0              -- Type attributes
    writeByte writer 0              -- Reserved
    writeShort writer 0             -- Section table index
    writeInt64 writer 0             -- Symbol value
    writeInt64 writer 0             -- Size of object
    
    --Entry 1 (file entry)
    writeInt writer 1               -- Symbol name
    writeByte writer 4              -- Type attributes
    writeByte writer 0              -- Reserved
    writeShort writer 0xFFF1             -- Section table index
    writeInt64 writer 0            -- Symbol value
    writeInt64 writer 0             -- Size of object
    
    --Section entry
    writeInt writer 0               -- Symbol name
    writeByte writer 3              -- Type attributes
    writeByte writer 0              -- Reserved
    writeShort writer 2             -- Section table index
    writeInt64 writer 0             -- Symbol value
    writeInt64 writer 0             -- Size of object
    
    --Start entry
    writeInt writer 11               -- Symbol name
    writeByte writer 16              -- Type attributes
    writeByte writer 0              -- Reserved
    writeShort writer 2             -- Section table index
    writeInt64 writer 0             -- Symbol value
    writeInt64 writer 0             -- Size of object
    
-- ================================================================
    -- The string table for the symbol table
    writeByte writer 0
    writeStr writer "first.asm\0"
    writeStr writer "_start\0"
    
-- ================================================================
    -- The code
    -- mov eax, 1
    writeByte writer 0xB8
    writeInt writer 1
    
    -- mov ebx, 5
    writeByte writer 0xBB
    writeInt writer 9
    
    -- int 0x80
    writeByte writer 0xCD
    writeByte writer 0x80

    
    hClose writer
