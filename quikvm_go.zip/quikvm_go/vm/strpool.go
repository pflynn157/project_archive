package main

import "fmt"

type StringPool struct {
	pool []string
	size int
	count int
}

//Sets up an empty array for our string pool
func (s* StringPool) Setup() {
	s.pool = make([]string, 100)
	s.size = 100
	s.count = 0
}

//Write a string to our pool
func (s* StringPool) Write(str string) {
	if (s.count+1) >= s.size {
		ls := s.size
		s.size += 100
		s2 := make([]string, s.size)
		
		for x := 0; x<ls; x++ {
			s2[x] = s.pool[x]
		}
		
		s.pool = s2
	}
	
	s.pool[s.count] = str
	s.count++
}

//Prints the string pool
func (s* StringPool) DbPool() {
	for x := 0; x<s.count; x++ {
		fmt.Println("DB:",s.pool[x])
	}
}
