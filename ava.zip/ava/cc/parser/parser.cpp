#include <ava/ast_builder.hpp>

#include "parser.hpp"
#include "../lex/lex.hpp"

//
// Constructors/destructors
//
Parser::Parser(std::string input) : BaseParser(input, new Scanner(input)) {
}

Parser::~Parser() {
}

//
// The main parsing function
//
bool Parser::parse() {
    Token token = scanner->getNext();
    while (token.type != Eof) {
        bool code = true;
        
        switch (token.type) {
            case Int: code = buildFunction(token); break;
            
            default: {
                syntax->addError(scanner->getLine(), "Invalid token in global scope.");
                code = false;
            }
        }
        
        if (!code) break;
        token = scanner->getNext();
    }
    
    // Check for errors
    if (syntax->errorsPresent()) {
        syntax->printErrors();
        return false;
    }
    
    syntax->printWarnings();

    return true;
}

//
// Builds a function
//
bool Parser::buildFunction(Token startToken) {
    AstDataType *dataType = buildDataType(startToken);

    // Function name
    Token token = scanner->getNext();
    std::string name = token.id_val;
    if (token.type != Id) {
        syntax->addError(scanner->getLine(), "Invalid function: expected name.");
        return false;
    }
    
    // Arguments
    token = scanner->getNext();
    if (token.type != LParen) {
        syntax->addError(scanner->getLine(), "Invalid function: expected \'(\'.");
        return false;
    }
    
    token = scanner->getNext();
    while (token.type != RParen) {
        token = scanner->getNext();
    }
    
    // Create the AST and then parse the block
    AstFunction *func = new AstFunction(name);
    func->setDataType(dataType);
    tree->addGlobalStatement(func);
    
    token = scanner->getNext();
    if (token.type != LCBrace) {
        syntax->addError(scanner->getLine(), "Invalid function: expected block.");
        return false;
    }
    
    buildBlock(func->getBlock());
    
    return true;
}

//
// Builds a block
//
bool Parser::buildBlock(AstBlock *block) {
    Token token = scanner->getNext();
    while (token.type != Eof && token.type != RCBrace) {
        bool code = true;
        switch (token.type) {
            case Int: code = buildVariableDec(block, token);
                break;
            case Return: code = buildReturn(block); break;
            
            default: {
                syntax->addError(scanner->getLine(), "Invalid token in block.");
                return false;
            }
        }
        
        if (!code) return false;
        token = scanner->getNext();
    }
    
    return true;
}

//
// Builds a variable declaration
//
bool Parser::buildVariableDec(AstBlock *block, Token startToken) {
    // First token should be identifier
    Token token = scanner->getNext();
    std::string name = token.id_val;
    if (token.type != Id) {
        syntax->addError(scanner->getLine(), "Invalid variable declaration: expected name.");
        return false;
    }

    // Check the next token
    scanner->rewind(token);

    // Build the data type
    AstDataType *dataType = buildDataType(startToken);

    // Build the AST nodes
    AstVarDec *vd = new AstVarDec(name, dataType);
    block->addStatement(vd);

    AstExprStatement *va = new AstExprStatement;
    va->setDataType(dataType);
    AstExpression *expr = buildExpression(dataType, SemiColon);
    va->setExpression(expr);
    block->addStatement(va);

    return true;
}

//
// Builds a return statement
//
bool Parser::buildReturn(AstBlock *block) {
    AstExpression *expr = buildExpression(AstBuilder::buildInt32Type(), SemiColon);

    AstReturnStmt *ret = new AstReturnStmt;
    ret->setExpression(expr);
    block->addStatement(ret);

    return true;
}

//
// Builds a data type from a given token
//
AstDataType *Parser::buildDataType(Token token) {
    switch (token.type) {
        case Int: return AstBuilder::buildInt32Type();
        
        default: {}
    }
    
    return nullptr;
}

