#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

int current_thr = 1;

void sp(int sec) {
	sec *= 1000000;
	usleep(sec);
}

void *thread1()
{
	printf("Thread %d\n", current_thr);
	sp(2);
	printf("Done 1\n");
}

void *thread2()
{
	printf("Thread %d\n", current_thr);
	sp(3);
	printf("Done 2\n");
}

void *thread3()
{
	printf("Thread %d\n", current_thr);
	sp(4);
	printf("Done 3\n");
}

void main()
{
	pthread_t id;
	
	pthread_create(&id, NULL, thread1, NULL);
	pthread_join(id, NULL);
	current_thr += 1;
	
	pthread_create(&id, NULL, thread2, NULL);
	pthread_join(id, NULL);
	current_thr += 1;
	
	pthread_create(&id, NULL, thread3, NULL);
	pthread_join(id, NULL);
}
