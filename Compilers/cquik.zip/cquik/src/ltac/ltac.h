#pragma once

typedef enum {
    LT_None,

    // Data types
    LT_StringL,
    
    // Code types
    LT_FuncDec,
    
    LT_KArg_I,      // Kernel argument (immediate)
    LT_Syscall
} LtacType;

struct LtacListNode;

// Represents a list of LtacNode's
typedef struct
{
    struct LtacListNode *head;
} LtacList;

// Represents a file
typedef struct
{
    const char *file_name;
    LtacList *data;
    LtacList *text;
} LtacFile;

// Represents a node
typedef struct
{
    LtacType type;
    
    const char *str_val1;
    int i_val1;
} LtacNode;

struct LtacListNode
{
    struct LtacListNode *next;
    LtacNode *element;
};

// Functions
LtacFile *ltac_create_file(const char *file_name);
LtacNode *ltac_create_node(LtacType type);

void ltac_add_code(LtacNode *code, LtacFile *file);

void ltac_print_file(LtacFile *file);

