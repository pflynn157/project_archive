## C Compiler

Welcome to my C compiler! This is a simple C compiler written in C++ and using LLVM for backend generation. The lexer, parser, and the AST are all written from scratch. In fact, this project is a fork of my Tiny Lang compiler.

### License

This program is licensed under the BSD-3 License.

