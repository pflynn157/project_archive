#include <stdio.h>

#include "debug.h"
#include "ast.h"

void print_data_type(DataType type)
{
    switch (type)
    {
        case None: printf("?? "); break;
        case Void: printf("void "); break;
        case Int: printf("int "); break;
    }
}

void print_stmt_type(StatementType type)
{
    switch (type)
    {
        case Ret: printf("return "); break;
        case RetVoid: printf("return_void "); break;
    }
}

void print_expr_type(ExprType type)
{
    switch (type)
    {
        case Empty: printf("?? "); break;
        case UnaryExpr: printf("unary_expr"); break;
    }
}

void print_ast(Ast *ast)
{
    printf("\nModule: %s\n\n", ast->mod_name);
    
    for (int i = 0; i<ast->func_count; i++)
    {
        Function *func = ast->funcs[i];
        print_data_type(func->type);
        printf("%s\n", func->name);
        printf("Block size: %d\n", func->block->line_count);
        
        Block *block = func->block;
        for (int j = 0; j<block->line_count; j++)
        {
            Expression *line = block->lines[j];
            
            printf("  ");
            print_stmt_type(line->stmt_type);
            print_expr_type(line->expr_type);
            
            printf("(");
            
            ExprNode **expr_list = line->expr_list;
            for (int k = 0; k<line->expr_count; k++)
            {
                ExprNode *current = expr_list[k];
                switch (current->type)
                {
                    case IntLiteral: printf("%d ", current->i32_literal); break;
                }
            }
            
            printf(")\n");
        }
    }
}
