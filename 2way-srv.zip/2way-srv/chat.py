import threading
import time
import os
import sys
from socket import *
from multiprocessing import Process
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *

toAdd = ""

class Window(QMainWindow):
	msgEntry = 0
	textEntry = 0
	
	def __init__(self):
		thread2 = Server()
		thread2.start()
	
		super().__init__()
		self.setWindowTitle("Chat")
		self.resize(600,500)
		
		mainWidget = QFrame()
		mainLayout = QVBoxLayout()
		mainLayout.setContentsMargins(0,0,0,0)
		mainWidget.setLayout(mainLayout)
		self.setCentralWidget(mainWidget)
		
		self.textEntry = QTextEdit()
		mainLayout.addWidget(self.textEntry)
		
		msgWidget = QFrame()
		msgLayout = QHBoxLayout()
		msgWidget.setLayout(msgLayout)
		mainLayout.addWidget(msgWidget)
		
		self.msgEntry = QLineEdit()
		self.msgEntry.returnPressed.connect(self.sendClicked)
		msgLayout.addWidget(self.msgEntry)
		
		sendBtn = QPushButton("Send")
		sendBtn.clicked.connect(self.sendClicked)
		msgLayout.addWidget(sendBtn)
		
		thread2.msgIn.connect(self.onToAdd)
		
	def sendClicked(self):
		toSend = self.msgEntry.text()
		send_data(toSend)
		self.msgEntry.setText("")
		
		txt = self.textEntry.toHtml()
		txt += "\n"
		txt += toSend
		self.textEntry.setText(txt)
		
	def onToAdd(self, msg):
		txt = self.textEntry.toHtml()
		txt += msg
		self.textEntry.setText(txt)

def send_data(data):
	#The IP address of your friends computer
	host = "192.168.254.15" 
	port = 8100
	addr = (host, port)

	UDPSock = socket(AF_INET, SOCK_DGRAM)
	
	UDPSock.sendto(data.encode(), addr)
	if data == "exit":
		UDPSock.close()
		os._exit(0)
		
class Server(QThread):
	msgIn = pyqtSignal(str)

	def run(self):
		#The IP address of your computer
		host = "192.168.0.12"
		port = 7478
		buf = 1024

		address = (host, port)
		UDPSock = socket(AF_INET, SOCK_DGRAM)
		UDPSock.bind(address)

		while True:
			(data, address) = UDPSock.recvfrom(buf)
			
			toAdd = "\n<b>Friend:</b> "
			toAdd += str(data.decode())
			
			if data == b"exit":
				break
				
			self.msgIn.emit(toAdd)

		UDPSock.close()
		os._exit(0)
	
if __name__ == "__main__":
	app = QApplication(sys.argv)
	win = Window()
	win.show()
	sys.exit(app.exec_())
