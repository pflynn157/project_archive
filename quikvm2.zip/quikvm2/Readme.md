## Quikvm2

This is a new version of my QuikVM program in Haskell. If it matures enough, I may supercede the original with it, but I'm not sure. Currently, this is just a fun learning project.
