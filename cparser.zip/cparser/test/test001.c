#include <stdio.h>

int main() {
    int x = 20;
    puts("Hello!");
    
    printf("%d\n", x);
    
    return 0;
}
