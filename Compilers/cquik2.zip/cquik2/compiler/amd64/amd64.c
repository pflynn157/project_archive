#include <stdio.h>
#include <stdlib.h>

#include <amd64/amd64.h>
#include <ltac/ltac.h>
#include <sym_table.h>

// Our symbol table
SymbolTable *vars;
int stack_pos = 0;

// Register information
static char call_args32[2][4] = {
    "edi",
    "esi"
};

static char call_args[2][4] = {
    "rdi",
    "rsi"
};

int reg_index = 0;

// Builds a pusharg statement
void amd64_pusharg(LtacInstr *code, FILE *writer)
{
    switch (code->int_val1)
    {
        case T_Const: break;
        case T_Addr: break;

        case T_NameAddr:
        {
            fprintf(writer, "  lea %s, %s\n", call_args + reg_index, code->str_val2);
            ++reg_index;
        } break;

        case T_Reg: break;
    }
}

// Builds a function call statement
void amd64_func_call(LtacInstr *code, FILE *writer)
{
    fprintf(writer, "  call %s\n\n", code->str_val1);
    reg_index = 0;
}

// Builds a return statement
void amd64_return(LtacInstr *code, FILE *writer)
{
    switch (code->int_val1)
    {
        case OP_Imm: fprintf(writer, "  mov eax, %d\n", code->int_val2); break;
        case OP_Var: break;
        case OP_Reg: break;
    }

    fputs("  ret\n", writer);
}

// Builds a variable declaration
void amd64_var_dec(LtacInstr *instr)
{
    int size = 1;

    switch (instr->int_val1)
    {
        case T_Int: size = 4; break;
        case T_Float:
        case T_String: size = 8; break;
        default: size = 1;
    }

    stack_pos += size;
    sym_table_add(vars, instr->str_val1, stack_pos);
}

// Integer variable assignment
void amd64_ivar_assign(LtacInstr *instr, FILE *writer)
{
    int loco = sym_table_get(vars, instr->str_val1);

    switch (instr->int_val1)
    {
        case OP_Imm:
        {
            fprintf(writer, "  mov DWORD PTR [rbp-%d], %d\n", loco, instr->int_val2);
        } break;

        case OP_Var: break;
        case OP_Reg: break;
    }
}

// Converts an LTAC instruction to an x64 instruction
void amd64_assemble_code(LtacInstr *code, FILE *writer)
{
    switch (code->type)
    {
        case LT_Func:
        {
            stack_pos = 0;
            fprintf(writer, "\n.globl %s\n", code->str_val1);
            fprintf(writer, "%s:\n", code->str_val1);
        } break;

        case LT_PushArg: amd64_pusharg(code, writer); break;
        case LT_FuncCall: amd64_func_call(code, writer); break;

        case LT_Return: amd64_return(code, writer); break;

        case LT_VarDec: amd64_var_dec(code); break;
        case LT_IVarAssign: amd64_ivar_assign(code, writer); break;
    }
}

// Converts an LTAC data instruction to Assembly
void amd64_assemble_data(LtacData *data, FILE *writer)
{
    switch (data->type)
    {
        case LD_String:
        {
            fprintf(writer, "  %s: .string %s\n", data->name, data->value);
        } break;

        //TODO: The rest
    }
}

// The main assembly function for the x86-64 architecture
void amd64_assemble(LtacFile *file)
{
    FILE *writer = fopen(file->file_name, "w");

    LtacData **data = file->data;
    int data_size = file->data_loco;

    LtacInstr **code = file->code;
    int code_size = file->code_loco;

    vars = sym_table_init_default();

    fputs(".intel_syntax noprefix\n", writer);
    fputs(".data\n", writer);

    for (int i = 0; i<data_size; i++)
        amd64_assemble_data(data[i], writer);

    fputs("\n", writer);
    fputs(".text\n", writer);

    for (int i = 0; i<code_size; i++)
        amd64_assemble_code(code[i], writer);

    fclose(writer);
    free(vars);
}
