## Zipper

Zipper is a simple application for viewing zip files. It uses libzip as its backend. The program is still in its very early stages of development, so its not ready to be used in a production environment.
