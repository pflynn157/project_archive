function isPrime(no) {
	if (no%2 == 0 || no%3 == 0 || no%5 == 0 || no%7 == 0) {
		return false;
	} else {
		var sqr = Math.sqrt(no);
		for (var i = 5; i<sqr; i+=6) {
			if (no%i==0 || no%(i+2)==0) {
				return false;
			}
		}
		return true;
	}
}

function findPrime() {
	var input = document.getElementById("in").value;
	if (isPrime(input)) {
		setOutput("Prime");
	} else {
		setOutput("Not Prime");
	}
}
