#include <algorithm>

#include <ava/parser.hpp>
#include <ava/ast_builder.hpp>

BaseParser::BaseParser(std::string input, BaseScanner *scanner) {
    this->input = input;
    this->scanner = scanner;
    
    tree = new AstTree(input);
    syntax = new ErrorManager;
}

BaseParser::~BaseParser() {
    delete scanner;
    delete syntax;
}

//
// Expression builders
//
bool BaseParser::buildOperator(Token token, ExprContext *ctx) {
    if (!isOperator(token.type)) return true;
    
    AstOp *op = buildAstOperator(token.type, ctx->lastWasOp);
    if (!op) return false;
    
    if (ctx->opStack.size() > 0 && op->isBinaryOp()) {
        AstOp *top = ctx->opStack.top();
        if (top->isBinaryOp()) {
            AstBinaryOp *op1 = static_cast<AstBinaryOp *>(op);    
            AstBinaryOp *op2 = static_cast<AstBinaryOp *>(top);
            if (op1->getPrecedence() > op2->getPrecedence()) {
                if (!applyHigherPred(ctx)) return false;
            }
        }
    }
    
    ctx->opStack.push(op);
    ctx->lastWasOp = true;

    return true;        
}

// Applies higher precedence for an operator
bool BaseParser::applyHigherPred(ExprContext *ctx) {
    if (ctx->output.empty()) {
        syntax->addError(scanner->getLine(), "Invalid expression: No RVAL");
        return false;
    }
    AstExpression *rval = checkExpression(ctx->output.top(), ctx->varType);
    ctx->output.pop();
    
    if (ctx->output.empty()) {
        syntax->addError(scanner->getLine(), "Invalid expression: No LVAL");
        return false;
    }
    AstExpression *lval = checkExpression(ctx->output.top(), ctx->varType);
    ctx->output.pop();
    
    AstBinaryOp *op = static_cast<AstBinaryOp *>(ctx->opStack.top());
    ctx->opStack.pop();
    
    op->setLVal(lval);
    op->setRVal(rval);
    ctx->output.push(op);
    
    return true;
}

// Applies operator associativity
bool BaseParser::applyAssoc(ExprContext *ctx) {
    V_AstType lastOp = V_AstType::None;
    while (ctx->opStack.size() > 0) {
        if (ctx->output.empty()) {
            syntax->addError(scanner->getLine(), "Invalid expression: No RVAL");
            return false;
        }
        AstExpression *rval = checkExpression(ctx->output.top(), ctx->varType);
        ctx->output.pop();
        
        if (ctx->output.empty()) {
            syntax->addError(scanner->getLine(), "Invalid expression: No LVAL");
            return false;
        }
        AstExpression *lval = checkExpression(ctx->output.top(), ctx->varType);
        ctx->output.pop();
        
        AstBinaryOp *op = static_cast<AstBinaryOp *>(ctx->opStack.top());
        ctx->opStack.pop();
        
        if (op->getType() == lastOp) {
            AstBinaryOp *op2 = static_cast<AstBinaryOp *>(rval);
            
            rval = op2->getRVal();
            op2->setRVal(op2->getLVal());
            op2->setLVal(lval);
            
            lval = op2;
        }
        
        op->setLVal(lval);
        op->setRVal(rval);
        ctx->output.push(op);
        
        lastOp = op->getType();
    }
    
    return true;
}

// This is meant mainly for literals; it checks to make sure all the types in
// the expression agree in type. LLVM will have a problem if not
AstExpression *BaseParser::checkExpression(AstExpression *expr, AstDataType *varType) {
    if (!varType) return expr;

    switch (expr->getType()) {
        case V_AstType::I32L: {
            // Change to byte literals
            if (varType->getType() == V_AstType::Int8) {
                AstI32 *i32 = static_cast<AstI32 *>(expr);
                AstI8 *byte = new AstI8(i32->getValue());
                expr = byte;
                
            // Change to word literals
            } else if (varType->getType() == V_AstType::Int16) {
                AstI32 *i32 = static_cast<AstI32 *>(expr);
                AstI16 *i16 = new AstI16(i32->getValue());
                expr = i16;
                
            // Change to qword literals
            } else if (varType->getType() == V_AstType::Int64) {
                AstI32 *i32 = static_cast<AstI32 *>(expr);
                AstI64 *i64 = new AstI64(i32->getValue());
                expr = i64;
            }
        } break;
            
        default: {}
    }
    
    return expr;
}

// Our new expression builder
AstExpression *BaseParser::buildExpression(AstDataType *currentType, int stopToken, bool isConst, bool buildList) {
    ExprContext *ctx = new ExprContext;
    if (currentType) ctx->varType = currentType;
    else ctx->varType = AstBuilder::buildVoidType();
    
    AstExprList *list = new AstExprList;
    bool isList = buildList;
    
    Token token = scanner->getNext();
    while (!isEofToken(token.type) && token.type != stopToken) {
        if (isConstLiteral(token.type)) {
            ctx->lastWasOp = false;
            AstExpression *expr = buildConstExpr(token);
            ctx->output.push(expr);
        } else if (isIdentifier(token.type)) {
            if (!buildIDExpr(token, ctx)) return nullptr;
        } else if (isOperator(token.type)) {
            if (!buildOperator(token, ctx)) {
                return nullptr;
            }
        } else if (isSubExprStart(token.type)) {
            AstExpression *subExpr = buildExpression(ctx->varType, getSubExprStop(), false, isList);
            if (!subExpr) {
                return nullptr;
            }
            ctx->output.push(subExpr);
            ctx->lastWasOp = false;
        } else if (isSubExprStop(token.type)) {
            // TODO: Syntax check
        } else if (isListItemSeparator(token.type)) {
            applyAssoc(ctx);
            AstExpression *expr = checkExpression(ctx->output.top(), ctx->varType);
            list->addExpression(expr);
            while (ctx->output.size() > 0) ctx->output.pop();
            while (ctx->opStack.size() > 0) ctx->opStack.pop();
            isList = true;
        } else {
            syntax->addError(scanner->getLine(), "Invalid token in expression.");
            return nullptr;
        }
        
        if (!ctx->lastWasOp && ctx->opStack.size() > 0) {
            if (ctx->opStack.top()->getType() == V_AstType::Neg) {
                AstExpression *val = checkExpression(ctx->output.top(), ctx->varType);
                ctx->output.pop();
                
                AstNegOp *op = static_cast<AstNegOp *>(ctx->opStack.top());
                ctx->opStack.pop();
                op->setVal(val);
                ctx->output.push(op);
            }
        }
        
        token = scanner->getNext();
    }
    
    if (isEofToken(token.type)) {
        syntax->addError(scanner->getLine(), "Invalid expression-> missing \';\'.");
        return nullptr;
    }
    
    // Build the expression
    applyAssoc(ctx);
    
    
    if (ctx->output.size() == 0) {
        return list;
    }
    
    // Type check the top
    AstExpression *expr = checkExpression(ctx->output.top(), ctx->varType);
    
    if (isList) {
        list->addExpression(expr);
        return list;
    }
    return expr;
}

//
// Checks to see if a string is a constant
//
int BaseParser::isConstant(std::string name) {
    if (globalConsts.find(name) != globalConsts.end()) {
        return 1;
    }
    
    if (localConsts.find(name) != localConsts.end()) {
        return 2;
    }
    
    return 0;
}

//
// Checks to see if a string is a variable
//
bool BaseParser::isVar(std::string name) {
    if (std::find(vars.begin(), vars.end(), name) != vars.end()) {
        return true;
    }
    return false;
}

//
// Checks to see if a string is a function
//
bool BaseParser::isFunc(std::string name) {
    if (std::find(funcs.begin(), funcs.end(), name) != funcs.end()) {
        return true;
    }
    return false;
}

