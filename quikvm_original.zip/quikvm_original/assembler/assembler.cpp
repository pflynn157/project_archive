#include <iostream>
#include <fstream>
#include <string>
#include <vector>

#include <bytecode.hh>

#include "assembler.hh"
#include "str.hh"

//File content
std::vector<std::string> contents;

//Objects needed for pass one
int lblCounter = 0;
std::vector<std::string> labels;

int ivarCounter = 0;
std::vector<std::string> ivars;
	
//Pass one
void pass1(std::ofstream *writer) {
	for (auto ln : contents) {
		auto cmd = get_first(ln);
		
		if (cmd == "lbl") {
			auto name = get_second(ln);
			labels.push_back(name);
			++lblCounter;
		} else if (cmd == "i_var") {
			auto name = get_second(ln);
			ivars.push_back(name);
			ivarCounter++;
		}
	}
}

//Returns the location of a particular label
int lbl_loco(std::string name) {
	for (int i = 0; i<lblCounter; i++) {
		if (labels[i] == name) {
			return i;
		}
	}
	
	return -1;
}

//Returns the location of a particular variable
int ivar_loco(std::string name) {
	for (int i = 0; i<ivarCounter; i++) {
		if (ivars[i] == name) {
			return i;
		}
	}
	
	return -1;
}

//Builds our binary
void build(const char *path) {
	//Create the output file name
	auto base = get_base(std::string(path));
	base += ".bin";

	//Set up the output
	std::ifstream reader(path);
	std::ofstream writer(base.c_str(), std::ios::binary);
	std::string line = "";
	
	if (!reader.is_open()) {
		std::cout << "Fatal: Unable to open input!" << std::endl;
		std::exit(1);
	}
	
	writer << header;
	
	//Load the file
	while (std::getline(reader, line)) {
		contents.push_back(line);
	}
	
	//Run pass 1
	pass1(&writer);
	
	//Parse!
	for (auto ln : contents) {
		auto cmd = get_first(ln);
		
		unsigned char opcode = 0;
		unsigned char type = 0x00;
		int operand = 0;
		std::string str_operand = "";
		
		if (cmd == "i_load") {
			operand = std::stoi(get_second(ln));
			opcode = ByteCode::I_LOAD;
			type = ByteCode::TYPE_INT;
			
		} else if (cmd == "i_add") {
			opcode = ByteCode::I_ADD;
			type = ByteCode::TYPE_INT;
			
		} else if (cmd == "i_sub") {
			opcode = ByteCode::I_SUB;
			type = ByteCode::TYPE_INT;
			
		} else if (cmd == "i_mul") {
			opcode = ByteCode::I_MUL;
			type = ByteCode::TYPE_INT;
			
		} else if (cmd == "i_div") {
			opcode = ByteCode::I_DIV;
			type = ByteCode::TYPE_INT;
			
		} else if (cmd == "i_mod") {
			opcode = ByteCode::I_MOD;
			type = ByteCode::TYPE_INT;
			
		} else if (cmd == "i_print") {
			opcode = ByteCode::I_PRINT;
			type = ByteCode::TYPE_INT;
			
		} else if (cmd == "i_input") {
			opcode = ByteCode::I_INPUT;
			type = ByteCode::TYPE_INT;
			
		} else if (cmd == "i_var") {
			opcode = ByteCode::I_VAR;
			type = ByteCode::TYPE_INT;
			
		} else if (cmd == "i_store") {
			opcode = ByteCode::I_STORE;
			auto name = get_second(ln);
			operand = ivar_loco(name);
			type = ByteCode::TYPE_INT;
			
		} else if (cmd == "i_load_var") {
			opcode = ByteCode::I_LOAD_VAR;
			auto name = get_second(ln);
			operand = ivar_loco(name);
			type = ByteCode::TYPE_INT;
			
		} else if (cmd == "s_load") {
			auto s_operand = get_second(ln);
			s_operand = rm_quotes(s_operand);
			int len = s_operand.length();
			
			opcode = ByteCode::S_LOAD;
			operand = len;
			str_operand = s_operand;
		
		} else if (cmd == "s_print") {
			opcode = ByteCode::S_PRINT;
			
		} else if (cmd == "d_load") {
			opcode = ByteCode::D_LOAD;
			type = ByteCode::TYPE_DEC;
			
		} else if (cmd == "d_print") {
			opcode = ByteCode::D_PRINT;
			type = ByteCode::TYPE_DEC;
			
		} else if (cmd == "lbl") {
			auto name = get_second(ln);
			operand = lbl_loco(name);
			opcode = ByteCode::LBL;
			
		} else if (cmd == "jmp") {
			auto name = get_second(ln);
			operand = lbl_loco(name);
			opcode = ByteCode::JMP;
			
		} else if (cmd == "je") {
			auto name = get_second(ln);
			operand = lbl_loco(name);
			opcode = ByteCode::JE;
		
		} else if (cmd == "jne") {
			auto name = get_second(ln);
			operand = lbl_loco(name);
			opcode = ByteCode::JNE;
			
		} else if (cmd == "i_cmp") {
			operand = std::stoi(get_second(ln));
			opcode = ByteCode::I_CMP;
			type = ByteCode::TYPE_INT;
			
		} else if (cmd == "exit") {
			opcode = ByteCode::EXIT;
			
		} else {
			std::cout << "Fatal: Invalid operation." << std::endl;
			std::cout << ln << std::endl;
			std::exit(1);
		}
		
		writer << (unsigned char)opcode;
		writer << (unsigned char)type;
		writer.write(reinterpret_cast<const char *>(&operand), sizeof(int));
		
		if (str_operand != "") {
			writer.write(str_operand.c_str(), str_operand.length());
		}
	}
	
	reader.close();
	writer.close();
}
