#pragma once

#include <fstream>
#include <string>
#include <stack>

#include <ava/lex.hpp>

// Represents a token
enum TokenType {
    EmptyToken,
    Eof,
    
    Extern,
    Func,
    Struct,
    End,
    Return,
    VarD,
    Const,
    Bool,
    Char,
    Str,
    I8,
    U8,
    I16,
    U16,
    I32,
    U32,
    I64,
    U64,
    If,
    Elif,
    Else,
    While,
    Is,
    Then,
    Do,
    Break,
    Continue,
    Import,
    True,
    False,
    Logical_And,
    Logical_Or,
    Dot,
    SemiColon,
    Comma,
    LParen,
    RParen,
    LBracket,
    RBracket,
    Plus,
    Minus,
    Arrow,
    Mul,
    Div,
    And,
    Or,
    Xor,
    Colon,
    Assign,
    GT,
    GTE,
    LT,
    LTE,
    EQ,
    NEQ,
    
    // Literals
    Id,
    String,
    CharL,
    Int32
};

// The main lexical analysis class
class Scanner : public BaseScanner {
public:
    explicit Scanner(std::string input);
    ~Scanner();
    
    void rewind(Token token) override;
    Token getNext() override;
    
    std::string getRawBuffer() override;
    int getLine() override { return currentLine; }
    
    bool isEof() override { return reader.eof(); }
    bool isError() override { return error; }
private:
    std::stack<Token> token_stack;
    
    // Control variables for the scanner
    std::string rawBuffer = "";
    std::string buffer = "";
    bool inQuote = false;
    int currentLine = 1;
    bool skipNextLineCount = false;
    
    // Functions
    bool isSymbol(char c);
    TokenType getKeyword();
    TokenType getSymbol(char c);
    bool isInt();
    bool isHex();
};

