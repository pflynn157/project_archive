//
// Copyright 2021-2022 Patrick Flynn
// This file is part of the Tiny Lang compiler.
// Tiny Lang is licensed under the BSD-3 license. See the COPYING file for more information.
//
#include <iostream>

#include <tlc/parser.hpp>
#include <ava/ast.hpp>
#include <ava/ast_builder.hpp>

bool Parser::isEofToken(int token) {
    if (token == Eof) return true;
    return false;
}

bool Parser::isOperator(int token) {
    switch (token) {
        case Assign:
        case Plus: 
        case Minus:
        case Mul:
        case Div:
        case And:
        case Or:
        case Xor:
        case EQ:
        case NEQ:
        case GT:
        case LT:
        case GTE:
        case LTE:
        case Logical_And:
        case Logical_Or: return true;
        
        default: {}
    }
    
    return false;
}

bool Parser::isConstLiteral(int token) {
    switch (token) {
        case True:
        case False:
        case CharL:
        case Int32:
        case String: return true;
        
        default: {}
    }
    
    return false;
}

bool Parser::isIdentifier(int token) {
    if (token == Id) return true;
    return false;
}

bool Parser::isSubExprStart(int token) {
    if (token == LParen) return true;
    return false;
}

bool Parser::isSubExprStop(int token) {
    if (token == RParen) return true;
    return false;
}

bool Parser::isListItemSeparator(int token) {
    if (token == Comma) return true;
    return false;
}

int Parser::getSubExprStop() {
    return RParen;
}

AstOp *Parser::buildAstOperator(int token, bool lastWasOp) {
    switch (token) {
        case Assign: return new AstAssignOp;
        case Plus: return new AstAddOp;
        case Mul: return new AstMulOp;
        case Div: return new AstDivOp;
        case And: return new AstAndOp;
        case Or: return new AstOrOp;
        case Xor: return new AstXorOp;
        case EQ: return new AstEQOp;
        case NEQ: return new AstNEQOp;
        case GT: return new AstGTOp;
        case LT: return new AstLTOp;
        case GTE: return new AstGTEOp;
        case LTE: return new AstLTEOp;
        case Logical_And: return new AstLogicalAndOp;
        case Logical_Or: return new AstLogicalOrOp;
        case Minus: {
            if (lastWasOp) {
                return new AstNegOp;
            } else {
                return new AstSubOp;
            }
        }
        
        default: {}
    }
    
    return nullptr;
}

// Builds a constant expression value
AstExpression *Parser::buildConstExpr(Token token) {
    switch (token.type) {
        case True: return new AstI32(1);
        case False: return new AstI32(0);
        case CharL: return new AstChar(token.i8_val);
        case Int32: return new AstI32(token.i32_val);
        case String: return new AstString(token.id_val);
        
        default: {}
    }
    
    return nullptr;
}

bool Parser::buildIDExpr(Token token, ExprContext *ctx) {
    ctx->lastWasOp = false;
    int currentLine = scanner->getLine();

    std::string name = token.id_val;
    if (ctx->varType && ctx->varType->getType() == V_AstType::Void) {
        ctx->varType = typeMap[name];
        if (ctx->varType && ctx->varType->getType() == V_AstType::Ptr)
            ctx->varType = static_cast<AstPointerType *>(ctx->varType)->getBaseType();
    }
    
    token = scanner->getNext();
    if (token.type == LBracket) {
        //AstExpression *index = nullptr;
        //buildExpression(nullptr, DataType::I32, RBracket, EmptyToken, &index);
        AstExpression *index = buildExpression(AstBuilder::buildInt32Type(), RBracket);
        
        AstArrayAccess *acc = new AstArrayAccess(name);
        acc->setIndex(index);
        ctx->output.push(acc);
    } else if (token.type == LParen) {
        if (currentLine != scanner->getLine()) {
            syntax->addWarning(scanner->getLine(), "Function call on newline- possible logic error.");
        }
        
        if (!isFunc(name)) {
            syntax->addError(scanner->getLine(), "Unknown function call.");
            return false;
        }
    
        AstFuncCallExpr *fc = new AstFuncCallExpr(name);
        AstExpression *args = buildExpression(ctx->varType, RParen, false, true);
        fc->setArgExpression(args);
        
        ctx->output.push(fc);
    } else if (token.type == Dot) {
        // TODO: Search for structures here

        Token idToken = scanner->getNext();
        if (idToken.type != Id) {
            syntax->addError(scanner->getLine(), "Expected identifier.");
            return false;
        }
        
        AstStructAccess *val = new AstStructAccess(name, idToken.id_val);
        ctx->output.push(val);
    } else {
        int constVal = isConstant(name);
        if (constVal > 0) {
            if (constVal == 1) {
                AstExpression *expr = globalConsts[name].second;
                ctx->output.push(expr);
            } else if (constVal == 2) {
                AstExpression *expr = localConsts[name].second;
                ctx->output.push(expr);
            }
        } else {
            if (isVar(name)) {
                AstID *id = new AstID(name);
                ctx->output.push(id);
            } else {
                syntax->addError(scanner->getLine(), "Unknown variable.");
                return false;
            }
        }
        
        scanner->rewind(token);
    }
    return true;
}

