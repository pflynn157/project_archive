//
// Copyright 2021 Patrick Flynn
// This file is part of the Tiny Lang compiler.
// Tiny Lang is licensed under the BSD-3 license. See the COPYING file for more information.
//
#include <iostream>

#include <lex/Lex.hpp>

void Token::print() {
    switch (type) {
        case EmptyToken: std::cout << "?? "; break;
        case Eof: std::cout << "EOF "; break;
        
        case Extern: std::cout << "EXTERN "; break;
        case Struct: std::cout << "STRUCT "; break;
        case Return: std::cout << "RETURN "; break;
        case Const: std::cout << "CONST "; break;
        case If: std::cout << "IF"; break;
        case Else: std::cout << "ELSE"; break;
        case While: std::cout << "WHILE"; break;
        case Break: std::cout << "BREAK"; break;
        case Continue: std::cout << "CONTINUE"; break;
        case Import: std::cout << "IMPORT"; break;
        
        case Id: std::cout << "ID "; break;
        case Int32: std::cout << "I32 "; break;
        
        case Nl: std::cout << "\\n "; break;
        case SemiColon: std::cout << "; "; break;
        case Assign: std::cout << ":= "; break;
        case LParen: std::cout << "("; break;
        case RParen: std::cout << ")"; break;
        case LBracket: std::cout << "["; break;
        case RBracket: std::cout << "]"; break;
        case Comma: std::cout << ", "; break;
        case Dot: std::cout << ". "; break;
        
        case Plus: std::cout << "+ "; break;
        case Minus: std::cout << "- "; break;
        case Mul: std::cout << "* "; break;
        case Div: std::cout << "/ "; break;
        
        case EQ: std::cout << "== "; break;
        case NEQ: std::cout << "!= "; break;
        case GT: std::cout << "> "; break;
        case LT: std::cout << "< "; break;
        case GTE: std::cout << ">= "; break;
        case LTE: std::cout << "<= "; break;
        
        default: {}
    }
    
    std::cout << id_val << " ";
    std::cout << i32_val << " ";
    
    std::cout << std::endl;
}

