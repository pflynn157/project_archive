module Elf(loadFile, writeBody, createHeader) where

import System.IO
import Data.Binary
import Data.Int
import Data.Char

import Reader
import Writer

-- Loads a binary file into a byte list
loadFileLoop reader list = do
    isEOF <- hIsEOF reader
    if isEOF
        then return (reverse list)
        else do
            byte <- readByte reader
            loadFileLoop reader (byte : list)

loadFile path = do
    reader <- openBinaryFile path ReadMode
    bytes <- loadFileLoop reader []
    hClose reader
    return bytes
    
-- Writes the body of an ELF file
writeBody writer [] = return ()
writeBody writer (x:xs) = do
    hPutChar writer x
    writeBody writer xs

writeBuf writer 7 = return()
writeBuf writer i = do
    writeByte writer 0x00
    writeBuf writer (i + 1)

-- Creates the ELF and program header
createHeader writer dataSize = do
    let index = 120 + dataSize
    let absIndex = 4194304 + index

    -- The header
    writeInt writer 0x464c457F          -- The Magic number
    writeByte writer 0x02               -- 64-bit
    writeByte writer 0x01               -- LSB encoding
    writeByte writer 0x01               -- ELF version 1
    writeByte writer 0x00               -- OS ABI version
    writeByte writer 0x00               -- ABI version
    
    writeBuf writer 0                   -- The buffer
    
    writeShort writer 0x02              -- Object type- 2 is executable
    writeShort writer 0x3e              -- Architecture type
    writeInt writer 1                   -- ELF version
    
    writeInt64 writer absIndex          -- Start address to execute
    writeInt64 writer 64                -- Program header start
    
    writeInt64 writer 0                 -- Section header table offset
    writeInt writer 0
    writeShort writer 64                -- ELF header size
    writeShort writer 56                -- Program header size
    writeShort writer 1                 -- 1 program header
    
    --The sections
    writeShort writer 0
    writeShort writer 0
    writeShort writer 0
    
    -- The program header
    writeInt writer 1
    writeInt writer 5
    
    writeInt64 writer index         -- The index of the ELF where the segment starts
    writeInt64 writer absIndex      -- Virtual program start
    writeInt64 writer 0             -- Physical address- ignore
    
    writeInt64 writer 132           -- File size in bytes
    writeInt64 writer 132           -- Segment size in bytes
    writeInt64 writer 1

