
#include <gio/gio.h>

#include "editor.h"

void editor_modified(GtkTextBuffer *buffer, gpointer *data)
{
    Editor *edit = (Editor *)data;
    edit->modified = 1;
}

Editor *create_editor()
{
    GtkWidget *editor, *scrollView;
    
    editor = gtk_source_view_new();
    gtk_source_view_set_show_line_numbers(GTK_SOURCE_VIEW(editor), 1);
    
    scrollView = gtk_scrolled_window_new(NULL, NULL);
    gtk_container_add(GTK_CONTAINER(scrollView), editor);
    
    Editor *edit = (Editor *)malloc(sizeof(Editor));
    edit->editor = editor;
    edit->scrollView = scrollView;
    edit->srcFile = NULL;
    edit->modified = 0;
    
    GtkTextBuffer *buffer;
    buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(editor));
    
    g_signal_connect(G_OBJECT(buffer), "changed", G_CALLBACK(editor_modified), (gpointer *)edit);
    
    return edit;
}

void set_editor_syntax_highlighter(Editor *edit, const char *id)
{
    GtkTextBuffer *buffer;
    buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(edit->editor));
    
    GtkSourceLanguageManager *manager = gtk_source_language_manager_new();
    GtkSourceLanguage *lang = gtk_source_language_manager_get_language(manager, id);
    gtk_source_buffer_set_language(GTK_SOURCE_BUFFER(buffer), lang);
}

void editor_load_file(Editor *edit, const char *path)
{
    if (edit->srcFile == NULL)
    {
        edit->srcFile = gtk_source_file_new();
    }

    GFile *gPath = g_file_new_for_path(path);
    gtk_source_file_set_location(edit->srcFile, gPath);
    
    GtkTextBuffer *buffer;
    buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(edit->editor));
    
    GtkSourceFileLoader *loader;
    loader = gtk_source_file_loader_new(GTK_SOURCE_BUFFER(buffer), edit->srcFile);
    
    gtk_source_file_loader_load_async(loader, G_PRIORITY_DEFAULT, NULL, NULL,
        NULL, NULL, NULL, NULL);
}

void editor_save_file(Editor *edit)
{
    if (edit->srcFile == NULL)
    {
        puts("Save-as");
        return;
    }
    
    GtkTextBuffer *buffer;
    buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(edit->editor));
    
    GtkSourceFileSaver *saver;
    saver = gtk_source_file_saver_new(GTK_SOURCE_BUFFER(buffer), edit->srcFile);
    
    gtk_source_file_saver_save_async(saver, G_PRIORITY_DEFAULT, NULL, NULL,
        NULL, NULL, NULL, NULL);
}

