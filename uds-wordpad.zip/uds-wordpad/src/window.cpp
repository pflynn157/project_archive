//
// Copyright 2021 Patrick Flynn
// This file is part of uds-wordpad.
// uds-wordpad is licensed under the BSD-3 license. See the COPYING file for more information.
//
#include <QMessageBox>
#include <QPixmap>

#include <window.hpp>

Window::Window() {
    this->setWindowTitle("Wordpad");
    this->setWindowIcon(QPixmap(":/icons/uds-wordpad.svg"));
    this->resize(700, 500);
    
    main_toolbar = new MainToolbar;
    this->addToolBar(main_toolbar);
    
    format_toolbar = new FormatToolbar;
    this->addToolBar(format_toolbar);
    
    tabwidget = new TabWidget;
    this->setCentralWidget(tabwidget);
    
    initMenuBar();
    initStatusBar();
}

void Window::setCurrentFile(QString path) {
    currentFile->setText(path);
}

void Window::setCurrentSaved(bool saved) {
    if (saved) currentStatus->setText("saved");
    else currentStatus->setText("unsaved");
}

void Window::closeEvent(QCloseEvent *event) {
    int count = tabwidget->count();
    bool anyUnsaved = false;
    
    for (int i = 0; i<count; i++) {
        Editor *edit = static_cast<Editor *>(tabwidget->widget(i));
        if (!edit->isSaved()) {
            anyUnsaved = true;
            break;
        }
    }
    
    if (!anyUnsaved) {
        event->accept();
        return;
    }
    
    QMessageBox prompt;
    prompt.setText("You have modified files.");
    prompt.setInformativeText("Do you wish to save?");
    prompt.setStandardButtons(QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);
    prompt.setDefaultButton(QMessageBox::Save);
    int choice = prompt.exec();
    
    if (choice == QMessageBox::Discard) {
        event->accept();
        return;
    } else if (choice == QMessageBox::Cancel) {
        event->ignore();
        return;
    }
    
    Actions actions;
    for (int i = 0; i<count; i++) {
        tabwidget->setCurrentIndex(i);
        
        Editor *edit = tabwidget->getCurrentWidget();
        if (!edit->isSaved()) actions.saveFile();
    }
    
    event->accept();
}

void Window::initMenuBar() {
    menubar = new QMenuBar;
    
    file_menu = new FileMenu;
    menubar->addMenu(file_menu);
    
    edit_menu = new EditMenu;
    menubar->addMenu(edit_menu);
    
    help_menu = new HelpMenu;
    menubar->addMenu(help_menu);
    
    this->setMenuBar(menubar);
}

void Window::initStatusBar() {
    currentFile = new QLabel("untitled");
    currentStatus = new QLabel("saved");

    statusbar = new QStatusBar;
    statusbar->addPermanentWidget(currentStatus);
    statusbar->addPermanentWidget(currentFile);
    this->setStatusBar(statusbar);
}

Window::~Window() {
    delete main_toolbar;
    delete format_toolbar;
    delete tabwidget;
    delete menubar;
    delete file_menu;
    delete edit_menu;
    delete help_menu;
}

