#include <window.hpp>

Window::Window()
    : tabs(new QTabWidget),
      accounts(new AccountsWidget)
{
    this->setWindowTitle("Expense Tracker");
    this->resize(700, 500);
    
    tabs->addTab(accounts, "Accounts");
    tabs->addTab(new QWidget, "Budget");
    tabs->addTab(new QWidget, "Monthly Expenses");
    tabs->addTab(new QWidget, "One-Time Expenses");
    
    this->setCentralWidget(tabs);
}

Window::~Window() {
    delete tabs;
}