#include <QFileDialog>

#include "actions.hh"
#include "window.hh"

void Actions::newFile() {
    Window::canvasBg->newImage();
}

void Actions::openFile() {
    QFileDialog chooser;
    chooser.setWindowTitle("Choose Image");
    chooser.setAcceptMode(QFileDialog::AcceptOpen);

    if (!chooser.exec() && chooser.selectedFiles().length()==0) {
        return;
    }

    QPixmap img(chooser.selectedFiles().at(0));
    QImage i = img.toImage();

    int width = i.width();
    int height = i.height();

    Window::canvasBg->getCanvas()->setFixedSize(width,height);
    Window::canvasBg->getCanvas()->setPath(chooser.selectedFiles().at(0));
    Window::canvasBg->getCanvas()->setImage(i);
}

void Actions::saveFile() {
    Canvas *c = Window::canvasBg->getCanvas();
    if (c->isUntitled()) {
        saveFileAs();
        return;
    }
    c->save();
}

void Actions::saveFileAs() {
    QFileDialog chooser;
    chooser.setWindowTitle("Save Image As...");
    chooser.setAcceptMode(QFileDialog::AcceptSave);

    if (!chooser.exec()) {
        return;
    }

    if (chooser.selectedFiles().length()==0) {
        return;
    }

    QString file = chooser.selectedFiles().at(0);
    Canvas *c = Window::canvasBg->getCanvas();
    c->setPath(file);
    c->save();
}
