#include <iostream>
#include <cstdio>
#include <string>
#include <elf.h>

#include "elf.hpp"

extern int output1_size();
extern void output1(FILE *file);
extern void output2(FILE *file);

int main(int argc, char *argv[]) {
    FILE *file = fopen("a.out", "w");
    
    // ELF part
    auto elf = new ElfFile("first.c");
    
    auto symtab = new ElfSymTab();
    elf->addSection(symtab);
    
    auto strtab = new ElfStrTab();
    elf->addSection(strtab);
    
    auto text = new ElfText(output1_size());
    elf->addSection(text);
    
    elf->addFunction("_start", 0);
    
    elf->write(file);

    // Code part
    output1(file);
    
    delete elf;
    fclose(file);

    return 0;
}
