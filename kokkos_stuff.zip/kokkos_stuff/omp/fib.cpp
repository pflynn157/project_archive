#include <stdio.h>
#include <omp.h>

// detached untied
#define PTASK_FLAG_DETACHABLE 0x40

// Compiler-generated code (emulation)
typedef struct ident {
  void* dummy; // not used in the library
} ident_t;

typedef struct {
  int type;
  union {
    void *task;
  } ed;
} kmp_event_t;

typedef struct shar { // shareds used in the task
} *pshareds;

typedef struct task {
  pshareds shareds;
  int(*routine)(int,struct task*);
  int part_id;
  omp_event_handle_t evt;
} *ptask, kmp_task_t;

typedef void(*task_entry_t)(int, ptask, int, int&);
#ifdef __cplusplus
extern "C" {
#endif
extern int __kmpc_global_thread_num(void *id_ref);
extern ptask __kmpc_omp_task_alloc(void *loc, int gtid, int flags,
                                   size_t sz, size_t shar, task_entry_t rtn);

extern omp_event_handle_t __kmpc_task_allow_completion_event(
                              ident_t *loc_ref, int gtid, ptask task);

extern void __kmpc_fork_call(ident_t *, int nargs,
                                 task_entry_t microtask, ...);
                
extern int __kmpc_omp_task(ident_t *loc_ref, int gtid, ptask task);                 
extern int __kmpc_omp_taskwait(ident_t *loc_ref, int gtid);
#if __cplusplus
}
#endif

int fib(int n);

// User's code, outlined into task entry
void task_entry(int gtid, ptask task, int n, int &x) {
    int x_local = fib(n);
    x += x_local;
}

int fib(int n) {
    int gtid = __kmpc_global_thread_num(NULL);
    ptask task;
    pshareds psh;
    omp_event_handle_t evt;
    
    if (n < 2) return 1;
    
    int x = 0;
    task = (ptask)__kmpc_omp_task_alloc(NULL, gtid, PTASK_FLAG_DETACHABLE, sizeof(struct task), sizeof(struct shar), &task_entry);
    psh = task->shareds;
    evt = (omp_event_handle_t)__kmpc_task_allow_completion_event(NULL,gtid,task);
    task->evt = evt;
    __kmpc_fork_call(NULL, 4, &task_entry, (n-1), &x);
    
    int y = fib(n-2);
    __kmpc_omp_task(NULL, gtid, task);
    __kmpc_omp_taskwait(NULL, gtid);
    
    return x + y;
}

int main(int argc, char **argv) {
    printf("%d\n", fib(10));
    return 0;
}
