// Copyright 2019 Patrick Flynn
//
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, 
//	this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, this 
//	list of conditions and the following disclaimer in the documentation and/or 
//	other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors may 
//	be used to endorse or promote products derived from this software 
//	without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#include <vector>
#include <string>
#include <iostream>
#include <cmath>

#include "math.hh"
#include "vars.hh"
#include "strutils.hh"

bool is_operator(char c) {
	if (c == '+' || c == '-' || c == '*' || c == '/'
		|| c == '%' || c == '&' || c == '|' || c == '~'
		|| c == '!' || c == '^') {
		return true;	
	}
	return false;
}

std::vector<std::string> breakup(std::string ln) {
	std::vector<std::string> objects;
	std::string current = "";
	char last_c = 0;
	
	for (char c : ln) {
		if (is_operator(c) && (last_c != '\'' && last_c != '\"')) {
			if (is_var(current)) {
				current = var_val(current);
			}
			
			objects.push_back(current);
			current = "";
		
			std::string op = "";
			op += c;
			objects.push_back(op);
		
			continue;
		}
		
		last_c = c;
		current += c;
	}
	
	if (is_var(current)) {
		current = var_val(current);
	}
	
	objects.push_back(current);
	return objects;
}

//Check to see if a string is math
bool is_math(std::string ln) {
	if (contains(ln, '+') || contains(ln, '-') ||
		contains(ln, '*') || contains(ln, '/') ||
		contains(ln, '%') || contains(ln, '^')) {
		return true;	
	}
	return false;
}

//This function examines our line and sees if we are adding numbers
// or adding to strings
bool is_no_math(std::string ln) {
	//Get everything up to the first operator
	std::string data = "";
	
	for (char c : ln) {
		if (is_operator(c)) {
			break;
		}
		data += c;
	}
	
	//See if we have a variable
	if (is_var(data)) {
		data = var_val(data);
	}
	
	//Get the datatype
	auto type = get_datatype(data);
	
	if (type == DataType::STR || type == DataType::CHAR) {
		return false;
	}
	return true;
}

//Solve string problems
std::string solve_str(std::string ln) {
	auto objects = breakup(ln);
	std::string result = "\"";
	
	for (int i = 1; i<=objects.size(); i+=2) {
		auto to_append = objects.at(i-1);
		to_append = rm_first_last(to_append);
		result += to_append;
	}
	
	result += "\"";
	return result;
}

//The wrapper function needed to call everything
Var solve_exp(Var v) {
	double result = solve_chain(v.val);
	
	if (v.type == DataType::INT) {
		int r = (int)result;
		v.val = std::to_string(r);
	} else if (v.type == DataType::DEC) {
		v.val = std::to_string(result);
	} else if (v.type == DataType::NONE) {
		int r2 = (int)result;
		if (r2 == result) {
			v.type = DataType::INT;
			v.val = std::to_string(r2);
		} else {
			v.type = DataType::DEC;
			v.val = std::to_string(result);
		}
	}

	return v;
}

/*
To solve:
1) Break down the program into objects; an object is either a number or an operator.
2) Go through the array, and solve multiplication and division first;
	if the operator is addition or subtraction, re-add it to the new array;
	otherwise, re-add the new product/quotient to the array
3) Go through the array again, this time solving addition and subtraction
4) Return the result
*/
double solve_column(std::string problem) {
	double answer = 0;
	
	//First, break down the array
	std::vector<std::string> objects1;
	std::string current = "";
	
	for (char c : problem) {
		if (c == '+' || c == '-' || c == '*' || c == '/' 
			|| c == '^' || c == '%') {
			objects1.push_back(current);
			
			current = "";
			current += c;
			objects1.push_back(current);
			
			current = "";
		} else {
			current += c;
		}
	}
	
	objects1.push_back(current);
	
	//Now, go through the array again and solve for mp/div
	std::vector<std::string> objects2;
	double tanswer = 0;
	bool was_last = false;
	
	for (int i = 1; i<objects1.size(); i+=2) {
		if (objects1.at(i) == "+" || objects1.at(i) == "-") {
			if (was_last) {
				objects2.push_back(std::to_string(tanswer));
				was_last = false;
			} else {
				objects2.push_back(objects1.at(i-1));
			}
			
			objects2.push_back(objects1.at(i));
			//objects2.push_back(objects1.at(i+1));
		} else if (objects1.at(i) == "*" || objects1.at(i) == "/" 
			|| objects1.at(i) == "^" || objects1.at(i) == "%") {
			double no2 = std::atof(objects1.at(i+1).c_str());
			
			if (!was_last) {
				tanswer = std::atof(objects1.at(i-1).c_str());
				was_last = true;
			}
			
			
			if (objects1.at(i) == "*") {
				tanswer *= no2;
			} else if (objects1.at(i) == "/") {
				tanswer /= no2;
			} else if (objects1.at(i) == "^") {
				tanswer = std::pow(tanswer, no2);
			} else if (objects1.at(i) == "%") {
				tanswer = (double)((int)tanswer % (int)no2);
			}
		} else {
			std::cout << "Error: Unknown operator." << std::endl;
		}
	}
	
	if (was_last) {
		objects2.push_back(std::to_string(tanswer));
	} else {
		objects2.push_back(objects1.at(objects1.size()-1));
	}
	
	//Now solve for addition and subtraction
	//Since we are on the last step, we can append it directly to the answer variable
	answer = std::atof(objects2.at(0).c_str());
	
	for (int i = 1; i<objects2.size(); i+=2) {
		double no2 = std::atof(objects2.at(i+1).c_str());
		
		if (objects2.at(i) == "+") {
			answer += no2;
		} else if (objects2.at(i) == "-") {
			answer -= no2;
		}
	}
	
	return answer;
}

/*
To solve:
1) Determine how many layers we have
2) Break up the string into objects
3) Solve each layer, starting at the top
    -> When solved, put result into objects
4) Solve final equation
*/
double solve_chain(std::string problem) {
    double answer = 0;

    //Count the number of layers
    int layers = 1;
    bool closed = false;

    for (char c : problem) {
        if (c == '(') {
            if (closed) {
                closed = false;
            } else {
                ++layers;
            }
        } else if (c == ')') {
            closed = true;
        }
    }

    //Break up the string
    std::vector<std::string> objects;
    std::string current = "";

    for (char c : problem) {
        if (c == '+' || c == '-' || c == '*' || c == '/'
            || c == '^' || c == '%' || c == '(' || c == ')') {
            objects.push_back(current);
            
            current = "";
            current += c;
            objects.push_back(current);

            current = "";
        } else {
            current += c;
        }
    }

    objects.push_back(current);
    
    //Check each object to see if we have any variables
    std::vector<std::string> temp;
    
    for (std::string o : objects) {
    	if (is_var(o)) {
    		temp.push_back(var_val(o));
		} else {
			temp.push_back(o);
		}
    }
    
    objects = temp;

    //Now, solve each layer
    int current_layer = layers;
    std::vector<std::string> n_objects;

    while (current_layer>0) {
        int cp = 1;
        std::vector<std::string> objects_tmp;

        std::vector<std::string> to_parse;
        if (current_layer == layers) {
            to_parse = objects;
        } else {
            to_parse = n_objects;
        }

        for (unsigned int i = 0; i<to_parse.size(); i++) {
            if (to_parse.at(i) == "(") {
                ++cp;

                if (cp == current_layer) {
                    std::string prob = "";

                    for (unsigned int j = i+1; j<to_parse.size(); j++) {
                        if (to_parse.at(j) == ")") {
                            double answer = solve_column(prob);
                            objects_tmp.push_back(std::to_string(answer));
                            i = j+1;
                            --cp;
                            break;
                        } else {
                            prob += to_parse.at(j);
                        }
                    }
                } else {
                    objects_tmp.push_back(to_parse.at(i));
                }
            } else if (to_parse.at(i) == ")") {
                if (cp > 1) {
                    --cp;
                }
                objects_tmp.push_back(to_parse.at(i));
            } else {
                objects_tmp.push_back(to_parse.at(i));
            }
        }

        n_objects = objects_tmp;
        --current_layer;
    }

    
    //Re-assemble into one string
    std::string prob = "";
    for (std::string str : n_objects) {
        prob += str;
    }

    //Solve
    answer = solve_column(prob);

    return answer;
}
