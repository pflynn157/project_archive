#include <fstream>
#include <iostream>

#include "server.hpp"
#include "writer.hpp"

//
// This is in charge of determing paths to be served
//
std::string Server::findPath(std::string reqPath) {
    // First, check to see if it's in the router
    if (config->router.find(reqPath) != config->router.end()) {
        std::string path = config->router[reqPath];
        
        int dotPos = path.find_last_of(".");
        std::string ext = path.substr(dotPos);
        if (ext == ".ww") {
            path = path.substr(0, dotPos);
            
            HtmlWriter *writer = new HtmlWriter(basePath + path, config->singleFile);
            writer->parse();
            writer->print();
            writer->close();
            
            return basePath + path + ".html";
        }
        
        return basePath + path;
    }
    
    // Second, see if we have a variable path
    for (auto const &rt : config->router) {
        std::string reqPath2 = rt.first;
        if (reqPath2.find("<") == -1 || reqPath2.find(">") == -1) {
            continue;
        }
        
        // Determine if we have a matching variable path
        int pos = reqPath2.find_first_of("<");
        std::string prefix = reqPath2.substr(0, pos);
        
        if (reqPath.length() < prefix.length()) continue;
        std::string reqPathPrefix = reqPath.substr(0, pos);
        
        if (prefix != reqPathPrefix) continue;
        
        // Setup the writer
        std::string resPath = rt.second;
        int dotPos = resPath.find_last_of(".");
        resPath = resPath.substr(0, dotPos);
        HtmlWriter *writer = new HtmlWriter(basePath + resPath, config->singleFile);
        
        // Parse and set the parameters
        int pos2 = reqPath2.find_first_of(">");
        int len = pos2 - pos - 1;
        std::string arg = reqPath2.substr(pos + 1, len);
        
        std::string val = "";
        for (int i = pos; i<reqPath.length(); i++) {
            if (reqPath[i] == '/') break;
            val += reqPath[i];
        }
        
        writer->addArg(arg, val);
        
        // Parse and send back the file
        writer->parse();
        writer->print();
        writer->close();
        
        return basePath + resPath + ".html";
    }

    // Otherwise, move onto regular parsing
    std::string path = basePath;
    if (reqPath == "/") {
        reqPath = "index";
        path += "index";
    } else {
        reqPath = reqPath.substr(1);
        path += reqPath;
    }
    
    // The search follows this hierarchy
    // 1) <the path itself>
    // 2) *.ww
    // 3) *.html
    std::ifstream reader(path);
    if (reader.is_open()) {
        reader.close();
        return path;
    }
    
    std::string path2 = path + ".ww";
    reader = std::ifstream(path2);
    if (reader.is_open()) {
        reader.close();
        
        HtmlWriter *writer = new HtmlWriter(basePath + reqPath, config->singleFile);
        writer->parse();
        writer->print();
        writer->close();
        
        reader.close();
        return path + ".html";
    }
    
    std::string path3 = path + ".html";
    reader = std::ifstream(path3);
    if (reader.is_open()) {
        reader.close();
        return path3;
    }

    return "";
}
