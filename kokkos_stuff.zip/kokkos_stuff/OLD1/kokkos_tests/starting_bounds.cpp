//
// This does a test of MDRange starting at an index other than zero (see line 25)
//
#include <cstdio>
#include <Kokkos_Core.hpp>

const unsigned int ROWS = 4;
const unsigned int COLS = 6;

int main (int argc, char* argv[]) {

  int *num1 = (int *)malloc(sizeof(int)*ROWS*COLS);
  int *num2 = (int *)malloc(sizeof(int)*ROWS*COLS);
  
  for (int i = 1; i<ROWS; i++) {
    for (int j = 2; j<COLS; j++) {
      num1[i*COLS+j] = j;
    }
  }


  Kokkos::initialize (argc, argv);

  {
    Kokkos::parallel_for("loop1", Kokkos::MDRangePolicy<Kokkos::Rank<2>>({1,2},{ROWS,COLS}),
      KOKKOS_LAMBDA(const int i, const int j) {
        num2[i*COLS+j] = j;
    });
  }
  
  puts("NUM1");
  for (int i = 0; i<ROWS; i++) {
    for (int j = 0; j<COLS; j++) {
      printf("%d ", num1[i*COLS+j]);
    }
    puts("");
  }
  puts("===========================================");
  puts("NUM2");
  for (int i = 0; i<ROWS; i++) {
    for (int j = 0; j<COLS; j++) {
      printf("%d ", num2[i*COLS+j]);
    }
    puts("");
  }

  Kokkos::finalize ();
  return 0;
}
