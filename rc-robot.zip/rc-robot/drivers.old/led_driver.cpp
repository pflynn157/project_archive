//gcc -Wall -pthread -o prog prog.c -lpigpio -lrt
#include <pigpio.h>
#include <iostream>
#include <cstdlib>

#include "daemon.hh"
#include "ipc.hh"

int main(int argc, char **argv) {
	if (argc != 2 && argv[1] != "--no-daemon") {
		start_daemon();
	}
	
	if (gpioInitialise() < 0) {
		std::cerr << "Error: Unable to start GPIO" << std::endl;
		std::exit(1);
	}
	
	gpioSetMode(16, PI_OUTPUT);
	gpioWrite(16, 0);
	
	int key = ipc_gen_key("led");
	
	while (true) {
		std::string data = ipc_read(key);
		
		if (data == "on") {
			gpioWrite(16, 1);
		} else if (data == "off") {
			gpioWrite(16, 0);
		} else if (data == "exit") {
			break;
		}
	}
	
	ipc_cleanup(key);
	gpioTerminate();
	return 0;
}

