#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ast.h"

struct Node *create_node()
{
    struct Node *node = malloc(sizeof(struct Node));
    node->lval = NULL;
    node->rval = NULL;
    node->sval = NULL;
    return node;
}

struct Node *create_op_node(NodeType type, struct Node *lval, struct Node *rval)
{
    struct Node *node = create_node();
    node->type = type;
    node->lval = lval;
    node->rval = rval;
    return node;
}

struct Node *ast_create_char_node(char val)
{
    struct Node *node = create_node();
    node->type = CharL;
    node->ival = val;
    return node;
}

struct Node *create_int_node(int val)
{
    struct Node *node = create_node();
    node->type = IntL;
    node->ival = val;
    return node;
}

struct Node *ast_create_float_node(double val)
{
    struct Node *node = create_node();
    node->type = FloatL;
    node->flt_val = val;
    return node;
}

struct Node *ast_create_string_node(char *val)
{
    int old_len = strlen(val);
    int len = old_len - 2;
    int pos = 0;
    
    char *new_val = malloc(sizeof(char) * len);
    for (int i = 1; i<old_len - 1; i++)
    {
        new_val[pos] = val[i];
        ++pos;    
    }
    
    free(val);
    
    struct Node *node = create_node();
    node->type = StringL;
    node->sval = new_val;
    return node;
}

struct Node *create_id_node(char *val)
{
    struct Node *node = create_node();
    node->type = Id;
    node->sval = val;
    return node;
}

struct Statement *create_stmt(StmtType type, struct Node *operand)
{
    struct Statement *stmt = malloc(sizeof(struct Statement));
    stmt->type = type;
    stmt->ival = 0;
    stmt->operand = operand;
    return stmt;
}

struct Statement *create_typed_stmt(StmtType type, int data_type, struct Node *operand)
{
    struct Statement *stmt = malloc(sizeof(struct Statement));
    stmt->type = type;
    stmt->ival = data_type;
    stmt->operand = operand;
    return stmt;
}

struct Block *create_block()
{
    struct Block *block = malloc(sizeof(struct Block));
    block->line_list = malloc(sizeof(struct Statement *) * 10);
    block->line_count = 0;
    block->line_max = 10;
    return block;
}

struct Block *ast_reset_block(struct Block *original)
{
    struct Block *current = create_block();
    memmove(current, original, sizeof(struct Block));
    
    original = create_block();
    
    return current;
}

void ast_add_statement(struct Block *block, struct Statement *stmt)
{
    if (block == NULL)
    {
        block = create_block();
    }
    
    if (block->line_count >= block->line_max)
    {
        block->line_max = 20;
        block->line_list = realloc(block->line_list, sizeof(struct Statement *) * 20);
    }

    block->line_list[block->line_count] = stmt;
    block->line_count += 1;
}

struct Function *create_function(DataType data_type, char *name, struct Block *param_block, struct Block *block)
{
    struct Function *func = malloc(sizeof(struct Function));
    func->type = data_type;
    func->name = name;
    func->block = block;
    func->param_block = param_block;
    func->is_extern = 0;
    return func;
}

struct Function *create_extern_function(DataType data_type, char *name, struct Block *param_block)
{
    struct Function *func = malloc(sizeof(struct Function));
    func->type = data_type;
    func->name = name;
    func->block = NULL;
    func->param_block = param_block;
    func->is_extern = 1;
    return func;
}

AstTree *create_tree(const char *mod_name)
{
    AstTree *tree = malloc(sizeof(AstTree));
    tree->module_name = mod_name;
    tree->func_list = malloc(sizeof(struct Function *) * 10);
    tree->func_count = 0;
    tree->func_max = 10;
    return tree;
}

void ast_add_function(AstTree *tree, struct Function *func)
{
    if (tree->func_count >= tree->func_max)
    {
        tree->func_max = 20;
        tree->func_list = realloc(tree->func_list, sizeof(struct Function *) * 20);
    }

    tree->func_list[tree->func_count] = func;
    tree->func_count += 1;
}

// Destroy the AST and free all memory
void ast_destroy_node(struct Node *node)
{
    if (node->lval) ast_destroy_node(node->lval);
    if (node->rval) ast_destroy_node(node->rval);
    
    if (node->sval) free(node->sval);
    
    free(node);
}

void ast_destroy_block(struct Block *block)
{
    for (int j = 0; j<block->line_count; j++)
    {
        struct Statement *stmt = block->line_list[j];
        
        if (stmt->operand)
        {
            ast_destroy_node(stmt->operand);
        }
        
        free(stmt);
    }
    
    free(block->line_list);
    free(block);
}

void ast_destroy_tree(AstTree *tree)
{
    for (int i = 0; i<tree->func_count; i++)
    {
        struct Function *func = tree->func_list[i];
        struct Block *block = func->block;
        struct Block *param_block = func->param_block;
        
        if (block)
            ast_destroy_block(block);
            
        if (param_block)
            ast_destroy_block(param_block);
        
        if (func->name) free(func->name);
        free(func);
    }
    
    free(tree->func_list);
    free(tree);
}

