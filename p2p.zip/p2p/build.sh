#!/bin/bash

clang++ server.cpp -o sv -lpthread
clang++ client.cpp -o cl

echo "Done"
