// Copyright 2018 Patrick Flynn
//
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, 
//	this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, this 
//	list of conditions and the following disclaimer in the documentation and/or 
//	other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors may 
//	be used to endorse or promote products derived from this software 
//	without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#include <iostream>
#include <cstdlib>

#include "parse_utils.hh"
#include "string_utils.hh"

//TODO-> Change to indicate that we are building comparison
BuiltFunction ParseUtils::build(std::string line, std::vector<Var> vars) {
	BuiltFunction f;

	std::string content = "";
	
	std::string condition = "";
	std::string if_part = "";
	std::string else_part = "";
	
	bool c1 = false;
	bool c2 = false;
	bool parse = true;
	
	//First, break up the string into component parts
	for (int i = 0; i<line.length(); i++) {
		if (line[i]=='[') {
			for (int j = i+1; j<line.length(); j++) {
				if (line[j]==']') {
					i = j+1;
					break;
				} else {
					condition+=line[j];
				}
			}
			continue;
		} else if (line[i]==':') {
			if (c1 && !c2) {
				c2 = true;
			} else if (!c1) {
				c1 = true;
			}
			parse = true;
			i+=1;
			continue;
		} else if (line[i]==';') {
			if (parse) {
				parse = false;			
			}
		} else {
			if (parse && c2) {
				else_part+=line[i];
			} else if (parse && c1) {
				if_part+=line[i];
			}	
		}
	}
	
	//Parse the comparison
	std::string str1 = "";
	std::string str2 = "";
	bool found_sign = false;
	char sign = ' ';
	
	std::string cmp1 = "";
	std::string cmp2 = "";
	
	for (int i = 0; i<condition.length(); i++) {
		if (condition[i]=='>' || condition[i]=='<') {
			cmp1 = "jg";
			cmp2 = "jl";
			sign = condition[i];
			found_sign = true;
		} else if (condition[i]=='=') {
			cmp1 = "je";
			cmp2 = "jne";
			sign = condition[i];
			found_sign = true;
		} else if (condition[i]=='!') {
			cmp1 = "jne";
			cmp2 = "je";
			sign = condition[i];
			found_sign = true;
		} else {
			if (found_sign) {
				str2+=condition[i];
			} else {
				str1+=condition[i];
			}
		}
	}
	
	//See if comparisons are variables
	bool use_vars = false;
	std::string str1_val = "";
	std::string str2_val = "";
	
	for (int i = 0; i<vars.size(); i++) {
		Var v = vars.at(i);
		
		if (v.name==str1) {
			str1_val = v.val;
			use_vars = true;
		}
		
		if (v.name==str2) {
			str2_val = v.val;
			use_vars = true;
		}
	}
	
	//Create some needed labels
	int no1 = rand()%1001;
	int no2 = rand()%1001;
	int no3 = rand()%1001;
	
	std::string label1 = "L"+std::to_string(no1);
	std::string label2 = "L"+std::to_string(no2);
	std::string label3 = "L"+std::to_string(no3);
	
	//Build an assembly statement based on the information above
	//We build based on whether or not stored vars are used.
	if (use_vars) {
		content+="push rbp\nmov rbp, rsp\n";
		content+="mov DWORD [rbp-24], "+str1_val+"\n";
		content+="mov DWORD [rbp-16], "+str2_val+"\n";
		
		if (sign=='<') {
			content+="mov eax, DWORD [rbp-16]\n";
			content+="cmp eax, DWORD [rbp-24]\n";
		} else if (sign=='>' || sign=='=' || sign=='!') {
			content+="mov eax, DWORD [rbp-24]\n";
			content+="cmp eax, DWORD [rbp-16]\n";
		}
	} else {
		content+="mov rax, "+str1+"\n";
		content+="mov rbx, "+str2+"\n";
		
		if (sign=='<') {
			content+="cmp rbx, rax\n";
		} else if (sign=='>' || sign=='=' || sign=='!') {
			content+="cmp rax, rbx\n";
	}
	}
	
	content+=cmp1+" "+label1+"\n";
	content+=cmp2+" "+label2+"\n";
	
	//Build functions
	BuiltFunction fb1 = build_function(if_part,vars);
	BuiltFunction fb2 = build_function(else_part,vars);
	
	for (int i = 0; i<fb1.section_data.size(); i++) {
		f.section_data.push_back(fb1.section_data.at(i));
	}
	
	for (int i = 0; i<fb2.section_data.size(); i++) {
		f.section_data.push_back(fb2.section_data.at(i));
	}
	
	std::string fn1 = fb1.ln;
	std::string fn2 = fb2.ln;
	
	//Build the rest of the statements
	content+=label1+":\n"+fn1+"\n";
	content+="jmp "+label3+"\n\n";
	
	content+=label2+":\n"+fn2+"\n";
	content+="jmp "+label3+"\n\n";
	
	content+=label3+":\n";
	
	f.ln = content+"\n";
	return f;
}

BuiltFunction ParseUtils::build_loop(std::string line,std::vector<Var> vars) {
	BuiltFunction f;
	
	//First, break up the statement
	std::string loop_cmd = "";
	std::vector<std::string> loop_body1;
	
	bool f1 = false;
	std::string s = "";
	
	for (int i = 0; i<line.length(); i++) {
		if (line[i]==';') {
			if (!f1) {
				loop_cmd = s;
				f1 = true;
			} else {
				loop_body1.push_back(s);
			}
			s="";
		} else {
			s+=line[i];
		}
	}
	
	//Parse the loop command line
	bool fs = false;
	std::string str_no = "";
	
	for (int i = 0; i<loop_cmd.length(); i++) {
		if (loop_cmd[i]==' ') {
			fs = true;
			continue;
		} else if (loop_cmd[i]==';') {
			break;
		} else {
			if (fs) {
				str_no+=loop_cmd[i];
			}
		}
	}
	
	//Get the body-> First get just the lines
	bool ffs = false;
	std::string b_line = "";
	std::vector<std::string> blines;
	
	for (int i = 0; i<line.length(); i++) {
		if (line[i]==';') {
			if (!ffs) {
				ffs = true;
			} else {
				blines.push_back(b_line);
			}
			b_line = "";
			continue;
		} else {
			if (ffs) {
				b_line+=line[i];
			}
		}
	}
	
	//Get the body-> now clean up the lines
	std::string b_line2 = "";
	std::vector<std::string> f_blines;
	
	for (int i = 0; i<blines.size(); i++) {
		bool fs2 = false;
		std::string current = blines.at(i);
		std::string new_ln = "";
		
		for (int j = 0; j<current.size(); j++) {
			if (current[j]==' ') {
				if (!fs2) {
					fs2 = true;
				} else {
					new_ln+=current[j];
				}
				continue;
			} else {
				if (fs2) {
					new_ln+=current[j];
				}
			}
		}
		
		f_blines.push_back(new_ln);
	}
	
	//Convert it all to assembly
	int no = rand()%1001;
	
	f.ln+="mov rcx, "+str_no+"\n";
	f.ln+="loop"+std::to_string(no)+":\n";
	f.ln+="push rcx\n";
	
	for (int i = 0; i<f_blines.size(); i++) {
		std::string current = f_blines.at(i);
		BuiltFunction f2 = build_function(current,vars);
		
		f.ln+=f2.ln;
		
		for (int j = 0; j<f2.section_data.size(); j++) {
			f.section_data.push_back(f2.section_data.at(j));
		}
	}
	
	f.ln+="pop rcx\n";
	f.ln+="loop loop"+std::to_string(no)+"\n";
	
	return f;
}

BuiltFunction ParseUtils::build_function(std::string line, std::vector<Var> vars) {
	BuiltFunction ret;
	std::string ln = "";
	std::string first = first_part(line);

	std::string qt = "";
				
	bool in = false;
	bool found_qt = false;
	
	//First, break up the line			
	for (int k = 0; k<line.size(); k++) {
		if (line[k]==' ' && !in) {
			in = true;
			continue;
		} else if (line[k]=='\"') {
			found_qt = true;
			continue;
		} else if (line[k]==';') {
			break;
		} else {
			if (in) {
				qt+=line[k];
			}
		}
	}
				
	if (qt.length()==0) {
		//This would be a call for a function that takes no parameters.
		std::string print = "call "+first+"\n";
		ln = print;
	} else {
		int no = rand()%1001;
		std::string print = "";
			
		if (found_qt) {
			//Called if the function has parameters surrounded by quotations (a string)
			std::string str = "str"+std::to_string(no);
			
			std::string data = str+" db \""+qt+"\",0xA\n";
			data+=str+"_len equ $-"+str+"\n";
				
			ret.section_data.push_back(data);
						
			print = "push "+str+"\n";
			print+="push "+str+"_len\n";
			print+="call "+first+"\nadd rsp, 16\n";
		} else {
			//Called if the function references a variable
			
			//First, see if such a variable even exists
			std::string val = "";
			
			for (int i = 0; i<vars.size(); i++) {
				Var v = vars.at(i);
				
				if (v.name==qt) {
					val = v.val;
					break;
				}
			}
			
			//If the string is empty, we have an error
			if (val.length()==0) {
				std::cerr << "Error: Unspecified variable." << std::endl;
				std::exit(1);
			}
			
			//Conver the variable to a string
			std::string str = "str"+std::to_string(no);
			
			std::string data = str+" db \""+val+"\",0xA\n";
			data+=str+"_len equ $-"+str+"\n";
				
			ret.section_data.push_back(data);
						
			print = "push "+str+"\n";
			print+="push "+str+"_len\n";
			print+="call "+first+"\nadd rsp, 16\n";
		}
					
		ln = print;
	}
	
	ret.ln = ln;
	return ret;
}
