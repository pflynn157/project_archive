---
layout: post
title:  "Posting Schedule"
date:   2021-06-20
categories: none
---

Surprisingly I’ve already had some views on this site. For any newcomers or returning readers, I just wanted to make a quick note that my posting schedule is tentatively going to be each Sunday. I generally write posts ahead of time and schedule them, so they will appear early Sunday morning. These will be the regular posts; I may include a few other miscellaneous things on Wednesdays, but probably not more frequent than this.
