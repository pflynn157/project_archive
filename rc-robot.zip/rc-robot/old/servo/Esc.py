import time
import pigpio

class servo:

    gpio = 4

    def __init__(self, pi_inst, pin):
        self.gpio = pin

        self.pi = pi_inst
        self.pi.set_mode(self.gpio, pigpio.OUTPUT)
        self.pi.set_servo_pulsewidth(self.gpio, 1500)

    def control(self, pwm):
        self.pi.set_servo_pulsewidth(self.gpio, pwm)

    def stop(self):
        self.pi.set_mode(self.gpio, pigpio.OUTPUT)
        self.pi.write(self.gpio, 0)

if __name__ == "__main__":
    import time
    import Esc
    import PWM

    pi = pigpio.pi()
    monitor = PWM.monitor(pi,14)
    sv = Esc.servo(pi, 15)
    sv.control(1500)

    contents = []
    last = 0

    start = time.time()
    while (time.time() - start) < 10:
        pw = monitor.pulse_width()
        sv.control(pw)
        #if pw != last:
        #last = pw
        print("PW: "+str(pw))
        contents.append(pw)

    monitor.cancel()

    print("Data logged.")
    print("Hit any key to continue...")
    input()

    print("Length: "+str(len(contents)))

    for i in contents:
        print("PW: "+str(i))
        sv.control(i)

    sv.stop()
    pi.stop()
