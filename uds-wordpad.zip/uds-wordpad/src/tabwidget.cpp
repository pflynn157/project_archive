//
// Copyright 2021 Patrick Flynn
// This file is part of uds-wordpad.
// uds-wordpad is licensed under the BSD-3 license. See the COPYING file for more information.
//
#include <QFileInfo>
#include <QMessageBox>

#include <tabwidget.hpp>
#include <editor.hpp>
#include <global.hpp>
#include <window.hpp>
#include <actions.hpp>

TabWidget::TabWidget() {
    this->setMovable(true);
    this->setTabsClosable(true);
    
    addUntitledTab();
    
    connect(this, SIGNAL(currentChanged(int)), this, SLOT(onTabChanged(int)));
    connect(this, SIGNAL(tabCloseRequested(int)), this, SLOT(onTabClosed(int)));
}

TabWidget::~TabWidget() {
}

void TabWidget::addUntitledTab() {
    Editor *edit = new Editor;
    this->addTab(edit, "untitled");
    
    int count = this->count() - 1;
    this->setCurrentIndex(count);
}

void TabWidget::addTabFromFile(QString path) {
    QString tab_title = QFileInfo(path).fileName();
    
    Editor *edit = getCurrentWidget();
    if (edit->isUntitled() && edit->isSaved()) {
        int pos = currentIndex();
        this->setTabText(pos, tab_title);
        edit->setFile(path, tab_title);
    } else {
        edit = new Editor;
        edit->setFile(path, tab_title);
        this->addTab(edit, tab_title);
        
        int count = this->count() - 1;
        this->setCurrentIndex(count);
    }
    
    // Now set the text
    edit->openFile();
    
    // Set the window statusbar
    win->setCurrentFile(path);
    win->setCurrentSaved(true);
    
    // Update the formatting
    win->getFormatToolbar()->updateFormat(edit->isBoldOn(), edit->isItalicOn(), edit->isUnderlineOn());
}

Editor *TabWidget::getCurrentWidget() {
    Editor *edit = static_cast<Editor *>(this->currentWidget());
    return edit;
}

void TabWidget::onTabChanged(int index) {
    Editor *edit = static_cast<Editor *>(this->widget(index));
    win->setCurrentFile(edit->getFullPath());
    win->setCurrentSaved(edit->isSaved());
    
    win->getFormatToolbar()->updateFormat(edit->isBoldOn(), edit->isItalicOn(), edit->isUnderlineOn());
}

void TabWidget::onTabClosed(int index) {
    Editor *edit = static_cast<Editor *>(this->widget(index));
    if (!edit->isSaved()) {
        QMessageBox prompt;
        prompt.setText("This file has been modified.");
        prompt.setInformativeText("Do you wish to save?");
        prompt.setStandardButtons(QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);
        prompt.setDefaultButton(QMessageBox::Save);
        int choice = prompt.exec();
        
        if (choice == QMessageBox::Save) {
            if (edit->isUntitled()) {
                this->setCurrentIndex(index);
                Actions().saveFileAs();
            } else {
                edit->saveFile();
            }
        } else if (choice == QMessageBox::Cancel) {
            return;
        }
        
        if (this->count() == 1) addUntitledTab();
        delete edit;
    } else {
        if (this->count() == 1) addUntitledTab();
        delete edit;
    }
}

