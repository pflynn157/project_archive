module Main(main) where

import System.Environment
import System.Exit
import System.FilePath.Posix
import System.IO
import Data.String.Utils
import Data.Map (Map)
import qualified Data.Map as Map

import Utils
import Pass1
import Pass2
import Elf

-- Loads the file to memory
load reader contents = do
    isEOF <- hIsEOF reader
    if isEOF
        then return ((reverse contents))
        else do
            ln <- hGetLine reader
            let ln2 = strip ln
            if (length ln2) == 0
                then load reader contents
                else load reader (ln2 : contents)
    
runPass2 [] symbols writer lc = return ()
runPass2 (x:xs) symbols writer lc = do
    let parts = parse x
    size <- assemble writer parts symbols lc
    runPass2 xs symbols writer (lc + size)
    
-- Check command line arguments
checkArgs args = do
    if (length args) == 0
        then do
            putStrLn "Fatal: No input specified."
            exitFailure
        else return ()

-- The main function
main = do
    -- Get the file name
    args <- getArgs
    checkArgs args
    
    let name = head args
    let outName = (takeBaseName name) ++ ".bin"

    --Load the file
    reader <- openFile name ReadMode
    writer <- openBinaryFile outName WriteMode
    
    contents <- load reader []
    hClose reader
    
    -- Split up the assembly file
    let dataContents = getData contents [] False
    let codeContents = getCode contents [] False
    
    -- Parse and write the data section
    let dataRaw = runData1 dataContents [] 0
    
    -- Parse the code section
    let symbolsRaw = runPass1 codeContents [] 0
    let symbols = Map.fromList (symbolsRaw ++ (fst dataRaw))
    
    -- Assemble
    assembleData dataContents writer
    runPass2 codeContents symbols writer 0
    
    hClose writer
    
    bytes <- loadFile outName

    writer2 <- openBinaryFile outName WriteMode
    createHeader writer2 (snd dataRaw)
    writeBody writer2 bytes
    hClose writer2
    
