#!/usr/bin/python3
from socket import *
from drivers.led import *
from interpreter import *

macAddr = "B8:27:EB:89:61:0F"
port = 3
bklog = 1
size = 1024
statLed = 16

socketd = socket(AF_BLUETOOTH, SOCK_STREAM, BTPROTO_RFCOMM)
socketd.bind((macAddr, port))
socketd.listen(bklog)

led_toggle(0)

try:
	client, addr = socketd.accept()
	
	print("[Rx] Connection started")
	client.send(bytes("Connection received.", 'UTF-8'))
	led_toggle(1)
	
	uploading = False
	path = None
	
	while 1:
		data = client.recv(size)
		if data:
			client.send(bytes("0x0", 'UTF-8'))
			d = data.decode()
			
			if d == "exit":
				break
			elif get_first(d) == "upload":
				path = open(get_second(d), "x")
				uploading = True
				continue
			elif d == "eof":
				uploading = False
				path.close()
				path = None
				continue
				
			if uploading:
				path.write(str(d)+"\n")
			else:
				print(d)
				result = interpret(d)
				client.send(bytes(result, 'UTF-8'))
		else:
			client.send(bytes("0x1", 'UTF-8'))
finally:
    print("[Rx] Ending connection")
    client.close()
    socketd.close()
    
    led_toggle(0)
