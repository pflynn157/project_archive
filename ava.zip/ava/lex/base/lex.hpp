#pragma once

#include <fstream>
#include <string>
#include <stack>

#include <ava/lex.hpp>

// Represents a token
enum TokenType {
    EmptyToken,
    Eof,
    
    //##TOKEN LIST
    
    // Literals
    Id,
    String,
    CharL,
    Int32
};

// The main lexical analysis class
class Scanner : public BaseScanner {
public:
    explicit Scanner(std::string input);
    ~Scanner();
    
    void rewind(Token token) override;
    Token getNext() override;
    
    std::string getRawBuffer() override;
    int getLine() override { return currentLine; }
    
    bool isEof() override { return reader.eof(); }
    bool isError() override { return error; }
private:
    std::stack<Token> token_stack;
    
    // Control variables for the scanner
    std::string rawBuffer = "";
    std::string buffer = "";
    bool inQuote = false;
    int currentLine = 1;
    bool skipNextLineCount = false;
    
    // Functions
    bool isSymbol(char c);
    TokenType getKeyword();
    TokenType getSymbol(char c);
    bool isInt();
    bool isHex();
};

