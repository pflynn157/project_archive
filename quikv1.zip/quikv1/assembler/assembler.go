package main

import (
	"os"
	//"fmt"
	"strconv"
)

type Assembler struct {
	writer *os.File
}

//Creates the file and generates the signiture
func (a* Assembler) Setup(out_path string) {
	sig := []byte {
		0xF1,
		'Q',
		'U',
		'I',
		'K',
		0xF2,
	}
	
	file, err := os.Create(out_path)
	if err != nil {
		println("Fatal error: Could not create output file.")
		os.Exit(1)
	}
	
	file.Write(sig)
	a.writer = file
}

//A utility function to insert a single byte
func (a* Assembler) InsertByte(b byte) {
	bytes := make([]byte, 1)
	bytes[0] = b
	a.writer.Write(bytes)
}

//Write to the string section
func (a* Assembler) WriteString(str string) {
	length := len(str) + 1
	bytes := make([]byte, length)
	index := 0
	
	for _, c := range str {
		bytes[index] = byte(c)
		index++
	}
	
	bytes[index] = 0xF3
	a.writer.Write(bytes)
}

//Write to the data section
func (a* Assembler) WriteData(str string) {
	cmd := GetFirst(str, ' ')
	operand := GetSecond(str, ' ')
	
	opr_i, _ := strconv.Atoi(operand)
	opr := byte(opr_i)
	word := make([]byte, 2)
	
	word[1] = opr
	
	//Set the bytecode
	if cmd == "exit" {
		word[0] = 0xA0
	//The load commands
	} else if cmd == "i_load" {
		word[0] = 0xA1
	} else if cmd == "d_load" {
		word[0] = 0xA2
	} else if cmd == "s_load" {
		word[0] = 0xA3
		
	//The store commands
	} else if cmd == "i_store" {
		word[0] = 0xA4
	} else if cmd == "d_store" {
		word[0] = 0xA5
	} else if cmd == "s_store" {
		word[0] = 0xA6
		
	//The println commands
	} else if cmd == "i_println" {
		word[0] = 0xA7
	} else if cmd == "d_println" {
		word[0] = 0xA8
	} else if cmd == "s_println" {
		word[0] = 0xA9
		
	//The print commands
	} else if cmd == "i_print" {
		word[0] = 0xAA
	} else if cmd == "d_print" {
		word[0] = 0xAB
	} else if cmd == "s_print" {
		word[0] = 0xAC
		
	//The input commands
	} else if cmd == "i_input" {
		word[0] = 0xAD
	} else if cmd == "d_input" {
		word[0] = 0xAE
	} else if cmd == "s_input" {
		word[0] = 0xAF
		
	//Addition commands
	} else if cmd == "i_add" {
		word[0] = 0xB0
	}

	a.writer.Write(word)
}

//Write it all out and close the file
func (a* Assembler) WriteOut() {
	a.writer.Close()
}
