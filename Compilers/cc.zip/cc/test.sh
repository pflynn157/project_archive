#!/bin/bash

# Syntax: <path> <type-> std, syscall, asx86>
function run_test() {
    for entry in $1
    do
    	name=`basename $entry .c`
    	
        if [[ $2 == "std" ]] ; then
    	    ./build/compiler/cc $entry
        elif [[ $2 == "syscall" ]] ; then
            ./build/compiler/cc $entry --no-stdlib
        elif [[ $2 == "asx86" ]] ; then
            ./build/compiler/cc $entry --no-stdlib -lasx86
        fi
        
    	./test.py $entry ./a.out
    	
    	if [[ $? != 0 ]] ; then
    		exit 1
    	fi
    done
}

echo "Running all tests..."
echo ""

if [ ! -d ./build ] ; then
	echo "Error: The compiler does not seem to be built."
	exit 1
fi

mkdir -p ./build/test

run_test 'test/single-exec/*.c' 'std'
run_test 'test/std/*.c' 'std'
run_test 'test/std/math/*.c' 'std'
run_test 'test/std/ret/*.c' 'std'
run_test 'test/syscall/*.c' 'syscall'

rm a.out

echo "Done"
