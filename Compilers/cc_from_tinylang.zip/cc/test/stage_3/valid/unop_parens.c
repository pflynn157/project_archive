int main() {
    return ~(1 + 1);
}