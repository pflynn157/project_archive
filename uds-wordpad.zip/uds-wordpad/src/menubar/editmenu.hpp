//
// Copyright 2021 Patrick Flynn
// This file is part of uds-wordpad.
// uds-wordpad is licensed under the BSD-3 license. See the COPYING file for more information.
//
#pragma once

#include <QMenu>
#include <QAction>

#include <actions.hpp>

class EditMenu : public QMenu {
    Q_OBJECT
public:
    EditMenu();
    ~EditMenu();
private:
    Actions *actions;
    QAction *cut, *copy, *paste, *selectAll;
    QAction *undo, *redo;
};

