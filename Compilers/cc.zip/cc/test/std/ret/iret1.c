//OUTPUT
//Hello!
//Number: 10
//END

//RET 23
 
extern void puts(char *str);
extern void exit(int rc);
extern void printf(char *str, ...);

int main() 
{
    puts("Hello!");
    printf("Number: %d\n", 10);
    
    return 23;
}
