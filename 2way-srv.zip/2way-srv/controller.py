#!/usr/bin/python3
from PyQt5.QtWidgets import *
from socket import *
import sys

class Window(QMainWindow):
	throttle = None
	lastThr = 1500
	
	steering = None
	lastSteer = 6.5

	def __init__(self):
		super().__init__()
		self.setWindowTitle("Controller")
		self.resize(700,500)
		
		mainWidget = QFrame()
		layout = QHBoxLayout()
		mainWidget.setLayout(layout)
		self.setCentralWidget(mainWidget)
		
		self.throttle = QSlider()
		self.throttle.setMaximum(2000)
		self.throttle.setMinimum(700)
		self.throttle.setValue(1500)
		self.throttle.setTickInterval(50)
		layout.addWidget(self.throttle)
		
		self.throttle.valueChanged.connect(self.val_changed)
		
		self.steering = QDial()
		self.steering.setMaximum(35)
		self.steering.setMinimum(5)
		self.steering.setValue(6.5)
		self.steering.setNotchTarget(5)
		layout.addWidget(self.steering)
		
		self.steering.valueChanged.connect(self.steer_changed)
		
	def val_changed(self):
		val = self.throttle.value()
		diff = val - self.lastThr
		self.lastThr = val
		cmd = "INC THR "+str(diff)
		
		if diff < 0:
			diff *= -1
			cmd = "DEC THR "+str(diff)
			
		self.send_data(cmd)
		
	def steer_changed(self):
		val = self.steering.value()
		diff = val - self.lastSteer
		self.lastSteer = val
		cmd = "INC STR "+str(0.2)
		
		if diff < 0:
			diff *= -1
			cmd = "DEC STR "+str(0.2)
			
		self.send_data(cmd)
		
	def send_data(self, data):
		host = "192.168.254.15"
		port = 8100
		addr = (host, port)
		
		sockfd = socket(AF_INET, SOCK_DGRAM)
		sockfd.sendto(data.encode(), addr)
		sockfd.close()

if __name__ == "__main__":
	app = QApplication(sys.argv)
	win = Window()
	win.send_data("SETUP")
	win.show()
	app.exec_()
