package co.patrickflynn.notetaker.ui.editor

import android.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import co.patrickflynn.notetaker.CWD
import co.patrickflynn.notetaker.R
import java.io.File
import android.content.DialogInterface
import android.text.Editable
import android.text.TextWatcher

class EditorActivity : AppCompatActivity(), TextWatcher {

    private var cwd = ""
    private var modified = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editor)

        cwd = intent.getStringExtra(CWD)!!
        val file = File(applicationContext.filesDir, cwd)
        title = file.name

        // Load the file
        val editor = findViewById<EditText>(R.id.editor)
        editor.addTextChangedListener(this)

        var block = ""
        val reader = file.bufferedReader()
        for (line in reader.readLines()) {
            if (line == null) continue
            block += line + "\n"
        }
        editor.setText(block)

        modified = false
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.editor, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_save -> {
                saveFile()
                true
            }

            R.id.action_close -> {
                closeFile()
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun saveFile() {
        val file = File(applicationContext.filesDir, cwd)
        val editor = findViewById<EditText>(R.id.editor)
        val writer = file.bufferedWriter()
        writer.write(editor.text.toString())
        writer.flush()
        writer.close()
        modified = false
    }

    private fun closeFile() {
        if (modified) {
            val builder: AlertDialog.Builder = AlertDialog.Builder(this@EditorActivity)
            builder.setTitle("Confirm Close")
            builder.setMessage("This file has not been saved!")
            builder.setPositiveButton("Save") { dialogInterface, i ->
                saveFile()
                finish()
            }
            builder.setNegativeButton("Close",
                DialogInterface.OnClickListener { dialogInterface, i -> finish() })
            builder.setNeutralButton("Cancel",
                DialogInterface.OnClickListener { dialogInterface, i -> })
            val dialog: AlertDialog = builder.create()
            dialog.show()
        } else {
            finish()
        }
    }

    override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
    override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}

    override fun afterTextChanged(p0: Editable?) {
        modified = true
    }
}