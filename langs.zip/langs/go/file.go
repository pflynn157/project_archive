package main

import (
	"fmt"
	"os"
	"bufio"
)

func main() {
	file, err := os.Open("file.go")
	if err != nil {
		println("Fatal error: Could not open file.")
		os.Exit(1)
	}
	defer file.Close()
	
	reader := bufio.NewScanner(file)
	for reader.Scan() {
		fmt.Println(reader.Text())
	}
}
