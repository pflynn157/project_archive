use std::io;

fn break_up(line:String) {
	let mut parts:Vec<String> = Vec::new();
	let mut current = String::new();
	
	let mut in_quote = false;
	
	for c in line.chars() {
		if c == ' ' {
			if !in_quote {
				parts.push(current);
				current = "".to_string();
				continue;
			}
		} else if c == '\"' {
			in_quote = !in_quote;
		}
		
		current.push_str(&c.to_string());
	}
	
	parts.push(current);
	
	//db
	for ln in parts {
		println!("PT: {}", ln);
	}
}

fn main() {
	println!("Enter a command: ");
	
	let mut cmd = String::new();
	io::stdin().read_line(&mut cmd).expect("Unknown input.");
	cmd = cmd.trim().to_string();
	
	break_up(cmd);
}
