#include <iostream>
#include <string>
#include <vector>

#include <compiler.hpp>
#include <parser.hpp>
#include <ltac_build.hpp>

void help() {
    std::cout << "HELP!!!!" << std::endl;
}

// TODO: This should reflect the current config
void version() {
    std::cerr << "Orca v0.01" << std::endl;
    std::cerr << "Build for x86-64" << std::endl;
}

// Get the basename of a path
std::string getBasename(std::string path) {
    std::string ret = "";
    
    int start = path.find_last_of('/');
    int end = path.find_last_of('.');
    
    if (start == -1) start = 0;
    if (end == -1) end = path.length();
    
    for (int i = start; i<end; i++)
        ret += path[i];
        
    return ret;
}

int main(int argc, char *argv[]) {
    if (argc == 1) {
        std::cerr << "Fatal: No input file specified." << std::endl;
        std::cerr << "Type --help for more options." << std::endl;
        return 1;
    }
    
    // Parse options
    std::vector<std::string> inputFiles;
    bool astOnly = false;
    bool ltacOnly = false;
    bool asmOnly = false;
    
    for (int i = 1; i<argc; i++) {
        std::string arg = argv[i];
        
        if (arg == "-h" || arg == "--help") {
            help();
            return 0;
        } else if (arg == "-v" || arg == "--version") {
            version();
            return 0;
        } else if (arg == "--ast") {
            astOnly = true;
        } else if (arg == "--ltac") {
            ltacOnly = true;
        } else if (arg == "-S") {
            asmOnly = true;
        } else {
            if (arg[0] == '-') {
                std::cerr << "Error: Unknown option: " << arg << std::endl;
                std::cerr << std::endl;
                std::cerr << "Type --help for more information" << std::endl;
                return 1;
            } else {
                inputFiles.push_back(arg);
            }
        }
    }
    
    // Now build according to settings
    std::string input = inputFiles[0];
    std::string unitName = getBasename(input);
    
    auto tree = getAstTree(input, unitName);
    auto ltac = getLtacFile(tree, unitName);
    
    // Generate an AST representation
    if (astOnly) {
        std::cout << "Generating AST graph" << std::endl;
        printAst(tree, unitName);
        
    // Generate an LTAC representation
    } else if (ltacOnly) {
        std::cout << "Generating LTAC source" << std::endl;
        ltacPrint(ltac);
        
    // Compile, but don't assemble
    } else if (asmOnly) {
        std::cout << "Generating Assembly" << std::endl;
        
    // Do everything
    } else {
        compile(ltac);
        
        std::string path = "/tmp/" + ltac->getName();
        assemble(path);
    }
    
    delete tree;
    
    return 0;
}
