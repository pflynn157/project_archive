## CppEditor
CppEditor is an advanced, universal text/code editor written in C++. It has all the features you would except of a modern text editor. CppEditor is designed to run on any platform, and to be easily ported to new platforms with minimal modifications.

#### Our Mission
Our mission is to provide a useful, lightweight, easy-to-use text/code editor that can be used across all platforms, and ported to new ones with minimal effort. Our goal is to make CppEditor useful, stable, powerful, and versatile. We hope that you enjoy the editor, and find its portability useful and its interface enjoyable.

#### Licensing
CppEditor is currently licensed under the BSD 3-clause license. The included TinyXML2 source code is licensed under the zlib license. The libipc, libsettings, and libsyntax-highlighter libraries are all licensed under the BSD-3 license. The included icons are part of the Oxygen Icon Theme; they are licensed under LGPL. The Qt Framework is licensed under LGPL as well. Note: CppEditor, before version 17 (with 16.1 being the last version) was licensed under the GNU Public License v3 because the program had the option to link to GNU libraries, and there was a little bit of included GNU code. This has been removed and replaced. Please see the licenses for more detail.

#### Supported Platforms
Fully supported:   
1. Linux
2. BSD
3. Windows

Supported with difficulty:   
1. Haiku OS

#### Dependencies
The following are needed to build CppEditor:   
1. Qt5 Core
2. Qt5 Widgets
3. Qt5 GUI
4. libipc
5. libsettings
6. libsyntax-highlighter

#### Languages
CppEditor speaks multiple languages! Below is a list of all currently supported languages. Please note that as of the time of writing, I created all the language files myself. As I do not speak all these languages, I had to use Google Translate; therefore, the translations could have errors. You have been warned. If you want them fixed, or want to submit additional translations, please contribute! Also, please note that the entire program is not fully translated. However, most of it is. This will be fixed over time.   
Languages:   
1. Afrikaans
2. German
3. English
4. Spanish
5. Esperanto
6. Italian
7. Dutch
8. Swedish


