#include <stdio.h>
#include <limits.h>

int main() {
    int count = 2;
    int result = 2;
    for (int i = 3; count < 10001; i += 2) {
        if (i % 5 == 0 || i % 6 == 0) continue;
        
        int found = 0;
        for (int j = i - 1; j >= 2; j--) {
            if (i % j == 0) {
                found = 1;
                break;
            }
        }
        
        if (!found) {
            result = i;
            ++count;
        }
    }
    
    printf("%d\n", result);

    return 0;
}
