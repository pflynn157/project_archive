#include <amd64/amd64.hpp>

#include <ltac/struct.hpp>
#include <ltac/types.hpp>

// Kernel arguments
std::string kargs32[] = {
    "eax",
    "edi",
    "esi",
    "edx",
    "r10d",
    "r8d",
    "r9d"
};

std::string kargs[] = {
    "rax",
    "rdi",
    "rsi",
    "rdx",
    "r10",
    "r8",
    "r9"
};

// Function arguments
// Yes, its very similar
std::string fc_args32[] = {
    "edi",
    "esi",
    "edx",
    "r10d",
    "r8d",
    "r9d"
};

std::string fc_args[] = {
    "rdi",
    "rsi",
    "rdx",
    "r10",
    "r8",
    "r9"
};

int ldArgPos = 0;

// Builds an extern declaration
void Amd64::buildExtern(LtacInstr *instr) {
    auto func = static_cast<LtacExtern *>(instr);
    writer << "extern " << func->getName() << std::endl;
}

// Builds a function declaration
void Amd64::buildFunc(LtacInstr *instr) {
    auto func = static_cast<LtacFunc *>(instr);
    writer << "global " << func->getName() << ":" << std::endl;
    
    writer << "  push rbp" << std::endl;
    writer << "  mov rbp, rsp" << std::endl;
    
    if (func->getStackSize() > 0)
        writer << "  sub rsp, " << func->getStackSize() << std::endl;
    
    writer << std::endl;
    
    ldArgPos = 0;
}

// The argument loading
void Amd64::buildLdBArg(LtacInstr *instr) {
    auto ldarg = static_cast<LtacLdArg *>(instr);
}

void Amd64::buildLdWArg(LtacInstr *instr) {
    auto ldarg = static_cast<LtacLdArg *>(instr);
}

void Amd64::buildLdDwArg(LtacInstr *instr) {
    auto ldarg = static_cast<LtacLdArg *>(instr);
    
    writer << "  mov [rbp-" << ldarg->getPos() << "], ";
    writer << fc_args32[ldArgPos] << std::endl;
    writer << std::endl;
    
    ++ldArgPos;
}

void Amd64::buildLdQwArg(LtacInstr *instr) {
    auto ldarg = static_cast<LtacLdArg *>(instr);
    
    writer << "  mov [rbp-" << ldarg->getPos() << "], ";
    writer << fc_args[ldArgPos] << std::endl;
    writer << std::endl;
    
    ++ldArgPos;
}

// Builds a system call
void Amd64::buildSyscall(LtacInstr *instr) {
    auto syscall = static_cast<LtacSyscall *>(instr);
    auto args = syscall->getArgs();
    
    // Write the arguments
    for (int i = 0; i<args.size(); i++) {        
        auto current = args[i];
        
        switch (current->getType()) {
            case LtacType::Int: {
                auto arg = static_cast<LtacInt *>(current);
                
                writer << "  mov " << kargs32[i] << ", ";
                writer << arg->getVal() << std::endl;
            } break;
            
            case LtacType::String: {
                auto arg = static_cast<LtacString *>(current);
                
                writer << "  mov " << kargs[i] << ", ";
                writer << arg->getVal() << std::endl;
            } break;
            
            case LtacType::Var32: {
                auto arg = static_cast<LtacVar32 *>(current);
                
                writer << "  mov " << kargs32[i] << ", ";
                writer << "[rbp-" << arg->getPos() << "]" << std::endl;
            } break;
            
            case LtacType::Ptr: {
                auto arg = static_cast<LtacPtr *>(current);
                
                writer << "  mov " << kargs[i] << ", ";
                writer << "[rbp-" << arg->getPos() << "]" << std::endl;
            } break;
        }
    }
    
    // The syscall instruction
    writer << "  syscall" << std::endl;
    writer << std::endl;
}

// Builds a function call
void Amd64::buildFuncCall(LtacInstr *instr) {
    auto fc = static_cast<LtacFuncCall *>(instr);
    auto args = fc->getArgs();
    
    // Write the arguments
    for (int i = 0; i<args.size(); i++) {
        auto current = args[i];
        
        switch (current->getType()) {
            case LtacType::Int: {
                auto arg = static_cast<LtacInt *>(current);
                
                writer << "  mov " << fc_args32[i] << ", ";
                writer << arg->getVal() << std::endl;
            } break;
            
            case LtacType::String: {
                auto arg = static_cast<LtacString *>(current);
                
                writer << "  mov " << fc_args[i] << ", ";
                writer << arg->getVal() << std::endl;
            } break;
            
            case LtacType::Var32: {
                auto arg = static_cast<LtacVar32 *>(current);
                
                writer << "  mov " << fc_args32[i] << ", ";
                writer << "[rbp-" << arg->getPos() << "]" << std::endl;
            } break;
            
            case LtacType::Ptr: {
                auto arg = static_cast<LtacPtr *>(current);
                
                writer << "  mov " << fc_args[i] << ", ";
                writer << "[rbp-" << arg->getPos() << "]" << std::endl;
            } break;
            
            case LtacType::Ref: {
                auto arg = static_cast<LtacRef *>(current);
                
                writer << "  lea " << fc_args[i] << ", ";
                writer << "[rbp-" << arg->getPos() << "]" << std::endl;
            } break;
        }
    }
    
    // Write the actual call
    writer << "  call " << fc->getName() << std::endl;
    writer << std::endl;
}

// Builds a return statement
void Amd64::buildVRet(LtacInstr *instr) {
    writer << "  leave" << std::endl;
    writer << "  ret" << std::endl;
    writer << std::endl;
}

// Builds a 32-bit integer return statement
void Amd64::buildI32Ret(LtacInstr *instr) {
    auto ret = static_cast<LtacI32Ret *>(instr);
    
    switch (ret->getStrType()) {
        case StrType::Const: {
            writer << "  mov eax, " << ret->getVal() << std::endl; 
        } break;
        
        case StrType::Mem: {
            writer << "  mov eax, [rbp-" << ret->getVal() << "]" << std::endl;
         } break;
         
        case StrType::Reg: {
            std::string reg = op_regs32[ret->getVal()];
            
            if (reg != "eax")
                writer << "  mov eax, " << reg << std::endl;
        } break;
        
        case StrType::Stack: {
            writer << "  pop rax" << std::endl;
        } break;
        
        default: writer << "  xor eax, eax" << std::endl;
    }
    
    writer << "  leave" << std::endl;
    writer << "  ret" << std::endl;
    writer << std::endl;
}
