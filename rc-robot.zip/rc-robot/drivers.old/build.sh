#!/bin/bash
echo "Building the IPC test program..."
g++ ipc_msg.cpp ipc.cpp -o ipc_msg

echo "Building LED driver..."
g++ led_driver.cpp ipc.cpp daemon.cpp -o led_driver -pthread -lpigpio -lrt
