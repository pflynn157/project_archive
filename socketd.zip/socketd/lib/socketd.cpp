// Copyright 2019 Patrick Flynn
//
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, 
//	this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, this 
//	list of conditions and the following disclaimer in the documentation and/or 
//	other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors may 
//	be used to endorse or promote products derived from this software 
//	without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#include <iostream>
#include <string>
#include <thread>
#include <cstdlib>
#include <functional>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "socketd.hh"
namespace socketd {

std::string host = "";
int port = 8100;

std::function<void(std::string)> func;
std::function<void()> rt_func;
std::function<void()> exit_func;

void send_data(std::string msg) {
	struct sockaddr_in addr, client;
	memset(&addr, 0, sizeof(addr));
	
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = inet_addr(host.c_str());
	addr.sin_port = htons(port);
	
	int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	int i = bind(sockfd, (const struct sockaddr *) & addr, sizeof(addr));
	
	socklen_t l = sizeof(addr);
	sendto(sockfd, msg.c_str(), msg.length(), 0,
		(struct sockaddr *)&addr, l);
	
	if (msg == "exit") {
		std::cout << "[Client] Exiting..." << std::endl;
		close(sockfd);
		exit_func();
	}
}

void server() {
	char buffer[1024];
	
	struct sockaddr_in addr;
	memset(&addr, 0, sizeof(addr));
	
	addr.sin_family = AF_INET;
	addr.sin_port = htons(port);
	addr.sin_addr.s_addr = INADDR_ANY;
	
	int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	bind(sockfd, (const struct sockaddr *) & addr, sizeof(addr));
	
	for (;;) {
		socklen_t l = sizeof(addr);
		int n = recvfrom(sockfd, (char *)buffer, 1024,
			MSG_WAITALL, (struct sockaddr *)&addr, &l);
			
		buffer[n] = '\0';
		func(std::string(buffer));
		
		if (std::string(buffer) == "exit") {
			std::cout << "[Server] Exiting..." << std::endl;
			close(sockfd);
			exit_func();
		}
		
		for (int i = 0; i<n; i++) {
			buffer[i] = '\0';
		}
	}
}

void run_time() {
	rt_func();
}

void set_server_callback(std::function<void(std::string)> f) {
	func = f;
}

void set_client_func(std::function<void()> f) {
	rt_func = f;
}

void set_exit_func(std::function<void()> f) {
	exit_func = f;
}

void set_host(std::string h) {
	host = h;
}

void set_port(int p) {
	port = p;
}

void setup() {
	std::thread s(server);
	std::thread rt(run_time);
	
	s.join();
	rt.join();	
}

}
