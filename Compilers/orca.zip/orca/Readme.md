## Orca Comiler

This is the compiler and toolchain for yet another programming language project I'm trying... Anyway. As far as the language goes, Orca is similar to my former Quik projects. The reason I pretty much just renamed it was first because the compiler project is sufficiently different, and secondly because I didn't really think I needed to create yet another iteration of that project.

Unlike previous projects, Orca is a complete toolchain. The project does not require any external tools other than CMake and a C and C++ compiler to build it. Orca is a systems language; there is a compiler that generates assembly, and custom assembler to finish the process.

This project is solely a learning experience. If it doesn't get anywhere, it will most likely be because of the assembler.

### The Compiler

The compiler is written in C++, except for the parser and scanner, which is written using Flex and Bison. This is actually my first significant compiler that uses this. I really didn't want to focus on the parsing system (other than AST analysis and beyond) this time around, and personally, I think Bison makes it a lot easier to define the grammar without worrying about documentation and tons of spec files. Also, unlike previous compilers, the AST has a built-in feature to allow for generating dot files, which I'll admit are ugly. The important part is you can compile them to PNG or SVG, which makes understanding the AST a whole lot easier. This can be invoked with the "--ast" command line argument.

The LTAC layer is the intermediate layer between the AST and the assembly. The idea behind this is to create a pseudo-assembly of sorts, which can allow for easier optimizations in some cases (a feature that is way down the road), and for easy porting to other architectures. You can see what the LTAC looks like with the "--ltac" command line argument.

Currently, the compiler and the assembler only generate for the x86-64 platform. I want to eventually port this to Arm, but that's also a stretch goal.

### The Assembler

The assembler is written in C and also uses Flex and Bison for parsing. The assembler can generate both ELF and flat binaries. It is important to note that not all instructions- even the most common ones- are fully supported yet. I'll mainly be adding them on an as-needed basis.

Now, regarding the ELF files. The ELF files that are generated are extremely simple. They are executable straight off the assembler; no linker is required. Basically all they generate is the ELF header with appropriate information, the program header, and the code. Data such as strings are supported and are simply placed before the executable code. Currently, there are no sections. I have no plans at the moment to expand this at the moment, but I do acknowledge that the point will come when this is woefully inadequate for real work. 

### Goals

The immediate goal of this project is as a learning experience. Since I've been into compilers, I've both wanted to learn more about assemblers and eventually build my own system that does the entire process from top to bottom. At the time of writing, it can print "Hello World" and return a number on its own, which I'm super happy about. For current progress, see the "examples" folder.
