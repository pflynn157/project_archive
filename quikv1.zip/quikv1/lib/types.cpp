#include "types.hh"
#include "strutils.hh"

//Get the datatype of a variable
DataType get_datatype(std::string val) {
	DataType type = DataType::NONE;
	
	//1) Check for string
	if (is_str(val)) {
		return DataType::STR;
	}
	
	//2) Check for chars
	if (is_char(val)) {
		return DataType::CHAR;
	}
	
	//3) Check for boolean
	if (val == "true" || val == "false") {
		return DataType::BOOL;
	}
	
	//4) Check for decimal number
	bool num = true;
	
	if (contains(val, '.')) {	
		for (char c : val) {
			if (c == '.') {
				continue;
			} else if (!isdigit(c)) {
				num = false;
				break;
			}
		}
		
		if (num) {
			return DataType::DEC;
		}
	}
	
	//5) Check for regular integer
	num = true;
	
	for (char c : val) {
		if (!isdigit(c)) {
			num = false;
			break;
		}
	}
	
	if (num) {
		return DataType::INT;
	}
	
	return type;
}
