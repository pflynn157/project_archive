#include <ava/compiler/Compiler.hpp>

#include "compiler.hpp"
#include "ast.hpp"

Value *TestCompiler::compileExtendedValue(AstExpression *expr, bool isAssig) {
    AstExtExpr *node = dynamic_cast<AstExtExpr *>(expr);
    switch (node->getType()) {
        case AstType::One: return builder->getInt32(1);
        
        default: {}
    }
    
    return nullptr;
}

