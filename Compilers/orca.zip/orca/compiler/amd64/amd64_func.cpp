#include <amd64/amd64.hpp>

#include <ltac/struct.hpp>
#include <ltac/types.hpp>

// Kernel arguments
std::string kargs32[] = {
    "eax",
    "edi",
    "esi",
    "edx",
    "r10d",
    "r8d",
    "r9d"
};

std::string kargs[] = {
    "rax",
    "rdi",
    "rsi",
    "rdx",
    "r10",
    "r8",
    "r9"
};

// Function arguments
// Yes, its very similar
std::string fc_args32[] = {
    "edi",
    "esi",
    "edx",
    "r10d",
    "r8d",
    "r9d"
};

std::string fc_args[] = {
    "rdi",
    "rsi",
    "rdx",
    "r10",
    "r8",
    "r9"
};

int ldArgPos = 0;

// Builds a function declaration
void Amd64::buildFunc(LtacInstr *instr) {
    auto func = static_cast<LtacLabel *>(instr);
    writer << func->getName() << ":" << std::endl;
    
    writer << "  push rbp" << std::endl;
    writer << "  mov rbp, rsp" << std::endl;
    writer << std::endl;
    
    ldArgPos = 0;
}

// The argument loading
void Amd64::buildLdBArg(LtacInstr *instr) {
    auto ldarg = static_cast<LtacLdArg *>(instr);
}

void Amd64::buildLdWArg(LtacInstr *instr) {
    auto ldarg = static_cast<LtacLdArg *>(instr);
}

void Amd64::buildLdDwArg(LtacInstr *instr) {
    auto ldarg = static_cast<LtacLdArg *>(instr);
    
    writer << "  mov [rbp-" << ldarg->getPos() << "], ";
    writer << fc_args32[ldArgPos] << std::endl;
    writer << std::endl;
    
    ++ldArgPos;
}

void Amd64::buildLdQwArg(LtacInstr *instr) {
    auto ldarg = static_cast<LtacLdArg *>(instr);
    
    writer << "  mov [rbp-" << ldarg->getPos() << "], ";
    writer << fc_args[ldArgPos] << std::endl;
    writer << std::endl;
    
    ++ldArgPos;
}

// Builds a system call
void Amd64::buildSyscall(LtacInstr *instr) {
    auto syscall = static_cast<LtacSyscall *>(instr);
    auto args = syscall->getArgs();
    
    // Write the arguments
    for (int i = 0; i<args.size(); i++) {        
        auto current = args[i];
        
        switch (current->getType()) {
            case LtacType::Int: {
                auto arg = static_cast<LtacInt *>(current);
                
                writer << "  mov " << kargs32[i] << ", ";
                writer << arg->getVal() << std::endl;
            } break;
            
            case LtacType::String: {
                auto arg = static_cast<LtacString *>(current);
                
                writer << "  mov " << kargs[i] << ", ";
                writer << arg->getVal() << std::endl;
            } break;
            
            case LtacType::Var32: {
                auto arg = static_cast<LtacVar32 *>(current);
                
                writer << "  mov " << kargs32[i] << ", ";
                writer << "[rbp-" << arg->getPos() << "]" << std::endl;
            } break;
            
            case LtacType::Ptr: {
                auto arg = static_cast<LtacVar32 *>(current);
                
                writer << "  mov " << kargs[i] << ", ";
                writer << "[rbp-" << arg->getPos() << "]" << std::endl;
            } break;
        }
    }
    
    // The syscall instruction
    writer << "  syscall" << std::endl;
    writer << std::endl;
}

// Builds a function call
void Amd64::buildFuncCall(LtacInstr *instr) {
    auto fc = static_cast<LtacFuncCall *>(instr);
    auto args = fc->getArgs();
    
    // Write the arguments
    for (int i = 0; i<args.size(); i++) {
        auto current = args[i];
        
        switch (current->getType()) {
            case LtacType::Int: {
                auto arg = static_cast<LtacInt *>(current);
                
                writer << "  mov " << fc_args32[i] << ", ";
                writer << arg->getVal() << std::endl;
            } break;
            
            case LtacType::String: {
                auto arg = static_cast<LtacString *>(current);
                
                writer << "  mov " << fc_args[i] << ", ";
                writer << arg->getVal() << std::endl;
            } break;
            
            case LtacType::Var32: {
                auto arg = static_cast<LtacVar32 *>(current);
                
                writer << "  mov " << fc_args32[i] << ", ";
                writer << "[rbp-" << arg->getPos() << "]" << std::endl;
            } break;
            
            case LtacType::Ptr: {
                auto arg = static_cast<LtacVar32 *>(current);
                
                writer << "  mov " << fc_args[i] << ", ";
                writer << "[rbp-" << arg->getPos() << "]" << std::endl;
            } break;
        }
    }
    
    // Write the actual call
    writer << "  call " << fc->getName() << std::endl;
    writer << std::endl;
}

// Builds a return statement
void Amd64::buildRet(LtacInstr *instr) {
    writer << "  leave" << std::endl;
    writer << "  ret" << std::endl;
    writer << std::endl;
}
