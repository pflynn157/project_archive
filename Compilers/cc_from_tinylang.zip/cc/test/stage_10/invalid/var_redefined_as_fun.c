int foo = 4;

int foo() {
    return 3;
}

int main() {
    return foo;
}