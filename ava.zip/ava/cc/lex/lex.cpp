#include <iostream>
#include <cctype>

#include "lex.hpp"

Scanner::Scanner(std::string input) : BaseScanner(input) {}
Scanner::~Scanner() {}

void Scanner::rewind(Token token) {
    token_stack.push(token);
}

// The main scanning function
Token Scanner::getNext() {
    if (token_stack.size() > 0) {
        Token top = token_stack.top();
        token_stack.pop();
        return top;
    }

    Token token;
    if (reader.eof()) {
        token.type = Eof;
        return token;
    }
    
    for (;;) {
        char next = reader.get();
        if (reader.eof()) {
            token.type = Eof;
            break;
        }
        
        rawBuffer += next;
        
        std::string __next = "";
        __next += next;
        __next += reader.get();
        if (reader.eof()) {
            token.type = Eof;
            break;
        }
        if (__next == "//") {
            while (next != '\n' && !reader.eof()) {
                next = reader.get();
                rawBuffer += next;
            }
            continue;
        }
        reader.unget();
        
        if (next == '*') {
          if (reader.peek() == '/') {
            reader.get();
    while (!reader.eof()) {
        char __c = reader.get();
        if (__c == '*' && reader.get() == '/' ) break;
    }
    continue;
          }
        }
        
        
        // TODO: This needs some kind of error handleing
        if (next == '\'') {
            char c = reader.get();
            rawBuffer += c;
            if (c == '\\') {
                c = reader.get();
                if (c == 'n') {
                    c = '\n';
                    rawBuffer += c;
                }
            }
        
            Token charL;
            charL.i8_val = c;
            charL.type = CharL;
            
            next = reader.get();
            rawBuffer += next;
            return charL;
        }
        
        if (next == '\"') {
            if (inQuote) {
                Token str;
                str.type = String;
                str.id_val = buffer;
                
                buffer = "";
                inQuote = false;
                return str;
            } else {
                inQuote = true;
                continue;
            }
        }
        
        if (inQuote) {
            if (next == '\\') {
                next = reader.get();
                rawBuffer += next;
                switch (next) {
                    case 'n': buffer += '\n'; break;
                    case 't': buffer += '\t'; break;
                    default: buffer += '\\' + next;
                }
            } else {
                buffer += next;
            }
            continue;
        }
        
        if (next == ' ' || next == '\n' || isSymbol(next)) {
            if (next == '\n') {
                if (skipNextLineCount) skipNextLineCount = false;
                else ++currentLine;
            }
        
            if (buffer.length() == 0) {
                if (isSymbol(next)) {
                    Token sym;
                    sym.type = getSymbol(next);
                    return sym;
                }
                continue;
            }
            
            // Check if we have a symbol
            // Here, we also check to see if we have a floating point
            if (next == '.') {
                if (isInt()) {
                    buffer += ".";
                    continue;
                } else {
                    Token sym;
                    sym.type = getSymbol(next);
                    token_stack.push(sym);
                }
            } else if (isSymbol(next)) {
                Token sym;
                sym.type = getSymbol(next);
                token_stack.push(sym);
            }
            
            // Now check the buffer
            token.type = getKeyword();
            if (token.type != EmptyToken) {
                buffer = "";
                break;
            }
            
            if (isInt()) {
                token.type = Int32;
                token.i32_val = std::stoi(buffer);
            } else if (isHex()) {
                token.type = Int32;
                token.i32_val = std::stoi(buffer, 0, 16);
            } else {
                token.type = Id;
                token.id_val = buffer;
            }
            
            // Reset everything
            buffer = "";
            break;
        } else {
            buffer += next;
        }
    }
    
    return token;
}

std::string Scanner::getRawBuffer() {
    std::string ret = rawBuffer;
    rawBuffer = "";
    return ret;
}

bool Scanner::isSymbol(char c) {
    switch (c) {
        //case ';':
        case ';': return true;
        case '=': return true;
        case '(': return true;
        case ')': return true;
        case '{': return true;
        case '}': return true;
        case '+': return true;
        case '-': return true;
        case '*': return true;
        case '/': return true;
        case '%': return true;
        case '&': return true;
        case '|': return true;
        case '^': return true;
        case '<': return true;
        case '>': return true;
        case '!': return true;
        case ':': return true;
        case '?': return true;
        case '.': return true;
        case '[': return true;
        case ']': return true;
        
        default: return false;
    }
    return false;
}

TokenType Scanner::getKeyword() {
    //if (buffer == "extern") return Extern;
    if (buffer == "auto") return Auto;
    else if (buffer == "break") return Break;
    else if (buffer == "case") return Case;
    else if (buffer == "char") return Char;
    else if (buffer == "const") return Const;
    else if (buffer == "continue") return Continue;
    else if (buffer == "default") return Default;
    else if (buffer == "do") return Do;
    else if (buffer == "double") return Double;
    else if (buffer == "else") return Else;
    else if (buffer == "enum") return Enum;
    else if (buffer == "extern") return Extern;
    else if (buffer == "float") return Float;
    else if (buffer == "for") return For;
    else if (buffer == "goto") return Goto;
    else if (buffer == "if") return If;
    else if (buffer == "int") return Int;
    else if (buffer == "long") return Long;
    else if (buffer == "register") return Register;
    else if (buffer == "return") return Return;
    else if (buffer == "short") return Short;
    else if (buffer == "signed") return Signed;
    else if (buffer == "sizeof") return Sizeof;
    else if (buffer == "static") return Static;
    else if (buffer == "struct") return Struct;
    else if (buffer == "switch") return Switch;
    else if (buffer == "typedef") return Typedef;
    else if (buffer == "union") return Union;
    else if (buffer == "unsigned") return Unsigned;
    else if (buffer == "void") return Void;
    else if (buffer == "volatile") return Volatile;
    else if (buffer == "while") return While;
    return EmptyToken;
}

TokenType Scanner::getSymbol(char c) {
    switch (c) {
        case ';': return SemiColon;
        case '=': {
            char c2 = reader.get();
            if (c2 == '=') {
                rawBuffer += c2;
                return Eq;
            } else {
                reader.unget();
                return Assign;
            }
        } break;
        case '(': return LParen;
        case ')': return RParen;
        case '{': return LCBrace;
        case '}': return RCBrace;
        case '+': {
            char c2 = reader.get();
            if (c2 == '=') {
                rawBuffer += c2;
                return AddEq;
            } else if (c2 == '+') {
                rawBuffer += c2;
                return Inc;
            } else {
                reader.unget();
                return Add;
            }
        } break;
        case '-': {
            char c2 = reader.get();
            if (c2 == '=') {
                rawBuffer += c2;
                return SubEq;
            } else if (c2 == '-') {
                rawBuffer += c2;
                return Dec;
            } else if (c2 == '>') {
                rawBuffer += c2;
                return Arrow;
            } else {
                reader.unget();
                return Sub;
            }
        } break;
        case '*': {
            char c2 = reader.get();
            if (c2 == '=') {
                rawBuffer += c2;
                return MulEq;
            } else {
                reader.unget();
                return Mul;
            }
        } break;
        case '/': {
            char c2 = reader.get();
            if (c2 == '=') {
                rawBuffer += c2;
                return DivEq;
            } else {
                reader.unget();
                return Div;
            }
        } break;
        case '%': {
            char c2 = reader.get();
            if (c2 == '=') {
                rawBuffer += c2;
                return ModEq;
            } else {
                reader.unget();
                return Mod;
            }
        } break;
        case '&': {
            char c2 = reader.get();
            if (c2 == '=') {
                rawBuffer += c2;
                return AndEq;
            } else if (c2 == '&') {
                rawBuffer += c2;
                return LAnd;
            } else {
                reader.unget();
                return And;
            }
        } break;
        case '|': {
            char c2 = reader.get();
            if (c2 == '=') {
                rawBuffer += c2;
                return OrEq;
            } else if (c2 == '|') {
                rawBuffer += c2;
                return LOr;
            } else {
                reader.unget();
                return Or;
            }
        } break;
        case '^': {
            char c2 = reader.get();
            if (c2 == '=') {
                rawBuffer += c2;
                return XorEq;
            } else {
                reader.unget();
                return Xor;
            }
        } break;
        case '<': {
            char c2 = reader.get();
            if (c2 == '<') {
                rawBuffer += c2;
                return Lsh;
            } else if (c2 == '<') {
                rawBuffer += c2;
                return LshEq;
            } else if (c2 == '=') {
                rawBuffer += c2;
                return Le;
            } else {
                reader.unget();
                return Lt;
            }
        } break;
        case '>': {
            char c2 = reader.get();
            if (c2 == '>') {
                rawBuffer += c2;
                return Rsh;
            } else if (c2 == '>') {
                rawBuffer += c2;
                return RshEq;
            } else if (c2 == '=') {
                rawBuffer += c2;
                return Ge;
            } else {
                reader.unget();
                return Gt;
            }
        } break;
        case '!': {
            char c2 = reader.get();
            if (c2 == '=') {
                rawBuffer += c2;
                return Ne;
            } else {
                reader.unget();
                return Not;
            }
        } break;
        case ':': return Colon;
        case '?': return QMark;
        case '.': return Dot;
        case '[': return LBracket;
        case ']': return RBracket;
        default: return EmptyToken;
    }
    return EmptyToken;
}

bool Scanner::isInt() {
    for (char c : buffer) {
        if (!isdigit(c)) return false;
    }
    return true;
}

bool Scanner::isHex() {
    if (buffer.length() < 3) return false;
    if (buffer[0] != '0' || buffer[1] != 'x') return false;
    
    for (int i = 2; i<buffer.length(); i++) {
        if (!isxdigit(buffer[i])) return false;
    }
    return true;
}

