#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <errno.h>
#include <unistd.h>
#include <sys/wait.h>

#include <str_list.h>
#include <amd64/amd64.h>

// Checks for the global object directory; currently, all
// libraries and start files are object files, and will be
// linked with the user's program
//
// Global directory is /usr/local/lib/quik
int amd64_check_lib()
{
    DIR *dir = opendir("/usr/local/lib/quik");
    if (dir) closedir(dir);
    else return 0;
    return 1;
}

// Calls the assembler
void amd64_call_as(StrList *as_args)
{
    pid_t pid = fork();
    int wstatus;

    if (pid > 0)
    {
        waitpid(pid, &wstatus, 0);
        return;
    }
    else if (pid == 0)
    {
        int rc = execvp("as", as_args->items);

        if (rc == -1)
        {
            puts("Fatal: Unable to call assembler.");
            printf("Quik requires the GNU Assembler for x86-64. Please make sure ");
            printf("it is installed and in the PATH.\n\n");

            printf("ERRNO: %s\n", strerror(errno));

           exit(1);
        }
    }
    else
    {
        puts("Fatal: Unable to call assembler.");
        exit(1);
    }
}

// Calls the linker
void amd64_call_ld(StrList *ld_args)
{
    pid_t pid = fork();
    int wstatus;

    if (pid > 0)
    {
        waitpid(pid, &wstatus, 0);
        return;
    }
    else if (pid == 0)
    {
        int rc = execvp("ld", ld_args->items);

        if (rc == -1)
        {
            puts("Fatal: Unable to call linker.");
            puts("Quik requires a system linker, generally denoted as ld.");
            puts("Please make sure one is installed, and try again.");
            exit(1);
        }

        exit(0);
    }
    else
    {
        puts("Fatal: Unable to call linker.");
        exit(1);
    }
}

// The main build function
void amd64_build(const char *file_name)
{
    StrList *as_args = str_list_create(5);
    str_list_add(as_args, "");
    str_list_add(as_args, file_name);
    str_list_add(as_args, "-o");
    str_list_add(as_args, "out.o");
    str_list_add_null(as_args);
    amd64_call_as(as_args);

    StrList *ld_args = str_list_create(10);
    str_list_add(ld_args, "");
    str_list_add(ld_args, "out.o");

    const char *path = "/usr/local/lib/quik/";

    if (amd64_check_lib())
    {
        DIR *d;
        struct dirent *dir;
        d = opendir(path);

        while ((dir = readdir(d)) != NULL)
        {
            char *current = dir->d_name;
            char *end = strrchr(current, '.');

            if (end && strcmp(end, ".o") == 0)
            {
                int size = strlen(path) + strlen(current) + 1;
                char *full_path = malloc(sizeof(char)*size);
                strcat(full_path, path);
                strcat(full_path, current);

                str_list_add(ld_args, full_path);
            }
        }

        closedir(d);
    }
    else
    {
        puts("Cannot find standard library.");
    }

    str_list_add(ld_args, "-o");
    str_list_add(ld_args, "out.exe");
    str_list_add_null(ld_args);
    amd64_call_ld(ld_args);
}
