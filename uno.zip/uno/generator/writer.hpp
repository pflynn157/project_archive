#pragma once

#include <fstream>
#include <string>
#include <vector>
#include <map>

#include "Lex.hpp"
#include "tree.hpp"

class HtmlWriter {
public:
    explicit HtmlWriter(std::string input, bool singleFile = true);
    
    void addArg(std::string name, std::string val) {
        args[name] = val;
    }
    
    void parse();
    void print();
    void close();
protected:
    void printBlock(Block *block, int spacing = 1);
    void printElement(Element *element, int spacing = 1);
    void printCSS(Node *node);

    bool generateMeta();
    bool generateBlock(Token blockToken, int spacing = 0, Block *parent = nullptr);
    bool generateElement(Token elementToken, int spacing = 0, Block *parent = nullptr);
    void indent(int amount);
    bool argExists(std::string name);
private:
    std::string input;
    bool singleFile = true;
    Tree *domTree;
    std::string cssBlock = "";
    std::map<std::string, std::string> args;
    
    Scanner *scanner;
    std::ofstream htmlWriter;
    std::ofstream cssWriter;
};
