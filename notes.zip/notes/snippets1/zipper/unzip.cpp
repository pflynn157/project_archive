//unzip.cpp
#include <zip.h>
#include <iostream>

int main()
{
    //Open the ZIP archive
    int err = 0;
    zip *z = zip_open("file.zip", 0, &err);

	//Get number of entries
	auto no = zip_get_num_entries(z,NULL);
	
	//List entries
	for (int i = 0; i<no; i++) {
		//Print name
		const char *file = zip_get_name(z,i,ZIP_FL_ENC_RAW);
		std::cout << "Name: " << file << std::endl;
		
		//Print contents
		struct zip_stat stat;
		zip_stat_init(&stat);
		zip_stat(z,file,0,&stat);
		
		char *contents = new char[stat.size];
				
		zip_file *f = zip_fopen(z,file,0);
		zip_fread(f,contents,stat.size);
		zip_fclose(f);
		
		for (int j = 0; j<stat.size; j++) {
			std::cout << contents[j];
		}
		
		std::cout << std::endl << std::endl;
		delete[] contents;
	}

	//Close archive
    zip_close(z);
}
