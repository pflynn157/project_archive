#include <iostream>
#include "stack.hh"

//Test 1
//This is a generic test
void test1() {
	Stack stack(20);
	
	for (int i = 1; i<=10; i++) {
		stack.push(i);
	}
	
	int size = stack.size();
	std::cout << "Size: " << size << std::endl;
	
	int no1 = stack.pop();
	int p1 = stack.peek();
	int no2 = stack.pop();
	no2 = stack.pop();
	no2 = stack.pop();
	
	std::cout << "No1: " << no1 << std::endl;
	std::cout << "P1: " << p1 << std::endl;
	std::cout << "No2: " << no2 << std::endl;
}

//Test 2
//This tests stack overflow
void test2() {
	Stack stack(20);

	for (int i = 0; i<30; i++) {
		stack.push(i);
	}
	
	std::cout << "Test failed" << std::endl;
}

//Test 3
//This tests pop from an empty stack
void test3() {
	Stack stack(3);
	stack.push(1);
	stack.push(2);
	
	stack.pop();
	int n = stack.pop();
	
	std::cout << "N: " << n << std::endl;
	
	stack.pop();
	
	std::cout << "Test failed" << std::endl;
}

//Test 4
//This tests peek from an empty stack
void test4() {
	Stack stack(3);
	stack.push(1);
	stack.push(2);
	
	stack.pop();
	int n = stack.peek();
	stack.pop();
	
	std::cout << "Peek-> N: " << n << std::endl;
	
	stack.peek();
	
	std::cout << "Test failed" << std::endl;
}

//Our main function
//Just comment whatever you want to test
int main() {
	test1();
	//test2();
	//test3();
	//test4();
}
