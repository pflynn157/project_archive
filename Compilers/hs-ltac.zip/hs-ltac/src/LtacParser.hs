module LtacParser(ParseData(..), buildCode, buildData) where

import Ltac

-- Various data elements
data ParseData = ParseData {
        node :: LtacNode
      , arg :: Int
      , stack :: Int
      , vars :: [(String, Int)]
      , fName :: String
    } deriving (Show, Eq)

-- A utility function for finding position of a variable
findPos [] name = 0
findPos (x:xs) name = do
    if (fst x) == name
        then snd x
        else findPos xs name
        
-- A utility function to determine type and return position if needed
getVar dType name vmap
    | dType == "i.var" = show (findPos vmap name)
    | dType == "string" = name
    | otherwise = name
    
-- A utility function for determining if we have integer math
-- This is for the register - register operations
isIMathRR instr
    | instr == "i.add_rr" = True
    | instr == "i.sub_rr" = True
    | instr == "i.mul_rr" = True
    | instr == "i.div_rr" = True
    | instr == "i.mod_rr" = True
    | otherwise = False
    
-- Determines math type
mathType instr
    | instr == "i.add_rr" = "add"
    | instr == "i.sub_rr" = "sub"
    | instr == "i.mul_rr" = "mul"
    | instr == "i.div_rr" = "div"
    | instr == "i.mod_rr" = "mod"
    | otherwise = ""

-- Responsible for the code
decode ln pd
    -- Function related stuff
    | instr == "func" = do
        let name = parts !! 1
        let node = LtacNode Func name "" ""
        ParseData node arg_c loco vmap name
        
    | instr == "pusharg" = do
        let dType = parts !! 1
        let name = getVar dType (parts !! 2) vmap
        let l = show (arg_c + 1)
        let node = LtacNode PushArg dType name l
        ParseData node (arg_c + 1) loco vmap funcName
        
    | instr == "call" = do
        let node = LtacNode Call (parts !! 1) "" ""
        ParseData node 0 loco vmap funcName
        
    | instr == "ret" = do
        let node = LtacNode Ret "" "" ""
        ParseData node 0 0 vmap ""
        
    -- Integer variable related stuff
    | instr == "i.var" = do
        let pos = loco + 4
        let vars2 = (parts !! 1, pos) : vmap
        let node = LtacNode IVar "" "" ""
        ParseData node 0 pos vars2 funcName
        
    | instr == "i.store_i" = do
        let name = parts !! 1
        let val = parts !! 2
        let pos = findPos vmap name
        let node = LtacNode IStoreI (show pos) val ""
        ParseData node 0 loco vmap funcName
        
    | instr == "i.ldr_i" = do
        let regNo = parts !! 1
        let val = parts !! 2
        let node = LtacNode ILdrI regNo val ""
        ParseData node 0 loco vmap funcName
        
    | instr == "i.ldr_v" = do
        let regNo = parts !! 1
        let pos = findPos vmap (parts !! 2)
        let node = LtacNode ILdrV regNo (show pos) ""
        ParseData node 0 loco vmap funcName
        
    | instr == "i.str" = do
        let regNo = parts !! 1
        let pos = findPos vmap (parts !! 2)
        let node = LtacNode IStr regNo (show pos) ""
        ParseData node 0 loco vmap funcName
        
    | (isIMathRR instr) == True = do
        let mathT = mathType instr
        let node = LtacNode IMathRR mathT (parts !! 1) (parts !! 2)
        ParseData node 0 loco vmap funcName
    
    -- Unknown instruction    
    | otherwise = do
        let node = LtacNode None "" "" ""
        ParseData node arg_c loco vmap funcName
        
    where
        parts = words ln
        instr = head parts
        arg_c = arg pd
        loco = stack pd
        vmap = vars pd
        funcName = fName pd
        
-- Calculates the stack size of a function
calcStackSize 0 sSize = 0
calcStackSize sPos sSize = do
    if sSize < (sPos + 1)
        then calcStackSize sPos (sSize + 16)
        else sSize
        
-- Updates the stack size of a function
updateStackSize [] code name size = reverse code
updateStackSize (x:xs) code name size = do
    if ((instr x) == Func) && ((arg1 x) == name)
        then do
            let node = LtacNode Func name (show size) ""
            updateStackSize xs (node : code) name size
        else updateStackSize xs (x : code) name size

-- The main loop for translating IR code into LTAC
buildCode [] code pd = reverse code
buildCode (x:xs) code pd = do
    let c = decode x pd
    if (instr (node c)) == Ret
        then do
            let stackPos = stack pd
            let stackSize = calcStackSize stackPos 0
            let code2 = updateStackSize code [] (fName pd) stackSize
            buildCode xs ((node c) : code2) c
        else buildCode xs ((node c) : code) c
    
-- Responsible for the data
dropQuotes s = do
    let s2 = tail s
    let s3 = reverse s2
    let s4 = tail s3
    reverse s4

stringElement x = do
    let parts = words x
    let name = parts !! 1
    let s_parts = unwords (drop 2 parts)
    let s = dropQuotes s_parts
    LtacNode String name s ""

buildData [] code = return (reverse code)
buildData (x:xs) code = do
    let element = stringElement x
    buildData xs (element : code)
    

