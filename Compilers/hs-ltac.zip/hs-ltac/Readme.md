## hs-ltac

### Introduction
This is a Haskell version of my LTAC IR found in my extcc and Quik compilers. I am currently exploring the use of Haskell for compilers and code generators, with this being the main project. Currently, it is an executable rather than a library; it has its own version of Assembly (called LTAC Assembly), which is processed and transformed into LTAC, and then passed to the backend for code generation.

This project is new and in exploratory stages. If things seem to work out, I will consider either incorporating it into my other compilers, or designing front-ends for other languages.

To get an understanding of the tree, please see the Ltac.hs file in the src folder.

### Backends
Currently, Intel x86-64 and Intel i386 backends are supported. Compiling and linking are supported; for the Assembly code, we are using the GNU Assembler. For linking, we are currently invoking GCC. Please note that this is behavior that I intend to change later on. I am not doing that right now though because linking can become very platform-specific.

### Documentation
Documentation can be found in the /docs folder. Currently, I only have documentation for LTAC Assembly, but this is a good way to get started.

The ``ltac_syntax.xlsx`` spreadsheet contains the syntax for the LtacNode types. As new node types are added, we will update this sheet.
