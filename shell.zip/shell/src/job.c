#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

#include <list.h>

void run_job(StrList *list)
{
    //First, construct the job
    int size = list->size;
    
    char *cmd = list->items[0];
    char **args = malloc(sizeof(char *)*size+1);
    args[0] = "";
    
    for (int i = 1; i<=size; i++)
        args[i] = list->items[i];

    pid_t pid = fork();
    int wstatus;
    
    if (pid > 0)    //Parent
    {
        free(cmd);
        free(args);
        
        waitpid(pid, &wstatus, 0);
        
        return;
    }
    else if (pid == 0)  //Child
    {
        int rc = execvp(cmd, args);
        
        if (rc == -1)
        {
            puts("Unknown command.");
        }

        return;
    }
    else
    {
        free(cmd);
        free(args);
        free(list);
    
        puts("Error: Could not start process.");
        exit(1);
    }
}
