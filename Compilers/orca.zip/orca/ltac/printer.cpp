#include <iostream>
#include <fstream>
#include <string>

#include <ltac_build.hpp>
#include <ltac/struct.hpp>
#include <ltac/types.hpp>
#include <ltac/var.hpp>

// The main printing function for the entire file
void ltacPrint(LtacFile *file) {
    std::ofstream writer(file->getName());
    
    for (auto data : file->getData()) {
        writer << data->printData() << std::endl;
    }
    
    writer << std::endl;
    
    for (auto code : file->getCode()) {
        writer << code->printInstr() << std::endl;
    }
    
    writer.close();
}

// The individual print functions for the instructions

//========================================================
// String values (data section)

std::string LtacStringVal::printData() {
    return name + " .string \"" + val + "\"";
}

//========================================================
// Labels

std::string LtacLabel::printInstr() {
    return name + ":";
}

//========================================================
// Function argument loads

std::string LtacLdArg::printInstr() {
    std::string content = "  ";
    
    switch (this->type) {
        case LtacType::LdBArg: content += "ldb_arg"; break;
        case LtacType::LdWArg: content += "ldw_arg"; break;
        case LtacType::LdDwArg: content += "lddw_arg"; break;
        case LtacType::LdQwArg: content += "ldqw_arg"; break;
        default: content += "ldarg";
    }
    
    content += " " + std::to_string(this->pos);
    return content;
}

//========================================================
// Function calls

std::string LtacFuncCall::printInstr() {
    std::string content = "";

    for (auto arg : args) {
        switch (arg->getType()) {
            case LtacType::Int: {
                content += "  pusharg_i " + arg->printInstr() + "\n";
            } break;
            
            case LtacType::String: {
                content += "  pusharg_s " + arg->printInstr() + "\n";
            } break;
            
            case LtacType::Var32: {
                content += "  pusharg_v32 " + arg->printInstr() + "\n";
            } break;
            
            case LtacType::Ptr: {
                content += "  pusharg_ptr " + arg->printInstr() + "\n";
            } break;
        }
    }
    
    content += "  call " + name + "\n";
    return content;
}

//========================================================
// Returns

std::string LtacRet::printInstr() {
    return "  ret\n";
}

//========================================================
// System calls

std::string LtacSyscall::printInstr() {
    std::string content = "";

    for (auto arg : args) {
        switch (arg->getType()) {
            case LtacType::Int: {
                content += "  pushkarg_i " + arg->printInstr() + "\n";
            } break;
            
            case LtacType::String: {
                content += "  pushkarg_s " + arg->printInstr() + "\n";
            } break;
            
            case LtacType::Var32: {
                content += "  pushkarg_v32 " + arg->printInstr() + "\n";
            } break;
            
            case LtacType::Ptr: {
                content += "  pushkarg_ptr " + arg->printInstr() + "\n";
            } break;
        }
    }
    
    content += "  syscall\n";
    return content;
}

//========================================================
// Variables

std::string LtacVar32::printInstr() {
    return "[bp-" + std::to_string(pos) + "]";
}

std::string LtacPtr::printInstr() {
    return "[bp-" + std::to_string(pos) + "]";
}

std::string LtacMovI32::printInstr() {
    std::string content = "  mov [bp-" + std::to_string(pos);
    content += "], " + std::to_string(val) + "\n";
    
    return content;
}

std::string LtacMovV32::printInstr() {
    std::string content = "  mov [bp-" + std::to_string(dest);
    content += "], ";
    content += "[bp-" + std::to_string(src) + "]\n";
    
    return content;
}

