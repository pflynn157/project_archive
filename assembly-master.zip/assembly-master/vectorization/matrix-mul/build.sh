#!/bin/bash
#gcc main.c -c
#nasm -felf64 array_add.asm
#gcc -no-pie array_add.o main.o -o array_add

gcc main.c -c -g
nasm -felf64 vec_mul.asm -g
nasm -felf64 array_add.asm -g
gcc -no-pie vec_mul.o array_add.o main.o -o matrixmul -g
