#pragma once

void shell_mode();
