// Copyright 2017 Patrick Flynn
//
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, 
//	this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, this 
//	list of conditions and the following disclaimer in the documentation and/or 
//	other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors may 
//	be used to endorse or promote products derived from this software 
//	without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#include <iostream>
#include <QString>
#include <QFile>
#include <QTextStream>
#include <QFileInfo>

#include "key_parser.hh"
using namespace CppLib;

void genTestFile() {
    std::cout << "Generating test file..." << std::endl;
    QFile file("./test_file");
    if (file.open(QFile::ReadWrite)) {
        QTextStream writer(&file);
        writer << "key1=Key1Content\n";
        writer << "key2=ThisIsKeyTwo\n";
        writer << "key3=This is a key with spaces.\n";
        writer << "     key4=This is a key with a lot of whitespace    ";
        file.close();
    }
    std::cout << "Done" << std::endl;
    std::cout << "The absolute path of your test file is as follows: " << QFileInfo(file).absolutePath().toStdString() << std::endl;
    std::cout << std::endl;
}

void loadTest() {
    std::cout << "TEST 1" << std::endl;
    std::cout << "Testing load functions..." << std::endl;
    std::cout << "\n";
    std::cout << "Not preserving whitespace..." << std::endl;
    KeyParser *parser = new KeyParser("./test_file");
    std::cout << "\nDisplaying all keys..." << std::endl;
    for (int i = 0; i<parser->allKeys()->size(); i++) {
        std::cout << QString(parser->allKeys()->at(i)).toStdString() << std::endl;
    }
    std::cout << "Done" << std::endl;
    std::cout << "Preserving whitespace..." << std::endl;
    KeyParser *parser2 = new KeyParser("./test_file",true);
    std::cout << "\nDisplaying all keys..." << std::endl;
    for (int i = 0; i<parser2->allKeys()->size(); i++) {
        std::cout << QString(parser2->allKeys()->at(i)).toStdString() << std::endl;
    }
    std::cout << "Done" << std::endl;
    std::cout << "\n";
    std::cout << "Checking the keyExists function..." << std::endl;
    std::cout << "Test 1: ";
    if (parser->keyExists("key3")) {
        std::cout << "Succeeded";
    } else {
        std::cout << "Failed";
    }
    std::cout << std::endl;
    std::cout << "Test 2: ";
    if (parser->keyExists("kkeeyy22")) {
        std::cout << "Failed";
    } else {
        std::cout << "Succeeded";
    }
    std::cout << std::endl;
    std::cout << "The content loading test has completed." << std::endl;
    std::cout << std::endl;
}

void valueTest() {
    std::cout << "TEST 2" << std::endl;
    std::cout << "Test the value function..." << std::endl;
    std::cout << std::endl;
    KeyParser *parser1 = new KeyParser("./test_file");
    KeyParser *parser2 = new KeyParser("./test_file",true);
    QString test1 = parser1->value("key1");
    QString test2 = parser2->value("key3");
    std::cout << "Printing values..." << std::endl;
    std::cout << test1.toStdString() << std::endl;
    std::cout << test2.toStdString() << std::endl;
    std::cout << std::endl;
    std::cout << "Test 1: ";
    if (test1=="Key1Content") {
        std::cout << "Succeeded";
    } else {
        std::cout << "Failed";
    }
    std::cout << std::endl;
    std::cout << "Test 2: ";
    if (test2=="This is a key with spaces.") {
        std::cout << "Succeeded";
    } else {
        std::cout << "Failed";
    }
    std::cout << "\n\n";
    std::cout << "The value test has been completed." << std::endl;
    std::cout << std::endl;
}

void keyEditTest() {
    std::cout << "TEST 3" << std::endl;
    std::cout << "This test tests the addKey, editKey, and deleteKey functions." << std::endl;
    std::cout << std::endl;
    std::cout << "Executing our functions..." << std::endl;
    KeyParser *parser = new KeyParser("./test_file");
    parser->addKey("key5","This key has been added by the test program.");
    parser->editKey("key1","This was edited by the test program.");
    parser->deleteKey("key4");
    parser->write();
    std::cout << "Done" << std::endl;
    std::cout << std::endl;
    std::cout << "Printing all content..." << std::endl;
    QFile file("./test_file");
    if (file.open(QFile::ReadWrite)) {
        QTextStream reader(&file);
        while (!reader.atEnd()) {
            std::cout << reader.readLine().toStdString() << std::endl;
        }
        file.close();
    }
    std::cout << "Done" << std::endl;
    std::cout << std::endl;
    std::cout << "The key editing test has been completed." << std::endl;
    std::cout << std::endl;
}

int main() {
    genTestFile();
    loadTest();
    valueTest();
    keyEditTest();
    return 0;
}
