#!/bin/bash

echo "Building..."

if [ -d build/stdlib ] ; then
    cd build/stdlib
    rm -r ./*
    cd ../..
else
    mkdir -p build/stdlib
fi

cp -r lib/*.asm build/stdlib
cd build/stdlib

as start.asm -o start.o
as io.asm -o io.o
as string.asm -o string.o

if [ ! -d /usr/local/lib/quik ] ; then
    sudo mkdir /usr/local/lib/quik
fi

sudo cp *.o /usr/local/lib/quik

echo "Done"
