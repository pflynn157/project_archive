#include <iostream>
#include <stdlib.h>

int main() {
	double val = 3.14;
	
	char buf[64];
	sprintf(buf, "%ld", *(long*)&val);
	
	long no = std::stol(buf);
	std::cout << no << std::endl;
	return 0;
}
