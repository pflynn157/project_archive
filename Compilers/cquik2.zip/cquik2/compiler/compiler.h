#pragma once

#include <ltac/ltac.h>

typedef enum
{
    Amd64,
    AArch64
} ArchType;

void compiler_init(ArchType type);
void compiler_run(LtacFile *file);
void compiler_build();
