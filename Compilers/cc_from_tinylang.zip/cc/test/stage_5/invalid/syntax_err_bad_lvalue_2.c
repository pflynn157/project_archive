int main() {
    int a = 2;
    !a = 3;
    return a;
}