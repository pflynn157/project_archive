#!/bin/bash
echo "You are about to remove the libipc library."
echo "This can break other applications."
echo "Do you wish to continue? (y,n)"
read x

if [ $x == "n" ]
then exit 0
fi

echo "Uninstalling..."

cd /usr/local/include/cpplib
rm {ipc_manager,ipc_thread}.hh

cd /usr/local/lib
rm ./libipc.so
rm ./libipc.so.1
rm ./libipc.so.1.0
rm ./libipc.so.1.0.0

ldconfig

echo "Done"
