//
// Copyright 2021 Patrick Flynn
// This file is part of uds-wordpad.
// uds-wordpad is licensed under the BSD-3 license. See the COPYING file for more information.
//
#pragma once

#include <QTabWidget>
#include <QString>

#include <editor.hpp>

class TabWidget : public QTabWidget {
    Q_OBJECT
public:
    TabWidget();
    ~TabWidget();
    
    void addUntitledTab();
    void addTabFromFile(QString path);
    
    Editor *getCurrentWidget();
private slots:
    void onTabChanged(int index);
    void onTabClosed(int index);
};

