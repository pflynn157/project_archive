#include <iostream>

#include "config.hpp"

typedef Config::Token Tk;

ConfigParser::ConfigParser(std::string basePath) {
    if (basePath[basePath.length() - 1] != '/')
        basePath += "/";
    std::string path = basePath + "main.rt";
    scanner = new Config::Scanner(path);
    
    config = new ServerConfig;
}

ServerConfig *ConfigParser::getConfig() {
    Tk token = scanner->getNext();
    
    while (token.type != Config::Eof) {
        switch (token.type) {
            case Config::Router: parseRouter(); break;
            case Config::Generator: parseGenerator(); break;
            
            default: {
                std::cerr << "Error: Unknown token in router global scope." << std::endl;
            }
        }
    
        token = scanner->getNext();
    }

    return config;
}

void ConfigParser::parseRouter() {
    Tk token = scanner->getNext();
    if (token.type != Config::LBrace) {
        std::cerr << "Error: Expected \'{\' to open router block." << std::endl;
        return;
    }
    
    token = scanner->getNext();
    while (token.type != Config::RBrace) {
        std::string reqPath = "";
        std::string outputPath = "";
        
        if (token.type != Config::String) {
            std::cerr << "Error: Expected path." << std::endl;
            return;
        }
        
        reqPath = token.id_val;
        
        token = scanner->getNext();
        if (token.type != Config::Colon) {
            std::cerr << "Error: Expected \':\' in router entry." << std::endl;
            return;
        }
        
        token = scanner->getNext();
        if (token.type != Config::String) {
            std::cerr << "Error: Expected output path." << std::endl;
            return;
        }
        
        outputPath = token.id_val;
        
        token = scanner->getNext();
        if (token.type != Config::SemiColon) {
            std::cerr << "Error: Expected terminator in router entry." << std::endl;
            return;
        }
        
        config->router[reqPath] = outputPath;
    
        token = scanner->getNext();
    }
}

void ConfigParser::parseGenerator() {
    Tk token = scanner->getNext();
    if (token.type != Config::LBrace) {
        std::cerr << "Error: Expected \'{\' to open router block." << std::endl;
        return;
    }
    
    token = scanner->getNext();
    while (token.type != Config::RBrace) {
        switch (token.type) {
            case Config::SingleFile: {
                token = scanner->getNext();
                if (token.type != Config::Colon) {
                    std::cerr << "Error: Expected \':\' in generator entry." << std::endl;
                    return;
                }
                
                token = scanner->getNext();
                if (token.type == Config::On) config->singleFile = true;
                else config->singleFile = false;
                
                token = scanner->getNext();
                if (token.type != Config::SemiColon) {
                    std::cerr << "Error: Expected terminator in generator entry." << std::endl;
                    return;
                }
            } break;
            
            default: {
                std::cerr << "Error: Unknown field in generator block." << std::endl;
                return;
            }
        }
    
        token = scanner->getNext();
    }
}
