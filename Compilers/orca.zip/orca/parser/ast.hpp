#pragma once

#include <string>
#include <fstream>
#include <vector>

enum class DataType {
    None,
    Void,
    Byte,
    Char,
    Octal,
    Int,
    Float,
    String
};

enum class MathType {
    None,
    Add,
    Sub,
    Mul,
    Div,
    Inc,
    Dec
};

enum class CmpType {
    None,
    Eq,
    Neq,
    Gt,
    Lt,
    Gte,
    Lte
};

enum class StringOp {
    None,
    Len
};

enum class AstType {
    None,
    Tree,
    Scope,
    
    Func,
    ArgList,
    Arg,
    
    FuncCall,
    Ret,
    
    Var,
    
    Cond,
    While,
    If,
    Elif,
    Else,
    
    Byte,
    Char,
    Octal,
    Int,
    Float,
    String,
    Id,
    
    MathOp,
    CmpOp,
    StringOp
};

class AstNode {
public:
    AstNode() {}
    AstNode(AstType type) {
        this->type = type;
    }
    
    virtual std::string writeDot(std::string prefix) {
        return "";
    }
    
    std::string writeDotStd(std::string prefix, std::string val, std::string color = "");
    std::string writeDotParent(std::string prefix, std::string nodeName, std::string shape = "");
    
    void addChild(AstNode *node);
    void addChildren(std::vector<AstNode *> list);
    
    std::vector<AstNode *> getChildren() {
        return children;
    }
    
    AstType getType() {
        return type;
    }
protected:
    AstType type;
    std::vector<AstNode *> children;
};

// The top-most AST node
class AstTree : public AstNode {
public:
    AstTree(std::string file);
    std::string writeDot();
private:
    std::string file;
};

// Represents a scope
class AstScope : public AstNode {
public:
    AstScope() { type = AstType::Scope; }
    std::string writeDot(std::string prefix);
};

// Represents a function
class AstFunc : public AstNode {
public:
    explicit AstFunc();
    explicit AstFunc(std::string name);
    explicit AstFunc(std::string name, DataType type);
    std::string writeDot(std::string prefix);
    
    std::string getName() {
        return name;
    }
private:
    std::string name = "";
    DataType retType = DataType::Void;
};

// Represents an argument list
class AstArgList : public AstNode {
public:
    AstArgList();
    std::string writeDot(std::string prefix);
};

// Represents an argument
class AstArg : public AstNode {
public:
    explicit AstArg(std::string name, DataType dt);
    
    std::string getName() { return name; }
    DataType getDataType() { return dataType; }
    
    std::string writeDot(std::string prefix);
private:
    std::string name = "";
    DataType dataType = DataType::None;
};

// Represents a function call
class AstFuncCall : public AstNode {
public:
    explicit AstFuncCall(std::string name);
    std::string writeDot(std::string prefix);
    
    std::string getName() { return name; }
private:
    std::string name = "";
};

// Represents a return statement
class AstRet : public AstNode {
public:
    AstRet();
    std::string writeDot(std::string prefix);
};

// Represents a variable
class AstVar : public AstNode {
public:
    explicit AstVar(std::string name);
    explicit AstVar(std::string name, bool dec);
    explicit AstVar(std::string name, bool dec, DataType dt);
    bool isDeclaration();
    void setDeclaration(bool dec);
    DataType getDataType();
    void setDataType(DataType dt);
    std::string getName();
    void setName(std::string name);
    std::string writeDot(std::string prefix);
private:
    std::string name = "";
    bool declaration = false;
    DataType dataType = DataType::None;
};

// Represents a conditional statement
class AstCond : public AstNode {
public:
    explicit AstCond();
    std::string writeDot(std::string prefix);
};

// Represents a generic conditional-based statement
class AstCondStm : public AstNode {
public:
    explicit AstCondStm();
    explicit AstCondStm(AstCond *cond);
    std::string writeDot(std::string prefix);
protected:
    AstCond *cond;
    std::string condName = "";
};

// Represents a while loop
class AstWhile : public AstCondStm {
public:
    explicit AstWhile(AstCond *cond) : AstCondStm(cond) {
        type = AstType::While;
        condName = "While";
    }
};

// Represents an if statement
class AstIf : public AstCondStm {
public:
    explicit AstIf(AstCond *cond) : AstCondStm(cond) {
        type = AstType::If;
        condName = "If";
    }
};

// Represents an elif statement
class AstElif : public AstCondStm {
public:
    explicit AstElif(AstCond *cond) : AstCondStm(cond) {
        type = AstType::Elif;
        condName = "Elif";
    }
};

// Represents an else statement
class AstElse : public AstNode {
public:
    explicit AstElse();
    std::string writeDot(std::string prefix);
};

// Represents a byte literal (otherwise known as a hex value)
class AstByte : public AstNode {
public:
    explicit AstByte(unsigned char val);
    std::string writeDot(std::string prefix);
private:
    unsigned char val = 0;
};

// Represents a character literal
class AstChar : public AstNode {
public:
    explicit AstChar(char val);
    std::string writeDot(std::string prefix);
private:
    char val = 0;
};

// Represents an octal literal
class AstOctal : public AstNode {
public:
    explicit AstOctal(std::string val);
    std::string writeDot(std::string prefix);
private:
    std::string val = "";
};

// Represents an integer
class AstInt : public AstNode {
public:
    explicit AstInt(int val);
    std::string writeDot(std::string prefix);
    
    int getVal() { return val; }
private:
    int val = 0;
};

// Represents a float
class AstFloat : public AstNode {
public:
    explicit AstFloat(float val);
    std::string writeDot(std::string prefix);
private:
    float val = 0;
};

// Represents an ID
class AstId : public AstNode {
public:
    explicit AstId(std::string val);
    std::string writeDot(std::string prefix);
    
    std::string getVal() { return val; }
private:
    std::string val = "";
};

// Represents a string
class AstString : public AstNode {
public:
    explicit AstString(std::string val);
    std::string writeDot(std::string prefix);
    
    std::string getVal() { return val; }
private:
    std::string val = "";
};

// Represents a math operator
class AstMathOp : public AstNode {
public:
    explicit AstMathOp(MathType op);
    std::string writeDot(std::string prefix);
private:
    MathType op = MathType::None;
};

// Represents a comparison operator
class AstCmpOp : public AstNode {
public:
    explicit AstCmpOp(CmpType op);
    std::string writeDot(std::string prefix);
private:
    CmpType op = CmpType::None;
};

// Represents a string operation
class AstStringOp : public AstNode {
public:
    explicit AstStringOp(std::string id, StringOp op);
    std::string writeDot(std::string prefix);
private:
    std::string id = "";
    StringOp op = StringOp::None;
};

