#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QtXml>
#include <iostream>

#include "repository.hpp"

// Returns a list of valid syntaxes
QStringList Repository::syntaxList() {
    QStringList dirEntries = getEntries(":/data/syntax");
    QStringList names;
    
    for (QString item : dirEntries) {
        QString name = getName(":/data/syntax/" + item);
        names.append(name);
    }

    return names;
}

// Returns the definition file for a given syntax name
QString Repository::defForName(QString name) {
    QStringList dirEntries = getEntries(":/data/syntax");
    QStringList names;
    
    for (QString item : dirEntries) {
        QString currentName = getName(":/data/syntax/" + item);
        if (currentName == name) {
            return QFileInfo(item).baseName();
        }
    }
    
    return "";
}

// Returns the definition file for a given file name
QString Repository::defForFileName(QString name) {
    QStringList dirEntries = getEntries(":/data/syntax");
    QStringList names;
    
    for (QString item : dirEntries) {
        QStringList extensions = getExtensions(":/data/syntax/" + item);
        
        for (QString ext : extensions) {
            if (name.endsWith(ext)) {
                return getName(":/data/syntax/" + item);
            }
        }
    }
    
    return "";
}

// Returns a list of valid syntax themes
QStringList Repository::themeList() {
    QStringList dirEntries = getEntries(":/data/theme");
    QStringList names;
    
    for (QString item : dirEntries) {
        QString name = getName(":/data/theme/" + item);
        names.append(name);
    }

    return names;
}

// Returns the theme file for a given theme name
QString Repository::themeForName(QString name) {
    QStringList dirEntries = getEntries(":/data/theme");
    QStringList names;
    
    for (QString item : dirEntries) {
        QString currentName = getName(":/data/theme/" + item);
        if (currentName == name) {
            return QFileInfo(item).baseName();
        }
    }
    
    return "";
}

// Returns a list of given entries
QStringList Repository::getEntries(QString path) {
    QDir dir(path);
    return dir.entryList(QDir::Files | QDir::NoDotAndDotDot, QDir::Name);
}

// Loads an XML doc for reading
QDomDocument *Repository::getDocument(QString path) {
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly)) {
        std::cout << "Unable to open file: " << path.toStdString() << std::endl;
        return nullptr;
    }
    
    QDomDocument *doc = new QDomDocument("doc");
    if (!doc->setContent(&file)) {
        std::cout << "Unable to read file: " << path.toStdString() << std::endl;
        return nullptr;
    }
    
    return doc;
}

// Parses the XML file and returns the name for the syntax
QString Repository::getName(QString path) {
    QString name = "(unknown)";
    QDomDocument *doc = getDocument(path);
    if (doc == nullptr)
        return name;
    
    QDomElement element = doc->documentElement();
    QDomNode node = element.firstChild();
    
    while (!node.isNull()) {
        element = node.toElement();
        if (element.isNull()) {
            node = node.nextSibling();
            continue;
        }
        
        if (element.tagName() == "name") {
            name = element.text();
            break;
        }
        
        node = node.nextSibling();
    }
    
    return name;
}

// Parses the XML file and returns the extensions for the syntax
QStringList Repository::getExtensions(QString path) {
    QString name = "(unknown)";
    QDomDocument *doc = getDocument(path);
    if (doc == nullptr)
        return QStringList();
    
    QDomElement element = doc->documentElement();
    QDomNode node = element.firstChild();
    
    while (!node.isNull()) {
        element = node.toElement();
        if (element.isNull()) {
            node = node.nextSibling();
            continue;
        }
        
        if (element.tagName() == "extensions") {
            name = element.text();
            break;
        }
        
        node = node.nextSibling();
    }
    
    QStringList list;
    QString buffer = "";
    for (QChar c : name) {
        if (c == ';') {
            list.push_back(buffer);
            buffer = "";
        } else {
            buffer += c;
        }
    }
    
    list.push_back(buffer);
    return list;
}
