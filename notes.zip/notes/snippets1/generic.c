#include <stdio.h>

//T- 1-> int
//	2-> double
void print(void *arg, int t)
{
	if (t == 1) {
		int x = *(int *)arg;
		printf("INT: %d\n", x);
	} else if (t == 2) {
		double d = *(double *)arg;
		printf("Float: %f\n", d);
	}
}

void main()
{
	int x = 5;
	print((void *)&x, 1);
	
	puts("");
	
	double pi = 3.14;
	print((void *)&pi, 2);
}
