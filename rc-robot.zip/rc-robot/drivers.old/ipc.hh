#pragma once

#include <string>

int ipc_gen_key(std::string key);
void ipc_write(std::string data, int key);
std::string ipc_read(int key);
void ipc_cleanup(int key);


