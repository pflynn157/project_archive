// kernel main

// Display is default 80 (col) x 25 (row)

char *display = (char *)0x000B8000;
int row = 0;
int col = 0;

void write_entry(char letter, char color)
{
    display[col] = letter;
    display[col+1] = color;
    
    col += 2;
    if (col >= 80) {
        col = 0;
        ++row;
    }
}

void clear_display()
{
    for (int i = 0; i<25; i++)
    {
        for (int j = 0; j<80; j++)
        {
            write_entry(' ', 0x28);
        }
    }
}

void kernel_main() 
{
    clear_display();
}
