#!/bin/bash

cd x86/src

rm ../obj/*

aflex parser.l
gnatchop -w parser.ada
ayacc parser.y
gnatchop -w parser.ada

cd ../..

gprbuild -P adaasm.gpr

