## Docs

Contains various documentation on Ida.

Please note that some of it is a little lacking and in some cases completely out of date. I do plan to update in the near future however. I'm sorry in advance.
