// A simple linear test to make sure nothing got messed up with 1-D arrays
#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <Kokkos_Core.hpp>

const size_t SIZE = 16000;

int main(int argc, char **argv) {
    Kokkos::initialize(argc, argv);
    
    // Init arrays
    int *num1 = (int *)malloc(sizeof(int)*SIZE);
    int *num2 = (int *)malloc(sizeof(int)*SIZE);
    int *result1 = (int *)malloc(sizeof(int)*SIZE);
    int *result2 = (int *)malloc(sizeof(int)*SIZE);
    
    // Fill the arrays
    Kokkos::parallel_for("Init", SIZE, KOKKOS_LAMBDA(const size_t i) {
        num1[i] = rand() % 10;
        num2[i] = rand() % 10;
        result1[i] = num1[i] + num2[i];
    });
    
    // Now, add
    Kokkos::parallel_for("Add", SIZE, KOKKOS_LAMBDA(const size_t i) {
        result2[i] = num1[i] + num2[i];
    });
    
    int errors = 0;
    for (int i = 0; i<SIZE; i++) {
        if (result1[i] != result2[i]) ++errors;
    }
    printf("Errors: %d\n", errors);
    
    return 0;
}

