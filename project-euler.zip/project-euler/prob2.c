#include <stdio.h>

int main() {
    int no1 = 0;
    int no2 = 1;
    int sum = 0;
    
    while (1) {
        int current = no1 + no2;
        no1 = no2;
        no2 = current;
        
        if (current >= 4000000) break;
        if (current % 2 == 0) sum += current;
    }
    
    printf("%d\n", sum);
    
    return 0;
}
