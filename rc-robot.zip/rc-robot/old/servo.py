#!/usr/bin/python3
#Cycles:
# 0 -> 5
# 90 -> 7.5
# 180 -> 10
#
#Call with ChangeDutyCycle
import RPi.GPIO as GPIO
import time

class Servo:
	servo = 8
	pwm = 0
	
	def init(self):
		GPIO.setmode(GPIO.BOARD)
		GPIO.setup(self.servo, GPIO.OUT)

		self.pwm = GPIO.PWM(self.servo, 50)
		self.pwm.start(7)
		self.steer(7)
		
	def steer(self, deg):
		deg = float(deg)
		if deg >= 5:
			if deg <= 10:
				self.pwm.ChangeDutyCycle(float(deg))
				
	def control(self):
		while True:
			deg = float(input("> "))
			self.steer(deg)

