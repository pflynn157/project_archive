#pragma once

#include <QMenu>
#include <QAction>

class FileMenu : public QMenu {
    Q_OBJECT
public:
    FileMenu();
    ~FileMenu();
private:
    QAction *newFile, *openFile, *saveFile, *saveFileAs;
private slots:
    void onNewFileClicked();
    void onOpenFileClicked();
    void onSaveClicked();
    void onSaveAsClicked();
};
