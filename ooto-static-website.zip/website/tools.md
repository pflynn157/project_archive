---
layout: page
title: Tools
permalink: /tools/
---

Welcome to the tools page! Although I generally try to make use of available tools on my OS, I have a few tools I use in my everyday development. Of course, using these tools is not a requirement for the overall project, but I think it would be helpful to have them here.

All source code can be found here: [https://gitlab.com/ootoproject](https://gitlab.com/ootoproject). Because I use many of them for work beyond these projects, many are mirrored to my [personal Github profile](https://github.com/patrickf2000).

### Desktop Tools

* [__CppEditor__](/tools/cppeditor) -> My text/code editor I use for just about everything. It is written in C++ and uses the Qt and KDE libraries, making it portable across operating systems.

### Other Tools

* [__minilex__](/tools/minilex) -> A simple, easy-to-use minimalist lexical analyzer generator. Generates an analyzer in C++ that can be integrated directly into a project.

