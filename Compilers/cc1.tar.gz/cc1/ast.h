#pragma once

// Overall AST structure
/*
AST base
    -> Functions
        -> Block
            -> Expression (statement_type, values)
*/

// Represents the various types
typedef enum
{
    None,
    Void,
    Int
} DataType;

typedef enum
{
    Empty,
    UnaryExpr
} ExprType;

typedef enum
{
    VarDec,
    Ret,
    RetVoid
} StatementType;

typedef enum
{
    IntLiteral
} NodeType;

// Represents various AST elements
typedef struct
{
    NodeType type;
    int i32_literal;
} ExprNode;

typedef struct
{
    StatementType stmt_type;
    ExprType expr_type;
    
    ExprNode **expr_list;
    int expr_count;
    int expr_max;
} Expression;

typedef struct
{
    Expression **lines;
    int line_count;
    int line_max;
} Block;

typedef struct
{
    DataType type;
    const char *name;
    
    Block *block;
} Function;

typedef struct
{
    const char *mod_name;
    
    Function **funcs;
    int func_count;
    int func_max;
} Ast;

void ast_set_data_type(DataType type);
void ast_set_expr_type(ExprType type);
void ast_set_statement_type(StatementType type);
void ast_set_id(const char *identifier);
void ast_set_int_node(int literal);
void ast_add_declare_id(char *identifier);

void ast_build_function(Ast *ast);
void ast_build_expression();

Ast *create_ast(const char *mod_name);
void free_ast(Ast *ast);

