from socket import *

macAddr = "B8:27:EB:89:61:0F"
port = 3
bklog = 1
size = 1024

socketd = socket(AF_BLUETOOTH, SOCK_STREAM, BTPROTO_RFCOMM)
socketd.bind((macAddr, port))
socketd.listen(bklog)

try:
    client, addr = socketd.accept()
    while 1:
            data = client.recv(size)
            if data:
                d = data.decode()
                print(d)
                client.send(data)
except:
    print("Goodbye")
    client.close()
    socketd.close()
