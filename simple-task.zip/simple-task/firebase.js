const firebaseApp = require("firebase/app");
const firebaseAuth = require("firebase/auth");

const firebase = firebaseApp.initializeApp({
    apiKey: "AIzaSyCDv9guv2TELL0I23KVyAqaTTw9wKSC2mo",
    authDomain: "project1-fe974.firebaseapp.com",
    projectId: "project1-fe974",
    storageBucket: "project1-fe974.appspot.com",
    messagingSenderId: "813046834700",
    appId: "1:813046834700:web:878e420f698c8e33b33029",
    databaseURL: "project1-fe974-default-rtdb.europe-west1.firebasedatabase.app"
});

exports.firebase = firebase;
exports.currentUser = null;

const auth = firebaseAuth.getAuth(this.firebase);

firebaseAuth.onAuthStateChanged(auth, user => {
    if (user) {
        console.log("Signed In");
        this.currentUser = user;
        console.log(exports.currentUser.uid);
    } else {
        console.log("Sign Out");
        this.currentUser = null;
    }
});