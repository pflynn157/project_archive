var searchData=
[
  ['var',['Var',['../structVar.html',1,'']]],
  ['varinfo',['VarInfo',['../structVarInfo.html',1,'']]]
];
