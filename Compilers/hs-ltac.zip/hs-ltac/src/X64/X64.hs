module X64.X64(x64Func,
    x64Ret,
    x64PushArg,
    x64Call,
    x64IStoreI,
    x64ILdrI,
    x64ILdrV,
    x64IStr,
    x64IMathRR) where
    
import System.IO

import Ltac
import X64.X64Registers
import X64.X64Vars
import X64.X64Math

-- Translates certain instructions to x86-64 Assembly
-- Function declarations
x64Func ln writer = do
    let line = (arg1 ln) ++ ":"
    hPutStrLn writer line
    
    -- Setup the stack
    hPutStrLn writer "\tpush rbp"
    hPutStrLn writer "\tmov rbp, rsp"
    
    let stackSize = arg2 ln
    if stackSize == "0"
        then hPutStrLn writer ""
        else do
            hPutStrLn writer ("\tsub rsp, " ++ stackSize)
            hPutStrLn writer ""
    
-- Function return instructions
x64Ret ln writer = do
    hPutStrLn writer ""
    hPutStrLn writer "\tleave"
    hPutStrLn writer "\tret"
    hPutStrLn writer ""
    
-- Pusharg instruction
x64PushArg2 ln writer
    -- Raw integer
    | t == "int" = do
        hPutStr writer "\tmov "
        hPutStr writer (x64CallReg32 no)
        hPutStrLn writer (", " ++ (arg2 ln))
        
    -- Raw string
    | t == "string" = do
        hPutStr writer "\tmov "
        hPutStr writer (x64CallReg64 no)
        hPutStr writer ", OFFSET FLAT:"
        hPutStrLn writer (arg2 ln)
        
    -- Integer variable
    | t == "i.var" = do
        hPutStr writer "\tmov "
        hPutStr writer (x64CallReg32 no)
        hPutStr writer ", DWORD PTR [rbp-"
        hPutStrLn writer ((arg2 ln) ++ "]")
        
    -- Unknown type
    | otherwise = putStrLn "Unknown type in pusharg"
    where
        t = arg1 ln
        no = read (arg3 ln) :: Int
        
x64PushArg ln writer = do
    let no = read (arg3 ln) :: Int
    if no == 1
        then do
            hPutStrLn writer ""
            x64PushArg2 ln writer
        else x64PushArg2 ln writer
        
-- The call instruction
x64Call ln writer = do
    hPutStrLn writer ("\tcall " ++ (arg1 ln) ++ "")
    hPutStrLn writer ""
    
