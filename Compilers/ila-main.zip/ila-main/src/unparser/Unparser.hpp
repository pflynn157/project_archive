#pragma once

#include <ast/ast.hpp>

enum class Unparser {
    TinyLang,
    Cpp,
    Ada,
    Java
};

void unparse(AstTree *file, Unparser lang);
void unparse_cpp(AstTree *file);
void unparse_ada(AstTree *file);

