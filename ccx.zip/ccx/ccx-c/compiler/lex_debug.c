#include <stdio.h>
#include <string.h>

#include "lex.h"

void lex_debug(Token token, Scanner *scanner) {
    switch (token) {
        case Func: puts("FUNC"); break;
        case Return: puts("RETURN"); break;
        case Var: puts("VAR"); break;
        
        case I32: puts("i32"); break;
        
        case LCBrace: puts("{"); break;
        case RCBrace: puts("}"); break;
        case LParen: puts("("); break;
        case RParen: puts(")"); break;
        case Colon: puts(":"); break;
        case Assign: puts(":="); break;
        case SemiColon: puts(";"); break;
        case Comma: puts(","); break;
        case Plus: puts("+"); break;
        
        case Id: printf("ID: %s [%ld]\n", lex_get_buffer(scanner), strlen(lex_get_buffer(scanner))); break;
        case IntL: printf("INTL: %d\n", lex_get_int_buffer(scanner)); break;
        
        default: puts("???");
    }
}

