#pragma once

#include <string>
#include <vector>

#include <unit.hpp>
#include <Block.hpp>

class Unit;
class Block;

class Function {
public:
    explicit Function(std::string name) {
        this->name = name;
    }

    void AddBlock(Block *block) {
        blocks.push_back(block);
    }

    void dump();

    static Function *Create(Unit *unit, std::string name);
private:
    std::string name = "";
    std::vector<Block *> blocks;
};
