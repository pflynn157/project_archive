package main

import (
	"os"
	"bytes"
)

type ByteReader struct {
	reader *os.File
}

//Setup our reader object
func (r* ByteReader) Setup(path string) {
	reader, err := os.Open(path)
	r.reader = reader
	if err != nil {
		println("Fatal error: Unable to open input.")
		os.Exit(1)
	}
	
	//Check the signature
	ex_sig := []byte {
		0xF1,
		'Q',
		'U',
		'I',
		'K',
		0xF2,
	}
	
	sig := make([]byte, 6)
	r.reader.Read(sig)
	
	if bytes.Equal(sig, ex_sig) == false {
		println("Fatal error: Invalid signature.")
		os.Exit(1)
	}
}

//Reads a single byte
func (r* ByteReader) ReadByte() byte {
	b := make([]byte, 1)
	r.reader.Read(b)
	return b[0]
}

//Read a word
func (r* ByteReader) ReadWord() []byte {
	word := make([]byte, 11)
	r.reader.Read(word)
	return word
}

//Closes up everything
func (r* ByteReader) Finish() {
	r.reader.Close()
}
