#include "keyboard.hh"
#include "string.hh"
#include "display.hh"
#include "ioasm.hh"

char lastKey = -1;

//Returns a character array from the keyboard
void getline(char *ln) {
	outb(0x60,0xFA);
	outb(0x60,0xF4);

	char line[50];
	char key = 0;
	int index = 0;
	
	clearArray(line,50);
	
	while (key != 0x1C && index < 50) {
		uint8_t code = inb(0x60);
		if (code == 0xFE) {
			continue;
		} else {
			outb(0x60,0xFA);
		}
		
		key = (char)code;
		if (key != lastKey) {
			lastKey = key;
		} else {
			continue;
		}
		
		//TODO: This is HORRIBLE, fix it
		if (key == 0x1E) {
			printf("a");
			line[index] = 'a';
			index++;
		} else if (key == 0x30) {
			printf("b");
			line[index] = 'b';
			index++;
		} else if (key == 0x2E) {
			printf("c");
			line[index] = 'c';
			index++;
		} else if (key == 0x20) {
			printf("d");
			line[index] = 'd';
			index++;
		} else if (key == 0x12) {
			printf("e");
			line[index] = 'e';
			index++;
		} else if (key == 0x21) {
			printf("f");
			line[index] = 'f';
			index++;
		} else if (key == 0x22) {
			printf("g");
			line[index] = 'g';
			index++;
		} else if (key == 0x23) {
			printf("h");
			line[index] = 'h';
			index++;
		} else if (key == 0x17) {
			printf("i");
			line[index] = 'i';
			index++;
		} else if (key == 0x24) {
			printf("j");
			line[index] = 'j';
			index++;
		} else if (key == 0x25) {
			printf("k");
			line[index] = 'k';
			index++;
		} else if (key == 0x26) {
			printf("l");
			line[index] = 'l';
			index++;
		} else if (key == 0x32) {
			printf("m");
			line[index] = 'm';
			index++;
		} else if (key == 0x31) {
			printf("n");
			line[index] = 'n';
			index++;
		} else if (key == 0x18) {
			printf("o");
			line[index] = 'o';
			index++;
		} else if (key == 0x19) {
			printf("p");
			line[index] = 'p';
			index++;
		} else if (key == 0x10) {
			printf("q");
			line[index] = 'q';
			index++;
		} else if (key == 0x13) {
			printf("r");
			line[index] = 'r';
			index++;
		} else if (key == 0x1F) {
			printf("s");
			line[index] = 's';
			index++;
		} else if (key == 0x14) {
			printf("t");
			line[index] = 't';
			index++;
		} else if (key == 0x16) {
			printf("u");
			line[index] = 'u';
			index++;
		} else if (key == 0x2F) {
			printf("v");
			line[index] = 'v';
			index++;
		} else if (key == 0x11) {
			printf("w");
			line[index] = 'w';
			index++;
		} else if (key == 0x2D) {
			printf("x");
			line[index] = 'x';
			index++;
		} else if (key == 0x15) {
			printf("y");
			line[index] = 'y';
			index++;
		} else if (key == 0x2C) {
			printf("z");
			line[index] = 'z';
			index++;
		}
	}
	
	outb(0x60,0xFA);

	printf("\n");
	
	const char *lnn = line;
	strcpy(ln,lnn);
}
