function solve5() {
	var index = 10;
	var found = 0;
	
	while (true) {
		for (var i = 1; i<21; i++) {
			if (index%i==0) {
				found++;
			}
		}
		
		if (found==20) {
			break;
		} else {
			found = 0;
			index++;
		}
	}
	
	setOutput(index);
}
