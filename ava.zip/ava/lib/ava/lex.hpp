#pragma once

#include <string>
#include <fstream>
#include <iostream>

struct Token {
    int type;
    std::string id_val;
    char i8_val;
    int i32_val;
    
    Token() {
        type = 0;
        id_val = "";
        i32_val = 0;
    }
    
    void print();
};

class BaseScanner {
public:
    explicit BaseScanner(std::string input) {
        reader = std::ifstream(input.c_str());
        if (!reader.is_open()) {
            std::cout << "Unknown input file." << std::endl;
            error = true;
        }
    }
    
    virtual ~BaseScanner() {
        reader.close();
    }
    
    virtual void rewind(Token token) = 0;
    virtual Token getNext() = 0;
    
    virtual std::string getRawBuffer() = 0;
    virtual int getLine() = 0;
    
    virtual bool isEof() = 0;
    virtual bool isError() = 0;
    
protected:
    std::ifstream reader;
    bool error = false;
};

