#include <iostream>
#include <string>
#include <cstdlib>

#include "assembler.hh"

int main(int argc, char *argv[]) {
	if (argc == 1) {
		std::cout << "Error: No input file specified." << std::endl;
		std::exit(1);
	}
	
	build(argv[1]);
	return 0;
}
