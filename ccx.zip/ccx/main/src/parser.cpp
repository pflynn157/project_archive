#include <stack>

#include "parser.hpp"

Parser::Parser(std::string path) {
    scanner = new Scanner(path);
    file = new AstFile(path);
    err = new ErrorManager(scanner);
}

Parser::~Parser() {
    if (scanner) delete scanner;
    if (err) delete err;
}

//
// The entry point, if you will, into the parser
// Here, we parse the global scope
//
AstFile *Parser::parseFile() {
    Token token = scanner->getNext();
    while (token.type != Eof) {
        switch (token.type) {
            case Func: buildFunction(); break;
            
            default: err->addSyntaxError("Invalid token in global scope.");
        }
        
        token = scanner->getNext();
    }
    
    // Print any errors
    err->print();
    
    // Return the file
    return file;
}

//
// Builds a function
//
void Parser::buildFunction() {
    Token idToken = scanner->getNext();
    if (idToken.type != Id) {
        err->addSyntaxError("Expected function name.");
        return;
    }
    
    // Parse function arguments
    Token token = scanner->getNext();
    if (token.type != LParen) {
        err->addSyntaxError("Expected opening \'(\' for arguments.");
        return;
    }
    
    while (token.type != RParen) {
        token = scanner->getNext();
    }
    
    // Check for data type
    token = scanner->getNext();
    DataType dataType = DataType::Void;
    if (token.type == Colon) {
        token = scanner->getNext();
        dataType = getDataType(token.type);
        if (dataType == DataType::Void) {
            err->addSyntaxError("Unknown type in function declaration.");
            return;
        }
        
        token = scanner->getNext();
    }
    
    if (token.type != LCBrace) {
        err->addSyntaxError("Expected opening \'{\' for block.");
        return;
    }
    
    // Build the function object, and then the block
    funcTypeMap[idToken.id_val] = dataType;
    typeMap.clear();
    arrayTypeMap.clear();
    currentFunc = idToken.id_val;
    
    AstFunction *func = new AstFunction(idToken.id_val, dataType);
    buildBlock(func->getBlock());
    file->addFunction(func);
}

//
// Builds a statement block
//
void Parser::buildBlock(AstBlock *block) {
    Token token = scanner->getNext();
    while (token.type != Eof && token.type != RCBrace) {
        switch (token.type) {
            // More advanced statements require separate function
            //
            case Var: buildVarDec(block); break;
            case Array: buildArrayDec(block); break;
            case Syscall: buildSyscall(block); break;
            case While: buildWhileLoop(block); break;
            case For: buildForLoop(block); break;
            case If: buildCondStmt(block); break;
            
            // Statements starting with identifiers
            case Id: {
                std::string name = token.id_val;
                token = scanner->getNext();
                
                if (token.type == Assign) {
                    buildVarAssign(block, name);
                } else if (token.type == LBracket) {
                    buildArrayAssign(block, name);
                } else if (token.type == LParen) {
                    buildFuncCallStmt(block, name);
                } else {
                    err->addSyntaxError("Invalid token following identifier.");
                }
            } break;
        
            // We can build simple statements right here
            //
            case Return: { 
                AstExpression *expr = buildExpression();
                AstStatement *stmt = new AstStatement(AstType::Return, funcTypeMap[currentFunc]);
                if (expr) stmt->setExpression(expr);
                block->addStatement(stmt);
            } break;
            
            case Break:
            case Continue: {
                AstStatement *stmt;
                if (token.type == Break) stmt = new AstStatement(AstType::Break);
                else stmt = new AstStatement(AstType::Continue);
                block->addStatement(stmt);
                
                token = scanner->getNext();
                if (token.type != SemiColon) {
                    err->addSyntaxError("Expected terminator.");
                }
            } break;
            
            default: err->addSyntaxError("Invalid token in block.");
        }
        token = scanner->getNext();
    }
    
    if (token.type != RCBrace) {
        err->addSyntaxError("Unexpected EOF in block.");
    }
}

//
// Builds a variable declaration
//
void Parser::buildVarDec(AstBlock *block) {
    Token token = scanner->getNext();
    std::string name = token.id_val;
    if (token.type != Id) {
        err->addSyntaxError("Expected variable name.");
    }
    
    token = scanner->getNext();
    if (token.type != Colon) {
        err->addSyntaxError("Expected \':\'.");
    }
    
    // Data type
    token = scanner->getNext();
    DataType dataType = getDataType(token.type);
    typeMap[name] = dataType;
    if (dataType == DataType::Void) {
        err->addSyntaxError("Void type invalid in this context.");
    }
    
    // Assign operator should be next
    token = scanner->getNext();
    if (token.type != Assign) {
        err->addSyntaxError("Expected \':=\'.");
    }
    
    // Now, build the expression
    AstExpression *expr = buildExpression();
    
    AstBinaryOp *assign = new AstBinaryOp(AstType::Assign);
    assign->setLVal(new AstId(name));
    assign->setRVal(expr);
    
    AstStatement *stmt = new AstStatement(AstType::VarDec, dataType);
    if (expr) stmt->setExpression(assign);
    block->addStatement(stmt);
}

//
// Builds a variable assignment
//
void Parser::buildVarAssign(AstBlock *block, std::string name) {
    AstExpression *expr = buildExpression();
    
    AstBinaryOp *assign = new AstBinaryOp(AstType::Assign);
    assign->setLVal(new AstId(name));
    assign->setRVal(expr);
    
    AstStatement *stmt = new AstStatement(AstType::VarAssign, typeMap[name]);
    if (expr) stmt->setExpression(assign);
    block->addStatement(stmt);
}

//
// Builds an array declaration
//
void Parser::buildArrayDec(AstBlock *block) {
    // Next token should be an ID
    Token token = scanner->getNext();
    std::string name = token.id_val;
    if (token.type != Id) {
        err->addSyntaxError("Expected array name.");
    }
    
    // Colon
    token = scanner->getNext();
    if (token.type != Colon) {
        err->addSyntaxError("Expected \':\' after type.");
    }
    
    // Datatype
    token = scanner->getNext();
    DataType dataType = getDataType(token.type);
    arrayTypeMap[name] = dataType;
    if (dataType == DataType::Void) {
        err->addSyntaxError("Void type invalid in this context.");
    }
    
    // The next token determines the array type
    token = scanner->getNext();
    bool isStackArray = false;
    TokenType endType;
    if (token.type == LParen) {
        isStackArray = false;
        endType = RParen;
    } else if (token.type == LBracket) {
        isStackArray = true;
        endType = RBracket;
    } else {
        err->addSyntaxError("Unknown token: arrays should be designated with either \'(\' or \'[\'.");
    }
    
    // Now, build the expression
    AstExpression *expr = buildExpression(endType);
    
    AstArrayDec *stmt = new AstArrayDec(name, isStackArray, dataType);
    if (expr) stmt->setExpression(expr);
    block->addStatement(stmt);
    
    // Final token should be the terminator
    token = scanner->getNext();
    if (token.type != SemiColon) {
        err->addSyntaxError("Unknown token: expected terminator after array declaration.");
    }
}

//
// Builds an array assignment
//
void Parser::buildArrayAssign(AstBlock *block, std::string name) {
    // First, build the array assignment expression
    AstExpression *dest_expr = buildExpression(RBracket);
    AstArrayAccess *acc = new AstArrayAccess(name, dest_expr);
    
    // Next, make sure we have an assignment operator
    Token token = scanner->getNext();
    if (token.type != Assign) {
        err->addSyntaxError("Unknown token: expected assignment operator.");
    }
    
    // Now, the main expression
    AstExpression *src_expr = buildExpression();
    
    // Finally, the statement itself
    AstBinaryOp *assign = new AstBinaryOp(AstType::Assign);
    assign->setLVal(acc);
    assign->setRVal(src_expr);
    
    AstStatement *stmt = new AstStatement(AstType::ArrayAssign, arrayTypeMap[name]);
    stmt->setExpression(assign);
    block->addStatement(stmt);
}

//
// Builds a function call statement
//
void Parser::buildFuncCallStmt(AstBlock *block, std::string name) {
    AstExpression *expr = buildExpression(RParen, true);
    AstFuncCallStmt *stmt = new AstFuncCallStmt(name);
    if (expr) stmt->setExpression(expr);
    else stmt->setExpression(new AstExprList);
    block->addStatement(stmt);
    
    // Syntax check
    Token token = scanner->getNext();
    if (token.type != SemiColon) {
        err->addSyntaxError("Expected \';\' after function call.");
    }
}

//
// Builds a syscall statement
//
void Parser::buildSyscall(AstBlock *block) {
    Token token = scanner->getNext();
    if (token.type != LParen) {
        err->addSyntaxError("Expected \'(\' after syscall statement.");
    }
    
    // Build the syscall
    AstExpression *expr = buildExpression(RParen, true);
    AstStatement *stmt = new AstStatement(AstType::Syscall);
    if (expr) stmt->setExpression(expr);
    else stmt->setExpression(new AstExprList);
    block->addStatement(stmt);
    
    // Syntax check
    token = scanner->getNext();
    if (token.type != SemiColon) {
        err->addSyntaxError("Expected \';\' after function call.");
    }
}

//
// Builds a while loop
//
void Parser::buildWhileLoop(AstBlock *block) {
    AstExpression *cond_expr = buildExpression(LCBrace);
    
    AstBlockStmt *loop = new AstBlockStmt(AstType::While);
    if (cond_expr) loop->setExpression(cond_expr);
    block->addStatement(loop);
    
    AstBlock *subBlock = new AstBlock;
    buildBlock(subBlock);
    loop->setBlock(subBlock);
}

//
// Builds a for loop
//
void Parser::buildForLoop(AstBlock *block) {
    AstExpression *init_expr = buildExpression();
    AstExpression *cmp_expr = buildExpression();
    AstExpression *inc_expr = buildExpression(LCBrace);
    
    AstForStmt *loop = new AstForStmt;
    loop->setInitExpr(init_expr);
    loop->setCmpExpr(cmp_expr);
    loop->setIncExpr(inc_expr);
    block->addStatement(loop);
    
    AstBlock *subBlock = new AstBlock;
    buildBlock(subBlock);
    loop->setBlock(subBlock);
}

//
// Builds a conditional statement
//
void Parser::buildCondStmt(AstBlock *block) {
    AstExpression *cond_expr = buildExpression(LCBrace);
    
    AstCondStmt *cond = new AstCondStmt(AstType::If);
    if (cond_expr) cond->setExpression(cond_expr);
    block->addStatement(cond);
    
    AstBlock *subBlock = new AstBlock;
    buildBlock(subBlock);
    cond->setBlock(subBlock);
    
    // Now build any sub-branches
    Token token = scanner->getNext();
    while (token.type != Eof) {
        if (token.type == Else) {
            token = scanner->getNext();
            if (token.type != LCBrace) {
                err->addSyntaxError("Expected opening \'{\'.");
            }
        
            AstCondStmt *stmt2 = new AstCondStmt(AstType::Else);
            AstBlock *subBlock2 = new AstBlock;
            buildBlock(subBlock2);
            stmt2->setBlock(subBlock2);
            
            cond->addBranch(stmt2);
            
            break;
        } else if (token.type == Elif) {
            AstExpression *cond_expr2 = buildExpression(LCBrace);
            
            AstCondStmt *stmt2 = new AstCondStmt(AstType::Elif);
            if (cond_expr2) stmt2->setExpression(cond_expr2);
            cond->addBranch(stmt2);
            
            AstBlock *subBlock2 = new AstBlock;
            buildBlock(subBlock2);
            stmt2->setBlock(subBlock2);
            
            token = scanner->getNext();
        } else {
            scanner->rewind(token);
            break;
        }
    }
}

//
// Builds an expression
//
void Parser::processExpression(std::stack<AstExpression *> &stack, std::stack<AstExpression *> &opStack) {
    while (!opStack.empty()) {
        AstExpression *rval = stack.top();
        stack.pop();
        
        AstExpression *lval = stack.top();
        stack.pop();
        
        AstBinaryOp *op = static_cast<AstBinaryOp *>(opStack.top());
        opStack.pop();
        op->setRVal(rval);
        op->setLVal(lval);
        
        /*if (op->getType() == rval->getType()) {
            AstBinaryOp *op1 = static_cast<AstBinaryOp *>(rval);
            AstBinaryOp *op2 = new AstBinaryOp(op->getType());
            
            op2->setLVal(op->getLVal());
            op2->setRVal(op1->getLVal());
            op->setLVal(op2);
            op->setRVal(op1->getRVal());
        }*/
        
        stack.push(op);
    }
}

AstExpression *Parser::buildExpression(TokenType endToken, bool isList) {
    std::stack<AstExpression *> output;
    std::stack<AstExpression *> opStack;
    AstExprList *list = nullptr;
    
    if (isList) list = new AstExprList;
    
    Token token = scanner->getNext();
    while (token.type != Eof && token.type != endToken) {
        switch (token.type) {
            // Literals
            case Id: output.push(new AstId(token.id_val)); break;
            
            case Int32: output.push(new AstInt(token.i32_val)); break;
            case String: output.push(new AstString(token.id_val)); break;
            case CharL: output.push(new AstChar(token.i8_val)); break;
            
            case True: output.push(new AstInt(1)); break;
            case False: output.push(new AstInt(0)); break;
            
            case Comma: {
                if (!list) list = new AstExprList;
                list->addItem(output.top());
                output.pop();
            } break;
            
            // Operators
            case Assign: opStack.push(new AstBinaryOp(AstType::Assign)); break;
            
            case Plus: opStack.push(new AstBinaryOp(AstType::Add)); break;
            case Minus: opStack.push(new AstBinaryOp(AstType::Sub)); break;
            case Mul: opStack.push(new AstBinaryOp(AstType::Mul)); break;
            case Div: opStack.push(new AstBinaryOp(AstType::Div)); break;
            case Mod: opStack.push(new AstBinaryOp(AstType::Mod)); break;
            
            case And: opStack.push(new AstBinaryOp(AstType::And)); break;
            case Or: opStack.push(new AstBinaryOp(AstType::Or)); break;
            case Xor: opStack.push(new AstBinaryOp(AstType::Xor)); break;
            
            case Eq: opStack.push(new AstBinaryOp(AstType::Eq)); break;
            case Ne: opStack.push(new AstBinaryOp(AstType::Ne)); break;
            case Gt: opStack.push(new AstBinaryOp(AstType::Gt)); break;
            case Lt: opStack.push(new AstBinaryOp(AstType::Lt)); break;
            case Ge: opStack.push(new AstBinaryOp(AstType::Ge)); break;
            case Le: opStack.push(new AstBinaryOp(AstType::Le)); break;
            
            default: err->addSyntaxError("Invalid token in expression.");
        }
        
        // Check operator precedence
        if (opStack.size() >= 2) {
            AstBinaryOp *op1 = static_cast<AstBinaryOp *>(opStack.top());
            opStack.pop();
            
            AstBinaryOp *op2 = static_cast<AstBinaryOp *>(opStack.top());
            
            if (op1->getPrecedence() > op2->getPrecedence()) {
                AstExpression *rval = output.top();
                output.pop();
                
                AstExpression *lval = output.top();
                output.pop();
                
                op2->setLVal(lval);
                op2->setRVal(rval);
                output.push(op2);
                opStack.pop();
            }
            
            opStack.push(op1);
        }
    
        token = scanner->getNext();
    }
    
    processExpression(output, opStack);
    
    if (list) {
        if (!output.empty()) list->addItem(output.top());
        return list;
    }
    
    if (output.size() == 0) return nullptr;
    return output.top();
}

DataType Parser::getDataType(TokenType type) {
    switch (type) {
        case U8: return DataType::U8;
        case I8: return DataType::I8;
        case U16: return DataType::U16;
        case I16: return DataType::I16;
        case U32: return DataType::U32;
        case I32: return DataType::I32;
        case U64: return DataType::U64;
        case I64: return DataType::I64;
        case U128: return DataType::U128;
        case I128: return DataType::I128;
        case W1: return DataType::W1;
        case W2: return DataType::W2;
        case W4: return DataType::W4;
        case W8: return DataType::W8;
        case Long: return DataType::Long;
        
        default: {}
    }
    return DataType::Void;
}

