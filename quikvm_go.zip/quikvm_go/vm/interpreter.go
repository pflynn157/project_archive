package main

type Interpreter struct {
	stringpool []string
}

//The main interpreter function
// Words (or instructions) are 11 bytes long
func (ir* Interpreter) Run(instr []byte) {
	cmd := instr[0]
	
	if cmd == 0xA3 {
		println("S load")
	} else if cmd == 0xB3 {
		println("S println")
	} else if cmd == 0xBA {
		println("exit")	
	}
}
