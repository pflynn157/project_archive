---
layout: post
title:  "Recent Readings"
date:   2021-06-30
categories: reading
---

I’ve been doing a lot of reading lately. In fact, I’ve blown through about three books in the past month or so (probably the past month and a half). I do like fiction and other genres, but I do also read my fair share of self-help literature, especially where technology is concerned. 

#### Deep Work

One could call this the Bible of Work. Written by a computer scientist, Dr. Cal Newport, the book talks about the necessity of deep focus in work today, why it’s valuable, and how to get to train yourself in it. Depending on how long you’ve looked at my old site, you will have noticed that I referenced the ideas a lot through my various anti-distraction experiments.

This is actually the third time reading this for me, and it’s one I try to re-read often, especially when starting a new job. Over-connection has become the norm at work, and when you’re trying to accomplish a deep task, such as writing a complex program, trying to pay attention to email, notifications, and a bunch of other stuff distracts you and takes you away from that.

In the technology debate, I highly recommend anything by Cal Newport because he does a very good job A) presenting the problem, B) presenting why it’s a problem (why it matters), and C) presenting an attainable solution. The last is especially important. There’s no sense in saying why technology is a problem if you don’t have a way to solve it.

#### No More Mr. Nice Guy

This is a new one for me, and was recommended by a good friend of mine. And to be fair, it’s more of a men’s book. But it’s one I highly recommend. Despite the title, the book doesn’t teach you how to be an asshole. In a nutshell, it addresses how to overcome “Nice guy syndrome”, which has been a growing occurrence since World War II. You could say it basically teaches men how to be men.

That said though, it by no means is anything against women. If anything, it’s the opposite. Nor do you have to fully fit the “nice guy” description to benefit from it. I honestly found it very refreshing to see a book like that in this day and age and its one I found very inspiring.

#### The Subtle Art of Not Giving a F**k

Yeah I know. Anyone who admits to reading that probably gets some eyebrows raised. This was a re-read for me; I first read it about a year ago. Honestly, this is something I should probably read each year.

The reason I like this book so much is because it doesn’t actually tell you anything other than reality. It’s the opposite of most self-help literature- you know, the motivational feel-good-about-yourself stuff that doesn’t actually solve anything. It’s also not a book about stoicism or not caring about anything. The entire premise is how to direct your energy and what to care about (and how to figure the latter out). It largely calls into question a lot of the undercurrents in our culture today.

Fair warning though, if offensive language bothers you, you shouldn’t read this. Usually, I feel that people who use tons and tons of offensive language do so to make themselves sound important or smart when they actually aren’t, but in this case it adds a lot of weight to the message. For a technology joke, it’s very Linus Torvalds-esque.

My only real complaint is that I wish he had left the last chapter out, or at least had a different underlying premise. I respect people who think that way, but I feel he went from reality to what he believed, which somewhat takes away from the message. But that’s just my opinion. Its definitely still a re-read for me.

