## ada-asm

This is an experiment at implementing an assembler using the Ada programming language.

Despite what the name says, this is not a full assembler. It isn't even half of one... The main item of interest is `src/elf.adb`. This contains a completely working ELF generator. The ELF is a fully relocatable object file.

I'm opening this up mainly because of the ELF portion. I would like to improve this at some point, but I'm not completely sure just yet.

### Why Ada?

Honestly, I think its a shame that Ada doesn't get more attention outside its niche area. The language is very solid in many ways, and contains a lot of features without the bloat in my opinion (the opposite of C++). 
