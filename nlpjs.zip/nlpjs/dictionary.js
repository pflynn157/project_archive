
const verb_helpers = [
    "am"
];

const verb_roots = [
    "is"
];

exports.isVerbHelper = function isVerbHelper(word) {
    return verb_helpers.includes(word);
}

exports.isVerbRoot = function isVerbRoot(word) {
    var found = false;
    
    verb_roots.forEach(verb => {
        if (verb === word) {
            found = true;
        } else if (verb.startsWith(word)) {
            // TODO: We need more sophisticated handling
            found = true;
        }
    });
    
    return found;
}

exports.isAdjective = function(word) {
    // TODO
    return false;
}

exports.isPronoun = function(pnoun) {
    if (pnoun === "i" || pnoun === "you" || pnoun === "he"
        || pnoun === "she" || pnoun === "they") {
         return true;   
    }
    return false;
}