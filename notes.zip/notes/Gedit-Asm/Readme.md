## Gedit-Asm

This is a syntax highlighting file for Intel Assembly meant for editors that use the GtkSourceView component. That means you should be able to use in Gedit, Pluma, Xed (the Linux Mint editor), and maybe others without any issues.

This was not originally my work; I downloaded it from here per a stack overflow question: www.carminebenedetto.net/_downloads/asm-intel.lang. All credit goes to whoever the original author is; No copyright infringement is intended.

What I did do though was modify it to highlight more XMM registers and the YMM registers, as the original did not have those. I also provided an install script. Run it was root, and restart whatever editor you are using.
