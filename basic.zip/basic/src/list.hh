#pragma once

#include <string>

void list_command(std::string line);
void list_add(std::string line);
void list_length(std::string line);
void list_show(std::string line);
void list_rm(std::string line);
void list_cls(std::string line);
void list_kill(std::string line);
