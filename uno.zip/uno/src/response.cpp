#include <iostream>
#include <fstream>
#include <chrono>
#include <ctime>
#include <string>
#include <unistd.h>
#include <sys/stat.h>

#include "server.hpp"

//Returns the time as a string
std::string Server::get_time() {
	auto ctime = std::chrono::system_clock::now();
	std::time_t timet = std::chrono::system_clock::to_time_t(ctime);
	std::string time = std::ctime(&timet);
	return time;
}

//Generates the default response header
std::string Server::generate_header(int content_len) {
	auto time = get_time();
	
	std::string header = "Date: " + time ;
	header += "Server: PdfSvr 1.0 (Linux x86)\n";
	header += "Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0\n";
	header += "Pragma: no-cache\n";
	header += "Last-Modified: " + time;
	header += "Content-Length: " + std::to_string(content_len) + "\n";
	header += "Connection: keep-alive, Keep-Alive\n";
	header += "Keep-Alive: timeout=3, max=3";
	header += "Content-Type: text/html\n";
	header += "\n";	
	
	return header;
}

//Load an html file
std::string Server::load_html(std::string file) {
	std::string html = "";
	std::string line = "";
	
	std::ifstream reader(file.c_str());
	if (reader.is_open()) {
		while (std::getline(reader, line)) {
			html += line + "\n";
		}
		
		reader.close();
	}
	
	return html;
}

//Sends a 404 error back to the user
void Server::send_404(int socketd) {
	std::cout << "404 error..." << std::endl;
	
	auto time = get_time();
	std::string content = "<h3>404 Error: Page not found</h3>";
	
	std::string header = "HTTP/1.1 404 Not Found\n";
	header += generate_header(content.length());
	header += content;
	
	write(socketd, header.c_str(), header.length());
}

//Send the response to the http server
void Server::send_response(int socketd, std::string path) {
	struct stat buffer;
	if (stat(path.c_str(), &buffer) != 0) {
		send_404(socketd);
		return;
	}

	std::string content = load_html(path);
	int length = content.length();

	auto time = get_time();

	std::string header = "HTTP/1.1 200 OK\n";
	header += generate_header(length);
	header += content;
	
	write(socketd, header.c_str(), header.length());
}
