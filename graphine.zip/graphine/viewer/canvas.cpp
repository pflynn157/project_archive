#include <iostream>

#include <canvas.hpp>
#include <dom.hpp>

Canvas::Canvas() {
    this->setStyleSheet("background-color:white;");
    
    // Add div test
    /*Dv *div = new Dv;
    div->bgColor = "#00ff99";
    
    Hdr1 *h1 = new Hdr1;
    h1->text = "Hello!";
    
    Hdr2 *inH2 = new Hdr2;
    inH2->text = "This is inside a block";
    
    addElement(h1, div);
    addElement(inH2, div);
    addElement(div);
    
    // Add headers test
    h1 = new Hdr1;
    h1->text = "Hi!!";
    addElement(h1);
    
    Hdr2 *h2 = new Hdr2;
    h2->text = "Hi!!";
    addElement(h2);
    
    Hdr3 *h3 = new Hdr3;
    h3->color = "#cc00cc";
    h3->text = "Hi!!";
    addElement(h3);
    
    Hdr4 *h4 = new Hdr4;
    h4->text = "Hi!!";
    addElement(h4);*/
}

Canvas::~Canvas() {
}

int Canvas::getLargestSize(Block *block) {
    int largest = 0;
    
    for (Element *element : block->children) {
        switch (element->type) {
            case Div: {
                Block *block = static_cast<Block *>(element);
                if (block->height > largest)
                    largest = block->height;
                    
                int next = getLargestSize(block);
                if (next > largest)
                    largest = next;
            } break;
            
            case H1:
            case H2:
            case H3:
            case H4: {
                H *h = static_cast<H *>(element);
                if (h->fontSize > largest)
                    largest = h->fontSize;
            } break;
            
            default: {}
        }
    }
    
    return largest;
}

int Canvas::getTotalSize(Block *block) {
    int size = 0;
    
    for (Element *element : block->children) {
        switch (element->type) {
            case Div: {
                Block *block = static_cast<Block *>(element);
                size += block->height;
                size += getTotalSize(block);
            } break;
            
            case H1:
            case H2:
            case H3:
            case H4: {
                H *h = static_cast<H *>(element);
                size += h->fontSize;
            } break;
        }
    }
    
    return size;
}

void Canvas::addElement(Element *element, Block *parent) {
    switch (element->type) {
        case Div: {
            Block *block = static_cast<Block *>(element);
            block->height = getTotalSize(block);
            
            block->x = xPos;
            block->y = yPos;
            block->yCounter = yPos;
            
            xPos = block->marginLeft;
            yPos += block->height;
            
            if (parent) parent->children.push_back(block);
            else elements.push_back(block);
        } break;
    
        case H1:
        case H2:
        case H3:
        case H4: {
            H *h = static_cast<H *>(element);
            
            if (parent) {
                parent->yCounter += h->fontSize;
                h->y = parent->yCounter;
                h->x = 0;
            } else {
                yPos += h->fontSize;
                xPos = h->marginLeft;
            
                h->x = xPos;
                h->y = yPos;
            }
            
            if (parent) parent->children.push_back(h);
            else elements.push_back(h);
        } break;
        
        default: {}
    }
}

void Canvas::renderCanvas(QPainter &painter, std::vector<Element *> toDraw) {
    for (auto element : toDraw) {
        switch (element->type) {
            case Div: {
                Block *block = static_cast<Block *>(element);
                
                int width = block->width;
                int height = block->height;
                
                if (width < 0) width = this->width();
                if (height < 0) height = this->height();
                
                QColor color(QString(block->bgColor.c_str()));
                painter.setBrush(color);
                painter.drawRect(block->x, block->y, width, height);
                
                renderCanvas(painter, block->children);
            } break;
        
            case H1:
            case H2:
            case H3:
            case H4: {
                QFont original = painter.font();
                
                H *h = static_cast<H *>(element);
                
                QFont current = original;
                current.setPixelSize(h->fontSize);
                painter.setFont(current);
                
                QColor color(QString(h->color.c_str()));
                painter.setPen(color);
                painter.drawText(h->x, h->y, QString(h->text.c_str()));
                
                painter.setFont(original);
            } break;
        }
    }
}

void Canvas::paintEvent(QPaintEvent *) {
    QPainter painter(this);
    renderCanvas(painter, elements);
}
