#include <stdio.h>

int main() {
    long int MAX = 600851475143;
    int result = 0;
    
    for (long int i = MAX - 1; i > 0; i--) {
        if (i % 2 == 0 || i % 3 == 0 || i % 5 == 0) {
            continue;
        }
        
        // Check prime
        if (MAX % i == 0) {
            int found = 0;
            for (long int j = (i / 2); j > 1; j--) {
                if (i % j == 0) {
                    found = 1;
                    break;
                }
            }
            
            if (!found) {
                result = i;
                break;
            }
        }
    }
    
    printf("%d\n", result);

    return 0;
}
