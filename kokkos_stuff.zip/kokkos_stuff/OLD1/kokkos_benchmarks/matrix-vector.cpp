//matvec.c
//Multiplies a matrix by a vector
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/timeb.h>
#include <malloc.h>
#include <Kokkos_Core.hpp>

#define N 25500

// read timer in second
double read_timer() {
    struct timeb tm;
    ftime(&tm);
    return (double) tm.time + (double) tm.millitm / 1000.0;
}

//Create a matrix and a vector and fill with random numbers
void init(float **matrix, float *vector) {
    for (int i = 0; i<N; i++) {
        for (int j = 0; j<N; j++) {
            matrix[i][j] = (float)rand()/(float)(RAND_MAX/10.0);
        }
        
        vector[i] = (float)rand()/(float)(RAND_MAX/10.0);
    }
}

//The parallel version
void parallel(float **matrix, float *vector, float **dest) {

  Kokkos::parallel_for("loop1", Kokkos::MDRangePolicy<Kokkos::Rank<2>>({0,0},{N,N}),
      KOKKOS_LAMBDA(const int i, const int j) {
        dest[i][j] = matrix[i][j] * vector[j];
    });
}

// The serial version
void serial(float **matrix, float *vector, float **dest) {
    for (int i = 0; i<N; i++) {
        for (int j = 0; j<N; j++) {
            dest[i][j] = matrix[i][j] * vector[j];
        }
    }
}

float check(float **A, float **B){
    float difference = 0;
    for(int i = 0;i<N; i++){
        for (int j = 0; j<N; j++)
        { difference += A[i][j]- B[i][j];}
    }
    return difference;
}

int main(int argc, char **argv) {
    Kokkos::initialize (argc, argv);
    
    //Set everything up
    float **dest_matrix = (float **)malloc(sizeof(float*)*N);
    float **serial_matrix = (float **)malloc(sizeof(float*)*N);
    float **matrix = (float **)malloc(sizeof(float*)*N);
    float *vector = (float *)malloc(sizeof(float)*N);
    
    for (int i = 0; i<N; i++) {
        dest_matrix[i] = (float *)malloc(sizeof(float)*N);
        serial_matrix[i] = (float *)malloc(sizeof(float)*N);
        matrix[i] = (float *)malloc(sizeof(float)*N);
    }
    
    srand(time(NULL));
    init(matrix, vector);
    
    double start = read_timer();
    parallel(matrix, vector, dest_matrix);
    double t = (read_timer() - start);
    
    double start_serial = read_timer();
    serial(matrix, vector, serial_matrix);
    double t_serial = (read_timer() - start_serial);
    
    printf("==================================================================\n");
    printf("Performance:\t\t\tRuntime (s)\n");
    printf("------------------------------------------------------------------\n");
    printf("Matrix-vector (Parallel):\t%4f\n", t);
    printf("Matrix-vector (Serial):\t\t%4f\n", t_serial);
    printf("Correctness check: %f\n", check(dest_matrix,serial_matrix));
    
    free(dest_matrix);
    free(serial_matrix);
    free(matrix);
    free(vector);
    
    return 0;    
}

