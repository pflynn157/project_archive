module X64.X64Registers(x64CallReg32,
    x64CallReg64,
    x64IntReg) where

x64CallReg32 no
    | no == 1 = "edi"
    | no == 2 = "esi"
    | no == 3 = "edx"
    | no == 4 = "ecx"
    | no == 5 = "r8d"
    | no == 6 = "r9d"
    | otherwise = ""
    
x64CallReg64 no
    | no == 1 = "rdi"
    | no == 2 = "rsi"
    | no == 3 = "rdx"
    | no == 4 = "rcx"
    | no == 5 = "r8"
    | no == 6 = "r9"
    | otherwise = ""
    
x64IntReg no
    | no == 1 = "r15d"
    | no == 2 = "r14d"
    | no == 3 = "r13d"
    | no == 4 = "r12d"
    | no == 5 = "r11d"
    | no == 6 = "r10d"
    | no == 7 = "r9d"
    | no == 8 = "r8d"
    | no == 9 = "eax"
    | no == 10 = "ebx"
    | no == 11 = "ecx"
    | no == 12 = "edx"
    | no == 13 = "edi"
    | no == 14 = "esi"
    | otherwise = ""
