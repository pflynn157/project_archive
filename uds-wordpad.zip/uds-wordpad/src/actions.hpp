//
// Copyright 2021 Patrick Flynn
// This file is part of uds-wordpad.
// uds-wordpad is licensed under the BSD-3 license. See the COPYING file for more information.
//
#pragma once

#include <QObject>

class Actions : public QObject {
    Q_OBJECT
public:
    void newFile();
    void openFile();
    void saveFile();
    void saveFileAs();
    void saveAll();
    void printCurrent();
    void exportCurrentPDF();
    void changeTextFG();
    void toggleBold();
    void toggleItalic();
    void toggleUnderline();
    void cut();
    void copy();
    void paste();
    void selectAll();
    void undo();
    void redo();
};

