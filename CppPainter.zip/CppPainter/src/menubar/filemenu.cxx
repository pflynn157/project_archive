#include "filemenu.hh"
#include "../actions.hh"

FileMenu::FileMenu() {
    this->setTitle("File");

    newFile = new QAction("New Image",this);
    openFile = new QAction("Open",this);
    saveFile = new QAction("Save",this);
    saveFileAs = new QAction("Save As",this);

    connect(newFile,&QAction::triggered,this,&FileMenu::onNewFileClicked);
    connect(openFile,&QAction::triggered,this,&FileMenu::onOpenFileClicked);
    connect(saveFile,&QAction::triggered,this,&FileMenu::onSaveClicked);
    connect(saveFileAs,&QAction::triggered,this,&FileMenu::onSaveAsClicked);

    this->addAction(newFile);
    this->addAction(openFile);
    this->addAction(saveFile);
    this->addAction(saveFileAs);
}

FileMenu::~FileMenu() {
    delete newFile;
    delete openFile;
    delete saveFile;
    delete saveFileAs;
}

void FileMenu::onNewFileClicked() {
    Actions::newFile();
}

void FileMenu::onOpenFileClicked() {
    Actions::openFile();
}

void FileMenu::onSaveClicked() {
    Actions::saveFile();
}

void FileMenu::onSaveAsClicked() {
    Actions::saveFileAs();
}
