#pragma once

#include "vector.h"

typedef enum {
    AST_None,
    
    // Statements
    AST_Return,
    AST_VarDec,
    AST_VarAssign,
    
    // Expressions
    AST_Id,
    AST_IntL,
    AST_ExprList,
    
    // Operators
    AST_Assign,
    AST_Add
} AstType;

//
// Represents an AST expression
//
typedef struct {
    AstType type;
    
    struct AstExpression *lval;
    struct AstExpression *rval;
    //vector *list;
    struct AstExpression *list[10];
    size_t list_size;
    
    uint64_t int_literal;
    char *name;
} AstExpression;

//
// Represents an AST statement
//
typedef struct {
    AstType type;
    AstExpression *expr;
} AstStatement;

//
// Represents an AST block
//
typedef struct {
    vector *block;
} AstBlock;

//
// Represents an AST function
//
typedef struct {
    char *name;
    AstBlock *block;
} AstFunction;

//
// Represents an AST file
//
typedef struct {
    char *name;
    vector *function_list;
} AstFile;

//
// Various helper functions to create everything
//
AstFile *ast_file_create(char *name);
AstFunction *ast_function_create(char *name);
AstStatement *ast_statement_create(AstType type);
AstExpression *ast_expr_create(AstType type);

void ast_add_function(AstFile *file, AstFunction *func);
void ast_add_statement(AstBlock *block, AstStatement *stmt);
void ast_set_expr(AstStatement *stmt, AstExpression *expr);

void ast_destroy(AstFile *file);

void ast_debug_expr(AstExpression *expr);
void ast_debug(AstFile *file);

