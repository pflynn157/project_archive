#include <string.h>
#include <malloc.h>

#include "strutils.h"

//Our trim function
char *trim(char *str)
{
	//Declare our variables
	int len = strlen(str);
	char buf[len];
	
	//Convert our string to an array
	for (int i = 0; i<len; i++) {
		buf[i] = str[i];
	}
	
	//Figure out where our start and end index is
	int start = 0;
	int start_bk = len;
	
	for (int i = 0; i<len; i++) {
		if (buf[i] == ' ' || buf[i] == '\t') {
			start++;
		} else {
			break;
		}
	}
	
	for (int i = len-1; i>=0; i--) {
		if (buf[i] == ' ' || buf[i] == '\t' || buf[i] == '\n') {
			start_bk--;
		} else {
			break;
		}
	}
	
	//Determine our new length
	int nlen = len-(start+(len-start_bk));
	
	//Allocate memory
	char *ret = malloc(nlen+1);
	
	//Create a new buffer
	char buf2[nlen];
	int index = 0;
	
	//Shift everything
	for (int i = start; i<start_bk; i++) {
		buf2[index] = buf[i];
		index++;
	}
	buf2[nlen] = '\0';
	
	//Copy everything back
	strcpy(ret, buf2);
	
	return ret;
}

//Returns the first part of a string
char *str_first(char *str)
{
	int len = strlen(str);
	char buf[len];
	int stop = 0;
	
	//Copy our string to a local array
	//Also determine the location of our first space
	for (int i = 0; i<len; i++) {
		buf[i] = str[i];
		
		if (str[i] == ' ' && stop == 0) {
			stop = i;
		}	
	}
	
	//Check to make sure a space was detected
	if (stop == 0) {
		char *ret = malloc(len+1);
		buf[len] = '\0';
		strcpy(ret, buf);
		return ret;
	} else {
		//Create a new array and allocate memory
		char buf2[stop+1];
		char *ret = malloc(stop+1);
		
		//Copy everything
		for (int i = 0; i<stop; i++) {
			buf2[i] = buf[i];
		}
		buf2[stop+1] = '\0';
		
		//Copy and return everything
		strcpy(ret, buf2);
		return ret;
	}
}

//Returns the second part of a string
char *str_second(char *str)
{
	int len = strlen(str);
	char buf[len];
	int start = 0, found = 0;
	
	//Copy to local array and determine loco of first space
	for (int i = 0; i<len; i++) {
		buf[i] = str[i];
		
		if (str[i] == ' ' && found == 0) {
			start = i+1;
			found = 1;
		}
	}
	
	//Create a new array and allocate memory
	int nlen = len-start;
	char buf2[nlen];
	char *ret = malloc(nlen);
	int index = 0;
	
	//Copy
	for (int i = start; i<len; i++) {
		buf2[index] = buf[i];
		index++;
	}
	buf2[nlen] = '\0';
	
	//Copy and return everything
	strcpy(ret, buf2);
	return ret;
}

