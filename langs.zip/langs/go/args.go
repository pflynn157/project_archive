package main

import "fmt"
import "os"

func main() {
	if len(os.Args) == 1 {
		println("No arguments!")
	} else {
		println("Your arguments are:")
		
		for i := 1; i<len(os.Args); i++ {
			ln := os.Args[i]
			fmt.Println("Current ARG: ", ln)
		}
	}
}
