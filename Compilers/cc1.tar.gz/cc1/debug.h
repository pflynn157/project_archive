#pragma once

#include "ast.h"

void print_ast(Ast *ast);
