#pragma once

typedef int FILE;

extern int sc_open(char *input, int flags, int mode);
extern void close(FILE fd);

FILE open(char *input);

