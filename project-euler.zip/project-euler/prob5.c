// 1-10 -> 1,2,3,4,5,6,7,8,9,10
#include <stdio.h>
#include <limits.h>

int main() {
    int i = 20;
    int result = 0;
    while (i < INT_MAX) {
        if (i % 2 != 0 || i % 3 != 0 || i % 5 != 0) {
            ++i;
            continue;
        }
        
        int not = 0;
        for (int j = 20; j>=4; j--) {
            if (i % j != 0) {
                not = 1;
                break;
            }
        }
        
        if (not == 0) {
            result = i;
            break;
        }
        
        ++i;
    }
    
    printf("%d\n", result);

    return 0;
}
