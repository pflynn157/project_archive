#pragma once

#include <string>

#include <ast.hpp>
#include <builder.hpp>

//extern void parse(const char *path, AstTree *tree);
extern void parse(const char *path, AstBuilder *b);

AstTree *buildAst(std::string path, std::string name);
void printAst(AstTree *ast, std::string output);
