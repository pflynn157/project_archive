#include <stdio.h>
#include <math.h>

int is_square(int num) {
    int n = sqrt(num);
    if (n * n == num) return 1;
    return 0;
}

int main() {
    int a = 0;
    int b = 0;
    int c = 0;
    
    for (a = 3; a < 1000; a++) {
        for (b = 4; b < 1000; b += 2) {
            int c1 = (a * a) + (b * b);
            c = sqrt(c1);
            
            if (!is_square(c1)) {
                continue;
            }
            
            if (a + b + c == 1000) {
                goto end;
            }
        }
    }
    end:
    
    printf("%d + %d = %d (%d)\n", a, b, c, a + b + c);
    
    long long int result = a * b * c;
    printf("%lld\n", result);
    
    return 0;
}
