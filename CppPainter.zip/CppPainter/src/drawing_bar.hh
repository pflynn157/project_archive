#pragma once

#include <QToolBar>
#include <QToolButton>

class DrawingBar : public QToolBar {
    Q_OBJECT
public:
    DrawingBar();
    ~DrawingBar();
private:
    QToolButton *rect, *ellipse, *colorChooser;
private slots:
    void onRectClicked();
    void onEllipseClicked();
    void onColorChooserClicked();
};
