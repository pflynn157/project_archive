#include <iostream>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

int main(int argc, char **argv) {
    int socketd = socket(AF_INET, SOCK_STREAM, 0);
    if (socketd == -1) {
        std::cerr << "Error: Unable to create socket." << std::endl;
        return 1;
    }
    
    struct sockaddr_in server;
    server.sin_addr.s_addr = inet_addr("127.0.0.1");
    server.sin_family = AF_INET;
    server.sin_port = htons(8182);
    
    // Connect
    if (connect(socketd, (struct sockaddr *)&server, sizeof(server)) < 0) {
        std::cout << "Unable to connect." << std::endl;
        return 1;
    }
    
    std::cout << "Connection established." << std::endl;
    
    std::string msg1 = "Hello!";
    std::string msg2 = "How are you?";
    std::string msg3 = "exit";
    
    send(socketd, msg1.c_str(), msg1.length(), 0);
    send(socketd, msg2.c_str(), msg2.length(), 0);
    send(socketd, msg3.c_str(), msg3.length(), 0);
    
    close(socketd);

    return 0;
}