#include <stdio.h>
#include <stdlib.h>

#include "lex.h"
#include "ast.h"
#include "parser.h"

int main(int argc, char *argv[]) {
    if (argc == 1) {
        fprintf(stderr, "Error: No input file.\n");
        return 1;
    }
    
    AstFile *file = parse_file(argv[1]);
    
    ast_debug(file);
    ast_destroy(file);
    
    /*Scanner *scanner = malloc(sizeof(Scanner));
    lex_init(argv[1], scanner);
    
    Token token = lex_get_next(scanner);
    while (token != Eof) {
        lex_debug(token, scanner);
        token = lex_get_next(scanner);
    }
    
    lex_destroy(scanner);*/
    
    /*AstFile *file = ast_file_create("first.tl");
    
    ///
    ///
    ///
    AstFunction *func1 = ast_function_create("main");
    
    AstExpression *expr1 = ast_expr_create(AST_IntL);
    expr1->int_literal = 10;
    
    AstStatement *ret1 = ast_statement_create(AST_Return);
    ast_set_expr(ret1, expr1);
    ast_add_statement(func1, ret1);
    
    ast_add_function(file, func1);
    ///
    ///
    ///
    AstFunction *func2 = ast_function_create("sayHello");
    ast_add_function(file, func2);
    
    ast_debug(file);
    
    ast_destroy(file);
    free(func1);
    free(func2);
    free(ret1);*/
    
    return 0;
}

