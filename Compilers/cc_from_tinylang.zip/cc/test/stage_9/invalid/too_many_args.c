int foo(int a) {
    return a + 1;
}

int main() {
    return foo(1, 2);
}