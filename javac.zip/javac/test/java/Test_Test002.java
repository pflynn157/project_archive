public class Test_Test002 {
    public static void main(String[] args) {
        int x = 20;
        System.out.println(x);
        
        x = 30;
        System.out.println(x);
        
        x = 31 + 23;
        System.out.println(x);
        
        x = x + 10;
        System.out.println(x);
        
        x = 100 + x;
        System.out.println(x);
        
        int y = 20 * 2;
        System.out.println(y);
       
        int z = y;
        System.out.println(z);
    }
}
