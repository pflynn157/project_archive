// Copyright 2019 Patrick Flynn
//
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, 
//	this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, this 
//	list of conditions and the following disclaimer in the documentation and/or 
//	other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors may 
//	be used to endorse or promote products derived from this software 
//	without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#include <iostream>
#include <cstdlib>

#include "array.hh"
#include "vars.hh"
#include "error.hh"

#include <strutils.hh>
#include <types.hh>

std::vector<Array> global_arrs;
std::vector<Array> local_arrs;

//Add an array object to one of our global lists
void add_to_array(std::vector<Array> *contents, Array arr) {
	for (int i = 0; i<contents->size(); i++) {
		if (contents->at(i).name == arr.name) {
			contents->erase(contents->begin() + i);
		}
	}
	
	contents->push_back(arr);
}

//Creates a new array
void arr_create(String line, bool global) {
	std::string ln = clr_spaces(line.str);
	std::string name = get_first(ln, '=');
	std::string type = get_second(ln, '=');
	
	Array arr;
	arr.name = name;
	
	if (type == "int") {
		arr.type = DataType::INT;
	} else if (type == "dec") {
		arr.type = DataType::DEC;
	} else if (type == "bool") {
		arr.type = DataType::BOOL;
	} else if (type == "char") {
		arr.type = DataType::CHAR;
	} else if (type == "str") {
		arr.type = DataType::STR;
	} else {
		syntax_err(line, "Invalid datatype.");
	}
	
	if (global) {
		global_arrs.push_back(arr);
	} else {
		local_arrs.push_back(arr);
	}
}

//Returns a variable by name
Array get_arr(std::string name) {
	Array arr;
	
	for (Array a : local_arrs) {
		if (a.name == name) {
			return a;
		}
	}
	
	for (Array a : global_arrs) {
		if (a.name == name) {
			return a;
		}
	}
	
	return arr;
}

//Add an item to the array
void arr_add_item(String line , bool global) {
	//Get the array
	std::string ln = clr_spaces(line.str);
	std::string name = get_first(ln, '+');
	std::string val = get_second(ln, '+');
	
	Array arr = get_arr(name);
	if (arr.name == "") {
		rt_err(line, "Unknown array.");
	}
	
	//Get the datatype
	auto type = get_datatype(val);
	
	//See if we have an raw value or a variable
	if (type != DataType::NONE) {
		if (type != arr.type) {
			syntax_err(line, "The item you're adding to the array must match the array's datatype.");
		}
	} else {
		val = var_val(val);
	}
	
	//Add it to the array
	arr.contents.push_back(val);
			
	if (global) {
		add_to_array(&global_arrs, arr);
	} else {
		add_to_array(&local_arrs, arr);
	}
}

//Remove an element from an array
int arr_remove(String line, bool global) {
	std::string ln = clr_spaces(line.str);
	std::string name = get_first(ln, '-');
	Array arr = get_arr(name);
	
	if (arr.name == "") {
		return 1;
	}
	
	std::string s_index = get_second(ln, '-');
	
	//If the s_index variable is empty, then clear the entire array
	if (s_index == "") {
		arr.contents.clear();
	} else {
		int index = get_index(s_index, line);
		
		//Make sure the index isn't greater than the array's length
		if (index >= arr.contents.size()) {
			rt_err(line, "Index out of bounds.");
		}
		
		//Remove the item
		arr.contents.erase(arr.contents.begin() + index);
	}
	
	if (global) {
		add_to_array(&global_arrs, arr);
	} else {
		add_to_array(&local_arrs, arr);
	}
	
	return 0;
}

//Returns a string representation of an array
std::string arr_to_str(std::string name) {
	Array arr = get_arr(name);
	if (arr.name == "") {
		return "";
	}

	std::string ret = "[";
	
	for (int i = 0; i<arr.contents.size(); i++) {
		if (i+1 >= arr.contents.size()) {
			ret += arr.contents.at(i);
		} else {
			ret += arr.contents.at(i) + ", ";
		}
	}
	
	ret += "]";
	
	return ret;
}

//A utility function for returning an integer (for array indexes)
int get_index(std::string s_index, String line) {
	int index = 0;
	DataType type = get_datatype(s_index);
			
	if (type == DataType::INT) {
		index = std::stoi(s_index);
	} else {
		Var v = get_var(s_index);
		
		if (v.name == "") {
			rt_err(line, "You are attempting to access an array index with an invalid variable or number.");
		} else if (v.type != DataType::INT) {
			rt_err(line, "Array elements can only be accessed with integers.");
		} else {
			s_index = var_val(s_index);
			index = std::stoi(s_index);
		}
	}
	
	return index;
}
