#include <QMenuBar>

#include "window.hh"
#include "canvas_bg.hh"

CanvasBg *Window::canvasBg;

Window::Window() {
    this->setWindowTitle("CppPainter");
    this->resize(1100,700);

    canvasBg = new CanvasBg;
    this->setCentralWidget(canvasBg);

    drawBar = new DrawingBar;
    this->addToolBar(drawBar);

    fileMenu = new FileMenu;

    this->menuBar()->addMenu(fileMenu);
}

Window::~Window() {
    delete fileMenu;
}
