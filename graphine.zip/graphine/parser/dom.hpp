#pragma once

#include <vector>
#include <string>

enum ElementType {
    None,
    
    Div,
    
    H1, H2, H3, H4
};

struct Element {
    bool isBlock;
    ElementType type;
    
    int x;
    int y;
    
    int marginLeft = 2;
};

struct Block : public Element {
    std::string bgColor = "#ffffff";
    int height = 0;
    int width = -1;
    
    int yCounter = 0;
    
    Block() {
        marginLeft = 0;
        isBlock = true;
    }
    
    std::vector<Element *> children;
};

struct Dv : public Block {
    Dv() {
        type = ElementType::Div;
    }
};

struct H : public Element {
    std::string color = "#000000";
    std::string text = "";
    int fontSize = 0;
};

struct Hdr1 : public H {
    Hdr1() {
        type = ElementType::H1;
        fontSize = 30;
    }
};

struct Hdr2 : public H {
    Hdr2() {
        type = ElementType::H2;
        fontSize = 25;
    }
};

struct Hdr3 : public H {
    Hdr3() {
        type = ElementType::H3;
        fontSize = 20;
    }
};

struct Hdr4 : public H {
    Hdr4() {
        type = ElementType::H4;
        fontSize = 15;
    }
};
