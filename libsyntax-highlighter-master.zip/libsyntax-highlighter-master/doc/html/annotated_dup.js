var annotated_dup =
[
    [ "CppLib", null, [
      [ "Repository", "class_cpp_lib_1_1_repository.html", "class_cpp_lib_1_1_repository" ],
      [ "SyntaxCombo", "class_cpp_lib_1_1_syntax_combo.html", "class_cpp_lib_1_1_syntax_combo" ],
      [ "SyntaxHighlighter", "class_cpp_lib_1_1_syntax_highlighter.html", "class_cpp_lib_1_1_syntax_highlighter" ]
    ] ]
];