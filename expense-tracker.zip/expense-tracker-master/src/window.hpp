#pragma once

#include <QMainWindow>
#include <QTabWidget>

#include <accounts.hpp>

class Window : public QMainWindow {
    Q_OBJECT
public:
    Window();
    ~Window();
protected:
    QTabWidget *tabs;
    AccountsWidget *accounts;
};