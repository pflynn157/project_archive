#include <stdio.h>
#include <omp.h>

// detached untied
#define PTASK_FLAG_DETACHABLE 0x40

// Compiler-generated code (emulation)
typedef struct ident {
  void* dummy; // not used in the library
} ident_t;

typedef struct {
  int type;
  union {
    void *task;
  } ed;
} kmp_event_t;

typedef struct shar { // shareds used in the task
} *pshareds;

typedef struct task {
  pshareds shareds;
  int(*routine)(int,struct task*);
  int part_id;
  omp_event_handle_t evt;
} *ptask, kmp_task_t;

typedef void(*task_entry_t)(int, ptask, int, float *, float *, float *);
#ifdef __cplusplus
extern "C" {
#endif
extern int __kmpc_global_thread_num(void *id_ref);
extern ptask __kmpc_omp_task_alloc(void *loc, int gtid, int flags,
                                   size_t sz, size_t shar, task_entry_t rtn);
extern int __kmpc_omp_task(void *loc, int gtid, ptask task);
extern omp_event_handle_t __kmpc_task_allow_completion_event(
                              ident_t *loc_ref, int gtid, ptask task);

extern void __kmpc_fork_call(ident_t *, int nargs,
                                 task_entry_t microtask, ...);
                                 
extern int __kmpc_omp_taskwait(ident_t *loc_ref, int gtid);
#if __cplusplus
}
#endif

// User's code, outlined into task entry
void task_entry(int gtid, ptask task, int i, float *A, float *B, float *C) {
    C[i] = A[i] + B[i];
}

void random_fill(float *data, size_t N) {
    for(size_t i = 0; i < N; ++i) 
        data[i] = rand() / (float)RAND_MAX;
}

int main(int argc, char **argv) {
  int i, j, gtid = __kmpc_global_thread_num(NULL);
  ptask task;
  pshareds psh;
  
  const int VEC_SIZE = 10;
  float *A = new float[VEC_SIZE];
  float *B = new float[VEC_SIZE];
  float *C = new float[VEC_SIZE];

  random_fill(A, VEC_SIZE);
  random_fill(B, VEC_SIZE);
  
  omp_event_handle_t evt;
  
  for (int i = 0; i<VEC_SIZE; i++) {
    task = (ptask)__kmpc_omp_task_alloc(NULL, gtid, PTASK_FLAG_DETACHABLE, sizeof(struct task), sizeof(struct shar), &task_entry);
    psh = task->shareds;
    evt = (omp_event_handle_t)__kmpc_task_allow_completion_event(NULL,gtid,task);
    task->evt = evt;
    __kmpc_fork_call(NULL, 4, &task_entry, i, A, B, C);
  }
  
  __kmpc_omp_taskwait(NULL, gtid);
  
  // Note: If we don't use the outputs there are cases where tapir+kitsune 
  // will simply remove the entire parallel loop above... 
  fprintf(stderr, "(%s) (%lf + %lf = %lf), (%lf + %lf = %lf), %lf, %lf\n", 
          argv[0], A[0], B[0], C[0],
          A[VEC_SIZE/4], B[VEC_SIZE/4], C[VEC_SIZE/4],
          C[VEC_SIZE/2], C[VEC_SIZE-1]);   

  delete []A;
  delete []B;
  delete []C;
}