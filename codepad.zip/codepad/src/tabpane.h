#pragma once

#include <gtk/gtk.h>

#include "window.h"

void tabpane_add_empty_tab(Window *win);
void tabpane_add_tab(Window *win, const char *path);
void tabpane_save_current_tab(Window *win);
void tabpane_tab_changed(GtkNotebook *notebook, GtkWidget *page, int page_num, gpointer *data);

