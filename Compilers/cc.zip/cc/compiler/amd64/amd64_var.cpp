#include <amd64/amd64.hpp>

#include <ltac/var.hpp>

// Builds the in32 -> mem instruction
void Amd64::buildMovI32(LtacInstr *instr) {
    auto mov = static_cast<LtacMovI32 *>(instr);
    
    if (mov->isPtr()) {
        writer << "  mov rax, [rbp-" << mov->getPos() << "]" << std::endl;
        writer << "  mov dword [rax-0], " << mov->getVal() << std::endl;
    } else {
        writer << "  mov dword [rbp-" << mov->getPos() << "], " << mov->getVal();
    }
    
    writer << std::endl;
}

// Moves one 32-bit var to another
void Amd64::buildMovV32(LtacInstr *instr) {
    auto mov = static_cast<LtacMovV32 *>(instr);
    
    writer << "  mov eax, [rbp-" << mov->getSrc() << "]" << std::endl;
    writer << "  mov [rbp-" << mov->getDest() << "], eax" << std::endl;
    writer << std::endl;
}

// Load immediate to register
void Amd64::buildLdI32(LtacInstr *instr) {
    auto ld = static_cast<LtacLdI32 *>(instr);

    std::string reg = op_regs32[ld->getPos()];
    int val = ld->getVal();
    
    writer << "  mov " << reg << ", " << val << std::endl;
}

// Load variable to register
void Amd64::buildLdV32(LtacInstr *instr) {
    auto ld = static_cast<LtacLdV32 *>(instr);
    
    std::string reg = op_regs32[ld->getPos()];
    int pos = ld->getVal();
    
    writer << "  mov " <<reg << ", [rbp-" << pos << "]";
    writer << std::endl;
}

// Load pointer variable to register
void Amd64::buildLdPtr32(LtacInstr *instr) {
    auto ld = static_cast<LtacLdPtr32 *>(instr);
    
    int pos = ld->getPos();
    int level = ld->getVal() - 1;
    int rPos = ld->getReg();
    std::string reg1 = op_regs[rPos];
    std::string reg2 = op_regs32[rPos];
    
    writer << "  mov " << reg1 << ", [rbp-" << pos << "]" << std::endl;
    
    for (int i = 0; i<level; i++)
        writer << "  mov " << reg1 << ", [" << reg1 << "-0]" << std::endl;
    
    writer << "  mov " << reg2 << ", [" << reg1 << "-0]" << std::endl;
    writer << std::endl;
}

// Store integer register to memory location
void Amd64::buildStrI32(LtacInstr *instr) {
    auto ld = static_cast<LtacStrI32 *>(instr);
    
    std::string reg = op_regs32[ld->getPos()];
    int dest = ld->getDest();
    
    writer << "  mov [rbp-" << dest << "], " << reg << std::endl;
    writer << std::endl;
}

// Load and store a reference to a variable
void Amd64::buildStrRef(LtacInstr *instr) {
    auto ref = static_cast<LtacStrRef *>(instr);
    
    writer << "  lea rax, [rbp-" << ref->getSrc() << "]" << std::endl;
    writer << "  mov [rbp-" << ref->getDest() << "], rax" << std::endl;
    writer << std::endl;
}
