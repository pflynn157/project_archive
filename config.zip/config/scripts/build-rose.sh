#!/bin/bash
# chmod 777 build-rose.sh
sudo apt-get update -y
sudo apt-get install -y git wget make automake libtool gcc g++ libboost-all-dev flex bison ghostscript

export ROSE_HOME=$HOME/passlab

mkdir -p ${ROSE_HOME}
git clone https://github.com/passlab/rose.git ${ROSE_HOME}/src

cd ${ROSE_HOME}/src
./build

mkdir ${ROSE_HOME}/build
cd ${ROSE_HOME}/build
${ROSE_HOME}/src/configure --prefix=${ROSE_HOME}/install --enable-languages=c,c++,binaries --with-boost=/usr --with-boost-libdir=/usr/lib/x86_64-linux-gnu

make core -j4

make install-core -j4
make check-core -j4

make install-tools -j4
