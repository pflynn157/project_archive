#include <ncurses.h>
#include <string.h>

void draw_console(int pair)
{
	attron(COLOR_PAIR(pair));
	
	for (int x = 0; x<COLS; x++) {
		for (int y = 0; y<LINES; y++) {
			printw(" ");
		}
	}
	
	attroff(COLOR_PAIR(pair));
}

void draw_bottom()
{
	mvprintw(0, 0, "");
	attron(COLOR_PAIR(2));
	
	for (int y = LINES-1; y<LINES; y++) {
		for (int x = 0; x<COLS; x++) {
			printw(" ");
		}
	}
	
	attroff(COLOR_PAIR(2));
}

void print_str(char *str) {
	attron(COLOR_PAIR(1));
	printw(str);
	
	int len = strlen(str);
	for (int x = len; x<COLS; x++) {
		printw(" ");
	}
	
	attroff(COLOR_PAIR(1));
}

int main()
{
	initscr();
	start_color();
	keypad(stdscr, TRUE);
	noecho();
	
	init_pair(1, COLOR_WHITE, COLOR_BLUE);
	init_pair(2, COLOR_GREEN, COLOR_BLACK);
	init_pair(3, COLOR_WHITE, COLOR_GREEN);
	
	draw_console(1);
	draw_bottom();
	
	mvprintw(0, 0, "F1: File F2: Edit F3: Exit F4: Switch User\n");
	int ch;
	
	while (ch != 'q') {
		attron(COLOR_PAIR(1));
	
		ch = getch();
		
		if (ch == KEY_F(1)) {
			print_str("Key F1 Pressed!");
			draw_console(3);
		} else if (ch == 'd') {
			print_str("D pressed!");
		} else {
			print_str("Something else pressed.");
		}
	}
	
	endwin();
	
	return 0;
}
