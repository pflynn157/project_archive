## asm Basic

This is a simple, in-progress BASIC interpreter written in x86 Intel Assembly. Why? I am currently working to learn assembly language, and this has proven to be an interesting challenge. So far, only the following commands are supported:   

* exit   
* debug (prints a simple debug message)   
* println   
