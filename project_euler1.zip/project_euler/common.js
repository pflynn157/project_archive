function setOutput(val) {
	document.getElementById("output").innerHTML = val;
}
