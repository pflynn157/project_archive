#pragma once

#include <string>
#include <vector>

#include <Function.hpp>
#include <Instruction.hpp>

class Function;
class Instruction;

class Block {
public:
    explicit Block(std::string name) {
        this->name = name;
    }

    void AddInstruction(Instruction *instr) {
        code.push_back(instr);
    }

    void dump();

    static Block *Create(Function *parent, std::string name);
private:
    std::string name = "";
    std::vector<Instruction *> code;
};
