#include <iostream>

#include <Block.hpp>

void Block::dump() {
    std::cout << name << ":" << std::endl;

    for (Instruction *instr : code) {
        std::cout << "    ";
        instr->dump();
    }
}

Block *Block::Create(Function *parent, std::string name) {
    Block *block = new Block(name);
    parent->AddBlock(block);

    return block;
}
