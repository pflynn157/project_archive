int main() {
    int a;
    int b;
    a = b = 4;
    return a - b;
}