#pragma once

#include <string>
#include <vector>

#include <types.hh>

void bytecode_assemble(std::vector<String> contents, std::string outfile);
