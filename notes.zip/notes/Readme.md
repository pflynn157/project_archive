## Notes

This contains notes, configurations, scripts, code snippets, templates, and other things for my day-to-day work and setup. I made this public so I can access it without my SSH keys.

Everything you find here is public domain.
