#include "elf.hpp"

#include <elf.h>
#include <iostream>

// The constructors to set things up
ElfSection::ElfSection(int type) {
    this->type = type;
}

ElfSection::ElfSection(std::string name, int type) {
    this->name = name;
    this->type = type;
}

// Return needed information
ElfSectionType ElfSection::getSecType() {
    return secType;
}

std::string ElfSection::getName() {
    return name;
}

std::string ElfSection::getLink() {
    return link_to;
}

int ElfSection::getType() {
    return type;
}

int ElfSection::getFlags() {
    return flags;
}

int ElfSection::getAlign() {
    return align;
}

//=====================================
// The .text section

ElfText::ElfText(int code_size) : ElfSection(".text", SHT_PROGBITS) {
    secType = ElfSectionType::Text;
    size = code_size;
    flags = SHF_ALLOC | SHF_EXECINSTR;
    align = 16;
}

//=====================================
// The .strtab section
ElfStrTab::ElfStrTab() : ElfSection(".strtab", SHT_STRTAB) {
    secType = ElfSectionType::Strtab;
}

void ElfStrTab::addString(std::string str) {
    strings.push_back(str);
}

int ElfStrTab::getSize() {
    int size = 1;
    for (auto str : strings) {
        size += str.length() + 1;
    }
    
    return size;
}

void ElfStrTab::writeContent(FILE *file) {
    fputc(0, file);
    
    for (auto str : strings) {
        fputs(str.c_str(), file);
        fputc(0, file);
    }
}


//=====================================
// The .symtab section
ElfSymTab::ElfSymTab() : ElfSection(".symtab", SHT_SYMTAB) {
    secType = ElfSectionType::Symtab;
    align = 8;
    link_to = ".strtab";
    
    // Create the default symbols
    Elf64_Sym symbol;
    
    // The null symbol
    symbol.st_name = 0;
    symbol.st_info = ELF64_ST_INFO(STB_LOCAL, STT_NOTYPE);
    symbol.st_other = ELF64_ST_VISIBILITY(STV_DEFAULT);
    symbol.st_shndx = STN_UNDEF;
    symbol.st_value = 0;
    symbol.st_size = 0;
    symbols.push_back(symbol);
    
    // The file symbol
    symbol.st_name = 1;
    symbol.st_info = ELF64_ST_INFO(STB_LOCAL, STT_FILE);
    symbol.st_other = ELF64_ST_VISIBILITY(STV_DEFAULT);
    symbol.st_shndx = SHN_ABS;
    symbol.st_value = 0;
    symbol.st_size = 0;
    symbols.push_back(symbol);
}

void ElfSymTab::addSectionSymbol(int pos) {
    Elf64_Sym symbol;
    symbol.st_name = 0;
    symbol.st_info = ELF64_ST_INFO(STB_LOCAL, STT_SECTION);
    symbol.st_other = ELF64_ST_VISIBILITY(STV_DEFAULT);
    symbol.st_shndx = pos;
    symbol.st_value = 0;
    symbol.st_size = 0;
    symbols.push_back(symbol);
}

void ElfSymTab::addGlobalSymbol(int name_pos, int pos, int section) {
    if (info_pos == 0) {
        info_pos = symbols.size();
    }

    Elf64_Sym symbol;
    symbol.st_name = name_pos;
    symbol.st_info = ELF64_ST_INFO(STB_GLOBAL, STT_NOTYPE);
    symbol.st_other = ELF64_ST_VISIBILITY(STV_DEFAULT);
    symbol.st_shndx = section;
    symbol.st_value = pos;
    symbol.st_size = 0;
    symbols.push_back(symbol);
}

// Returns the position of the first global symbol
int ElfSymTab::getInfo() {
    return info_pos;
}

// Return the size of the symbol table
int ElfSymTab::getSize() {
    return (sizeof(Elf64_Sym) * symbols.size());
}

int ElfSymTab::getEntrySize() {
    return sizeof(Elf64_Sym);
}

// Writes all the symbols
void ElfSymTab::writeContent(FILE *file) {
    for (auto sym : symbols) {
        fwrite(&sym, sizeof(Elf64_Sym), 1, file);
    }
}

