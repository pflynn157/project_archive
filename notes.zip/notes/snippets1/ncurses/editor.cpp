#include <ncurses.h>
#include <string>
#include <iostream>
#include <vector>
#include <fstream>
#include <string.h>

//Needed variables
int ch = 0;
int current_ln = 1;
int current_col = 0;
int max_ln = 1;
int max_col = 0;
std::string filename = "";

void editor_mode();
std::string get_all_text();
std::string get_file_name();
void save();

//Draws the console screen
void draw_screen() {
	attron(COLOR_PAIR(2));
	
	std::string menu = "F1: Exit | F2: Save";
	printw(menu.c_str());

	for (int y = 0; y<1; y++) {
		for (int x = menu.length(); x<COLS; x++) {
			printw(" ");
		}
	}
	
	attroff(COLOR_PAIR(2));
	attron(COLOR_PAIR(1));
	
	for (int y = 1; y<LINES-1; y++) {
		for (int x = 0; x<COLS; x++) {
			printw(" ");
		}
	}
	
	attroff(COLOR_PAIR(1));
	attron(COLOR_PAIR(2));
	
	for (int y = LINES-1; y<LINES; y++) {
		for (int x = 0; x<COLS; x++) {
			printw(" ");
		}
	}
	
	attroff(COLOR_PAIR(2));
	
	refresh();
	mvprintw(1, 0, "");
}

//The control logic for the the file naming screen
void filename_mode() {
	attron(COLOR_PAIR(2));
	attron(A_BOLD);
	
	move(LINES-1, 0);
	int col = 0;
	
	mvprintw(LINES-1, 0, " ");
	
	while (ch != '\n') {
		printw("%c", ch);
		
		for (int i = col+1; i<COLS; i++) {
			mvprintw(LINES-1, i, " ");
		}
		
		col++;
		move(LINES-1, col);
		
		ch = getch();
		refresh();
	}
	
	attroff(A_BOLD);
	attroff(COLOR_PAIR(2));
	
	filename = get_file_name();
	save();
	
	editor_mode();
}

//The logic for the editor screen
void editor_mode() {
	bool enter_file = false;
	move(current_ln, current_col);

	while (ch != KEY_F(1)) {
		//Logic for the up arrow key
		if (ch == KEY_UP) {
			if (current_ln -1 > 0) {
				current_ln -= 1;
				move(current_ln, current_col);
			}
			
		//Logic for down arrow key
		} else if (ch == KEY_DOWN) {
			if (current_ln + 1 <= max_ln) {
				current_ln++;
				move(current_ln, current_col);
			}
			
		//Logic for the left arrow key
		} else if (ch == KEY_LEFT) {
			if (current_col > 0) {
				current_col -= 1;
				mvprintw(current_ln, current_col, "");
			}
			
		//Logic for the right arrow key
		} else if (ch == KEY_RIGHT) {
			if (current_col <= max_col) {
				current_col++;
				move(current_ln, current_col);
			}
			
		//Logic for the backspace key
		} else if (ch == '\n') {
			current_ln++;
			current_col = 0;
			
			if (current_ln > max_ln) {
				max_ln++;
			}
			
			printw("%c", ch);
			
		//Logic for the F2 key
		} else if (ch == KEY_F(2)) {
			enter_file = true;
			break;
						
		//Logic for all other keys
		} else if (ch != 0) {
			printw("%c", ch);
			max_col++;
		}
		
		ch = getch();
		refresh();
	}
	
	if (enter_file) {
		filename_mode();
	}
}

//Returns all text in the console
std::string get_all_text() {
	std::string text = "";

	for (int i = 1; i<=max_ln; i++) {
		char *txt = new char[1024];
		mvinstr(i, 0, txt);
		text += std::string(txt);
		delete txt;
	}
	
	return text;
}

//Returns the text in the file name entry
std::string get_file_name() {
	char *txt = new char[1024];
	mvinstr(LINES-1, 1, txt);
	std::string name = "";
	
	for (int i = 0; i<strlen(txt); i++) {
		if (txt[i] == ' ') {
			break;
		}
		
		name += txt[i];
	}
	
	return name;
}

//Saves our file
void save() {
	std::ofstream writer(filename);
	std::string content = get_all_text();
	writer << content;
	writer.close();
}

//Our main function
int main(int argc, char *argv[]) {
	std::vector<std::string> content;

	initscr();
	start_color();
	keypad(stdscr, TRUE);
	noecho();
	
	init_pair(1, COLOR_WHITE, COLOR_BLACK);
	init_pair(2, COLOR_WHITE, COLOR_BLUE);
	
	draw_screen();
	editor_mode();

	endwin();
	
	return 0;
}
