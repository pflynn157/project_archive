public class Test_Test003 {
    public static void main(String[] args) {
        int x = 20;
        int y = 4;
        int answer = 0;
        
        answer = x + y;
        System.out.println(answer);
        
        answer = x - y;
        System.out.println(answer);
        
        answer = x * y;
        System.out.println(answer);
        
        answer = x / y;
        System.out.println(answer);
    }
}
