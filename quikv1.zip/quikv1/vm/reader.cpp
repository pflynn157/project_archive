#include <fstream>

#include "reader.hh"

//Load the content
ByteReader::ByteReader(std::string path) {
	std::ifstream reader(path.c_str(), std::ios::binary);
	std::vector<unsigned char> buf2(std::istreambuf_iterator<char>(reader), {});
	buffer = buf2;
}

//Check the signiture
bool ByteReader::isHeaderValid() {
	unsigned char sig[] = {0xF1, 'Q', 'U', 'I', 'K', 0xF2}; 
	bool found = true;
	
	for (int i = 0; i<6; i++) {
		if (sig[i] != buffer.at(i)) {
			found = false;
			break;
		}
	}
	
	return found;
}

//Loads everything into the appropriate arrays
void ByteReader::loadAll() {
	bool found = false;
	
	for (int i = 6; i<buffer.size(); i++) {
		auto c = buffer.at(i);
		
		if (c == 0xF5) {
			found = true;
			continue;
		}
		
		if (found) {
			instructions.push_back(c);
		} else {
			strpoolv.push_back(c);
		}
	}
}
