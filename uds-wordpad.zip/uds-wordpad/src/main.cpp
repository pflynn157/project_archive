//
// Copyright 2021 Patrick Flynn
// This file is part of uds-wordpad.
// uds-wordpad is licensed under the BSD-3 license. See the COPYING file for more information.
//
#include <QApplication>
#include <QFileInfo>

#include <window.hpp>
#include <global.hpp>

Window *win;

int main(int argc, char **argv) {
    QApplication app(argc, argv);
    
    win = new Window;
    win->show();
    
    if (argc > 1) {
        for (int i = 1; i<argc; i++) {
            QString fileName = QFileInfo(argv[i]).absoluteFilePath();
            win->getTabWidget()->addTabFromFile(fileName);
        }
    }
    
    return app.exec();
}

