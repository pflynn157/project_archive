#pragma once

#include <stddef.h>

extern void write(int fd, const char *buf, size_t count);
extern void read(int fd, const char *buf, size_t count);

void println(const char *str);
void print(const char *str, ...);

