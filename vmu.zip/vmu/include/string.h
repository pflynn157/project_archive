#pragma once

#include <stddef.h>

size_t strlen(const char *str);

