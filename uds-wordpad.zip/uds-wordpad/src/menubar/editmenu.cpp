//
// Copyright 2021 Patrick Flynn
// This file is part of uds-wordpad.
// uds-wordpad is licensed under the BSD-3 license. See the COPYING file for more information.
//
#include <QPixmap>

#include <menubar/editmenu.hpp>

EditMenu::EditMenu() {
    this->setTitle("Edit");
    
    cut = new QAction(QPixmap(":/icons/edit-cut.svg"), "Cut", this);
    copy = new QAction(QPixmap(":/icons/edit-copy.svg"), "Copy", this);
    paste = new QAction(QPixmap(":/icons/edit-paste.svg"), "Paste", this);
    selectAll = new QAction(QPixmap(":/icons/edit-select-all.svg"), "Select All", this);
    undo = new QAction(QPixmap(":/icons/edit-undo.svg"), "Undo", this);
    redo = new QAction(QPixmap(":/icons/edit-redo.svg"), "Redo", this);
    
    actions = new Actions;
    connect(cut, &QAction::triggered, actions, &Actions::cut);
    connect(copy, &QAction::triggered, actions, &Actions::copy);
    connect(paste, &QAction::triggered, actions, &Actions::paste);
    connect(selectAll, &QAction::triggered, actions, &Actions::selectAll);
    connect(undo, &QAction::triggered, actions, &Actions::undo);
    connect(redo, &QAction::triggered, actions, &Actions::redo);
    
    this->addAction(cut);
    this->addAction(copy);
    this->addAction(paste);
    this->addAction(selectAll);
    this->addSeparator();
    this->addAction(undo);
    this->addAction(redo);
}

EditMenu::~EditMenu() {
    delete actions;
    delete cut;
    delete copy;
    delete paste;
    delete selectAll;
    delete undo;
    delete redo;
}

