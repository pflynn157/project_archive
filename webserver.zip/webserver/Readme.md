## WebServer

This is a simple HTTP web server. Its capable of accepting HTTP requests and returning data to a web browser. The program is written in C++ and because it uses the UNIX socket library, it will only run on Unix systems.

Note that Linux does not allow normal users acess to low-numbered TCP ports, including port 80. However, if you have authbind installed, you can use it to test the binary. If you wish to install and use the webserver (not really recommended for a production environment...), you can run this command: sudo setcap CAP_NET_BIND_SERVICE=+eip /path/to/server/binary.
