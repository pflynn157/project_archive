#include <stdio.h>
#include <string.h>

#include "ast.h"
#include "debug.h"

#include "compiler.h"
#include "backend.h"

extern void parse(const char *path, AstTree *tree);

int main(int argc, char **argv)
{
    int print_ast = 1;
    int no_llvm = 0;
    
    if (argc > 1)
    {
        if (strcmp(argv[1], "--llvm") == 0) print_ast = 0;
        if (strcmp(argv[1], "--ast-only") == 0) no_llvm = 1;
    }

    AstTree *tree = create_tree("test");
    parse("./test.c", tree);
    
    if (print_ast)
        print_tree(tree);
        
    if (no_llvm)
        return 0;
    
    run_backend(tree, !print_ast);
    
    // TODO: Cleanup tree
    ast_destroy_tree(tree);
    
    // Assemble and link
    assemble();
    run_link();
    
    return 0;
}

