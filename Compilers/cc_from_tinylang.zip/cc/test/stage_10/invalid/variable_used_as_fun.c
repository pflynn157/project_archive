int foo = 3;

int main() {
    return foo();
}