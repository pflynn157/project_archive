#include <ava/ast_builder.hpp>

#include "parser.hpp"
#include "../lex/lex.hpp"

bool Parser::isEofToken(int token) {
    if (token == Eof) return true;
    return false;
}

bool Parser::isOperator(int token) {
    switch (token) {
        case Assign: return true;
    }
    return false;
}

bool Parser::isConstLiteral(int token) {
    switch (token) {
        case Int32: return true;
        
        default: {}
    }
    return false;
}

bool Parser::isIdentifier(int token) {
    if (token == Id) return true;
    return false;
}

bool Parser::isSubExprStart(int token) {
    if (token == LParen) return true;
    return false;
}

bool Parser::isSubExprStop(int token) {
    if (token == RParen) return true;
    return false;
}

bool Parser::isListItemSeparator(int token) { return false; }

int Parser::getSubExprStop() {
    return RParen;
}

AstOp *Parser::buildAstOperator(int token, bool lastWasOp) {
    switch (token) {
        case Assign: return new AstAssignOp;
    }
    return nullptr;
}

AstExpression *Parser::buildConstExpr(Token token) {
    switch (token.type) {
        case Int32: return AstBuilder::buildInt(token.i32_val);
        
        default: {}
    }
    
    return nullptr;
}

bool Parser::buildIDExpr(Token token, ExprContext *ctx) {
    AstID *id = new AstID(token.id_val);
    ctx->output.push(id);
    return true;
}

