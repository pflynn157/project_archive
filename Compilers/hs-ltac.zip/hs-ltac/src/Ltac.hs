module Ltac(LtacType(..), LtacNode(..)) where

-- Important datatypes
data LtacType = None
    | String | Float
    | Func | Lbl | Ret | PushArg | Call
    | IVar | IStoreI | ILdrI | ILdrV | IStr | IMathRR
    deriving (Show, Eq)

data LtacNode = LtacNode {
        instr :: LtacType
      , arg1 :: String
      , arg2 :: String
      , arg3 :: String
    } deriving (Show, Eq)

