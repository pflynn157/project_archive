#include <ava/ast.hpp>
#include <ava/ast_builder.hpp>

#include "ast.hpp"
#include "compiler.hpp"

int main(int argc, char *argv[]) {

    AstTree *tree = new AstTree("test_tree");
    AstFunction *func = new AstFunction("main");
    func->setDataType(AstBuilder::buildInt32Type());
    
    AstReturnStmt *ret = new AstReturnStmt;
    AstOne *one = new AstOne;
    ret->setExpression(one);
    func->addStatement(ret);
    
    tree->addGlobalStatement(func);
    
    tree->print();
    puts("--------------------");
    
    // compile
    CFlags flags;
    flags.name = "testcc";
    
    TestCompiler *compiler = new TestCompiler(tree, flags);
    compiler->compile();
    compiler->debug();

    return 0;
}

