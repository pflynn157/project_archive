#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ast.h"
#include "utils.h"

// These are various control variables used to build expressions
// TODO: Minimally the ID's, but maybe the other stuff will need to become stacks
DataType data_type = None;
ExprType expr_type = Empty;
StatementType stmt_type = Empty;

StringStack *dd_stack;
NodeStack *node_stack;
Block *current_block;

const char *id = "";

void clear_control()
{
    data_type = None;
    expr_type = Empty;
    stmt_type = Empty;
    id = "";
    
    if (current_block) free(current_block);
    current_block = (Block *)malloc(sizeof(Block));
    current_block->lines = (Expression **)malloc(sizeof(Expression *) * 10);
    current_block->line_count = 0;
    current_block->line_max = 10;
}

void ast_set_data_type(DataType type)
{
    data_type = type;
}

void ast_set_expr_type(ExprType type)
{
    expr_type = type;
}

void ast_set_statement_type(StatementType type)
{
    stmt_type = type;
}

void ast_set_id(const char *identifier)
{
    id = identifier;
}

void ast_add_declare_id(char *identifier)
{
    string_stack_push(dd_stack, identifier);
}

void ast_set_int_node(int literal)
{
    ExprNode *node = (ExprNode *)malloc(sizeof(ExprNode));
    node->type = IntLiteral;
    node->i32_literal = literal;
    
    node_stack_push(node_stack, node);
}

// Build an expression
void ast_build_expression()
{
    ExprNode **expr_list = (ExprNode **)malloc(sizeof(ExprNode *) * 10);

    Expression *expr = (Expression *)malloc(sizeof(Expression));
    expr->stmt_type = stmt_type;
    expr->expr_type = expr_type;
    
    expr->expr_list = expr_list;
    expr->expr_count = 0;
    expr->expr_max = 10;
    
    // Build the nodes
    switch (expr_type)
    {
        case UnaryExpr: {
            ExprNode *node = node_stack_pop(node_stack);
            expr->expr_list[0] = node;
            expr->expr_count = 1;
        } break;
        
        default: return;
    }
    
    // TODO: Size check (realloc)
    int pos = current_block->line_count;
    current_block->lines[pos] = expr;
    current_block->line_count += 1;
}

// Build a function declaration
void ast_build_function(Ast *ast)
{
    Block *block = (Block *)malloc(sizeof(Block));
    memcpy(block, current_block, sizeof(Block));
    
    current_block->line_count = 0;
    
    char *func_id = string_stack_pop(dd_stack);

    Function *func = (Function *)malloc(sizeof(Function));
    func->type = data_type;
    func->name = strdup(func_id);
    func->block = block;
    
    ast->funcs[ast->func_count] = func;
    ast->func_count += 1;
}

// Utility functions for the AST as a whole
Ast *create_ast(const char *mod_name)
{
    node_stack = node_stack_create();
    dd_stack = string_stack_create();

    Ast *ast = (Ast *)malloc(sizeof(Ast));
    ast->mod_name = mod_name;
    
    ast->funcs = (Function **)malloc(sizeof(Function *) * 10);
    ast->func_count = 0;
    ast->func_max = 10;
    
    clear_control();
    
    return ast;
}

void free_ast(Ast *ast)
{
    // TODO
    // Its here so I remember
}

