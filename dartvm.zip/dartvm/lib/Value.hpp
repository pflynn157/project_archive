#pragma once

#include <string>

class Value {
public:
    explicit Value(std::string name) {
        this->name = name;
    }

    virtual void dump() {}
protected:
    std::string name = "";
};
