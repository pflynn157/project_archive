#include <stdio.h>

#include "debug.h"
#include "ast.h"

void print_data_type(DataType type)
{
    switch (type)
    {
        case Void: printf("void "); break;
        case Char: printf("char "); break;
        case Short: printf("short "); break;
        case Int: printf("int "); break;
        case Long: printf("long "); break;
        case Float: printf("float "); break;
        case Double: printf("double "); break;
    }
}

void print_node(struct Node *node)
{
    if (!node)
    {
        printf("(null)\n");
        return;
    }
    
    if (node->lval) print_node(node->lval);

    switch (node->type)
    {
        case CharL: printf("\'%c\' ", node->ival); break;
        case IntL: printf("%d ", node->ival); break;
        case FloatL: printf("%f ", node->flt_val); break;
        case StringL: printf("\"%s\" ", node->sval); break;
        case Id: printf("%s ", node->sval); break;
        case Plus: printf("+ "); break;
        case Sub: printf("- "); break;
        case Mul: printf("* "); break;
        case Div: printf("/ "); break;
        case Pointer: printf("*"); break;
        case AddrOf: printf("&"); break;
        case Negate: printf("-"); break;
        case Assign: printf("= "); break;
    }
    
    if (node->rval) print_node(node->rval);
}

void print_statement(struct Statement *stmt, int out_terminal)
{
    if (!stmt)
    {
        puts("(null)");
        return;
    }
    
    //printf("STMT: ");
    
    switch (stmt->type)
    {
        case VarDec:
        {
            print_data_type(stmt->ival);
            print_node(stmt->operand);
        }
        break;
        
        case VarAssign: print_node(stmt->operand); break;
        
        case RetVoid: printf("return"); break;
        case Ret: printf("return "); print_node(stmt->operand); break;
    }
    
    if (out_terminal)
        printf(";\n");
}

void print_function(struct Function *func)
{
    if (!func)
    {
        printf("(null)\n");
        return;
    }
    
    if (func->is_extern)
        printf("extern ");
    
    print_data_type(func->type);
    printf("%s(", func->name);
    
    if (func->param_block != NULL)
    {
        struct Statement **param_block = func->param_block->line_list;
        int max = func->param_block->line_count;
        for (int i = 0; i<max; i++)
        {
            print_statement(param_block[i], 0);
            if (i + 1 < max) printf(", ");
        }
    }
    
    if (func->is_extern)
        printf(");\n\n");
    else
        printf(")\n{\n");
    
    if (!func->block) return;
    
    struct Statement **lines = func->block->line_list;
    for (int i = 0; i<func->block->line_count; i++)
    {
        printf("  ");
        print_statement(lines[i], 1);
    }
    
    if (!func->is_extern)
        printf("}\n\n");
}

void print_tree(AstTree *tree)
{
    if (!tree)
    {
        puts("Empty tree");
        return;
    }
    
    printf("MOD: %s\n", tree->module_name);
    
    struct Function **funcs = tree->func_list;
    for (int i = 0; i<tree->func_count; i++)
    {
        print_function(funcs[i]);
    }
}

