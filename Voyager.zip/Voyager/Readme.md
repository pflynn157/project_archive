## Voyager
Voyager is a simple web browser. It is written in C++ and uses the Qt library, included as the browser engine (which is based on Chromium). Most basic tasks are supported. Enjoy! 
