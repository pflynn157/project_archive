#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ast.h"

AstFile *ast_file_create(char *name) {
    AstFile *file = malloc(sizeof(AstFile));
    file->name = malloc(sizeof(char)*strlen(name));
    strcpy(file->name, name);
    file->function_list = vector_init();
    return file;
}

AstFunction *ast_function_create(char *name) {
    AstFunction *function = malloc(sizeof(AstFunction));
    function->name = name;
    
    function->block = malloc(sizeof(AstBlock));
    function->block->block = vector_init();
    return function;
}

AstStatement *ast_statement_create(AstType type) {
    AstStatement *statement = malloc(sizeof(AstStatement));
    statement->type = type;
    return statement;
}

AstExpression *ast_expr_create(AstType type) {
    AstExpression *expr = malloc(sizeof(AstExpression));
    expr->type = type;
    return expr;
}

void ast_add_function(AstFile *file, AstFunction *func) {
    size_t pos = file->function_list->size;
    vector_push_back(file->function_list, func, sizeof(AstFunction *));
    
    AstFunction *func_obj = (AstFunction *)vector_get_at(file->function_list, pos);
    func_obj->name = func->name;
    func_obj->block = func->block;
    func_obj->block->block = func->block->block;
    
    free(func);
}

void ast_add_statement(AstBlock *block, AstStatement *stmt) {
    size_t pos = block->block->size;
    vector_push_back(block->block, stmt, sizeof(stmt));
    
    AstStatement *stmt_obj = (AstStatement *)vector_get_at(block->block, pos);
    stmt_obj->expr = stmt->expr;
    
    free(stmt);
}

void ast_set_expr(AstStatement *stmt, AstExpression *expr) {
    stmt->expr = expr;
}

//
// Frees memory from the AST tree
//
void ast_expr_destroy(AstExpression *expr) {
    if (expr->lval) ast_expr_destroy((AstExpression *)expr->lval);
    if (expr->rval) ast_expr_destroy((AstExpression *)expr->rval);
    if (expr->name) free(expr->name);
    free(expr);
}

void ast_destroy(AstFile *file) {
    for (size_t i = 0; i<file->function_list->size; i++) {
        AstFunction *func = (vector_get_at(file->function_list, i));
        AstBlock *block = func->block;
        
        for (size_t j = 0; j<block->block->size; j++) {
            AstStatement *stmt = (AstStatement *)vector_get_at(block->block, j);
            
            if (stmt->expr) {
                ast_expr_destroy(stmt->expr);
            }
            
            free(stmt);
        }
        
        vector_destroy(block->block);
        free(block);
        free(func->name);
        free(func);
    }
    
    vector_destroy(file->function_list);
    free(file->name);
    free(file);
}

//
// The debug function
//
char *ast_print_type(AstType type) {
    switch (type) {
        case AST_Return: return "Return";
        case AST_VarDec: return "Var";
        case AST_VarAssign: return "Var=";
        
        case AST_Id: return "Id";
        case AST_IntL: return "IntL";
        
        default: "???";
    }
    
    return "";
}

void ast_debug_expr(AstExpression *expr) {
    if (expr == NULL) {
        printf("NULL ");
        return;
    }
    
    //printf("%s ", ast_print_type(expr->type));

    if (expr->type == AST_IntL) {
        printf("%d", (int)expr->int_literal);
        
    } else if (expr->type == AST_Id) {
        printf("%s", expr->name);
        
    } else if (expr->type == AST_ExprList) {
        printf("((");
        if (expr->list) {
            printf("[%ld] ", expr->list_size);
            for (size_t i = 0; i<expr->list_size; i++) {
                ast_debug_expr((AstExpression *)expr->list[i]);
                printf(", ");
            }
        } else {
            printf("NULL");
        }
        printf("))");
        
    } else if (expr->type == AST_Assign) {
        printf("(");
        ast_debug_expr((AstExpression *)expr->lval);
        printf(" := ");
        ast_debug_expr((AstExpression *)expr->rval);
        printf(")");
        
    } else if (expr->type == AST_Add) {
        printf("(");
        ast_debug_expr((AstExpression *)expr->lval);
        printf(" + ");
        ast_debug_expr((AstExpression *)expr->rval);
        printf(")");
    }
}

void ast_debug(AstFile *file) {
    printf("FILE: %s\n", file->name);
    
    for (size_t i = 0; i<file->function_list->size; i++) {
        AstFunction *func = (vector_get_at(file->function_list, i));
        printf("FUNC %s {\n", func->name);
        
        AstBlock *block = func->block;
        
        for (size_t j = 0; j<block->block->size; j++) {
            AstStatement *stmt = (AstStatement *)vector_get_at(block->block, j);
            printf("\t%s ", ast_print_type(stmt->type));
            
            if (stmt->expr) {
                AstExpression *expr = stmt->expr;
                ast_debug_expr(expr);
            }
            
            printf(";\n");
        }
        
        printf("}\n\n");
    }
}

