module X64.X64Vars(x64IStoreI,
    x64ILdrI,
    x64ILdrV,
    x64IStr) where

import System.IO

import Ltac
import X64.X64Registers

-- Store an immediate to an integer variable
x64IStoreI ln writer = do
    let pos = (arg1 ln)
    let val = (arg2 ln)
    hPutStr writer ("\tmov DWORD PTR [rbp-" ++ pos ++ "], ")
    hPutStrLn writer val
    
-- Load an immediate to integer register
x64ILdrI ln writer = do
    let regPos = read (arg1 ln) :: Int
    let reg = x64IntReg regPos
    let val = arg2 ln
    hPutStrLn writer ("\tmov " ++ reg ++ ", " ++ val)
    
-- Load an integer variable to register
x64ILdrV ln writer = do
    let regPos = read (arg1 ln) :: Int
    let reg = x64IntReg regPos
    let pos = arg2 ln
    hPutStrLn writer ("\tmov " ++ reg ++ ", DWORD PTR [rbp-" ++ pos ++ "]")
    
-- Stores an integer register to a memory location
x64IStr ln writer = do
    let regPos = read (arg1 ln) :: Int
    let reg = x64IntReg regPos
    let pos = arg2 ln
    hPutStrLn writer ("\tmov DWORD PTR [rbp-" ++ pos ++ "], " ++ reg)

