module Utils(parse, isInt, isRegister) where

import Data.List.Split
import Text.Read
import Data.Int
import Data.Char

-- The basic parse functions
dropEmpty :: [String] -> [String] -> [String]
dropEmpty [] new_parts = reverse new_parts
dropEmpty (x:xs) new_parts = do
    if (length x) == 0
        then dropEmpty xs new_parts
        else dropEmpty xs (x : new_parts)
        
checkStr [] last str = reverse str
checkStr (x:xs) last str = do
    if last == '\\'
        then do
            if x == 'n'
                then checkStr xs x ('\n' : str)
                else checkStr xs x (x : (last : str))
        else do
            if x == '\\'
                then checkStr xs x str
                else checkStr xs x (x : str)
        
checkStrParts parts = do
    if (length parts) /= 3
        then parts
        else do
            let op2 = parts !! 1
            if op2 /= "string"
                then parts
                else do
                    let op1 = head parts
                    let op3 = parts !! 2
                    let op3_n = checkStr op3 (chr 0) []
                    (op1 : (op2 : (op3_n : [])))
    
parse ln = do
    let parts = splitOneOf " ," ln
    let parts2 = dropEmpty parts []
    checkStrParts parts2

-- Checks to see if a string is an integer
isInt :: String -> Bool
isInt strInt
    | (readMaybe strInt :: Maybe Int32) == Nothing = False
    | otherwise = True
    
-- Checks to see if a string is a register
isRegister reg
    -- 32-bit registers
    | reg == "eax" = True
    | reg == "ebx" = True
    | reg == "ecx" = True
    | reg == "edx" = True
    | reg == "esp" = True
    | reg == "ebp" = True
    | reg == "esi" = True
    | reg == "edi" = True
    
    -- 64-bit registers
    | reg == "rax" = True
    | reg == "rbx" = True
    | reg == "rcx" = True
    | reg == "rdx" = True
    | reg == "rsp" = True
    | reg == "rbp" = True
    | reg == "rsi" = True
    | reg == "rdi" = True
    
    -- Or not
    | otherwise = False
