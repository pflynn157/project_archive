#include <iostream>

#include "parser.hpp"
#include "ast.hpp"
#include "compiler.hpp"

int main(int argc, char *argv[]) {
    if (argc == 1) {
        std::cerr << "Error: No input file specified." << std::endl;
        return 1;
    }
    
    // Command line arguments
    std::string input = "";
    bool printAst = false;
    bool printLLIR = false;
    
    for (int i = 1; i<argc; i++) {
        std::string arg = argv[i];
        if (arg == "--ast") printAst = true;
        else if (arg == "--llir") printLLIR = true;
        else input = arg;
    }

    // Build
    Parser *parser = new Parser(input);
    AstFile *file = parser->parseFile();
    
    if (printAst) file->print();
    
    Compiler *compiler = new Compiler(file);
    compiler->compile();
    
    if (printAst && printLLIR)
        std::cout << "-----------------------" << std::endl;
    if (printLLIR) compiler->print();
    
    compiler->assemble();
    
    //delete compiler;
    delete parser;
    delete file;
    
    return 0;
}

