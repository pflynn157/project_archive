int main() {
    int a = 0;
    int b = 0;
    if (a)
        b = 1;
    return b;
}