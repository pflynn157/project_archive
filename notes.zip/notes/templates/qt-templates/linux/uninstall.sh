#!/bin/bash
echo "Uninstalling..."

APP_NAME=uds_app

rm /opt/uds/bin/$APP_NAME
rm /opt/uds/icons/apps/$APP_NAME.svg
rm /usr/share/applications/$APP_NAME.desktop

update-desktop-database

echo "Done" 

