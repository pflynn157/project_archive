const express = require("express");
const {v4: uuidv4} = require("uuid");
const firebaseAuth = require("firebase/auth");
const {getDatabase, ref, child, set, get, remove} = require("firebase/database");
const {firebase} = require("./firebase.js");

const router = express.Router();
const auth = firebaseAuth.getAuth(firebase);
var currentUser = null;

router.get("/", (req, res, next) => {
    if (currentUser) {
        res.redirect("/dashboard");
    } else {
        res.render("index");
    }
});

router.get("/dashboard", (req, res, next) => {
    res.render("dashboard");
});

//
// Used for signup and login
//

// GET /signup
router.get("/signup", (req, res, next) => {
    res.render("signup");
});

router.post("/signup", (req, res, next) => {
    let email = req.body.email;
    let password = req.body.password;
    
    firebaseAuth.createUserWithEmailAndPassword(auth, email, password)
        .then(userCred => {
            currentUser = userCred.user;
            res.redirect("/dashboard");
        })
        .catch(err => next(err));    // TODO: Fix this
});

// GET /login
router.get("/login", (req, res, next) => {
    res.render("login");
});

router.post("/login", (req, res, next) => {
    let email = req.body.email;
    let password = req.body.password;
    
    firebaseAuth.signInWithEmailAndPassword(auth, email, password)
        .then(userCred => {
            currentUser = userCred.user;
            res.redirect("/dashboard");
        })
        .catch(error => next(err));    // TODO: Fix this
});

//
// The pages for the productivity apps
//
const testID = "adfagf234tfg";

router.get("/tasks", (req, res, next) => {
    const dbRef = ref(getDatabase());
    get(child(dbRef, "tasks/" + testID))
        .then(snapshot => {
            if (snapshot.exists()) {
                console.log(snapshot.val());
            }
            res.render("tasks", {tasks: snapshot.val()});
        })
        .catch(error => next(err));
});

router.post("/tasks", (req, res, next) => {
    let id = uuidv4();
    let body = req.body;
    const db = getDatabase();
    
    set(ref(db, "tasks/" + testID + "/" + id), {
        id: id,
        title: body.name,
        desc: ""
    })
    .then(() => {
        res.redirect("/tasks");
    })
    .catch();
});

router.post("/tasks/:id/complete", (req, res, next) => {
    let id = req.params.id;
    const db = getDatabase();
    remove(ref(db, "tasks/" + testID +"/" + id))
        .then(() => {
            res.redirect("/tasks");
        })
        .catch();
});

module.exports = router;
