#include <stdio.h>

int main() {
	typedef float float256 __attribute__((vector_size(32)));
	
	float256 array1 = {1, 2, 3, 4, 5, 6, 7, 8};
	float256 array2 = {10, 20, 30, 40, 50, 60, 70, 80};
	float256 answer_v = array1 + array2;
	
	float answer = 0;
	
	for (int i = 0; i<8; i++)
		answer += answer_v[i];
		
	printf("Answer: %f\n", answer);

	return 0;
}
