## Timer/Memory

This gives an example of how to use the Linux shared memory system and implementing a timer in C++. Each file corresponds to a binary. The writer program will write text to the shared memory location, and the timer program will check and read this memory at specific time intervals.

The best way to see it in action is to open each in its own terminal window, and run.
