#!/usr/bin/python3
import os
import time
		
class Esc:
	esc = 4
	pi = 0
	max_val = 2000
	min_val = 700
	neutral = 1500
	
	def init_d(self):
		print("Starting pigpiod...")
		time.sleep(1)
		os.system("sudo killall pigpiod")
		os.system("sudo pigpiod")
		print("Done")
		
	def init(self):
		import pigpio
		self.pi = pigpio.pi()

		self.pi.set_servo_pulsewidth(self.esc, 0)

	def control(self):
		time.sleep(1)
		speed = self.neutral
		print("d= +10, e= +100, a= -10, q= -100, x=stop")
	
		while True:
			self.pi.set_servo_pulsewidth(self.esc, speed)
			inp = str(input())
		
			if inp == "a":
				speed -= 10
			elif inp == "d":
				speed += 10
			elif inp == "e":
				speed += 100
			elif inp == "q":
				speed -= 100
			elif inp == "x":
				self.stop()
				break
			else:
				print("Unknown input")
				
	def set_neutral(self):
		self.pi.set_servo_pulsewidth(self.esc, self.neutral)
				
	def set_speed(self, speed):
		self.pi.set_servo_pulsewidth(self.esc, speed)
			
	def stop(self):
		self.pi.set_servo_pulsewidth(self.esc, self.neutral)
		self.pi.stop()
	

	def calibrate1(self):
		self.pi.set_servo_pulsewidth(self.esc, 0)
		self.pi.set_servo_pulsewidth(self.esc, self.max_val)

	def calibrate2(self):
		print("Setting up...")
		self.pi.set_servo_pulsewidth(self.esc, self.min_val)
		time.sleep(12)
		self.pi.set_servo_pulsewidth(self.esc, 0)
		time.sleep(2)
		self.pi.set_servo_pulsewidth(self.esc, self.min_val)
		time.sleep(1)
		self.pi.set_servo_pulsewidth(self.esc, self.neutral)
		print("Done")



