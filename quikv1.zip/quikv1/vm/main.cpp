#include <iostream>
#include <cstdlib>

#include "reader.hh"

int main(int argc, char **argv) {
	if (argc <= 1) {
		std::cout << "Error: No input file specified." << std::endl;
		std::exit(1);
	}
	
	auto file = std::string(argv[1]);
	
	
	ByteReader reader(file);
	bool pass = reader.isHeaderValid();
	
	if (!pass) {
		std::cout << "Error: Invalid QuikVM file." << std::endl;
		std::cout << "Header signature failed." << std::endl;
		std::exit(1);
	}
	
	reader.loadAll();
	
	return 0;
}
