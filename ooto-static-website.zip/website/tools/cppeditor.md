---
layout: page
title: CppEditor
permalink: /tools/cppeditor
---

CppEditor is the oldest project I still maintain. Originally, I did not intend for this to go on as long as it has, but it has since evolved from being a learning project to my everyday source code editor.

CppEditor started out as a learning project back in high school in 2016-2017 (I don’t remember- the license starts at 2017, but I remember working on it beforehand). Text editors are a great learning experience for new programmers, especially GUI programmers. They require you to know most basic programming and GUI tasks, while not being excessively complicated. Eventually, I put it aside to work on other more interesting things.

Fast forward to 2020. Up until that point, I had been using the Linux Mint editor, which has (and still has) the nice, traditional text editing interface that I both loved and was used to after 6+ years of programming. Around that time, I began having to use different desktop platforms, and in my opinion most of the editors were bad. I didn’t like installing desktop-specific editors because they require a ton of dependencies. I also didn’t like the fact that they didn’t work anywhere else like on Windows (if they did, they were generally awful). My solution: use my own editor. By this point in time, CppEditor was already very mature, despite not having worked on it for 3 years. It looked like the Mint editor, it had the multi-document interface, it had syntax highlighting thanks to KDE, it had the project pane, and it ran everywhere with almost no effort. So I cleaned it up some, added a few things I needed, and its been my everyday editor since.

Here are some screenshots:

![](/images/cppeditor1.png)

![](/images/cppeditor2.png)


### Features

Although there is some differentiation between versions 2 and 3 (see below), all versions contain the following:

* All basic editor functions, including undo/redo
* Syntax highlighting for many languages
* Multi-document interface (tabs)- supports editing many files at once
* File explorer panel with ability to open files and create new ones
* Basic find/replace
* Auto-indent
* Control over whether to indent with tabs or spaces
* Basic automatic bracket completion
* Support for detecting changes outside the editor
* Small code base- including highlighter, ~4k lines (excludes highlighter data files)


### Why Should I Use This?

A fair question, given the great multitude of editors in this world. These are the areas where CppEditor stands out:

* Small, simple code base
* Simple design, while still retaining the convenience of the GUI
* Traditional design
* Minimal yet fully cross-platform dependencies

I think the minimal, cross-platform design is the most compelling reason for using this (it’s why I use it). Although there are many good editors, many of them are tied to a specific operating system. Those that aren’t generally seem to fall into two categories: editors like GEdit, which technically run on most if not all platforms, but don’t look great; and editors like VS Code and Atom which are built on Electron. Electron apps are something I’m very much against. Electron apps use Chromium and V8 as the backend, and I believe this shows how far gone the software industry is to think using a whole f****** browser for something as simple as an editor is a good idea. I think Electron is good for website wrappers like Slack and Discord (even then its still stretching it), but using it for editors is ridiculous. I know I’ve probably offended some people by saying this, and I know what the compelling reasons for using Electron are (still not convinced…), but whatever.

Anyway. Going back to cross-platform, I’ve managed to get this to run- with the KDE dependencies- on Linux, several BSDs, MacOS, HaikuOS, and Windows. Now that KDE is gone, it will probably run other places as well. Basically, if there is a Qt port for the platform, it will run CppEditor.


### Building

To build and run, all CppEditor needs is Qt5 (most versions of Qt5 should work- I would be surprised if they didn’t). If you’re using the older KDE version, you will need KSyntaxHighlighter, KDBusAddons, and possibly KDE’s ECM.

For the actual build, all you need is a C++ compiler supporting at least C++11, and CMake >= 3.0. All Linux distros have these dependencies, and on other systems they can be installed easily.

These commands can be used on Unix-like systems:
```
mkdir build
cd build
 
cmake ..
make -j12
 
# For installing
cd ..
./deploy-linux.sh
cd build/linux_bin
sudo ./install.sh
```


### Version 2 vs Version 3

At the time of writing, there are two main versions. Version 2 is the original version I have been using since mid-2020, and version 3 is the in-progress version that I’m starting to use and test. Version 2 is on the stable branch, and version 3 is on the develop branch (which is also the repository’s default branch).

Originally, I used two tier 1 KDE libraries: KSyntaxHighlighting and KDBusAddons. KSyntaxHighlighting was for the obvious- syntax highlighting, and KDBusAddons was for IPC. While these are fully cross-platform, including on Windows, dealing with them is a pain, and more recently I’ve noticed that KSyntaxHighlighting looks different across certain distros.

Version 3 completely drops all KDE dependencies. I am using a very nice, yet very simple Qt syntax highlighting library I found on Github, QSourceHighlite. Because it has a liberal license, I simply forked it and added it to my repository. I also made several modifications and additions to make it integrate and work better with CppEditor. Currently, the integration is kind of raw, but I want to make sure everything works to my liking before I commit to dropping KDE for good. For now, I’m also completely dropping IPC support as its more of an annoyance than anything.

I’m going to keep version 3 unpublished for a few months while I get used to it and see how I like it. If all goes well, I will publish sometime this summer.


