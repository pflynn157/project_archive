#include <smmintrin.h>
#include <immintrin.h>
#include <stdio.h>
#include <malloc.h>

int main() 
{
	float array1[8] = {1, 2, 3, 4, 5, 6, 7, 8};
	float array2[8] = {10, 20, 30, 40, 50, 60, 70, 80};
	float *answer_v = malloc(sizeof(float)*8);
	float answer = 0;
	
	__m256 n1 = _mm256_loadu_ps(array1);
	__m256 n2 = _mm256_loadu_ps(array2);
	__m256 r = _mm256_add_ps(n1, n2);
	_mm256_storeu_ps(answer_v, r);
	
	for (int i = 0; i<8; i++)
		answer += answer_v[i];
		
	printf("Answer: %f\n", answer);

	return 0;	
}
