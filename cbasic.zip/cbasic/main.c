// main.c
#include <stdio.h>
#include <malloc.h>

#include "strutils.h"
#include "file.h"
#include "interpreter.h"
#include "loader.h"

void shell_mode()
{
	puts("Welcome to BASIC!");
	puts("You are in shell mode.");
	puts("");
	
	char buffer[100];
	for (;;)
	{
		fgets(buffer, 100, stdin);
		char *ln = buffer;
		ln = trim(ln);
		
		int code = interpret(ln);
		free(ln);
		
		if (code == 1)
			break;
	}
}

void file_mode(const char *path)
{
	int lines = line_count(path);
	char **contents = load_lines(path, lines);
	
	for (int i = 0; i<lines; i++) {
		char *current = contents[i];
	}
	
	run(contents, lines);	
}

int main(int argc, char *argv[])
{
	if (argc < 2) {
		shell_mode();
	} else {
		char *file = argv[1];
		file_mode(file);
	}

	return 0;
}
