#pragma once

#include <ltac/ltac.h>
#include <ast.h>

void ltac_assemble(AstNode *tree, LtacFile *file);
