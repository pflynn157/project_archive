
#include <gtk/gtk.h>

#include "actions.h"
#include "window.h"
#include "tabpane.h"

void action_open_file(Window *win)
{
    GtkWidget *dialog;
    GtkFileChooserAction action = GTK_FILE_CHOOSER_ACTION_OPEN;
    gint ret;
    
    dialog = gtk_file_chooser_dialog_new("Open File", GTK_WINDOW(win->window), action,
        "Cancel", GTK_RESPONSE_CANCEL, "Open", GTK_RESPONSE_ACCEPT, NULL);
    ret = gtk_dialog_run(GTK_DIALOG(dialog));
    
    if (ret != GTK_RESPONSE_ACCEPT)
        return;
        
    GtkFileChooser *chooser = GTK_FILE_CHOOSER(dialog);
    char *path = gtk_file_chooser_get_filename(chooser);
    
    Editor *current = win->tabContent[win->currentTab];
    
    if (current->srcFile == NULL && current->modified == 0)
    {
        editor_load_file(current, path);
    }
    else
    {
        tabpane_add_tab(win, path);
    }
    
    g_free(path);
    gtk_widget_destroy(dialog);
}

