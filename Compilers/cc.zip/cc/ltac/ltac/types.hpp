#pragma once

#include "ltac.hpp"

// Represents an integer
class LtacInt : public LtacInstr {
public:
    explicit LtacInt(int val) : LtacInstr(LtacType::Int) {
        this->val = val;
    }
    
    int getVal() { return val; }
    
    std::string printInstr() {
        return std::to_string(val);
    }
private:
    int val = 0;
};

// Represents a string
// The value is not a literal string value. It is the name of string string element
// which is stored in the data section.
class LtacString : public LtacInstr {
public:
    explicit LtacString(std::string val) : LtacInstr(LtacType::String) {
        this->val = val;
    }
    
    std::string getVal() { return val; }
    
    std::string printInstr() { return val; }
private:
    std::string val = "";
};

// Represents a data string (the full data segment)
class LtacStringVal : public LtacData {
public:
    LtacStringVal(std::string name, std::string val) : LtacData(LtacDType::String) {
        this->name = name;
        this->val = val;
    }
    
    std::string getName() { return name; }
    std::string getVal() { return val; }
    
    std::string printData();
private:
    std::string name = "";
    std::string val = "";
};
