#include <iostream>

#include "writer.hpp"

HtmlWriter::HtmlWriter(std::string input, bool singleFile) {
    this->input = input;
    this->singleFile = singleFile;
    
    int lastSlash = input.find_last_of("/");
    if (lastSlash != -1) {
        this->input = input.substr(lastSlash);
    }
    
    scanner = new Scanner(input + ".ww");
    htmlWriter = std::ofstream(input + ".html");
    if (!singleFile) cssWriter = std::ofstream(input + ".css");
    
    domTree = new Tree;
}

void HtmlWriter::parse() {
    Token token = scanner->getNext();
    
    while (token.type != Eof) {
        switch (token.type) {
            case Meta: if (!generateMeta()) return; break;
            
            case Main: {
                Token blockType = token;
                token = scanner->getNext();
                if (token.type != LBrace) {
                    std::cerr << "Expected \'{\' after \"main\"." << std::endl;
                    return;
                }
                
                generateBlock(blockType, 1);
            } break;
            
            default: {token.print();}
        }
        
        token = scanner->getNext();
    }
}

void HtmlWriter::print() {
    htmlWriter << "<!DOCTYPE HTML>" << std::endl;
    htmlWriter << "<html>" << std::endl;
    
    for (Block *block : domTree->blocks) {
        printBlock(block);
    }
    
    if (singleFile) {
        indent(1);
        htmlWriter << "<style>" << std::endl;
        htmlWriter << cssBlock;
        indent(1);
        htmlWriter << "</style>" << std::endl;
    } else {
        cssWriter << cssBlock << std::endl;
    }
    
    htmlWriter << "</html>" << std::endl;
    htmlWriter.close();
}

void HtmlWriter::close() {
    delete scanner;
}

void HtmlWriter::printBlock(Block *block, int spacing) {
    indent(spacing);
    htmlWriter << "<" << block->tagName << ">" << std::endl;
    
    for (Node *n : block->nodes) {
        if (n->isBlock) printBlock((Block *)n, spacing+1);
        else printElement((Element *)n, spacing+1);
    }
    
    indent(spacing);
    htmlWriter << "</" << block->tagName << ">" << std::endl;
    
    // Write block CSS rules
    printCSS(block);
}

void HtmlWriter::printElement(Element *element, int spacing) {
    indent(spacing);
    htmlWriter << "<" << element->tagName << " ";
    
    for (auto attr : element->attrs) {
        htmlWriter << attr.first << "=\"" << attr.second << "\" ";
    }
    
    htmlWriter << ">";
    
    if (element->endTag) {
        if (element->value.length() > 0) htmlWriter << element->value;
        htmlWriter << "</" << element->tagName << ">";
    }
    
    htmlWriter << std::endl;
    
    // Write element CSS rules
    printCSS(element);
}

void HtmlWriter::printCSS(Node *node) {
    if (node->cssRules.size() > 0) {
        //cssWriter << node->tagName << " {" << std::endl;
        cssBlock += node->tagName + "{\n";
        
        for (auto css : node->cssRules) {
            //indent(2);
            //cssWriter << css.first << ": " << css.second << std::endl;
            cssBlock += "  " + css.first + ": " + css.second + "\n";
        }
        
        //cssWriter << "}" << std::endl << std::endl;
        cssBlock += "}\n";
    }
}

bool HtmlWriter::generateMeta() {
    Token token = scanner->getNext();
    
    if (token.type != LBrace) {
        std::cerr << "Error: Expected \'{\' in \"meta\"." << std::endl;
        return false;
    }
    
    Block *block = new Block;
    block->tagName = "head";
    domTree->blocks.push_back(block);
    
    // Add the CSS file
    Element *link = new Element;
    link->tagName = "link";
    link->endTag = false;
    link->addAttribute("rel", "stylesheet");
    link->addAttribute("href", std::string(input + ".css"));
    block->nodes.push_back(link);
    
    token = scanner->getNext();
    while (token.type != RBrace) {
        switch (token.type) {
            // Generates a title tag in the header
            case Title: {
                token = scanner->getNext();
                if (token.type != Colon) {
                    std::cerr << "Error: Expected \':\' in \"title\"." << std::endl;
                    return false;
                }
                
                token = scanner->getNext();
                if (token.type != String) {
                    std::cerr << "Error: Expected string literal to name title." << std::endl;
                    return false;
                }
                
                Element *title = new Element;
                title->tagName = "title";
                title->value = token.id_val;
                block->nodes.push_back(title);
                
                token = scanner->getNext();
                if (token.type != SemiColon) {
                    std::cerr << "Error: Expected terminator." << std::endl;
                    return false;
                }
            } break;
            
            // Generates the author tag in the header
            // <meta name="author" content=<AUTHOR>>
            //
            case Author: {
                token = scanner->getNext();
                if (token.type != Colon) {
                    std::cerr << "Error: Expected \':\' in \"author\"." << std::endl;
                    return false;
                }
                
                token = scanner->getNext();
                if (token.type != String) {
                    std::cerr << "Error: Expected string literal to name auhtor." << std::endl;
                    return false;
                }
                
                Element *author = new Element;
                author->tagName = "meta";
                author->addAttribute("name", "author");
                author->addAttribute("content", token.id_val);
                block->nodes.push_back(author);
                
                token = scanner->getNext();
                if (token.type != SemiColon) {
                    std::cerr << "Error: Expected terminator." << std::endl;
                    return false;
                }
            } break;
            
            default: {
                std::cerr << "Error: Unknown token in meta." << std::endl;
                token.print();
                return false;
            }
        }
        
        token = scanner->getNext();
    }
    
    return true;
}

// Generates an HTML block
bool HtmlWriter::generateBlock(Token blockToken, int spacing, Block *parent) {
    std::string blockName = "";
    bool isBlock = false;
    
    switch (blockToken.type) {
        case Main: {
            blockName = "body";
            isBlock = true;
        } break;
        
        case Header: {
            blockName = "header";
            isBlock = true;
        } break;

        default: {} 
    }
    
    Block *block = new Block;
    block->tagName = blockName;
    if (parent) parent->nodes.push_back(block);
    else domTree->blocks.push_back(block);
    
    Token token = scanner->getNext();
    while (token.type != RBrace) {
        switch (token.type) {
            //
            // Handles CSS rules
            //
            case At: {
                token = scanner->getNext();
                if (token.type != Id) {
                    std::cerr << "Error: Expected CSS rule name." << std::endl;
                    return false;
                }
                
                std::string name = token.id_val;
                if (name == "color" && isBlock) {
                    name = "background-color";
                }
                
                token = scanner->getNext();
                if (token.type != Colon) {
                    std::cerr << "Error: Expected \':\' in CSS rule." << std::endl;
                    return false;
                }
                
                token = scanner->getNext();
                block->addCSS(name, token.id_val);
                
                token = scanner->getNext();
                if (token.type != SemiColon) {
                    std::cerr << "Error: Expected terminator in CSS rule." << std::endl;
                    return false;
                }
            } break;
            
            // Javascript
            case FuncSign: {
                token = scanner->getNext();
                while (token.type != RBrace) token = scanner->getNext();
            } break;
            
            // Header blocks
            case Header: {
                Token bt2 = token;
                token = scanner->getNext();
                if (token.type != LBrace) {
                    std::cerr << "Error: Expected \"{\" for header." << std::endl;
                    return false;
                }
                
                generateBlock(bt2, spacing + 1, block);
            } break;
            
            // Element tags
            case H1:
            {
                generateElement(token, spacing + 1, block);
            } break;
            
            default:{token.print();}
        }
        
        token = scanner->getNext();
    }
    
    return true;
}

bool HtmlWriter::generateElement(Token elementToken, int spacing, Block *parent) {
    std::string name = "";
    switch (elementToken.type) {
        case H1: name = "h1"; break;
        default: {}
    }
    
    Element *element = new Element;
    element->tagName = name;
    parent->nodes.push_back(element);
    
    // TODO: CSS?
    
    Token token = scanner->getNext();
    if (token.type != LParen) {
        std::cerr << "Error: Expected \'(\' to begin \"" << name << "\" tag." << std::endl;
        return false;
    }
    
    token = scanner->getNext();
    while (token.type != RParen) {
        switch (token.type) {
            case String: {
                element->value = token.id_val;
            } break;
            
            case Id: {
                if (argExists(token.id_val)) {
                    element->value = args[token.id_val];
                }
            } break;
            
            default: {token.print();}
        }
        
        token = scanner->getNext();
    }
    
    token = scanner->getNext();
    if (token.type != SemiColon) {
        std::cerr << "Error: Expected terminator." << std::endl;
        return false;
    }

    return true;
}

void HtmlWriter::indent(int amount) {
    for (int i = 0; i<amount*2; i++) {
        htmlWriter << " ";
    }
}

bool HtmlWriter::argExists(std::string name) {
    if (args.find(name) != args.end()) return true;
    return false;
}
