#include <stdio.h>
#include <omp.h>

// detached untied
#define PTASK_FLAG_DETACHABLE 0x40

int started = 0; 

// Compiler-generated code (emulation)
typedef struct ident {
  void* dummy; // not used in the library
} ident_t;

typedef struct {
  int type;
  union {
    void *task;
  } ed;
} kmp_event_t;

typedef struct shar { // shareds used in the task
  int n; 
  int *x;
} *pshareds;

typedef struct task {
  pshareds shareds;
  int(*routine)(int,struct task*);
  int part_id;
  omp_event_handle_t evt;
} *ptask, kmp_task_t;

typedef void(*fork_entry_t)(int*, int*, ...);
typedef void(*task_entry_t)(int, ptask);
#ifdef __cplusplus
extern "C" {
#endif
extern ptask __kmpc_omp_task_alloc(ident_t *loc, int gtid, int flags,
                                   size_t sz, size_t shar, task_entry_t rtn);
extern void __kmpc_fork_call(ident_t *, int nargs, 
                       fork_entry_t microtask, ...);
extern int __kmpc_omp_task(ident_t *loc_ref, int gtid, ptask task);                 
extern int __kmpc_omp_taskwait(ident_t *loc_ref, int gtid);
extern int __kmpc_single(ident_t *loc_ref, int gtid);
extern void __kmpc_end_single(ident_t *loc_ref, int gtid);
extern void __kmpc_barrier(ident_t *loc_ref, int gtid);
#if __cplusplus
}
#endif

int fib(int n);

// User's code, outlined into task entry
void task_entry(int gtid, ptask task) {
    int n = task->shareds->n;  
    *(task->shareds->x) = fib(n - 1); 
}

void fork_entry(int *pgtid, int *btid, int *pn, int *x){
    int gtid = *pgtid, n = *pn;

    // Now that we've entered a parellel context, ensure only one thread
    // continues with the following code
    if (__kmpc_single(NULL, gtid)) {
        if(n <= 2){
        *x = 1;
        return;
    }
    ptask task;
    pshareds psh;
    
    // Create task thunk (delayed computation) for fib(n-1) 
    task = (ptask)__kmpc_omp_task_alloc(NULL, gtid, 1, 
                                        sizeof(struct task), sizeof(struct shar), 
                                        &task_entry);
    task->shareds->n = n; 
    task->shareds->x = x; 
    
    // Submit thunk to runtime
    __kmpc_omp_task(NULL, gtid, task);

    // Compute the second call while waiting
    int y = fib(n-2);
    
    // Wait for the (n-1) call to finish
    __kmpc_omp_taskwait(NULL, gtid);
    __kmpc_end_single(NULL, gtid);
    
     *x = *x + y; 
  } 
  __kmpc_barrier(NULL, gtid); 
}

int fib(int n) {
  //if (n <= 2) return 1;
  int x;
  // Ensures tasking is run in a context where threads are initialized
  __kmpc_fork_call(NULL, 3, (fork_entry_t)&fork_entry, &n, &x);
  return x;   
}

int main(int argc, char **argv) {
  int n = argc > 1 ? atoi(argv[1]) : 40; 
  printf("%d\n", fib(n));
}
