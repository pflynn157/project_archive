#include "asmx86.hpp"

// Move an immediate value into a 32-bit register
void amd64_mov32_imm(Reg32 dest, int imm, FILE *file) {
    // Check for the prefix
    if (dest > EDI) {
        amd64_prefix(false, true, false, file);
    }

    // Encode the register
    switch (dest) {
        case EAX:
        case R8D: fputc(0xB8, file); break;
        case ECX:
        case R9D: fputc(0xB9, file); break;
        case EDX:
        case R10D: fputc(0xBA, file); break;
        case EBX:
        case R11D: fputc(0xBB, file); break;
        case ESP:
        case R12D: fputc(0xBC, file); break;
        case EBP:
        case R13D: fputc(0xBD, file); break;
        case ESI:
        case R14D: fputc(0xBE, file); break;
        case EDI:
        case R15D: fputc(0xBF, file);
    }
    
    // Write the immediate value
    fwrite(&imm, sizeof(int), 1, file);
}

