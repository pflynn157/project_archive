#include <stdio.h>
#include <stdlib.h>

#include <ltac/ltac.h>

LtacFile *ltac_create_file(const char *file_name)
{
    LtacFile *file = malloc(sizeof(LtacFile));
    file->data = malloc(sizeof(LtacList));
    file->text = malloc(sizeof(LtacList));
    file->file_name = file_name;
    
    return file;
}

LtacNode *ltac_create_node(LtacType type)
{
    LtacNode *node = malloc(sizeof(LtacNode));
    node->type = type;
    return node;
}

void ltac_add_code(LtacNode *code, LtacFile *file)
{
    LtacList *clist = file->text;
    
    struct LtacListNode *new_node = malloc(sizeof(struct LtacListNode));
    new_node->element = code;
    
    if (clist->head == NULL) {
        clist->head = new_node;
    } else {
        struct LtacListNode *current = clist->head;
        while (current->next != NULL) current = current->next;
        current->next = new_node;
    }
}

//////////////////////
// The debug functions

void ltac_print_node(LtacNode *node)
{
    switch (node->type)
    {
        case LT_FuncDec: printf("func %s:\n", node->str_val1); break;
        case LT_KArg_I: printf("  mov karg1, %d\n", node->i_val1); break;
        case LT_Syscall: printf("  syscall\n"); break;
        default: printf("IDK!!!");
    }
}

void ltac_print_file(LtacFile *file)
{
    printf("File: %s\n\n", file->file_name);
    
    puts(".data");
    // TODO
    
    puts("");
    puts(".text");
    
    struct LtacListNode *current = file->text->head;
    while (current != NULL) {
        ltac_print_node(current->element);
        current = current->next;
    }
}

