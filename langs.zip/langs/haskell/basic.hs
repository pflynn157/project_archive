--basic.hs
module Main(main) where

getCmd :: String -> IO()
getCmd cmd
    | cmd == "print" = putStrLn "Print!!"
    | cmd == "println" = putStrLn "Print Line!"
    | cmd == "add" = putStrLn "Add"
    | cmd == "var" = putStrLn "Var"
    | cmd == "arr" = putStrLn "Array"
    | otherwise = putStrLn "Unknown command!"

interpret :: String -> IO()
interpret ln = do
    let parts = words ln
    let cmd = head parts
    getCmd cmd
    return ()

shell :: IO()
shell = do
    putStr "> "
    ln <- getLine
    if ln == "exit"
        then return ()
        else do
            interpret ln
            shell

main = do
    putStrLn "HS BASIC"
    putStrLn ""
    shell
    return ()
    
