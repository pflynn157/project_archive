export QT_QPA_PLATFORMTHEME=gtk2

# Personal commands and aliases
alias myip="curl ipinfo.io/ip ; echo"
alias localip="ip addr show enp2s0 | grep 'inet ' | awk '{print $2}' | cut -f1 -d'/'"

# LANL-specific stuff
export LANL_INSTALL="$HOME/lanl/install"

alias kitsune="$LANL_INSTALL/bin/clang++"

function kitsune_llvm() {
    kitsune -frtti -fkokkos -ftapir=none -fopenmp $1.cpp -o $1.ll -S -emit-llvm -fno-discard-value-names
}

function kitsune_opencilk() {
    kitsune -frtti -fkokkos -fkokkos-no-init -ftapir=opencilk -fopenmp $2 $1.cpp -o $1
}

function clang_kokkos() {
    clang++ -fopenmp -O2 -I$LANL_INSTALL/include first.cpp -o $1 -L$LANL_INSTALL/lib64 -lkokkoscore -ldl
}

function start_work() {
    nano ~/lanl/test/first.cpp \
        ~/lanl/kitsune/clang/lib/CodeGen/CGKokkos.cpp \
        ~/lanl/kitsune/clang/lib/CodeGen/CodeGenFunction.h
}

