// Copyright 2019 Patrick Flynn
//
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, 
//	this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, this 
//	list of conditions and the following disclaimer in the documentation and/or 
//	other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors may 
//	be used to endorse or promote products derived from this software 
//	without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#include <iostream>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <cstdlib>
#include <thread>

#include "server.hh"
#include "response.hh"
#include "request.hh"

int socketd;
struct sockaddr_in server;

//The receiving function started by each thread of the server
void rcv_data(int nsocketd) {
	char buf[100];
	recv(nsocketd, buf, 100, 0);
		
	std::cout << std::endl << "Reply:" << std::endl;
	std::string data = std::string(buf);
	std::cout << data << std::endl;
	
	auto request = parse_request(data);
	auto path = "./www" + request.path;
	if (path == "./www/") {
		path = "./www/index.html";
	}
	
	send_response(nsocketd, path);
	close(nsocketd);
}

//The server init function
void server_init(svr_config config) {
	socketd = socket(AF_INET, SOCK_STREAM, 0);
	if (socketd == -1) {
		std::cout << "Error: Unable to create socket." << std::endl;
		std::exit(1);
	}
	
	server.sin_family = AF_INET;
	server.sin_addr.s_addr = INADDR_ANY;
	server.sin_port = htons(config.port);
}

//The main server run function
void server_run() {
	struct sockaddr_in client;

	int one = 1;
	setsockopt(socketd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
	
	if (bind(socketd, (struct sockaddr *)&server, sizeof(server)) < 0) {
		std::cout << "Bind failed." << std::endl;
		std::exit(1);
	}
	
	listen(socketd, 3);
	
	std::cout << "Bind complete." << std::endl;
	std::cout << "Listening for connections..." << std::endl;
	
	int c = sizeof(struct sockaddr_in);
	int nsocketd;
	
	while ((nsocketd = accept(socketd, (struct sockaddr *)&client, (socklen_t*)&c))) {
		std::cout << "New connection!" << std::endl;
		
		std::thread thread(rcv_data, nsocketd);
		thread.join();
	}
	
	if (nsocketd < 0) {
		std::cout << "Error: Connection failed." << std::endl;
		std::exit(1);
	}
	
	close(nsocketd);
	close(socketd);
}


