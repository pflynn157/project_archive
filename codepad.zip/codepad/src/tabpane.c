#include <stdlib.h>
#include <stdio.h>

#include <gtk/gtk.h>

#include "tabpane.h"
#include "window.h"
#include "editor.h"

typedef struct {
    Window *win;
    int tab_pos;
} TabInfo;

void tabpane_close_tab(GtkToolButton *btn, gpointer *data)
{
    TabInfo *tab = (TabInfo *)data;
    Window *win = tab->win;
    printf("Close at: %d\n", tab->tab_pos);
    
    gint tab_count = gtk_notebook_get_n_pages(GTK_NOTEBOOK(win->tabs));
    if (tab_count == 1)
        return;
        
    gtk_notebook_remove_page(GTK_NOTEBOOK(win->tabs), tab->tab_pos);
    
    if (tab->tab_pos + 1 == tab_count)
    {
        win->tabContent[tab->tab_pos] = NULL;
    }
    else
    {
        for (int i = tab->tab_pos; i<tab_count; i++)
        {
            win->tabContent[i] = win->tabContent[i+1];
        }
        
        win->tabContent[tab_count-1] = NULL;
    }
    
    /*if (tab->tab_pos == win->currentTab)
    {
        win->currentTab -= 1;
        gtk_notebook_set_current_page(GTK_NOTEBOOK(win->tabs), win->currentTab);
    }*/
    
    win->tabCount -= 1;
}

GtkWidget *tabpane_get_label(const char *file_name, TabInfo *info)
{
    GtkWidget *layout;
    layout = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 1);
    
    GtkWidget *label;
    label = gtk_label_new(file_name);

    GtkWidget *close_button_icon;
    close_button_icon = gtk_image_new_from_icon_name("window-close", GTK_ICON_SIZE_MENU);
    
    GtkToolItem *close_button;
    close_button = gtk_tool_button_new(close_button_icon, NULL);
    
    gtk_box_pack_start(GTK_BOX(layout), label, 0, 0, 1);
    gtk_box_pack_start(GTK_BOX(layout), GTK_WIDGET(close_button), 0, 0, 1);
    
    g_signal_connect(G_OBJECT(close_button), "clicked", G_CALLBACK(tabpane_close_tab), (gpointer *)info);
    
    gtk_widget_show_all(layout);
    return layout;
}

void tabpane_add_empty_tab(Window *win)
{
    Editor *editor1 = create_editor();
    set_editor_syntax_highlighter(editor1, "c");
    
    gint tab_count = gtk_notebook_get_n_pages(GTK_NOTEBOOK(win->tabs));
    gint tab_pos = tab_count;
    
    TabInfo *info = (TabInfo *)malloc(sizeof(TabInfo));
    info->win = win;
    info->tab_pos = tab_pos;
    
    GtkWidget *label = tabpane_get_label("untitled", info);
    gtk_notebook_append_page(GTK_NOTEBOOK(win->tabs), editor1->scrollView, label);
    
    gtk_widget_show_all(win->window);
    gtk_notebook_set_current_page(GTK_NOTEBOOK(win->tabs), tab_pos);
    
    // Add to the tab list
    if (tab_count >= 10)
    {
        // TODO: Re-allocate
    }
    
    win->tabCount = tab_count;
    win->tabContent[tab_pos] = editor1;
    win->currentTab = tab_pos;
}

void tabpane_add_tab(Window *win, const char *path)
{
    tabpane_add_empty_tab(win);
    Editor *current = win->tabContent[win->currentTab];
    editor_load_file(current, path);
}

void tabpane_save_current_tab(Window *win)
{
    Editor *current = win->tabContent[win->currentTab];
    editor_save_file(current);
}

void tabpane_tab_changed(GtkNotebook *notebook, GtkWidget *page, int page_num, gpointer *data)
{
    Window *win = (Window *)data;
    win->currentTab = page_num;
}

