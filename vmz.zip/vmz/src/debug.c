#include <stdio.h>

#include <vm_file.h>

#include "vm.h"

void vm_debug(VM *vm) {
    printf("VM File Dump\n");
    printf("File Version: %d.%d\n", vm->major_version, vm->minor_version);
    printf("\n");
    printf("ConstPool <%d> {\n", vm->const_pool_length);
    for (uint32_t i = 0; i<vm->const_pool_length; i++) {
        ConstPoolItem *item = (ConstPoolItem *)vm->const_pool[i];
        
        switch (item->item_type) {
            case 0xA0: {
                printf("\tSTR<%d> = %s\n", item->data_length, (char *)item->data);
            } break;
            
            default: {}
        }
    }
    printf("}\n\n");
    
    printf("Functions: %d\n\n", vm->func_count);
    
    for (uint32_t i = 0; i<vm->func_count; i++) {
        Function *func = (Function *)vm->functions[i];
        char *name = (char *)vm->const_pool[i]->data;
        
        printf("func %s [%d] {\n", name, func->code_length);
        for (uint16_t j = 0; j<func->code_length; j++) {
            printf("%x ", func->code[j]);
        }
        printf("\n}\n\n");
    }
}

