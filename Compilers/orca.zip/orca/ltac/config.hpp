#pragma once

// TODO: This should be automatically generated
// It is current specific to x86-64

#define BYTE_SIZE 1
#define CHAR_SIZE 1
#define OCTAL_SIZE 1
#define INT_SIZE 4
#define FLOAT_SIZE 4
#define PTR_SIZE 8
