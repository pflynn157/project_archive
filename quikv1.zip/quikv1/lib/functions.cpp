#include "functions.hh"
#include "types.hh"
#include "strutils.hh"
#include "error.hh"

std::vector<Func> load_funcs(std::vector<String> contents) {
	std::vector<Func> functions;

	bool in_func = false;
	int layer = 1;
	
	Func main, current;
	main.name = "MAIN";
	
	for (String str : contents) {
		std::string sv = str.str;
		std::string first = get_first(sv, ' ');
		
		if (first == "if" || first == "while" || first == "for"
			|| first == "loop") {
			layer++;
		} else if (first == "func") {
			in_func = true;
			auto sig = get_second(sv, ' ');
			current.name = func_name(sig);
			
			//Break up the arguments
			std::string args = func_args(sig);
			std::vector<std::string> parts;
			std::string cr = "";
			
			for (char c : args) {
				if (c == ',') {
					parts.push_back(cr);
					cr = "";
				} else {
					cr += c;
				}
			}
			
			if (cr != "") {
				parts.push_back(cr);
			}
			
			for (std::string s : parts) {
				std::string name = get_first(s, ':');
				std::string type = get_second(s, ':');
				
				Var v;
				v.name = name;
				
				if (type == "int") {
					v.type = DataType::INT;
				} else if (type == "dec") {
					v.type = DataType::DEC;
				} else if (type == "bool") {
					v.type = DataType::BOOL;
				} else if (type == "char") {
					v.type = DataType::CHAR;
				} else if (type == "str") {
					v.type = DataType::STR;
				} else {
					syntax_err(str, "You must specify a valid datatype for function arguments.");
				}
				
				current.args.push_back(v);
			}
			
			continue;
		} else if (first == "end" && in_func) {
			if (layer == 1) {
				in_func = false;
				functions.push_back(current);
				
				current.name = "";
				current.contents.clear();
				current.args.clear();
				
				continue;
			} else {
				layer--;
			}
		}
		
		if (in_func) {
			current.contents.push_back(str);
		} else {
			main.contents.push_back(str);
		}
	}
	
	functions.push_back(main);
	return functions;
}

//Gets the name of a function from a signiture
std::string func_name(std::string sig) {
	std::string ret = "";
	
	for (char c : sig) {
		if (c == '[') {
			break;
		} else {
			ret += c;
		}
	}
	
	return ret;
}

//Returns the arguments portion of the signiture
std::string func_args(std::string sig) {
	std::string ret = "";
	bool found = false;
	
	for (char c : sig) {
		if (c == '[') {
			found = true;
		} else if (c == ']') {
			break;
		} else {
			if (found) {
				ret += c;
			}
		}
	}
	
	ret = clr_spaces(ret);
	return ret;
}
