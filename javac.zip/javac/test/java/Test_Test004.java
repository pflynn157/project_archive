public class Test_Test004 {
    public static void main(String[] args) {
        int x = 20;
        int y = 4;
        int answer = 0;
        
        answer = x * y + 2 - 2 + x;
        System.out.println(answer);
    }
}
