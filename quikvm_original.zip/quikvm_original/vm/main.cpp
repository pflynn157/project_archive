#include <iostream>

#include "vm.hh"

int main(int argc, char *argv[]) {
	if (argc == 1) {
		std::cout << "Error: No input file!" << std::endl;
	}
	
	VM vm;
	vm.load(argv[1]);
	vm.run();
	return 0;
}
