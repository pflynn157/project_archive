#pragma once

#include <string>
#include <vector>
#include <cstdint>
#include <iostream>

//
// Represent the valid AST types
//
enum class AstType {
    None,
    
    // Statements
    Return,
    VarDec,
    VarAssign,
    FuncCall,
    Syscall,
    ArrayDec,
    ArrayAssign,
    While,
    For,
    Break,
    Continue,
    If,
    Elif,
    Else,
    
    // Operators
    Assign,
    Add,
    Sub,
    Mul,
    Div,
    Mod,
    And,
    Or,
    Xor,
    Eq,
    Ne,
    Gt,
    Lt,
    Le,
    Ge,
    
    // Expressions
    ExprList,
    Id,
    ArrayAccess,
    IntL,
    StringL,
    CharL,
};

//
// Represents a data type
//
enum class DataType {
    Void,
    U8, I8,
    U16, I16,
    U32, I32,
    U64, I64,
    U128, I128,
    W1,
    W2,
    W4,
    W8,
    Long
};

//
// Represents an AST expression
//
class AstExpression {
public:
    explicit AstExpression(AstType type) {
        this->type = type;
    }
    
    virtual ~AstExpression() {}
    
    AstType getType() {
        return type;
    }
    
    bool isBinaryOp();
    
    virtual void print() {}
protected:
    AstType type = AstType::None;
};

// Represents a list of expressions
class AstExprList : public AstExpression {
public:
    explicit AstExprList() : AstExpression(AstType::ExprList) {}
    
    ~AstExprList() {
        for (auto item : list) {
            if (item) delete item;
        }
    }
    
    void addItem(AstExpression *item) {
        list.push_back(item);
    }
    
    void print();
private:
    std::vector<AstExpression *> list;
};

// Represents a binary operator
class AstBinaryOp : public AstExpression {
public:
    explicit AstBinaryOp(AstType type);
    
    ~AstBinaryOp() {
        if (lval) delete lval;
        if (rval) delete rval;
    }
    
    void setLVal(AstExpression *expr) { this->lval = expr; }
    void setRVal(AstExpression *expr) { this->rval = expr; }
    
    AstExpression *getLVal() { return lval; }
    AstExpression *getRVal() { return rval; }
    int getPrecedence() { return precedence; }
    
    void print();
private:
    AstExpression *lval = nullptr;
    AstExpression *rval = nullptr;
    int precedence;
};

// Represents an identifier expression
class AstId : public AstExpression {
public:
    explicit AstId(std::string value) : AstExpression(AstType::Id) {
        this->value = value;
    }
    
    std::string getValue() { return value; }
    
    void print() {
        std::cout << value;
    }
private:
    std::string value = "";
};

// Represents an array access expression
class AstArrayAccess : public AstExpression {
public:
    explicit AstArrayAccess(std::string name, AstExpression *index) : AstExpression(AstType::ArrayAccess) {
        this->name = name;
        this->index = index;
    }
    
    ~AstArrayAccess() {
        if (index) delete index;
    }
    
    void print() {
        std::cout << name << "[";
        index->print();
        std::cout << "]";
    }
private:
    std::string name;
    AstExpression *index;
};

// Represents an integer literal expression
class AstInt : public AstExpression {
public:
    explicit AstInt(uint64_t value) : AstExpression(AstType::IntL) {
        this->value = value;
    }
    
    uint64_t getValue() { return value; }
    
    void print() {
        std::cout << value;
    }
private:
    uint64_t value = 0;
};

// Represents a string expression
class AstString : public AstExpression {
public:
    explicit AstString(std::string value) : AstExpression(AstType::StringL) {
        this->value = value;
    }
    
    void print() {
        std::cout << "\"" << value << "\"";
    }
private:
    std::string value = "";
};

// Represents a character expression
class AstChar : public AstExpression {
public:
    explicit AstChar(char value) : AstExpression(AstType::CharL) {
        this->value = value;
    }
    
    void print() {
        std::cout << "\'" << value << "\'";
    }
private:
    char value = 0;
};

//
// Represents an AST statement
//
class AstBlock;

class AstStatement {
public:
    explicit AstStatement(AstType type) {
        this->type = type;
    }
    
    explicit AstStatement(AstType type, DataType dataType) {
        this->type = type;
        this->dataType = dataType;
    }
    
    virtual ~AstStatement() {
        if (expr) delete expr;
    }
    
    AstType getType() { return type; }
    DataType getDataType() { return dataType; }
    
    void setExpression(AstExpression *expr) {
        this->expr = expr;
    }
    
    bool hasExpression() { return expr != nullptr; }
    AstExpression *getExpression() { return expr; }
    
    virtual void print();
protected:
    AstType type = AstType::None;
    DataType dataType = DataType::Void;
    AstExpression *expr = nullptr;
};

// Represents a block statement
class AstBlockStmt : public AstStatement {
public:
    explicit AstBlockStmt(AstType type) : AstStatement(type) {}
    ~AstBlockStmt();
    
    void setBlock(AstBlock *block) {
        this->block = block;
    }
    
    virtual void print();
protected:
    AstBlock *block;
};

// Represents a for-loop statement
class AstForStmt : public AstBlockStmt {
public:
    explicit AstForStmt() : AstBlockStmt(AstType::For) {}
    ~AstForStmt();
    
    void setInitExpr(AstExpression *expr) {
        this->init = expr;
    }
    
    void setCmpExpr(AstExpression *expr) {
        this->cmp = expr;
    }
    
    void setIncExpr(AstExpression *expr) {
        this->inc = expr;
    }
    
    void print();
private:
    AstExpression *init, *cmp, *inc;
};

// Represents a conditional statement
class AstCondStmt : public AstBlockStmt {
public:
    explicit AstCondStmt(AstType type) : AstBlockStmt(type) {}
    ~AstCondStmt();
    
    void addBranch(AstCondStmt *stmt) {
        branches.push_back(stmt);
    }
    
    void print();
private:
    std::vector<AstCondStmt *> branches;
};

// Represents an AST function statement
class AstFuncCallStmt : public AstStatement {
public:
    explicit AstFuncCallStmt(std::string name) : AstStatement(AstType::FuncCall) {
        this->name = name;
    }
    
    void print() {
        std::cout << "FC " << name;
        expr->print();
        std::cout << ";";
    }
private:
    std::string name = "";
};

// Represents an AST array declaration
class AstArrayDec : public AstStatement {
public:
    explicit AstArrayDec(std::string name, bool stackArray, DataType dataType) : AstStatement(AstType::ArrayDec) {
        this->name = name;
        this->stackArray = stackArray;
        this->dataType = dataType;
    }
    
    bool isStackArray() { return stackArray; }
    
    void print();
private:
    bool stackArray = false;
    DataType dataType = DataType::Void;
    std::string name = "";
};

//
// Represents an AST block
//
class AstBlock {
public:
    ~AstBlock();
    
    void addStatement(AstStatement *stmt) {
        block.push_back(stmt);
    }
    
    size_t getStatementCount() { return block.size(); }
    AstStatement *getStatement(size_t pos) {
        return block.at(pos);
    }
    
    void print(int indent = 4);
private:
    std::vector<AstStatement *> block;
};

//
// Represents an AST function
//
class AstFunction {
public:
    explicit AstFunction(std::string name, DataType dataType) {
        this->name = name;
        this->block = new AstBlock;
        this->dataType = dataType;
    }
    
    ~AstFunction() {
        if (block) delete block;
    }
    
    void addStatement(AstStatement *stmt) {
        block->addStatement(stmt);
    }
    
    std::string getName() { return name; }
    DataType getType() { return dataType; }
    
    AstBlock *getBlock() {
        return block;
    }
    
    void print();
private:
    std::string name = "";
    DataType dataType = DataType::Void;
    AstBlock *block;
};

//
// Represents an AST file
//
class AstFile {
public:
    explicit AstFile(std::string name) {
        this->name = name;
    }
    
    ~AstFile() {
        for (auto func : functions) {
            if (func) delete func;
        }
    }
    
    std::string getName() {
        return name;
    }
    
    void addFunction(AstFunction *func) {
        functions.push_back(func);
    }
    
    size_t getFunctionCount() { return functions.size(); }
    AstFunction *getFunction(size_t pos) {
        return functions.at(pos);
    }
    
    void print();
private:
    std::string name;
    std::vector<AstFunction *> functions;
};

