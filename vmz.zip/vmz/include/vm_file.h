#pragma once

#include <stdint.h>
#include <stdio.h>

typedef struct {
    uint16_t name_index;
    uint16_t code_length;
    uint8_t *code;
} Function;

typedef struct {
    uint8_t item_type;
    uint8_t data_length;
    void *data;
} ConstPoolItem;

typedef struct {
    int error_state;
    int major_version;
    int minor_version;
    
    uint32_t const_pool_length;
    ConstPoolItem **const_pool;
    
    uint32_t func_count;
    Function **functions;
} VM;


