#include <amd64/amd64.hpp>

#include <ltac/math.hpp>

// Integer math on two registers
void Amd64::buildI32Math(LtacInstr *instr, std::string op) {
    auto add = static_cast<LtacI32Math *>(instr);
    
    auto reg1 = op_regs32[add->getPos1()];
    auto reg2 = op_regs32[add->getPos2()];
    
    writer << "  " << op << " " << reg1 << ", " << reg2 << std::endl;
}