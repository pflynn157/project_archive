#include <iostream>

#include <unit.hpp>

void Unit::dump() {
    std::cout << "; module: " << name << std::endl;
    std::cout << std::endl;
    
    for (Function *func : functions) {
        func->dump();
    }
}
