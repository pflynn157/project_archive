#pragma once

#include <ast.hpp>
#include <ltac/struct.hpp>

AstTree *getAstTree(std::string input, std::string unitName);
LtacFile *getLtacFile(AstTree *input, std::string unitName);
void compile(LtacFile *input);
void assemble(std::string path, std::string output);
void link(std::string path, std::string output, std::vector<std::string> libs, bool useStdlib);
