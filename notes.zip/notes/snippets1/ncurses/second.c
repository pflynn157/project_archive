#include <ncurses.h>

int main()
{
	int ch;
	
	initscr();
	raw();
	keypad(stdscr, TRUE);
	noecho();
	
	for (int i = 0; i<3; i++) {
		printw("Type any character to see it bold.\n");
		ch = getch();
		
		if (ch == KEY_F(1)) {
			printw("F1 key pressed.\n");
		} else {
			printw("Key pressed: ");
			attron(A_BOLD);
			printw("%c", ch);
			attroff(A_BOLD);
		}
		printw("\n\n");	
	}
	
	refresh();
	getch();
	endwin();
	
	return 0;
}
