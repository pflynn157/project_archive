class prob10 {

	static boolean isPrime(double no) {
		if (no==1) {
			return false;
		} else if (no==2 || no==3 || no==5 || no==7) {
			return true;
		} else if (no%2==0 || no%3==0 || no%5 == 0 || no%7==0) {
			return false;
		} else {
			double sqr = Math.sqrt(no);
			for (double i = 5; i<=sqr; i+=6) {
				if (no%i==0 || no%(i+2)==0) {
					return false;
				}
			}
			return true;
		}
	}

	public static void main(String[] args) {
		long answer = 2;
		
		for (long i = 1; i<2000000; i+=2) {
			if (isPrime(i)) {
				answer+=i;
			}
		}
		
		System.out.println("Answer: "+answer);
	}
}
