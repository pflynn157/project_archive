#include "rex_kmp.h" 
//axpy.c
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/timeb.h>
#include <malloc.h>
#include <immintrin.h> 
#define N_RUNS 1000
#define N 120000
// read timer in second

double read_timer()
{
  struct timeb tm;
  ftime(&tm);
  return ((double )tm . time) + ((double )tm . millitm) / 1000.0;
}
//Create a matrix and a vector and fill with random numbers

void init(float *X,float *Y)
{
  for (int i = 0; i < 120000; i++) {
    X[i] = ((float )(rand())) / ((float )(2147483647 / 10.0));
    Y[i] = ((float )(rand())) / ((float )(2147483647 / 10.0));
  }
}
// Debug functions

void axpy(float *X,float *Y,float a)
{
  int i;
  __m512 __vec1 = _mm512_set1_ps(a);
  for (i = 0; i <= 119999; i += 16) {
    __m512 __vec0 = _mm512_loadu_ps(&Y[i]);
    __m512 __vec2 = _mm512_loadu_ps(&X[i]);
    __m512 __vec3 = _mm512_mul_ps(__vec2,__vec1);
    __m512 __vec4 = _mm512_add_ps(__vec3,__vec0);
    _mm512_storeu_ps(&Y[i],__vec4);
  }
}

int main(int argc,char **argv)
{
  int status = 0;
//Set everything up
  float *X = (malloc(sizeof(float ) * 120000));
  float *Y = (malloc(sizeof(float ) * 120000));
  float a = 3.14;
  srand((time(((void *)0))));
  init(X,Y);
  double start = read_timer();
  for (int i = 0; i < 1000; i++) 
    axpy(X,Y,a);
  double t = read_timer() - start;
  double gflops_serial = 2.0 * 120000 * 120000 * 1000 / (1.0e9 * t);
  printf("==================================================================\n");
  printf("Performance:\t\tRuntime (s)\t GFLOPS\n");
  printf("------------------------------------------------------------------\n");
  printf("AXPY (OpenMP):\t\t%4f\t%4f\n",t,gflops_serial);
  free(X);
  free(Y);
  return 0;
}
