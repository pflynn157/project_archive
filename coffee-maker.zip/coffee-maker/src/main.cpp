#include <iostream>
#include <cstdio>
#include <arpa/inet.h>
#include <vector>

#include <JavaIR.hpp>
#include <JavaBuilder.hpp>

int main(int argc, char *argv[]) {
    JavaClassBuilder builder("HelloWorld");

    builder.ImportField("java/lang/System", "java/io/PrintStream", "out");
    builder.ImportMethod("java/io/PrintStream", "println", "(Ljava/lang/String;)V");

    // Create the constructor
    JavaFunction *construct = builder.CreateMethod("<init>", "()V");

    builder.CreateALoad(construct, 0);
    builder.CreateInvokeSpecial(construct, "<init>", "java/lang/Object");
    builder.CreateRetVoid(construct);

    // Our sayHello function
    JavaFunction *sayHelloFunc = builder.CreateMethod("sayHello", "()V", F_PUBLIC);

    builder.CreateGetStatic(sayHelloFunc, "out");
    builder.CreateString(sayHelloFunc, "Hello from sub-function!");
    builder.CreateInvokeVirtual(sayHelloFunc, "println");
    builder.CreateRetVoid(sayHelloFunc);

    // The main function
    JavaFunction *mainFunc = builder.CreateMethod("main", "([Ljava/lang/String;)V", F_PUBLIC | F_STATIC);

    builder.CreateGetStatic(mainFunc, "out");
    builder.CreateString(mainFunc, "Hello World!");
    builder.CreateInvokeVirtual(mainFunc, "println");

    // new HelloWorld();
    builder.CreateNew(mainFunc, "HelloWorld");
    builder.CreateDup(mainFunc);
    builder.CreateInvokeSpecial(mainFunc, "<init>", "HelloWorld");
    builder.CreateAStore(mainFunc, 1);

    // HelloWorld().sayHello()
    builder.CreateALoad(mainFunc, 1);
    builder.CreateInvokeVirtual(mainFunc, "sayHello");

    builder.CreateRetVoid(mainFunc);

    FILE *file = fopen("HelloWorld.class", "wb");
    builder.Write(file);
    fclose(file);
    return 0;
}
