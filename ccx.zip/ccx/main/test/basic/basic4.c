
int main() {
    int n = 10;
    int x1 = n + 7;
    int x2 = n - 7;
    int x3 = n * 7;
    int x4 = n / 7;
    return x1 + x2 + x3 + x4;
}

