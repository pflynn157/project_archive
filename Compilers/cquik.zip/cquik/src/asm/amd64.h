#pragma once

#include <ltac/ltac.h>

void amd64_generate(LtacFile *file);
void amd64_build(LtacFile *file);
void amd64_link(LtacFile *file);
