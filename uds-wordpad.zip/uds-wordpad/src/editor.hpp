//
// Copyright 2021 Patrick Flynn
// This file is part of uds-wordpad.
// uds-wordpad is licensed under the BSD-3 license. See the COPYING file for more information.
//
#pragma once

#include <QTextEdit>

class Editor : public QTextEdit {
    Q_OBJECT
public:
    Editor();
    void setUntitled(bool untitled = true);
    void setFile(QString fullPath, QString name);
    void openFile();
    void saveFile();
    void printPage();
    void exportPDF();
    void toggleBold();
    void toggleItalic();
    void toggleUnderline();
    
    // Our getters
    QString getFullPath() { return fullPath; }
    bool isUntitled() { return untitled; }
    bool isSaved() { return saved; }
    bool isBoldOn() { return bold; }
    bool isItalicOn() { return italic; }
    bool isUnderlineOn() { return underline; }
private:
    void onTextChanged();
    void onCursorChanged();
    
    bool untitled = true;
    bool saved = true;
    QString fullPath = "untitled"; 
    QString name = "untitled";
    bool bold = false;
    bool italic = false;
    bool underline = false;
};

