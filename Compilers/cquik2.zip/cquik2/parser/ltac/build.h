#pragma once

#include <ast.h>
#include <ltac/ltac.h>

void ltac_build(LtacFile *file, AstNode *tree);
