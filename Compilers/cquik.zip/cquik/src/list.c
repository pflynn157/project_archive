#include <stdlib.h>
#include <stdio.h>

#include <list.h>

void stack_push(AstLinkedList *stack, AstNode *node)
{
    struct AstListNode *new_node = malloc(sizeof(struct AstListNode));
    new_node->element = node;
    
    if (stack->head == NULL) 
    {
        stack->head = new_node;
    } 
    else 
    {    
        struct AstListNode *old_head = stack->head;
        new_node->next = old_head;
        stack->head = new_node;
    }
}

AstNode *stack_top(AstLinkedList *stack)
{
    struct AstListNode *current = stack->head;
    if (current == NULL) return NULL;
    return current->element;
}

void stack_pop(AstLinkedList *stack)
{
    if (stack->head == NULL) return;
    
    struct AstListNode *head = stack->head;
    struct AstListNode *next = head->next;
    
    if (next != NULL) stack->head = next;
    free(head);
}

void list_add_end(AstLinkedList *list, AstNode *node)
{
    struct AstListNode *new_node = malloc(sizeof(struct AstListNode));
    new_node->element = node;
    
    if (list->head == NULL) 
    {
        list->head = new_node;
    } 
    else 
    {
        struct AstListNode *current = list->head;
        while (current->next != NULL) current = current->next;
        current->next = new_node;
    }   
}

// Copy from list2 to list1
void list_copy(AstLinkedList *list1, AstLinkedList *list2)
{
    struct AstListNode *current = list2->head;
    while (current != NULL) 
    {
        list_add_end(list1, current->element);
        current = current->next;
    }
}

