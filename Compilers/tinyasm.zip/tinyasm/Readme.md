## tinyasm

### Intro
This is a very simple assembler for the x86-64 architecture. It is capable of generating simple ELF binary files. To see what it can currently do, please see the "test.asm" file in the root directory.

As I said above, this assembler is very simple, almost to the point of being useless. I already knew how to generate binary code and I knew how CPU instructions worked; the primary goal of this was originally to generate a working ELF file. However, because things seem to be working, I plan on continuing this project.

I originally started this project using C++; however, I began playing with Haskell a little more, and decided that it would be a better fit for this project, moreso from the parsing standpoint. I removed the C++ code, but if you really want to see it, you're welcome to go back in time on the git history. I find Haskell to be very well suited for this kind of work, and I've had very little issues with it.

### How did I do it?
The hardest part was generating the ELF binary; these resources were helpful:   
https://medium.com/@MrJamesFisher/understanding-the-elf-4bd60daac571   
https://en.wikipedia.org/wiki/Executable_and_Linkable_Format   
https://linux-audit.com/elf-binaries-on-linux-understanding-and-analysis/   

For the opcodes, I used the Intel software developers manual. In the Appendix, there is a very helpful table that gives the opcode map of the instructions. Further one, there is more useful data on how everything is encoded.   

Finally, various tools such as hexdump and readelf were very helpful.
