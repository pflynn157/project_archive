#include <stdio.h>

int main() {
    long long int result = 17;
    
    for (int i = 10; i<2000000; i++) {
    //for (int i = 10; i<20; i++) {
        int found = 0;
        for (long int j = i / 2; j > 1; j--) {
            if (i % j == 0) {
                found = 1;
                break;
            }
        }
        
        if (!found) {
            result += i;
        }
    }
    
    printf("%lld\n", result);

    return 0;
}
