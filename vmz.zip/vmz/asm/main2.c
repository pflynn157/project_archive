#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>

#include <opcodes.h>
#include <vm_file.h>

void writeSignature(FILE *file) {
    uint16_t signature = 0xA1A2;
    fwrite(&signature, sizeof(uint16_t), 1, file);
    
    // Versions: 1.0
    fputc(1, file);
    fputc(0, file);
}

void writeConstPool(VM *vm, FILE *file) {
    fwrite(&vm->const_pool_length, sizeof(uint32_t), 1, file);
    
    for (int i = 0; i<vm->const_pool_length; i++) {
        ConstPoolItem *item = vm->const_pool[i];
        fwrite(&item->item_type, sizeof(uint8_t), 1, file);
        fwrite(&item->data_length, sizeof(uint8_t), 1, file);
        
        switch (item->item_type) {
            case 0xA0: {
                char *str = (char *)item->data;
                fwrite(str, sizeof(char), strlen(str), file);
                fputc(0, file);
            } break;
            
            default: {}
        }
    }
}

void writeFunctionPool(VM *vm, FILE *file) {
    fwrite(&vm->func_count, sizeof(uint32_t), 1, file);
    
    for (int i = 0; i<vm->func_count; i++) {
        Function *func = vm->functions[i];
        fwrite(&func->name_index, sizeof(uint16_t), 1, file);
        fwrite(&func->code_length, sizeof(uint16_t), 1, file);
        
        for (int j = 0; j<func->code_length; j++)
            fputc(func->code[j], file);
    }
}

void checkCodeSize(Function *func, int length) {
    int index = func->code_length;
    if (index == 0) {
        func->code = malloc(sizeof(uint8_t) * length);
        func->code_length = length;
    } else {
        index += length;
        func->code = realloc(func->code, index);
        func->code_length = index;
    }
}

void createInstr0(Function *func, Opcode opcode) {
    int index = func->code_length;
    checkCodeSize(func, 1);
    func->code[index] = opcode;
}

void createInstrI32(Function *func, Opcode opcode, int arg) {
    uint8_t op1 = arg << 24;
    uint8_t op2 = arg << 16;
    uint8_t op3 = arg << 8;
    uint8_t op4 = arg;
    
    int index = func->code_length;
    checkCodeSize(func, 5);
    
    func->code[index] = opcode;
    func->code[index+1] = op1;
    func->code[index+2] = op2;
    func->code[index+3] = op3;
    func->code[index+4] = op4;
}

int main2(int argc, char *argv[]) {
    FILE *file = fopen("first.bin", "wb");
    
    writeSignature(file);
    
    // Create our VM structure
    VM *vm = malloc(sizeof(VM));
    
    // Create constant pool
    int const_pool_size = 1;
    vm->const_pool_length = const_pool_size;
    vm->const_pool = malloc(sizeof(ConstPoolItem *) * const_pool_size);
    
    ConstPoolItem *str_item = malloc(sizeof(ConstPoolItem));
    str_item->item_type = 0xA0;
    char *name = "main";
    str_item->data_length = strlen(name) + 1;
    str_item->data = name;
    vm->const_pool[0] = str_item;
    
    // Write constant pool
    writeConstPool(vm, file);
    
    // Write library
    // TODO: Add this
    uint8_t lib_count = 0;
    fwrite(&lib_count, sizeof(uint8_t), 1, file);
    
    // Create the function
    Function *mainFunc = malloc(sizeof(Function));
    mainFunc->name_index = 0;
    mainFunc->code_length = 0;
    
    // -> Code
    /*
        pushc 2
        pushc 10
        iadd
        iprint
        retvoid
        exit
    */
    createInstrI32(mainFunc, PUSHC, 2);
    createInstrI32(mainFunc, PUSHC, 10);
    createInstr0(mainFunc, IADD);
    createInstr0(mainFunc, IPRINT);
    createInstr0(mainFunc, RETVOID);
    createInstr0(mainFunc, EXIT);
    
    // Create the function pool
    vm->functions = malloc(sizeof(Function *) * 1);
    vm->func_count = 1;
    vm->functions[0] = mainFunc;
    writeFunctionPool(vm, file);
    
    fputc(0xFF, file);
    
    fclose(file);
    return 0;
}

