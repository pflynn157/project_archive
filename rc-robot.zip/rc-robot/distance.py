import RPi.GPIO as GPIO
import time

def get_distance():
	try:
		GPIO.setmode(GPIO.BOARD)

		triggerPin = 40
		echoPin = 38

		GPIO.setup(triggerPin, GPIO.OUT)
		GPIO.setup(echoPin, GPIO.IN)

		GPIO.output(triggerPin, GPIO.LOW)
		GPIO.output(triggerPin, GPIO.HIGH)

		time.sleep(0.00001)
		GPIO.output(triggerPin, GPIO.LOW)

		while GPIO.input(echoPin) == 0:
		    startTime = time.time()
		while GPIO.input(echoPin) == 1:
		    endTime = time.time()

		pulseDir = endTime - startTime
		dist = round(pulseDir * 17150, 2)

		GPIO.cleanup()
		return dist
	finally:
		GPIO.cleanup()
