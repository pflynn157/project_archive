#pragma once

#include <ava/ast.hpp>

enum class AstType {
    Program,
    One
};

class AstExtExpr : public AstExpression {
public:
    explicit AstExtExpr(AstType type) : AstExpression(V_AstType::ExtExpr) {
        this->type = type;
    }
    
    AstType getType() { return type; }
private:
    AstType type;
};

class AstProgram : public AstGlobalStatement {
public:
    explicit AstProgram(std::string name) : AstGlobalStatement(V_AstType::ExtGlobal) {
        this->name = name;
    }
    
    void print() override;
private:
    std::string name = "";
};

class AstOne : public AstExtExpr {
public:
    explicit AstOne() : AstExtExpr(AstType::One) {}
    void print() override;
};

