#pragma once

#include <map>
#include <string>

#include <ltac/ltac.hpp>
#include <ltac/struct.hpp>
#include <ast.hpp>

struct Var {
    int pos;
    DataType type;
    int ptrLevel;
};

class LtacBuilder {
public:
    explicit LtacBuilder(LtacFile *file);
    void buildLtac(AstNode *top);
protected:
    void buildFunc(AstNode *child);
    void buildFuncCall(AstFuncCall *astFc, bool syscall);
    void buildRet(AstNode *ret);
    
    int buildVarDec(std::string name, DataType dataType, int flags, int ptrLevel);
    void buildVarDec(AstVar *var);
    void buildVarAssign(AstVar *var);
    void buildIVarMath(AstNode *var);
    
    std::string buildString(std::string val);
private:
    LtacFile *file;
    int strIndex = 0;
    int stackPos = 0;
    
    std::map<std::string, Var> vars;
};

void ltacPrint(LtacFile *file);
