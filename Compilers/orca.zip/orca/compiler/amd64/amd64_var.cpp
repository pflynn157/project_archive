#include <amd64/amd64.hpp>

#include <ltac/var.hpp>

// Builds the in32 -> mem instruction
void Amd64::buildMovI32(LtacInstr *instr) {
    auto mov = static_cast<LtacMovI32 *>(instr);
    
    writer << "  mov dword [rbp-" << mov->getPos() << "], " << mov->getVal();
    writer << std::endl;
}

// Moves one 32-bit var to another
void Amd64::buildMovV32(LtacInstr *instr) {
    auto mov = static_cast<LtacMovV32 *>(instr);
    
    writer << "  mov eax, [rbp-" << mov->getSrc() << "]" << std::endl;
    writer << "  mov [rbp-" << mov->getDest() << "], eax" << std::endl;
    writer << std::endl;
}