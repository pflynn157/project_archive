## Assembly Standard Library

This is a simple example of how a standard library for a language on Linux could work. It is written in Assembly and only uses Linux system calls. I am tossing around creating a programming language with zero dependence on the C library or calling conventions; if I do so, this is how it would look.

Currently, the following functions are working:   
* malloc   
* free   
* strlen   
* puts   
* print_int   
* print_number   
* exit   

As far as the programs go, there are examples for mkdir, command line arguments, and malloc/free.