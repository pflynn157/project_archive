#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <str_list.h>

//Create a new list
StrList *str_list_create(int size)
{
    StrList *list = malloc(sizeof(StrList));
    list->items = malloc(sizeof(char *)*size);
    list->size = 0;
    list->max_size = size;
    return list;
}

StrList *str_list_create_empty()
{
    return str_list_create(10);
}

//Add to the list
void str_list_add_item(StrList *list, char *item)
{
    int max_size = list->max_size;
    int size = list->size;
    
    if (size >= max_size)
    {
        int new_size = max_size + (max_size / 2);
        list->items = realloc(list->items, sizeof(char *)*new_size);
        list->max_size = new_size;
    }

    list->items[size] = item;
    list->size = size + 1;
}

void str_list_add(StrList *list, const char *item)
{
    str_list_add_item(list, strdup(item));
}

void str_list_add_null(StrList *list)
{
    str_list_add_item(list, NULL);
}

// Display the list
void str_list_display(StrList *list)
{
    if (list->size == 0)
    {
        puts("[]");
        return;
    }

    for (int i = 0; i<list->size; i++)
    {
        printf("Item at %d: %s\n", i, list->items[i]);
    }
}
