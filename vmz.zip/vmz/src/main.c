#include <stdio.h>
#include <stdlib.h>

#include <vm_file.h>

#include "vm.h"

int main(int argc, char *argv[]) {
    if (argc == 1) {
        printf("Error: No input specified.\n");
        return 1;
    }
    
    const char *input = argv[1];
    VM *vm = malloc(sizeof(VM));
    vm_load(vm, input);
    
    vm_debug(vm);
    puts("========================");
    
    vm_run(vm);
    
    //vm_close(vm);
    //free(vm);
    
    return 0;
}

