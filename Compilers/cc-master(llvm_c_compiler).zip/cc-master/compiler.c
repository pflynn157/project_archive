#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

#include <llvm-c/Core.h>
#include <llvm-c/Target.h>
#include <llvm-c/TargetMachine.h>
#include <llvm-c/Support.h>

#include "compiler.h"
#include "ast.h"
#include "backend.h"

void run_backend(AstTree *tree, int print)
{
    char const *args[] = { "", "--x86-asm-syntax=intel" };
    LLVMParseCommandLineOptions(2, args, NULL);
    
    LLVMContextRef context = LLVMContextCreate();
    LLVMModuleRef module = LLVMModuleCreateWithNameInContext("mod1", context);
    LLVMBuilderRef builder = LLVMCreateBuilderInContext(context);
    
    // Build the backend
    build_backend(tree, context, module, builder);
    
    // Dump the module if the user so wishes
    if (print)
        LLVMDumpModule(module);
    
    // Compile
    LLVMInitializeAllTargetInfos();
    LLVMInitializeAllTargets();
    LLVMInitializeAllTargetMCs();
    LLVMInitializeAllAsmParsers();
    LLVMInitializeAllAsmPrinters();
    
    char *target_triple = LLVMGetDefaultTargetTriple();
    
    LLVMTargetRef target;
    char *msg;
    LLVMGetTargetFromTriple(target_triple, &target, &msg);
    
    char *cpu_name = LLVMGetHostCPUName();
    char *cpu_features = LLVMGetHostCPUFeatures();
    
    LLVMTargetMachineRef machine = LLVMCreateTargetMachine(target, target_triple, cpu_name, cpu_features,
                                    LLVMCodeGenLevelNone, LLVMRelocDefault, LLVMCodeModelDefault);
                                    
    LLVMTargetMachineEmitToFile(machine, module, "./first.s", LLVMAssemblyFile, &msg);
                                    
    LLVMDisposeTargetMachine(machine);
    
    // Cleanup and return
    free(target_triple);
    free(cpu_name);
    free(cpu_features);
    
    LLVMDisposeBuilder(builder);
    LLVMDisposeModule(module);
    LLVMContextDispose(context);
}

void assemble()
{
    pid_t pid = fork();
    
    if (pid < 0)
    {
        printf("Fatal: Fork failed on asm step.\n");
        exit(1);
    }
    else if (pid == 0)
    {
        execlp("as", "as", "first.s", "-o", "first.o", (char *)NULL);
        
        printf("Fatal: Unable to call the assembler.\n");
        exit(1);
    }
    else
    {
        int wstatus;
        waitpid(-1, &wstatus, 0);
    }
}

void run_link()
{        
    pid_t pid = fork();
    
    if (pid < 0)
    {
        printf("Fatal: Fork failed on ld step.\n");
        exit(1);
    }
    else if (pid == 0)
    {
        execlp("ld", "ld", "first.o", "-o", "first",
            "/usr/lib64/crti.o",
            "/usr/lib64/crtn.o",
            "/usr/lib64/crt1.o",
            "-dynamic-linker", "/lib64/ld-linux-x86-64.so.2",
            "-lc", (char *)NULL );
        
        printf("Fatal: Unable to call the linker.\n");
        exit(1);
    }
    else
    {
        int wstatus;
        waitpid(-1, &wstatus, 0);
    }
}

