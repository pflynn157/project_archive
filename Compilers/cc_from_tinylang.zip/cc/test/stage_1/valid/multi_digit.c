int main() {
    return 100;
}