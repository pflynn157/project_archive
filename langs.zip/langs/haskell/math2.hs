module Main(main) where

--Convert
-- m-> yd -> 1 m = 1.09361 yd
-- L -> gal -> 1 L = 0.264172 gal
-- kg -> lbs -> 1 kg = 2.20462 lbs
convert :: (Double, [Char]) -> (Double, [Char])
convert (val, target)
    | target == "m" = (val*1.09361, "yd")
    | target == "L" = (val*0.264172, "gal")
    | target == "kg" = (val*2.20462, "lbs")
    | otherwise = (val, "unknown")
    
--Converts a string to a double
stod :: String -> Double
stod str = read str
    
--Our main function
main = do
    putStrLn "\tConverter"
    putStr "Enter units: "
    units <- getLine
    
    putStr "Enter value: "
    valStr <- getLine
    
    let val = stod valStr
    let result = convert(val, units)
    
    let r = fst (result)
    let u = snd (result)
    putStrLn $ "Result: " ++ (show r) ++ " " ++ u
