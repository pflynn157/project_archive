#pragma once

#include "lex.h"
#include "ast.h"

typedef struct {
    Scanner *scanner;
    
    AstFile *file;
    AstFunction *currentFunc;
} Parser;

AstFile *parse_file(char *name);

