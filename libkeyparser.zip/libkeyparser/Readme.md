# libkeyparser

This is a keyparser library. It is written entirely in C++ and uses the Qt libraries. This library is licensed under the BSD-3 license. See the 'licenses/COPYING.txt' file for more info.

### What is the key syntax?
The key syntax looks like this:   
`key=vale`   
It is actually quite common, as it is easy to use and easy to parse.

###What are some uses for it?
The library, obviously, is used to parse the syntax.   
    
The syntax, however, has many uses. freedesktop.org .desktop files use this syntax. Nemo-script uses the syntax. The Dolphin file browser stores folder-specific settings using this syntax. On Linux, the Qt QSettings class stores program's settings using this syntax. This syntax is probably most ideal for parsing settings files.

### How do I use it?
Let's say you have the following file:   
`show_hidden_files=false`   
`show_files_first=true`   
You saved it as ./test_file.   
    
Below is an example of some of its uses:   
```c++
#include <iostream>
#include <key_parser.hh>

int main() {

//Create a new keyparser object, without preserving whitespace.
KeyParser *parser = new KeyParser("./test_file");

//We want to get the value of "show_hidden_files"
QString showHiddenFiles = parser->value("show_hidden_files");

//We want to reset the value of "show_files_first"
parser->editKey("show_first_first","true");

//We want to check to see if a key exists, and if not, add it.
if (!parser->keyExists("empty_trash_on_exit")) {
    parser->addKey("empty_trash_on_exit","false");
}

//We want to check to see if a key exists, and if so, delete it.
if (parser->keyExists("to_delete")) {
    parser->deleteKey("to_delete");
}

//Now that we are all done, we want to write everything back to file.
parser->write();

return 0;
}
```

### How does it work?
The parser is very simple. It simply reads the indicated file and loads each line into a QStringList. All the functions then search the list. When the write function is called, everything is written back to the file.

### How do I build it?
This library uses the QMake build system. To build, we highly recommend that you create a separate build directory. You can then use the provided installation script. You can do something like this:   
```bash
#Create our build directory
mkdir build
cd build

#Configure and build
qmake ..
make

#Run the test program
export LD_LIBRARY_PATH=./lib
test/testKeyparser

#Install
cd ..
sudo ./install.sh
```
