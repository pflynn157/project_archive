#!/bin/bash
cp asm-intel.lang /usr/share/gtksourceview-2.0/language-specs/
cp asm-intel.lang /usr/share/gtksourceview-3.0/language-specs/
echo "Done"
