#!/bin/bash
make

cd assembler
go build -o ../build/quikasm
cd ..

echo "Done"
