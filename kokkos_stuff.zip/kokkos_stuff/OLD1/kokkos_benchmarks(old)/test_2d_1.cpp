// Very simple test of kokkos that uses a functor.  In a nutshell,
// given the potential for different compilation units, kitsune does
// not support this construct and it should fall back to the standard
// C++ code gen paths. 
#include <cstdio>
#include <cstdlib>
#include <Kokkos_Core.hpp>
#include <time.h>

const unsigned int NUM = 7000;

int main (int argc, char* argv[]) {;

  //Kokkos::initialize (argc, argv);
  
  int *num1 = (int *)malloc(sizeof(int)*NUM*NUM);
  int *num2 = (int *)malloc(sizeof(int)*NUM*NUM);
  int *result1 = (int *)malloc(sizeof(int)*NUM*NUM);
  int *result2 = (int *)malloc(sizeof(int)*NUM*NUM);
  
  for (int i = 0; i<NUM; i++) {
    for (int j = 0; j<NUM; j++) {
        num1[i*NUM+j] = j;
        num2[i*NUM+j] = j*2;
        result1[i*NUM+j] = 0;
        result2[i*NUM+j] = j + (j*2);
    }
  }

  clock_t time;
  time = clock();
  {
    Kokkos::parallel_for("loop1", Kokkos::MDRangePolicy<Kokkos::Rank<2>>({0,0},{NUM,NUM}),
      KOKKOS_LAMBDA(const int i, const int j) {
        result1[i*NUM+j] = num1[i*NUM+j] + num2[i*NUM+j];
    });
  }
  time = clock() - time;
  double time_taken = ((double)time)/CLOCKS_PER_SEC;
  
  printf("Time (s): %f\n", time_taken);
  
  int errors = 0;
  int print_count = 0;
  for (int i = 0; i<NUM; i++) {
    for (int j = 0; j<NUM; j++) {
      if (result1[i*NUM+j] != result2[i*NUM+j]) {
        ++errors;
        if (print_count < 30) {
            printf("R1: %d | R2: %d (i: %d, j: %d)\n", result1[i*NUM+j], result2[i*NUM+j], i, j);
            ++print_count;
        }
      }
    }
  }
  printf("Errors: %d\n", errors);

  //Kokkos::finalize ();
  return 0;
}
