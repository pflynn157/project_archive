function solve6() {
	var answer = 0;
	var sumOfSquares = 0;
	var sumSquared = 0;
	
	for (var i = 1; i<101; i++) {
		sumOfSquares+=(i*i);
		sumSquared+=i;
	}
	
	sumSquared*=sumSquared;
	answer = sumSquared-sumOfSquares;
	
	setOutput(answer);
}
