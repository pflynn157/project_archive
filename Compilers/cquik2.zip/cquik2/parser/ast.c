#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <ast.h>

// Create an AST list
struct AstList *create_list()
{
    struct AstList *list = malloc(sizeof(struct AstList));
    list->elements = malloc(sizeof(AstNode)*10);
    list->loco = 0;
    list->size = 10;
    
    return list;
}

// Add element to AST list
void ast_list_add_element(struct AstList *list, AstNode *node)
{
    int loco = list->loco;

    if (loco >= list->size)
    {
        int size = list->size;
        size = size + (size / 2);
        list->elements = realloc(list->elements, sizeof(AstNode)*size);
        list->size = size;
    }

    list->elements[loco] = node;
    list->loco = loco + 1;
}

// Create an AST node
AstNode *ast_create_node(AstType type)
{
    AstNode *node = malloc(sizeof(AstNode));
    node->type = type;
    node->children = create_list();

    return node;
}

AstNode *ast_create_func(const char *name, DataType type)
{
    AstNode *fd = ast_create_node(FuncDec);
    fd->str_val1 = name;
    fd->int_val1 = type;
    return fd;
}

AstNode *ast_create_func_call(const char *name)
{
    AstNode *fc = ast_create_node(FuncCall);
    fc->str_val1 = name;
    return fc;
}

AstNode *ast_create_var(const char *name, DataType type)
{
    AstNode *vd = ast_create_node(Var);
    vd->str_val1 = name;
    vd->int_val1 = type;
    return vd;
}

AstNode *ast_create_int(int i)
{
    AstNode *ai = ast_create_node(Int);
    ai->int_val1 = i;
    return ai;
}

AstNode *ast_create_string(const char *str)
{
    AstNode *s = ast_create_node(String);
    s->str_val1 = strdup(str);
    return s;
}

// Add a child to parent node
void ast_add_child(AstNode *parent, AstNode *child)
{
    ast_list_add_element(parent->children, child);
}

// Debug functions
void print_datatype(DataType type)
{
    switch (type)
    {
        case T_Void: printf("Void"); break;
        case T_Int: printf("Int"); break;
        case T_Float: printf("Float"); break;
        case T_String: printf("String"); break;
        default: printf("???");
    }
}

void ast_print(AstNode *tree, int indent)
{
    for (int i = 0; i<indent; i++) printf(" ");

    switch (tree->type)
    {
        case Scope: puts("Scope"); break;

        case FuncDec:
        {
            printf("FuncDec %s -> ", tree->str_val1);
            print_datatype(tree->int_val1);
            puts("");
        } break;

        case While: puts("While"); break;
        case IfBlock: puts("If"); break;
        case ElifBlock: puts("Elif"); break;
        case ElseBlock: puts("Else"); break;

        case FuncCall: printf("FuncCall %s\n", tree->str_val1); break;
        case Cond: puts("Cond"); break;
        case Return: puts("Ret"); break;

        case Var:
        {
            printf("Var %s -> ", tree->str_val1);
            print_datatype(tree->int_val1);

            if (tree->int_val2) printf(" (new)");

            puts("");
        } break;

        case Int: printf("%d\n", tree->int_val1); break;
        case String: printf("%s\n", tree->str_val1); break;
    }

    struct AstList *children = tree->children;
    int len = children->loco;

    if (len > 0)
    {
        for (int i = 0; i<len; i++)
            ast_print(children->elements[i], indent+2);
    }
}
