-- A simple haskell calculator program
module Main(main) where

stoi :: String -> Int
stoi str = read str

main = do
    putStrLn "\tWelcome!"
    putStrLn "1) Add"
    putStrLn "2) Subtract"
    putStrLn "3) Multiply"
    putStrLn "4) Divide"
    no <- getLine
    if no == "1"
        then option1
        else if no == "2"
            then option2
            else if no == "3"
                then option3
                else if no == "4"
                    then option4
                    else putStrLn "Error: Unknown option!"
                    
end = do
    putStrLn ""
    putStrLn "Do you wish to return to the main menu? (y,n)"
    choice <- getLine
    
    if choice == "y" || choice == "Y"
        then main
        else if choice == "n" || choice == "N"
            then putStrLn "Goodbye!"
            else end
       
get_two_no :: IO (Int, Int)             
get_two_no = do
    putStrLn "Enter two numbers:"
    no1Str <- getLine
    no2Str <- getLine
    let no1 = stoi no1Str
    let no2 = stoi no2Str
    
    return (no1,no2)
        
option1 = do
    putStrLn "Addition"
    (no1, no2) <- get_two_no
    let answer = no1+no2
    putStrLn $ "The answer is: " ++ show answer
    end
    
option2 = do
    putStrLn "Subtraction"
    (no1, no2) <- get_two_no
    let answer = no1-no2
    putStrLn $ "The answer is: " ++ show answer
    end
    
option3 = do
    putStrLn "Multiply"
    (no1, no2) <- get_two_no
    let answer = no1*no2
    putStrLn $ "The answer is: " ++ show answer
    end
    
option4 = do
    putStrLn "Divide"
    (no1, no2) <- get_two_no
    let answer = no1 `div` no2
    putStrLn $ "The answer is: " ++ show answer
    end
    
