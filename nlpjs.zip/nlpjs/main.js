const dict = require("./dictionary.js");
const brain = require("./brain.js");

function analyzeNoun(input) {
    var output = [];
    
    // Control structures
    var article = "";
    var adjectives = [];
    
    input.forEach(word => {
        if (word === "the") {
            article = "the";
        } else if (word === "a" || word === "an") {
            article = "a";
        } else if (dict.isAdjective(word)) {
            adjectives.push(word);
        } else {
            // By default, assume a noun
            var type = "noun";
            if (dict.isPronoun(word)) type = "pronoun";
            
            var obj = {
                type: type,
                name: word,
                article: article,
                adjectives: adjectives
            };
            output.push(obj);
            
            article = "";
            adjectives = [];
        }
    });
    
    return output;
}

//
// Splits up the sentence for fine processing
//
function splitUp(input) {
    // First, split into individual words
    const words1 = input.split(" ");
    const words = [];
    words1.forEach(word => {
        var w = word.replace(".", "");
        w = w.toLowerCase();
        words.push(w);
    });
    
    const subject = [];
    const verb = [];
    const object = [];
    
    var inVerb = false;        // In English, the verb could be multiple words
    var foundVerb = false;     // If false, we're in subject; if true, we're in object
    
    // Break up into subject/object/verb
    words.forEach(word => {
        if (dict.isVerbHelper(word)) {
            inVerb = true;
            verb.push(word);
        } else if (dict.isVerbRoot(word)) {
            inVerb = false;
            foundVerb = true;
            verb.push(word);
        } else if (foundVerb) {
            object.push(word);        
        } else {
            subject.push(word);
        }
    });
    
    // Build the final array
    const sentence = {
        "subject": analyzeNoun(subject),
        "verb": verb,
        "object": analyzeNoun(object)
    };
    
    //db
    console.log(words);
    console.log(sentence);
    console.log("");
    
    return sentence;
}

function main(input) {
    brain.testInit();

    console.log("Parsing: " + input);
    const sentence = splitUp(input);
    
    var response = brain.respond(sentence);
    console.log(response);
}

main("He is a man.");
