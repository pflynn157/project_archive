#!/bin/bash
#The build script for CompactOS
#TODO: Rewrite using Makefiles or something better
export PATH="$HOME/opt/cross/bin:$PATH"

if [ ! -d ./build ] ; then
	mkdir build
fi

#Build the assembly files
nasm -felf32 kernel/boot.asm -o build/boot.o

#Build the C++ files
i686-elf-g++ -c kernel/kernel.cxx -o build/kernel.o -ffreestanding -O2 -Wall -Wextra -fno-exceptions -fno-rtti
i686-elf-g++ -c kernel/display.cxx -o build/display.o -ffreestanding -O2 -Wall -Wextra -fno-exceptions -fno-rtti
i686-elf-g++ -c kernel/vga.cxx -o build/vga.o -ffreestanding -O2 -Wall -Wextra -fno-exceptions -fno-rtti
i686-elf-g++ -c kernel/string.cxx -o build/string.o -ffreestanding -O2 -Wall -Wextra -fno-exceptions -fno-rtti
i686-elf-g++ -c kernel/keyboard.cxx -o build/keyboard.o -ffreestanding -O2 -Wall -Wextra -fno-exceptions -fno-rtti

#Link it all up
i686-elf-g++ -T kernel/linker.ld -o build/kernel.bin -ffreestanding -O2 -nostdlib build/*.o -lgcc

#Build an ISO disk image
mkdir -p isodir/boot/grub
cp build/kernel.bin isodir/boot/kernel.bin
#cp grub/grub.cfg isodir/boot/grub/grub.cfg
cp grub/menu.lst isodir/boot/grub
cp grub/stage2_eltorito isodir/boot/grub
#grub-mkrescue -o CompactOS.iso isodir
genisoimage -R                              \
                -b boot/grub/stage2_eltorito    \
                -no-emul-boot                   \
                -boot-load-size 4               \
                -A os                           \
                -input-charset utf8             \
                -quiet                          \
                -boot-info-table                \
                -o CompactOS.iso                       \
                isodir
