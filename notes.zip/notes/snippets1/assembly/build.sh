#!/bin/bash
nasm -f elf "$1.asm"
ld -m elf_i386 "-L/usr/lib32" -dynamic-linker /lib/ld-linux.so.2 -s "$1.o" -o "$1.bin" -lc
echo "Done"
