#pragma once

#include <ast/ast.hpp>

void unparse(AstTree *tree);

