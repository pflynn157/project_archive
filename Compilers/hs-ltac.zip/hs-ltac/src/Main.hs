module Main(main) where

import System.IO
import Data.String.Utils

import Ltac
import LtacParser
import LtacBuilder

-- Gets the data portion of the Assembly file
getData [] contents found = reverse contents
getData (x:xs) contents found = do
    if x == "section text"
        then reverse contents
        else if x == "section data"
            then getData xs contents True
            else getData xs (x : contents) True

-- Gets the code portion of the Assembly file
getCode [] contents found = reverse contents
getCode (x:xs) contents found = do
    if x == "section data"
        then getCode xs contents False
        else if x == "section text"
            then getCode xs contents True
            else if found == True
                then getCode xs (x : contents) found
                else getCode xs contents found

-- Loads a file
loadFile reader contents = do
    isEOF <- hIsEOF reader
    if isEOF
        then return (reverse contents)
        else do
            ln <- hGetLine reader
            let ln2 = strip ln
            if (length ln2) == 0
                then loadFile reader contents
                else loadFile reader (ln2 : contents)

-- The main function
main = do
    reader <- openFile "test.asm" ReadMode
    contents <- loadFile reader []
    hClose reader
    
    let dataContents = getData contents [] False
    let codeContents = getCode contents [] False
    
    dataParts <- buildData dataContents []
    
    let base = LtacNode None "" "" ""
    let code = buildCode codeContents [] (ParseData base 0 0 [] "")
    
    --Write everything out
    writer <- openFile "/tmp/out.asm" WriteMode
    let arch = "i386"
    
    initFile arch writer
    generateData writer dataParts
    
    let code2 = scanCode code arch
    generate writer code2 arch
    compile arch

    
