## LTAC

This is the documentation for the LTAC layer (low-level three address code). LTAC code is meant to be the last layer before Assembly. There are two parts: Data elements and 
code elements (instructions). Note: Assume type LtacInstr unless otherwise noted.

#### LtacString (type: Data)
* name -> The name of the string (to be referenced in code)
* value -> The string's value

#### LTAC Function
* name -> The name of the function

#### LTAC Var Declaration
* str_val1 -> The name of the var
* int_val1 -> The var's data type (must be part of the DataType enum- see the ast.h file)

#### LTAC Int Var Assignment
* str_val1 -> The name of the var (needed for location lookup)
* int_val1 -> The type of operation (see below)
* str_val2/int_val2 -> The value being assigned to the variable.

Operations:   
* OP_Imm -> Moves an immediate value to the variable (int_val2 contains the numer)
* OP_Var -> Moves another variable's value to a variable (str_val2 contains the name)
* OP_Reg -> Moves the contents of a register to a variable (int_val2 containers the register number)

#### LTAC Return
* int_val1 -> The type of operation
* int_val2/str_val2 -> The value being returned (if applicable)

#### LTAC PushArg
* int_val1 -> The type of operation
* int_val2/str_val2 -> The argument

Operations
* T_Const -> Push a numerical constant
* T_Addr -> Push memory address
* T_NameAddr -> Push named memory address
* T_Reg -> Push a register

#### LTAC Func Call
* str_val1 -> Function name
