#!/bin/bash
authbind --deep ./build/webserver
