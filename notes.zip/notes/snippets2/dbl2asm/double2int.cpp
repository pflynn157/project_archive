#include <stdio.h>
#include <string>
#include <iostream>

#include <stdint.h>

int main() {
	double val = 3.14;
	
	char buf[64];
	sprintf(buf, "%lu", *(uint64_t*)&val);
	
	std::cout << buf << std::endl;
	
	return 0;
}
