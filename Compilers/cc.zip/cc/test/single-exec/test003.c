//OUTPUT
//END

//RET 0

int
main()
{
	int x;
	
	x = 4;
	return x - 4;
}
