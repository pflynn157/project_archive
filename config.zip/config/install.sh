#!/bin/bash

cp ./nanorc ~/.nanorc
cp ./profile.sh ~/.profile

if [ ! -f ~/.setup ] ; then
    echo "Updating profiles..."
    cat profile_check.txt >> ~/.bashrc
    cat profile_check.txt >> ~/.bash_profile
    touch ~/.setup
fi

sudo cp Nano.desktop /usr/share/applications
sudo update-desktop-database

echo "Done"
echo "Make sure to log out and log back in"
