#pragma once

#include <cstdint>

class CPU {
public:
    CPU();
    void run();
    void printRegisters();
private:
    void fetch();
    void decode();
    void execute();
    void store();
    void reset();
    
    // Control signals and structures
    uint16_t pc = 0;
    uint8_t *registers;
    uint8_t cmp_reg = 0;
    
    // TEMP
    uint16_t *memory;
    
    // Control signals
    uint8_t instr = 0;
    uint8_t opcode = 0;
    uint8_t ctrl = 0;
    uint8_t rs1 = 0;
    uint8_t rs2 = 0;
    uint8_t rd = 0;
    uint8_t alu_op = 0;
    uint8_t imm = 0;
};

