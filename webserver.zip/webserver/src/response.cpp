// Copyright 2019 Patrick Flynn
//
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, 
//	this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, this 
//	list of conditions and the following disclaimer in the documentation and/or 
//	other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors may 
//	be used to endorse or promote products derived from this software 
//	without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#include <iostream>
#include <fstream>
#include <chrono>
#include <ctime>
#include <string>
#include <unistd.h>
#include <sys/stat.h>

//Returns the time as a string
std::string get_time() {
	auto ctime = std::chrono::system_clock::now();
	std::time_t timet = std::chrono::system_clock::to_time_t(ctime);
	std::string time = std::ctime(&timet);
	return time;
}

//Generates the default response header
std::string generate_header(int content_len) {
	auto time = get_time();
	
	std::string header = "Date: " + time ;
	header += "Server: PdfSvr 1.0 (Linux x86)\n";
	header += "Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0\n";
	header += "Pragma: no-cache\n";
	header += "Last-Modified: " + time;
	header += "Content-Length: " + std::to_string(content_len) + "\n";
	header += "Connection: keep-alive, Keep-Alive\n";
	header += "Keep-Alive: timeout=3, max=3";
	header += "Content-Type: text/html\n";
	header += "\n";	
	
	return header;
}

//Load an html file
std::string load_html(std::string file) {
	std::string html = "";
	std::string line = "";
	
	std::ifstream reader(file.c_str());
	if (reader.is_open()) {
		while (std::getline(reader, line)) {
			html += line + "\n";
		}
		
		reader.close();
	}
	
	return html;
}

//Sends a 404 error back to the user
void send_404(int socketd) {
	std::cout << "404 error..." << std::endl;
	
	auto time = get_time();
	std::string content = "<h3>404 Error: Page not found</h3>";
	
	std::string header = "HTTP/1.1 404 Not Found\n";
	header += generate_header(content.length());
	header += content;
	
	write(socketd, header.c_str(), header.length());
}

//Send the response to the http server
void send_response(int socketd, std::string path) {
	struct stat buffer;
	if (stat(path.c_str(), &buffer) != 0) {
		send_404(socketd);
		return;
	}

	std::string content = load_html(path);
	int length = content.length();

	auto time = get_time();

	std::string header = "HTTP/1.1 200 OK\n";
	header += generate_header(length);
	header += content;
	
	write(socketd, header.c_str(), header.length());
}
