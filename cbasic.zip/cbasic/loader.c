#include <stdio.h>
#include <malloc.h>
#include <string.h>

#include "loader.h"
#include "strutils.h"

char **clear_array(char **contents, int lines)
{
	//Build a new array
	char **array = malloc(sizeof(char *) * lines);
	
	for (int i = 0; i<lines; i++)
		array[i] = malloc(101);
		
	//Iterate through the old array
	for (int i = 0; i<lines; i++) {
		char *current = trim(contents[i]);
		char *first = str_first(current);
		printf("FIRST: %s\n", first);
		
		int cmp = strcmp("rem", first); 
		if (cmp == 0) {
			continue;
		} else {
			printf("Comp result: %d\n", cmp);
			strcpy(array[i], current);
		}
		
		free(current);
		free(first);
	}
		
	//Return it
	return array;
}

void run(char **contents, int lines)
{
	contents = clear_array(contents, lines);

	//DEBUG
	/*for (int i = 0; i<lines; i++) {
		char *current = trim(contents[i]);
		if (strlen(current) == 0)
			continue;
		printf("RN LN: %s\n", current);
		free(current);
	}*/
	
	free(contents);
}
