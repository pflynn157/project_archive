## AS

This is my simple assembler for the x86-64 platform.

NOTE: This is a new version I'm working on. I'm doing a complete rewrite from the original; currently the ELF generators are mostly in place, which is why I'm publishing it. If you wish to see the original sources, check out the "original" branch.
