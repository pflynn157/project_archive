#pragma once

void getline(char *ln);
