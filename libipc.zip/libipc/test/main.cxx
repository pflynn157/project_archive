// Copyright 2017 Patrick Flynn
//
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, 
//	this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, this 
//	list of conditions and the following disclaimer in the documentation and/or 
//	other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors may 
//	be used to endorse or promote products derived from this software 
//	without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#include <iostream>
#include <cstdlib>
#include <QString>
#include <QApplication>
#include <QMainWindow>
#include <QPushButton>

#include "../lib/ipc_manager.hh"
#include "../lib/ipc_thread.hh"

using namespace CppLib;

class Window : public QMainWindow {
public:
    Window() {
        this->setWindowTitle("IPC Test");

        QPushButton *exit = new QPushButton("Exit");
        connect(exit,&QPushButton::clicked,this,&Window::onClick);
        this->setCentralWidget(exit);
    }
private slots:
    void onClick() {
        IpcManager::closeApp();
        qApp->exit(0);
    }
};

class BusThread : public IpcThread {
protected:
    void argsCollected(QString content) {
        std::cout << "================" << std::endl;
        std::cout << content.toStdString() << std::endl;
        std::cout << "================" << std::endl;
    }
};

int main(int argc, char **argv) {
    IpcManager::registerApp("org.libipc.test");
    if (IpcManager::isLocked()) {
        std::cout << "in" << std::endl;
        IpcManager::sendArgument("Argument was sent!");
        std::exit(0);
    }
    IpcManager::lockApp();

    QApplication app(argc,argv);
    Window win;
    win.show();

    BusThread thread;
    thread.start(2000);

    return app.exec();
}
