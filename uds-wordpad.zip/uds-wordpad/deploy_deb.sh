#!/bin/bash

if [ ! -d ./build ] ; then
    echo "Error: The application does not seem to be built."
    exit 1
fi

cd build

if [ -d ./linux_deb ]; then
    rm -rf ./linux_deb
fi

mkdir linux_deb
mkdir -p linux_deb/opt/uds/bin
mkdir -p linux_deb/opt/uds/icons/apps
mkdir -p linux_deb/usr/share/applications
mkdir -p linux_deb/DEBIAN

cp src/uds-wordpad linux_deb/opt/uds/bin
cp ../src/icons/uds-wordpad.svg linux_deb/opt/uds/icons/apps
cp ../linux/DEBIAN/control linux_deb/DEBIAN
cp ../linux/uds-wordpad.desktop linux_deb/usr/share/applications

dpkg-deb --build linux_deb
mv linux_deb.deb uds-wordpad_amd64.deb

