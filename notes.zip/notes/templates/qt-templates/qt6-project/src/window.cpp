#include "window.hpp"

Window::Window() {
    this->setWindowTitle("Qt6 Template");
    this->resize(700, 500);
}

Window::~Window() {
}

