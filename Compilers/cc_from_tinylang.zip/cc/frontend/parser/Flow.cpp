//
// Copyright 2021 Patrick Flynn
// This file is part of the Tiny Lang compiler.
// Tiny Lang is licensed under the BSD-3 license. See the COPYING file for more information.
//
#include <parser/Parser.hpp>
#include <ast.hpp>

// Builds a conditional statement
bool Parser::buildConditional(AstBlock *block) {
    Token token = scanner->getNext();
    if (token.type != LParen) {
        syntax->addError(scanner->getLine(), "Expected \'(\'.");
        return false;
    }

    AstIfStmt *cond = new AstIfStmt;
    if (!buildExpression(cond, DataType::Void, RParen)) return false;
    block->addStatement(cond);
    
    AstExpression *expr = checkCondExpression(cond->getExpressions().at(0));
    cond->clearExpressions();
    cond->addExpression(expr);
    
    token = scanner->getNext();
    if (token.type != LCBrace) {
        scanner->rewind(token);
        buildBlock(cond->getBlockStmt(), layer, cond, false, false, true);
    } else {
        ++layer;
        buildBlock(cond->getBlockStmt(), layer, cond);
    }
    
    return true;
}

// Builds an ELIF statement
bool Parser::buildElif(AstIfStmt *block) {
    Token token = scanner->getNext();
    if (token.type != LParen) {
        syntax->addError(scanner->getLine(), "Expected \'(\'.");
        return false;
    }
    
    AstElifStmt *elif = new AstElifStmt;
    if (!buildExpression(elif, DataType::Void, RParen)) return false;
    block->addBranch(elif);
    
    AstExpression *expr = checkCondExpression(elif->getExpressions().at(0));
    elif->clearExpressions();
    elif->addExpression(expr);
    
    token = scanner->getNext();
    if (token.type != LCBrace) {
        scanner->rewind(token);
        buildBlock(elif->getBlockStmt(), layer, block, true, false, true);
    } else {
        buildBlock(elif->getBlockStmt(), layer, block, true);
    }
    
    
    return true;
}

// Builds an ELSE statement
bool Parser::buildElse(AstIfStmt *block) {
    AstElseStmt *elsee = new AstElseStmt;
    block->addBranch(elsee);
    
    Token token = scanner->getNext();
    if (token.type != LCBrace) {
        scanner->rewind(token);
        buildBlock(elsee->getBlockStmt(), layer, nullptr, false, true, true);
    } else {
        buildBlock(elsee->getBlockStmt(), layer, nullptr, false, true);
    }
    
    return true;
}

// Builds a while statement
bool Parser::buildWhile(AstBlock *block) {
    Token token = scanner->getNext();
    if (token.type != LParen) {
        syntax->addError(scanner->getLine(), "Expected \'(\'.");
        return false;
    }
    
    AstWhileStmt *loop = new AstWhileStmt;
    if (!buildExpression(loop, DataType::Void, RParen)) return false;
    block->addStatement(loop);
    
    token = scanner->getNext();
    if (token.type != LCBrace) {
        syntax->addError(scanner->getLine(), "Expected \'{\'.");
        return false;
    }
    
    AstExpression *expr = checkCondExpression(loop->getExpressions().at(0));
    loop->clearExpressions();
    loop->addExpression(expr);
    
    ++layer;
    buildBlock(loop->getBlockStmt(), layer);
    
    return true;
}

// Builds a loop keyword
bool Parser::buildLoopCtrl(AstBlock *block, bool isBreak) {
    if (isBreak) block->addStatement(new AstBreak);
    else block->addStatement(new AstContinue);
    
    Token token = scanner->getNext();
    if (token.type != SemiColon) {
        syntax->addError(scanner->getLine(), "Expected \';\' after break or continue.");
        return false;
    }
    
    return true;
}

