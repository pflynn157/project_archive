#include <iostream>
#include <cstdio>
#include <arpa/inet.h>
#include <vector>

#include <unit.hpp>
#include <Block.hpp>

struct ConstEntry {
    unsigned char type;
    unsigned short index;
    unsigned short index2 = 0;
    std::string data;

    void write(FILE *file) {
        fwrite(&type, sizeof(char), 1, file);
        fwrite(&index, sizeof(short), 1, file);

        if (index2 != 0) {
            fwrite(&index2, sizeof(short), 1, file);
        }

        for (char c : data) fputc(c, file);
    }
};

struct JavaCode {
    unsigned char opcode;
    unsigned short arg1;            // argPos = 1
    unsigned char arg1_byte;        // argPos = 2

    int argPos = 0;

    JavaCode(unsigned char opcode) {
        this->opcode = opcode;
    }

    JavaCode(unsigned char opcode, unsigned short arg1) {
        this->opcode = opcode;
        this->arg1 = htons(arg1);
        argPos = 1;
    }

    JavaCode(unsigned char opcode, unsigned char arg1) {
        this->opcode = opcode;
        this->arg1_byte = arg1;
        argPos = 2;
    }

    int size() {
        if (argPos == 1) return 3;
        else if (argPos == 2) return 2;
        return 1;
    }

    void write(FILE *file) {
        fputc(opcode, file);
        if (argPos == 1) fwrite(&arg1, sizeof(short), 1, file);
        else if (argPos == 2) fputc(arg1_byte, file);
    }
};

struct JavaCodeBlock {
    unsigned short codeIdx = 0;
    unsigned int size = 12;   // Code size is added when written
    unsigned short stackSize = htons(2);
    unsigned short maxVars = htons(1);

    std::vector<JavaCode> code;

    unsigned short exceptionSize = 0;
    unsigned short attrSize = 0;

    void addCode(JavaCode c) { code.push_back(c); }

    void write(FILE *file) {
        codeIdx = htons(codeIdx);

        unsigned int codeSize = 0;
        for (JavaCode c : code) codeSize += c.size();
        size = htonl(codeSize + size);
        codeSize = htonl(codeSize);

        fwrite(&codeIdx, sizeof(short), 1, file);
        fwrite(&size, sizeof(int), 1, file);
        fwrite(&stackSize, sizeof(short), 1, file);
        fwrite(&maxVars, sizeof(short), 1, file);

        fwrite(&codeSize, sizeof(int), 1, file);
        for (JavaCode c : code) c.write(file);

        fwrite(&exceptionSize, sizeof(short), 1, file);
        fwrite(&attrSize, sizeof(short), 1, file);
    }
};

struct JavaFunction {
    unsigned short flags = htons(0x0009);
    unsigned short nameIdx = 0;
    unsigned short typeIdx = 0;
    unsigned short attrCount = htons(1);

    JavaCodeBlock codeBlock;

    void addCode(JavaCode c) { codeBlock.addCode(c); }

    void write(FILE *file) {
        fwrite(&flags, sizeof(short), 1, file);
        fwrite(&nameIdx, sizeof(short), 1, file);
        fwrite(&typeIdx, sizeof(short), 1, file);
        fwrite(&attrCount, sizeof(short), 1, file);
        codeBlock.write(file);
    }
};

struct ClassFile {
    unsigned int magic = htonl(0XCAFEBABE);
    unsigned short minor_version = 0;
    unsigned short major_version = htons(0x0034);

    std::vector<ConstEntry> const_pool;

    unsigned short modifiers = htons(0x0021);
    unsigned short this_idx = 0;
    unsigned short super_idx = 0;

    unsigned short interface_count = 0;
    unsigned short field_count = 0;
    std::vector<JavaFunction *> methods;
    unsigned short attr_count = 0;

    void write(FILE *file) {
        fwrite(&magic, sizeof(int), 1, file);
        fwrite(&minor_version, sizeof(short), 1, file);
        fwrite(&major_version, sizeof(short), 1, file);

        unsigned short const_size = htons(const_pool.size() + 1);
        fwrite(&const_size, sizeof(short), 1, file);
        for (ConstEntry entry : const_pool) {
            entry.write(file);
        }

        fwrite(&modifiers, sizeof(short), 1, file);
        fwrite(&this_idx, sizeof(short), 1, file);
        fwrite(&super_idx, sizeof(short), 1, file);

        fwrite(&interface_count, sizeof(short), 1, file);
        fwrite(&field_count, sizeof(short), 1, file);

        unsigned short func_count = htons(methods.size());
        fwrite(&func_count, sizeof(short), 1, file);
        for (JavaFunction *func : methods) func->write(file);

        fwrite(&attr_count, sizeof(short), 1, file);
    }
};

class JavaClassBuilder {
public:
    explicit JavaClassBuilder(std::string className);
    int AddString(std::string value);
    void EnableIO();
    JavaFunction *CreateFunc(std::string name, std::string signature);

    void CreatePrintString(JavaFunction *func, std::string value);
    void CreateRetVoid(JavaFunction *func);

    void Write(FILE *file);
private:
    ClassFile java;
    int codeIdx = 0;
    int outPos = 0;
    int printlnPos = 0;
};

JavaClassBuilder::JavaClassBuilder(std::string className) {
    // Sets the class name
    java.this_idx = htons(0x01);

    ConstEntry classData;
    classData.type = 0x07;
    classData.index = htons(0x02);
    java.const_pool.push_back(classData);

    ConstEntry classNameEntry;
    classNameEntry.type = 0x01;
    classNameEntry.index = htons(className.length());   // Length, not index
    classNameEntry.data = className;
    java.const_pool.push_back(classNameEntry);

    // Set the super class
    java.super_idx = htons(0x03);

    classData.type = 0x07;
    classData.index = htons(0x04);
    java.const_pool.push_back(classData);

    std::string superClass = "java/lang/Object";
    classNameEntry.index = htons(superClass.length());
    classNameEntry.data = superClass;
    java.const_pool.push_back(classNameEntry);

    codeIdx = AddString("Code");
}

// Adds a string to the constant pool
int JavaClassBuilder::AddString(std::string value) {
    ConstEntry entry;
    entry.type = 0x01;
    entry.index = htons(value.length());
    entry.data = value;
    java.const_pool.push_back(entry);

    return java.const_pool.size();
}

// If called, we enable the java IO (System.out.println)
void JavaClassBuilder::EnableIO() {
    // First, add java.lang.System
    int systemIdx = java.const_pool.size() + 2;
    ConstEntry classData;
    classData.type = 0x07;
    classData.index = htons(systemIdx);
    java.const_pool.push_back(classData);

    ConstEntry classNameEntry;
    std::string entry = "java/lang/System";
    classNameEntry.type = 0x01;
    classNameEntry.index = htons(entry.length());
    classNameEntry.data = entry;
    java.const_pool.push_back(classNameEntry);

    // Now, java.io.PrintStream
    int printStreamIdx = java.const_pool.size() + 2;
    classData.index = htons(printStreamIdx);
    java.const_pool.push_back(classData);

    entry = "java/io/PrintStream";
    classNameEntry.index = htons(entry.length());
    classNameEntry.data = entry;
    java.const_pool.push_back(classNameEntry);

    /////////////////////////
    // Static variable "out"
    outPos = AddString("out");
    int printTypePos = AddString("Ljava/io/PrintStream;");

    // NameAndType #outPos:#printTypePos
    classData.type = 12;
    classData.index = htons(outPos);
    classData.index2 = htons(printTypePos);
    java.const_pool.push_back(classData);

    // FieldRef #sysIndex:#nameTypeIndex
    classData.type = 0x09;
    classData.index = htons(systemIdx - 1);
    classData.index2 = htons(java.const_pool.size());
    java.const_pool.push_back(classData);

    outPos = java.const_pool.size();

    ///////////////////
    // println(String)
    printlnPos = AddString("println");
    int printlnSigPos = AddString("(Ljava/lang/String;)V");

    // NameAndType #printlnPos:#printlnSigPos
    classData.type = 12;
    classData.index = htons(printlnPos);
    classData.index2 = htons(printlnSigPos);
    java.const_pool.push_back(classData);

    // MethodRef #printStreamIdx:#nameType
    classData.type = 10;
    classData.index = htons(printStreamIdx - 1);
    classData.index2 = htons(java.const_pool.size());
    java.const_pool.push_back(classData);

    printlnPos = java.const_pool.size();
}

JavaFunction *JavaClassBuilder::CreateFunc(std::string name, std::string signature) {
    int nameIdx = AddString(name);
    int sigIdx = AddString(signature);

    JavaFunction *func = new JavaFunction;
    func->nameIdx = htons(nameIdx);
    func->typeIdx = htons(sigIdx);
    func->codeBlock.codeIdx = codeIdx;
    java.methods.push_back(func);

    return func;
}

void JavaClassBuilder::CreatePrintString(JavaFunction *func, std::string value) {
    int valPos = AddString(value);

    ConstEntry entry;
    entry.type = 8;
    entry.index = htons(valPos);
    java.const_pool.push_back(entry);
    valPos = java.const_pool.size();

    JavaCode code1(0xB2, (unsigned short)outPos);
    JavaCode code2(0x12, (unsigned char)valPos);
    JavaCode code3(0xB6, (unsigned short)printlnPos);

    func->addCode(code1);
    func->addCode(code2);
    func->addCode(code3);
}

void JavaClassBuilder::CreateRetVoid(JavaFunction *func) {
    func->addCode(JavaCode(0xB1));
}

void JavaClassBuilder::Write(FILE *file) {
    java.write(file);
}

int main(int argc, char *argv[]) {
    /*Unit *unit = new Unit("module1");
    Function *mainFunc = Function::Create(unit, "main");

    Block *block = Block::Create(mainFunc, "entry");

    Instruction *ret1 = new Instruction(RET, "1");
    block->AddInstruction(ret1);

    Instruction *ret = new Instruction(RETVOID, "");
    block->AddInstruction(ret);

    unit->dump();

    delete unit;*/

    JavaClassBuilder builder("HelloWorld");
    builder.EnableIO();

    JavaFunction *mainFunc = builder.CreateFunc("main", "([Ljava/lang/String;)V");
    builder.CreatePrintString(mainFunc, "Hello from Java!");
    builder.CreateRetVoid(mainFunc);

    FILE *file = fopen("HelloWorld.class", "wb");
    builder.Write(file);
    fclose(file);
    return 0;
}
