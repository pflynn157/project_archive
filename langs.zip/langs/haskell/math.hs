--math.hs
import Data.Char

{-
factorial :: Int -> Int
factorial 0 = 1
factorial a = a * factorial (a-1)
-}

factorial a = if a == 0 then 1 else a * factorial (a-1)

zipUp :: [a] -> [b] -> [(a,b)]
zipUp [] [] = []
zipUp ax [] = []
zipUp [] bx = []
zipUp (a:ax) (b:bx) = (a,b) : zipUp ax bx

cipher :: [Char] -> Int -> [Char]
cipher [] _ = []
cipher (s:str) n = rotate s n : cipher str n

rotate :: Char -> Int -> Char
rotate s n = chr(ord s + n)

--Convert
-- m-> yd -> 1 m = 1.09361 yd
-- L -> gal -> 1 L = 0.264172 gal
-- kg -> lbs -> 1 kg = 2.20462 lbs
convert :: (Double, [Char]) -> (Double, [Char])
convert (val, target)
    | target == "m" = (val*1.09361, "yd")
    | target == "L" = (val*0.264172, "gal")
    | target == "kg" = (val*2.20462, "lbs")
    | otherwise = (val, "unknown")
