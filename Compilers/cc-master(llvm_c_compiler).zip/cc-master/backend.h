#pragma once

#include <llvm-c/Core.h>

#include "compiler.h"
#include "ast.h"

void build_backend(AstTree *tree, LLVMContextRef context, LLVMModuleRef mod, LLVMBuilderRef builder);
