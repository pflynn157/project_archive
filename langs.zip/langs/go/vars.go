package main

import "fmt"
import "strconv"

func getTwoNumbers() (int, int) {
	var no1_str string
	var no2_str string

	println("Enter a number:")
	fmt.Scanln(&no1_str)
	
	println("Enter another number:")
	fmt.Scanln(&no2_str)
	
	no1, _ := strconv.Atoi(no1_str)
	no2, _ := strconv.Atoi(no2_str)
	
	return no1, no2
}

func main() {
	no1, no2 := getTwoNumbers()
	answer := no1 + no2
	
	fmt.Printf("The sum is: %d\n", answer)
}
