#include <stdio.h>
#include <string.h>

#include <ast.h>
#include <ltac/ltac.h>
#include <ltac/builder.h>
#include <asm/amd64.h>

extern void parse(const char *path, AstNode *tree);

int main(int argc, char *argv[]) {
    AstNode *tree = ast_create_node(Scope);
    int debug = 0;

	if (argc > 1) 
	{
	    if (strcmp(argv[1], "debug") == 0) 
	    {
	        puts("Quik 3- Running in debug mode.");
	        puts("");
	        
	        debug = 1;
	        parse(argv[2], tree);
	    } 
	    else 
	    {
		    parse(argv[1], tree);
	    }
	} 
	else 
	{
		puts("Unknown file.");
		return 1;
	}
	
	if (debug)
	{
	    ast_print(tree, 0);
		puts("");
	}
	
// LTAC
	LtacFile *file = ltac_create_file("out.asm");
	ltac_assemble(tree, file);
	
	if (debug) ltac_print_file(file);
	
// Generate assembly
    
    amd64_generate(file);
    amd64_build(file);
    amd64_link(file);
	
	return 0;
}
