module I386.I386Registers(i386IntReg) where

i386IntReg no
    | no == 1 = "eax"
    | no == 2 = "ebx"
    | no == 3 = "edx"
    | no == 4 = "edi"
    | no == 5 = "esi"
    | no == 6 = "ecx"
    | no == 7 = ""
