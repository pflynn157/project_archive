//
// Copyright 2021 Patrick Flynn
// This file is part of uds-wordpad.
// uds-wordpad is licensed under the BSD-3 license. See the COPYING file for more information.
//
#include <QFont>
#include <QPrinter>
#include <QPrintDialog>
#include <QPdfWriter>
#include <QFileDialog>
#include <QFile>
#include <QTextStream>
#include <QtGlobal>

#include <editor.hpp>
#include <global.hpp>

Editor::Editor() {
    this->setAcceptRichText(true);
    
    connect(this, &QTextEdit::textChanged, this, &Editor::onTextChanged);
    connect(this, &QTextEdit::cursorPositionChanged, this, &Editor::onCursorChanged);
}

void Editor::setUntitled(bool untitled) {
    this->untitled = untitled;
    this->fullPath = "untitled";
    this->name = "untitled";
}

void Editor::setFile(QString fullPath, QString name) {
    this->fullPath = fullPath;
    this->name = name;
    this->untitled = false;
}

void Editor::openFile() {
    // Load the text
    QString text = "";
    
    QFile file(fullPath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        // TODO: Pop up error dialog
        return;
    }
    
    QTextStream reader(&file);
    while (!reader.atEnd()) {
        text += reader.readLine();
        text += "\n";
    }
    
    // Set the text
    if (name.endsWith(".rst") || name.endsWith(".htm") || name.endsWith(".html")) {
        this->setHtml(text);
#if QT_VERSION >= QT_VERSION_CHECK(5, 14, 0)
    } else if (name.endsWith(".md")) {
        this->setMarkdown(text);
#endif
    } else {
        this->setPlainText(text);
    }
    
    // Update formatting
    if (this->fontWeight() == QFont::Bold) bold = true;
    italic = fontItalic();
    underline = fontUnderline();
    
    this->saved = true;
    win->setCurrentSaved(true);
}

void Editor::saveFile() {
    QFile file(fullPath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        // TODO: Error dialog
        return;
    }
    
    QTextStream writer(&file);
    if (name.endsWith(".rst") || name.endsWith(".htm") || name.endsWith(".html")) {
        writer << toHtml();
#if QT_VERSION >= QT_VERSION_CHECK(5, 14, 0)
    } else if (name.endsWith(".md")) {
        writer << toMarkdown();
#endif
    } else {
        writer << toPlainText();
    }
    
    this->saved = true;
    win->setCurrentSaved(true);
}

void Editor::printPage() {
    QPrinter *printer = new QPrinter;
    QPrintDialog dialog(printer, this);
    
    if (dialog.exec() == QDialog::Accepted) {
        this->print(printer);
    }
}

void Editor::exportPDF() {
    QString fileName = QFileDialog::getSaveFileName(nullptr, "Export to PDF",
        getenv("HOME"), "PDF files (*.pdf)");
    if (fileName.isNull())
        return;
        
    QPdfWriter *writer = new QPdfWriter(fileName);
    this->print(writer);
}

void Editor::toggleBold() {
    bold = !bold;
    
    if (bold) {
        this->setFontWeight(QFont::Bold);
    } else {
        this->setFontWeight(QFont::Normal);
    }
}

void Editor::toggleItalic() {
    italic = !italic;
    this->setFontItalic(italic);
}

void Editor::toggleUnderline() {
    underline = !underline;
    this->setFontUnderline(underline);
}

void Editor::onTextChanged() {
    if (this->document()->isModified()) {
        this->saved = false;
        win->setCurrentSaved(false);
    }
}

void Editor::onCursorChanged() {
    if (this->fontWeight() == QFont::Bold) bold = true;
    italic = fontItalic();
    underline = fontUnderline();
    
    win->getFormatToolbar()->updateFormat(bold, italic, underline);
}

