## libsyntax-highlighting
This is a syntax highlighting library for the QTextEdit. The library enables you to create a code editor with minimal effort. The library also includes widgets that allow you to easily interface with this library.

See either the doc/ directory or the header files for information on how to use the library.

