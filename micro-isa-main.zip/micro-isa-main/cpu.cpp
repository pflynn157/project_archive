#include <cstdio>

#include "cpu.hpp"

CPU::CPU() {
    registers = new uint8_t[4];
    pc = 0;
    for (int i = 0; i<4; i++) registers[i] = 0;
    
    // TEMP
    memory = new uint16_t[65400];
    memory[0] = 0x32;       // ldi 3
    memory[1] = 0x09;       // mov r1, r0
    memory[2] = 0x42;       // ldi 4
    memory[3] = 0xC0;       // add r3
}

//
// The main run loop
//
void CPU::run() {
    while (pc < 4) {
        fetch();
        decode();
        execute();
        store();
    }
}

//
// Fetch stage
//
void CPU::fetch() {
    reset();
    instr = memory[pc];
    ++pc;
}

//
// Decode stage
//
void CPU::decode() {
    opcode = instr & 0x07;
    
    printf("--------\nOpcode: %X\n", opcode); // db
    
    switch (opcode) {
        // ALU
        case 0b000: {
            alu_op = (instr & 0x38) >> 3;
            rd = (instr & 0xC0) >> 6;
            
            printf("ALU %X -> r%X\n", opcode, rd);
        } break;
    
        // mov
        case 0b001: {
            rd = (instr & 0x18) >> 3;
            rs = (instr & 0x60) >> 5;
            
            printf("MOV rd: %X, rs: %X\n", rd, rs);
        } break;
        
        // ldi
        case 0b010: {
            ctrl = (instr & 0x08) >> 3;
            imm = (instr & 0xF0) >> 4;
            
            printf("CTRL: %X | Imm: %X\n", ctrl, imm);
        } break;
        
        default: {}
    }
}

//
// The execute stage
//
void CPU::execute() {
    switch (opcode) {
        // ALU
        case 0b000: {
            if (alu_op == 0) registers[rd] = registers[0] + registers[1];
        } break;
    
        // mov
        case 0b001: {
            registers[rd] = registers[rs];
        } break;
    
        // ldi
        case 0b010: {
            if (ctrl) {
                // TODO: LUI
            } else {
                registers[0] = imm;
            }
        } break;
        
        default: {}
    }
}

//
// The store stage
//
void CPU::store() {

}

//
// Resets all control signals
//
void CPU::reset() {
    instr = 0;
    opcode = 0;
    ctrl = 0;
    alu_op = 0;
    imm = 0;
    rs = 0;
    rd = 0;
}

