// Copyright 2019 Patrick Flynn
//
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, 
//	this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, this 
//	list of conditions and the following disclaimer in the documentation and/or 
//	other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors may 
//	be used to endorse or promote products derived from this software 
//	without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#include <iostream>
#include <string>
#include <cstdlib>

#include "loop.hh"
#include "strutils.hh"
#include "types.hh"
#include "interpreter.hh"
#include "vars.hh"
#include "condition.hh"
#include "array.hh"
#include "error.hh"

bool lp_stop = false;
bool lp_continue = false;

//The regular loop command
void lp_loop(std::vector<String> body, bool global) {
	std::string header = get_second(body.front().str, ' ');
	int count = 0;
	
	try {
		count = std::stoi(header);
	} catch (std::exception &e) {
		//We have a var
		Var v = get_var(header);
		if (v.name == "") {
			rt_err(body.front(), "No such variable or number.");
		}
		
		if (v.type != DataType::INT) {
			type_error(body.front());
		}
		
		try {
			count = std::stoi(v.val);
		} catch (std::exception &e) {
			type_error(body.front());
		}
	}
	
	for (int i = 0; i<count; i++) {
		for (int j = 1; j<body.size(); j++) {
			if (lp_stop) {
				lp_stop = false;
				return;
			} else if (lp_continue) {
				lp_continue = false;
				break;
			}
		
			interpret(body.at(j), global);
		}
	}
}

//The while loop
void lp_while(std::vector<String> body, bool global) {
	std::string header = get_second(body.front().str, ' ');
	header = rm_first_last(header);
	header = clr_spaces(header);

	while (evaluate(header, global)) {
		for (int i = 1; i<body.size(); i++) {
			if (lp_stop) {
				lp_stop = false;
				return;
			} else if (lp_continue) {
				lp_continue = false;
				break;
			}
			
			interpret(body.at(i), global);
		}
	}
}

//The for loop
void lp_for(std::vector<String> body, bool global) {
	//First, break up the header
	std::string header = get_second(body.front().str, ' ');
	header = clr_spaces(header);
	
	std::string local_var = get_first(header, '>');
	std::string range = get_second(header, '>');
	std::string max = get_first(range, ':');
	std::string inc = get_second(range, ':');
	
	//Create the local variable
	Var lv;
	lv.name = local_var;
	
	//Determine the datatype of our max variable, and iterate from there
	//Start with arrays
	Array arr = get_arr(max);
	
	if (arr.name != "") {
		lv.type = arr.type;
		
		if (inc != "") {
			syntax_err(body.front(), "Incremets are not valid with arrays.");
		}
	
		for (std::string val : arr.contents) {
			lv.val = val;
			add_var(lv, global);
			
			for (int i = 1; i<body.size(); i++) {
				if (lp_stop) {
					lp_stop = false;
					rm_var(lv, global);
					return;
				} else if (lp_continue) {
					lp_continue = false;
					break;
				}
				
				interpret(body.at(i), global);
			}
		}
	
		rm_var(lv, global);
		return;
	}
	
	//Try strings
	Var v = get_var(max);
	
	if ((v.name != "" && v.type == DataType::STR) || is_str(max)) {
		lv.type = DataType::CHAR;
		
		if (inc != "") {
			syntax_err(body.front(), "Incremets are not valid with arrays.");
		}
		
		std::string val = max;
		if (!is_str(max)) {
			val = var_val(max);
		}
		val = rm_first_last(val);

		for (char c : val) {
			lv.val.clear();
			lv.val += '\'';
			lv.val += c;
			lv.val += '\'';
			add_var(lv, global);
			
			for (int i = 1; i<body.size(); i++) {
				if (lp_stop) {
					lp_stop = false;
					rm_var(lv, global);
					return;
				} else if (lp_continue) {
					lp_continue = false;
					break;
				}
				
				interpret(body.at(i), global);
			}
		}

		rm_var(lv, global);
		return;
	}

	//Try for integers
	DataType type = get_datatype(max);

	if ((v.name != "" && v.type == DataType::INT) || type == DataType::INT) {
		lv.type = DataType::INT;
		int up = 1;
		int mx = 0;

		//Convert our max value
		if (type == DataType::INT) {
			mx = std::stoi(max);
		} else {
			std::string v_str = var_val(v.name);
			mx = std::stoi(v_str);
		}

		//Determine our increment value
		if (inc != "") {
			type = get_datatype(inc);

			if (type == DataType::INT) {
				up = std::stoi(inc);
			} else {
				v = get_var(inc);
				if (v.name == "" || v.type != DataType::INT) {
					syntax_err(body.front(), "Invalid variable or wrong datatype specified.");
				}

				std::string v_str = var_val(v.name);
				up = std::stoi(v_str);
			}
		}

		//Run our for loop
		for (int i = 0; i<mx; i+=up) {
			lv.val = std::to_string(i);
			add_var(lv, global);

			for (int j = 1; j<body.size(); j++) {
				if (lp_stop) {
					lp_stop = false;
					rm_var(lv, global);
					return;
				} else if (lp_continue) {
					lp_continue = false;
					break;
				}
			
				interpret(body.at(j), global);
			}
		}

		rm_var(lv, global);
		return;
	}

	//Unknown variable...
	syntax_err(body.front(), "Invalid variable or datatype.");
}
