#include <utils.hpp>

std::string get_path(std::string input) {
    size_t found = input.find_last_of("/\\");
    if (found == -1) return "./";
    return input.substr(0, found);
}

std::string get_name(std::string input) {
    size_t found = input.find_last_of("/\\");
    if (found < 0) return input;
    return input.substr(found+1);
}

