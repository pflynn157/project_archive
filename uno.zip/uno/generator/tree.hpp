#pragma once

#include <string>
#include <vector>

struct Tree;
struct Block;
struct Element;

struct Tree {
    std::vector<Block *> blocks;
};

struct Node {
    std::string tagName;
    std::string idName = "";
    bool isBlock = false;
    std::vector<std::pair<std::string, std::string>> cssRules;
    
    void addCSS(std::string key, std::string value) {
        cssRules.push_back(std::pair<std::string, std::string>(key, value));
    }
};

struct Block : Node {
    Block() {
        this->isBlock = true;
    }
    
    std::vector<Node *> nodes;
};

struct Element : Node {
    std::string value = "";
    bool endTag = true;
    
    std::vector<std::pair<std::string, std::string>> attrs;
    
    void addAttribute(std::string key, std::string value) {
        attrs.push_back(std::pair<std::string, std::string>(key, value));
    }
};
