#pragma once

#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

#include "config/config.hpp"

extern int socketd;

struct Request {
	std::string type;
	std::string path;
	std::string protocol;
};

class Server {
public:
    explicit Server(int port, std::string basePath, ServerConfig *confg = nullptr);
    void run();
protected:
    std::string basePath = "./";
    ServerConfig *config;

    void rcv_data(int nsocketd);
    struct sockaddr_in server;
    
    // response.cpp
    std::string get_time();
    std::string generate_header(int content_len);
    std::string load_html(std::string file);
    void send_404(int socketd);
    void send_response(int socketd, std::string path);
    
    // request.hpp
    Request parse_request(std::string request);
    
    // router.cpp
    std::string findPath(std::string reqPath);
};
