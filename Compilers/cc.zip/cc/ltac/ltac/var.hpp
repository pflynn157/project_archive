#pragma once

#include "ltac.hpp"

// A generic 32-bit variable
class LtacVar32 : public LtacInstr {
public:
    explicit LtacVar32(int pos) : LtacInstr(LtacType::Var32) {
        this->pos = pos;
    }
    
    int getPos() { return pos; }
    std::string printInstr();
private:
    int pos = 0;
};

// A pointer
class LtacPtr : public LtacInstr {
public:
    explicit LtacPtr(int pos) : LtacInstr(LtacType::Ptr) {
        this->pos = pos;
    }
    
    int getPos() { return pos; }
    std::string printInstr();
private:
    int pos = 0;
};

// A memory reference
class LtacRef : public LtacInstr {
public:
    explicit LtacRef(int pos) : LtacInstr(LtacType::Ref) {
        this->pos = pos;
    }
    
    int getPos() { return pos; }
    std::string printInstr();
private:
    int pos = 0;
};

// The base class for 32-bit integer/variable operations
class LtacI32Op : public LtacInstr {
public:
    explicit LtacI32Op(int val) {
        this->val = val;
    }
    
    explicit LtacI32Op(int pos, int val) {
        this->pos = pos;
        this->val = val;
    }
    
    int getPos() { return pos; }
    int getVal() { return val; }
protected:
    int pos = -1;
    int val = 0;
};

// Stores a 32-bit integer immediate to a variable or a pointer
class LtacMovI32 : public LtacI32Op {
public:
    LtacMovI32(int pos, int val) : LtacI32Op(pos, val) {
        this->type = LtacType::MovI32;
    }
    
    void setPtr(bool ptr) { this->ptr = ptr; }
    bool isPtr() { return ptr; }
        
    std::string printInstr();
private:
    bool ptr = false;
};

// Stores 32-bit var to a variable
class LtacMovV32 : public LtacInstr {
public:
    LtacMovV32(int dest, int src) : LtacInstr(LtacType::MovV32) {
        this->dest = dest;
        this->src = src;
    }
    
    int getDest() { return dest; }
    int getSrc() { return src; }
    
    std::string printInstr();
private:
    int dest = 0;
    int src = 0;
};

// Loads an 32-bit integer for use in an operation
class LtacLdI32 : public LtacI32Op {
public:
    explicit LtacLdI32(int val) : LtacI32Op(val) {
        this->type = LtacType::LdI32;
    }
    
    explicit LtacLdI32(int pos, int val) : LtacI32Op(pos, val) {
        this->type = LtacType::LdI32;
    }
    
    std::string printInstr();
};

// Loads a 32-bit variable for use in an operation
class LtacLdV32 : public LtacI32Op {
public:
    explicit LtacLdV32(int val) : LtacI32Op(val) {
        this->type = LtacType::LdV32;
    }
    
    explicit LtacLdV32(int pos, int val) : LtacI32Op(pos, val) {
        this->type = LtacType::LdV32;
    }
    
    std::string printInstr();
};

// Loads a pointer to a 32-bit variable
class LtacLdPtr32 : public LtacI32Op {
public:
    explicit LtacLdPtr32(int pos, int val, int reg = 0) 
            : LtacI32Op(pos, val) {
        this->type = LtacType::LdPtr32;
        this->reg = reg;
    }
    
    int getReg() { return reg; }
    
    std::string printInstr();
private:
    int reg = 0;
};

// Stores an 32-bit integer that was used in an operation
class LtacStrI32 : public LtacInstr {
public:
    explicit LtacStrI32(int dest) : LtacInstr(LtacType::StrI32) {
        this->dest = dest;
    }
    
    explicit LtacStrI32(int pos, int dest) : LtacInstr(LtacType::StrI32) {
        this->pos = pos;
        this->dest = dest;
    }
    
    int getPos() { return pos; }
    int getDest() { return dest; }
    
    std::string printInstr();
private:
    int pos = -1;        // If -1, we either push to the stack or don't care (the latter on a stack machine)
    int dest = 0;
};

// Stores a reference of one variable to a pointer variable
class LtacStrRef : public LtacInstr {
public:
    explicit LtacStrRef(int dest, int src) : LtacInstr(LtacType::StrRef) {
        this->dest = dest;
        this->src = src;
    }
    
    int getDest() { return dest; }
    int getSrc() { return src; }
    
    std::string printInstr();
private:
    int dest = 0;
    int src = 0;
};
