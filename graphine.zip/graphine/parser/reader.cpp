#include <iostream>

#include <reader.hpp>
#include <dom.hpp>

BinParser::BinParser(std::string input) {
    reader = std::ifstream(input);
}

void BinParser::parse(Block *parent) {
    unsigned char opcode = reader.get();
    while (!reader.eof()) {
        switch (opcode) {
            case 0xB0: std::cout << "H1" << std::endl; break;
            
            default: {
                printf("Unknown opcode: %X\n", opcode);
            }
        }
        
        opcode = reader.get();
    }
}

std::vector<Element *> BinParser::getElements() {
    return elements;
}