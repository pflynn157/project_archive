module I386.I386(i386FixFc,
    i386Func,
    i386Ret,
    i386PushArg,
    i386Call,
    i386IStoreI,
    i386ILdrI,
    i386ILdrV,
    i386IStr,
    i386IMathRR) where

import System.IO

import Ltac
import I386.I386Vars
import I386.I386Math

-- On Intel i386, arguments must be passed backwards
fcMerge [] code = code
fcMerge (x:xs) code = fcMerge xs (x : code)

fixFc [] tmp code = reverse code
fixFc (x:xs) tmp code
    | i == Call = do
        let code2 = fcMerge tmp code
        fixFc xs [] (x : code2)
    | i == PushArg = fixFc xs (x : tmp) code
    | otherwise = fixFc xs tmp (x : code)
    where
        i = instr x

i386FixFc code = fixFc code [] []

-- Translates certain instructions to i386 Assembly
-- Function declarations
i386Func ln writer = do
    let line = (arg1 ln) ++ ":"
    hPutStrLn writer line
    
    -- Setup the stack
    hPutStrLn writer "\tpush ebp"
    hPutStrLn writer "\tmov ebp, esp"
    
    let stackSize = arg2 ln
    if stackSize == "0"
        then hPutStrLn writer ""
        else do
            hPutStrLn writer ("\tsub esp, " ++ stackSize)
            hPutStrLn writer ""
    
-- Function return instructions
i386Ret ln writer = do
    hPutStrLn writer ""
    hPutStrLn writer "\tleave"
    hPutStrLn writer "\tret"
    hPutStrLn writer ""
    
-- Pusharg instruction
i386PushArg2 ln writer
    | dType == "string" = do
        let name = arg2 ln
        hPutStrLn writer ("\tpush OFFSET FLAT:" ++ name)
    
    | dType == "int" = hPutStrLn writer ("\tpush " ++ (arg2 ln))
    
    | dType == "i.var" = do
        let pos = arg2 ln
        hPutStrLn writer ("\tpush DWORD PTR [ebp-" ++ pos ++ "]")
    
    | otherwise = putStrLn "Unknown type in pusharg!"
    where
        dType = arg1 ln
        
i386PushArg ln writer = do
    let pos = arg3 ln
    if pos /= "1"
        then do
            hPutStrLn writer ""
            i386PushArg2 ln writer
        else i386PushArg2 ln writer
        
-- The call instruction
i386Call ln writer = do
    hPutStrLn writer ("\tcall " ++ (arg1 ln))
    hPutStrLn writer ""
    
