//bytecode.hh
//Contains opcodes for our VM
#pragma once

//The header
unsigned char header[] = {'Q', 'U', 'I', 'C', 'K'};

//Represents our bytecode
enum ByteCode {
	//Types
	TYPE_INT = 0x10,
	TYPE_DEC = 0x20,

	//Integers
	I_LOAD = 0xA0,
	I_ADD = 0xA1,
	I_SUB = 0xA2,
	I_MUL = 0xA3,
	I_DIV = 0xA4,
	I_MOD = 0xA5,
	I_PRINT = 0xA6,
	I_INPUT = 0xA7,
	I_VAR = 0xA8,
	I_STORE = 0xA9,
	I_LOAD_VAR = 0xAA,
	
	//Strings
	S_LOAD = 0xB1,
	S_PRINT = 0xB2,
	
	//Decimals
	D_LOAD = 0xC1,
	D_PRINT = 0xC2,
	
	//Labels
	LBL = 0x20,
	
	//Flow control
	JMP = 0x21,
	JE = 0x22,
	JNE = 0x23,
	
	//Compare
	I_CMP = 0x30,
	
	//Exit
	EXIT = 0x10
};
