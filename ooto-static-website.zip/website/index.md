---
# Feel free to add content and custom Front Matter to this file.
# To modify the layout, see https://jekyllrb.com/docs/themes/#overriding-theme-defaults

layout: home
---

# Welcome!

Welcome to the OOTO Project, and thanks for stopping by! OOTO is an umbrella project around various software and hardware research projects I purse in my free time. This site was started to give me an easy way to host and document them outside my personal website, and a way to take the focus off me and put them on the projects and my goals behind them.

OOTO is about exploration, and one of the main goals is to demonstrate why the advice "don't reinvent the wheel" is such bad advice. The projects here are not about creating the next cool app or some revolutionary AI technology. No, our goal is to explore, especially the fundamental aspects of computer science including hardware, low-level programming languages, various tools, and etc.

Finally, OOTO is about education. When I was working on my bachelor's degree in computer science, I was not surprised that the curriculum didn't go that deep into core technologies like hardware, compilers, languages, and so forth, but I was rather surprised and disappointed that it really didn't go into depth at all. These areas of computer science have become niche areas, a fact that will become a problem as the older generation of computer scientists retire. More people need to be educated about low-level computer science, and the area needs a better name. This is a secondary goal of the project.

For more information, see the About page. See the Projects and Tools page to see what we're currently working on, and see the Blog to learn about new things and updates!

