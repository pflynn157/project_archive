## Uno

Uno is a server-side web framework designed to create a unified way of writing web applications. It aims to create a single language that can combine HTML, CSS, and JavaScript, while providing server-side like functionality.
