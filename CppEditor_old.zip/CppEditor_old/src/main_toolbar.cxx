// Copyright 2017-2018 Patrick Flynn
//
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, 
//	this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, this 
//	list of conditions and the following disclaimer in the documentation and/or 
//	other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors may 
//	be used to endorse or promote products derived from this software 
//	without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE..
#include <QIcon>
#include <QPixmap>
#include <QFont>
#include <QUrl>
#include <QCursor>
#include <QVariant>
#include <QStringList>
#include <KF5/KSyntaxHighlighting/Definition>
#ifdef _WIN32
#include <settings.hh>
#else
#include <cpplib/settings.hh>
#endif

#include "main_toolbar.hh"
#include "global/slots.hh"
#include "global/css.hh"
#include "tabpane.hh"
#include "lang/lang-parser.hh"
#include "global.hh"

QComboBox *MainToolBar::syntaxmenu;
FontSpinner *MainToolBar::fontSize;

using namespace CppLib;
using namespace KSyntaxHighlighting;

MainToolBar::MainToolBar(QMainWindow *parentWindow) {
    parent = parentWindow;
    this->setStyleSheet(CssManager::stylesheetContent("toolbar"));
    this->setContextMenuPolicy(Qt::PreventContextMenu);

    newFile = new ToolButton("newFile");
    openFile = new ToolButton("openFile");
    saveFile = new ToolButton("saveFile");
    saveFileAs = new ToolButton("saveFileAs");
    cut = new ToolButton("cut");
    copy = new ToolButton("copy");
    paste = new ToolButton("paste");
    undo = new ToolButton("undo");
    redo = new ToolButton("redo");
    syntaxmenu = new QComboBox;
    fontSize = new FontSpinner;

    syntaxmenu->setVisible(QVariant(Settings::getSetting("toolbar/syntaxmenu","true")).toBool());
    auto list = repository->definitions();
    QStringList syntaxItems;
    for (int i = 0; i<list.size(); i++) {
        syntaxItems.push_back(list.at(i).name());
    }
    syntaxItems.sort(Qt::CaseInsensitive);
    syntaxItems.push_front("Plain Text");
    syntaxmenu->addItems(syntaxItems);

    QPixmap newFileIcon(":/icons/document-new.png");
    QPixmap openFileIcon(":/icons/document-open.png");
    QPixmap saveFileIcon(":/icons/document-save.png");
    QPixmap saveFileAsIcon(":/icons/document-save-as");
    QPixmap cutIcon(":/icons/edit-cut.png");
    QPixmap copyIcon(":/icons/edit-copy.png");
    QPixmap pasteIcon(":/icons/edit-paste.png");
    QPixmap undoIcon(":/icons/edit-undo.png");
    QPixmap redoIcon(":/icons/edit-redo.png");

#ifdef NO_THEME_ICONS
    newFile->setIcon(newFileIcon);
    openFile->setIcon(openFileIcon);
    saveFile->setIcon(saveFileIcon);
    saveFileAs->setIcon(saveFileAsIcon);
    cut->setIcon(cutIcon);
    copy->setIcon(copyIcon);
    paste->setIcon(pasteIcon);
    undo->setIcon(undoIcon);
    redo->setIcon(redoIcon);
#else
    newFile->setIcon(QIcon::fromTheme("document-new", newFileIcon));
    openFile->setIcon(QIcon::fromTheme("document-open", openFileIcon));
    saveFile->setIcon(QIcon::fromTheme("document-save", saveFileIcon));
    saveFileAs->setIcon(QIcon::fromTheme("document-save-as", saveFileAsIcon));
    cut->setIcon(QIcon::fromTheme("edit-cut",cutIcon));
    copy->setIcon(QIcon::fromTheme("edit-copy",copyIcon));
    paste->setIcon(QIcon::fromTheme("edit-paste",pasteIcon));
    undo->setIcon(QIcon::fromTheme("edit-undo",undoIcon));
    redo->setIcon(QIcon::fromTheme("edit-redo",redoIcon));
#endif

    newFile->setToolTip(trans("New file"));
    openFile->setToolTip(trans("Open a file"));
    saveFile->setToolTip(trans("Save current file"));
    saveFileAs->setToolTip(trans("Save current file as"));
    fontSize->setToolTip(trans("Change font size"));

    connect(newFile,&ToolButton::clicked,new Slots,&Slots::newFileSlot);
    connect(openFile,&ToolButton::clicked,new Slots,&Slots::openFileSlot);
    connect(saveFile,&ToolButton::clicked,new Slots,&Slots::saveFileSlot);
    connect(saveFileAs,&ToolButton::clicked,new Slots,&Slots::saveFileAsSlot);
    connect(cut,&ToolButton::clicked,new Slots,&Slots::cutSlot);
    connect(copy,&ToolButton::clicked,new Slots,&Slots::copySlot);
    connect(paste,&ToolButton::clicked,new Slots,&Slots::pasteSlot);
    connect(undo,&ToolButton::clicked,new Slots,&Slots::undoSlot);
    connect(redo,&ToolButton::clicked,new Slots,&Slots::redoSlot);
    connect(syntaxmenu,SIGNAL(currentTextChanged(QString)),this,SLOT(onComboTextChanged(QString)));
    connect(fontSize,SIGNAL(valueChanged(int)),this,SLOT(onFontSizeChanged()));

    this->addWidget(newFile);
    this->addWidget(openFile);
    this->addWidget(saveFile);
    this->addWidget(saveFileAs);
    this->addSeparator();
    this->addWidget(cut);
    this->addWidget(copy);
    this->addWidget(paste);
    this->addWidget(undo);
    this->addWidget(redo);
    this->addSeparator();
    this->addWidget(syntaxmenu);
    this->addWidget(fontSize);
}

MainToolBar::~MainToolBar() {
    delete newFile;
    delete openFile;
    delete saveFile;
    delete saveFileAs;
    delete cut;
    delete copy;
    delete paste;
    delete syntaxmenu;
    delete fontSize;
}

void MainToolBar::onFontSizeChanged() {
    QFont font = TabPane::currentWidget()->font();
    font.setPointSize(fontSize->value());
    TabPane::currentWidget()->setFont(font);
}

void MainToolBar::onComboTextChanged(QString item) {
    TabPane::currentWidget()->syntaxHighlight(item);
}
