#include <stdio.h>
#include <stdlib.h>

#include <vm_file.h>
#include <opcodes.h>

char *getLine(FILE *file) {
    long pos = ftell(file);
    long length = 0;
    char c = 0;
    
    while (feof(file) == 0) {
        c = fgetc(file);
        ++length;
        
        if (c == '\n') {
            break;
        }
    }
    
    if (length == 0) return NULL;
    
    // Rewrind the file, and setup the string pointer
    fseek(file, pos + length, SEEK_SET);
    char *str = malloc(sizeof(char) * length + 1);
    
    for (int i = 0; i<length; i++) {
        str[i] = fgetc(file);
    }
    str[length] = 0;
    
    return str;
}

int main(int argc, char *argv[]) {
    if (argc == 1) {
        printf("Fatal: No input specified.\n");
        return 1;
    }
    
    // The file we are building
    const char *input = argv[1];
    
    // Create a VM object
    VM *vm = malloc(sizeof(VM));
    
    // Read the file line by line, and assemble
    FILE *file = fopen(input, "r");
    
    char *line = getLine(file);
    while (line != NULL) {
        printf("LN: %s\n", line);
        
        line = getLine(file);
    }
    
    fclose(file);
    free(vm);
    
    return 0;
}

