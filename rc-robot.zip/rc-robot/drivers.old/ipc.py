from sysv_ipc import *

def ipc_gen_key(name):
	key = ftok(name, 747)
	mem = SharedMemory(key, flags=IPC_CREAT, size=1024)
	return mem
	
def ipc_write(data, mem):
	mem.write(data.encode())
	
def ipc_read(mem):
	return mem.read().decode()
	
def ipc_cleanup(mem):
	mem.remove()
	mem.detach()

