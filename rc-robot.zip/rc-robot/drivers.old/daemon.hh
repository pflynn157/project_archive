#pragma once

void sleep(int sec);
void start_daemon();
