//OUTPUT
//END

//RET 15

int
main()
{
	int x;
	int *p;
	int **pp;
    int ***ppp;
    
    x = 15;
	p = &x;
	pp = &p;
    ppp = &pp;
    
    return ***ppp;
}
