#pragma once

#include <vector>
#include <map>

struct Instruction {
	unsigned char opcode;
	unsigned char type;
	int operand;
	std::string s_operand;
};

class VM {
public:
	void load(const char *path);
	void run();
private:
	int counter = 0;
	std::vector<Instruction> instructions;
	std::map<int, int> branches;	
};
