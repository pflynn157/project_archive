#include "string.hh"

//Returns the length of a string
size_t strlen(const char* str) {
	size_t len = 0;
	while (str[len])
		len++;
	return len;
}

//strcpy function
char *strcpy(char *s1, const char *s2) {
	char *dst = s1;
	const char *src = s2;
	/* Do the copying in a loop.  */
	while ((*dst++ = *src++) != '\0')
		;               /* The body of this loop is left empty. */
	/* Return the destination string.  */
	return s1;
}

//strcat function
char *strcat(char *s1, const char *s2) {
	char *s = s1;
	/* Move s so that it points to the end of s1.  */
	while (*s != '\0')
		s++;
	/* Copy the contents of s2 into the space at the end of s1.  */
	strcpy(s, s2);
	return s1;
}

//strcmp function
int strcmp(const char *s1, const char *s2) {
	unsigned char uc1, uc2;
	/* Move s1 and s2 to the first differing characters 
        in each string, or the ends of the strings if they
        are identical.  */
	while (*s1 != '\0' && *s1 == *s2) {
		s1++;
		s2++;
	}
	/* Compare the characters as unsigned char and
        return the difference.  */
	uc1 = (*(unsigned char *) s1);
	uc2 = (*(unsigned char *) s2);
	return ((uc1 < uc2) ? -1 : (uc1 > uc2));
}

//Clears an array of characters
void clearArray(char *arr, int len) {
	for (int i = 0; i<len; i++) {
		arr[i] = 0;
	}
}
