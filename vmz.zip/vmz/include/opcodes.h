#pragma once

// Opcodes
typedef enum {
    PUSHC = 0xA1,
    
    IADD = 0xA3,
    
    RETVOID = 0x92,
    
    EXIT = 0x86,
    IPRINT = 0x87
} Opcode;

