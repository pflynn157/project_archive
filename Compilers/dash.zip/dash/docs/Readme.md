## Docs

Contains various documentation on Dash.

Please note that some of it is a little lacking. I'm sorry in advance.
