#include <stdio.h>
#include <stdlib.h>

#include <ltac/ltac.h>

LtacFile *ltac_create_file(const char *name)
{
    LtacFile *file = malloc(sizeof(LtacFile));
    file->file_name = name;

    file->data = malloc(sizeof(LtacData)*10);
    file->data_loco = 0;
    file->data_max = 10;

    file->code = malloc(sizeof(LtacInstr)*10);
    file->code_loco = 0;
    file->code_max = 10;
}

void ltac_add_data(LtacFile *file, LtacData *data)
{
    int loco = file->data_loco;
    int max = file->data_max;

    if (loco >= max)
    {
        max = max + (max / 2);
        file->data = realloc(file->data, sizeof(LtacData)*max);
        file->data_max = max;
    }

    file->data[loco] = data;
    file->data_loco = loco + 1;
}

void ltac_add_code(LtacFile *file, LtacInstr *instr)
{
    int loco = file->code_loco;
    int max = file->code_max;

    if (loco >= max)
    {
        max *= 2;
        file->code = realloc(file->code, sizeof(LtacInstr)*max);
        file->code_max = max;
    }

    file->code[loco] = instr;
    file->code_loco = loco + 1;
}

// Data segment elements
LtacData *ltac_create_data(LtacType type)
{
    LtacData *data = malloc(sizeof(LtacData));
    data->type = type;
    return data;
}

LtacData *ltac_create_string(const char *name, const char *val)
{
    LtacData *str = ltac_create_data(LD_String);
    str->name = name;
    str->value = val;
    return str;
}

// Instruction elements
LtacInstr *ltac_create_instr(LtacType type)
{
    LtacInstr *instr = malloc(sizeof(LtacInstr));
    instr->type = type;
    return instr;
}

LtacInstr *ltac_create_func(const char *name)
{
    LtacInstr *instr = ltac_create_instr(LT_Func);
    instr->str_val1 = name;
    return instr;
}

LtacInstr *ltac_create_pusharg(LtacType type)
{
    LtacInstr *instr = ltac_create_instr(LT_PushArg);
    instr->int_val1 = type;
    return instr;
}

LtacInstr *ltac_create_func_call(const char *name)
{
    LtacInstr *instr = ltac_create_instr(LT_FuncCall);
    instr->str_val1 = name;
    return instr;
}

LtacInstr *ltac_create_ret(LtacType type)
{
    LtacInstr *instr = ltac_create_instr(LT_Return);
    instr->int_val1 = type;
    return instr;
}

LtacInstr *ltac_create_var(const char *name, DataType type)
{
    LtacInstr *instr = ltac_create_instr(LT_VarDec);
    instr->str_val1 = name;
    instr->int_val1 = type;
    return instr;
}

LtacInstr *ltac_assign_int_var(const char *name, int type)
{
    LtacInstr *instr = ltac_create_instr(LT_IVarAssign);
    instr->str_val1 = name;
    instr->int_val1 = type;
    return instr;
}

// Debug
void ltac_print_data(LtacData *element)
{
    printf("  ");

    switch (element->type)
    {
        case LD_String: printf("%s .string \"%s\"\n", element->name, element->value); break;
        case LD_Float: break;
        default: puts("Unknown data element!");
    }
}

void ltac_print_code(LtacInstr *code)
{
    if (code->type == LT_Func)
    {
        printf("func %s\n", code->str_val1);
        return;
    }

    printf("  ");

    switch (code->type)
    {
        case LT_PushArg:
        {
            switch (code->int_val1)
            {
                case T_Const: printf("pusharg_c %d\n", code->int_val2); break;
                case T_Addr: printf("pusharg_addr\n"); break;
                case T_NameAddr: printf("pusharg_na %s\n", code->str_val2); break;
                case T_Reg: printf("pusharg_r %d\n", code->int_val2); break;
            }
        } break;

        case LT_FuncCall: printf("call %s\n", code->str_val1); break;

        case LT_Return:
        {
            printf("ret ");

            switch (code->int_val1)
            {
                case OP_Imm: printf("%d\n", code->int_val2); break;
                case OP_Var: printf("%s\n", code->str_val2); break;
                case OP_Reg: printf("%d\n", code->int_val2); break;
                default: puts("");
            }
        } break;

        case LT_VarDec:
        {
            printf("newvar %s (", code->str_val1);
            print_datatype(code->int_val1);
            printf(")\n");
        } break;

        case LT_IVarAssign:
        {
            switch (code->int_val1)
            {
                case OP_Imm: printf("movii %s, %d\n", code->str_val1, code->int_val2); break;
                case OP_Var: printf("moviv %s, %s\n", code->str_val1, code->str_val2); break;
                case OP_Reg: printf("movir %s, %d\n", code->str_val1, code->int_val2); break;
            }
        } break;

        default: puts("Unknown instruction.");
    }
}

void ltac_print_file(LtacFile *file)
{
    printf("File: %s\n\n", file->file_name);

    puts(".data");
    for (int i = 0; i<file->data_loco; i++)
        ltac_print_data(file->data[i]);

    printf("\n.code\n");
    for (int i = 0; i<file->code_loco; i++)
        ltac_print_code(file->code[i]);
}
