#pragma once

#include <QStringList>
#include <QString>
#include <QtXml>

class Repository {
public:
    static QStringList syntaxList();
    static QString defForName(QString name);
    static QString defForFileName(QString name);
    static QStringList themeList();
    static QString themeForName(QString name);
private:
    static QStringList getEntries(QString path);
    static QDomDocument *getDocument(QString path);
    static QString getName(QString path);
    static QStringList getExtensions(QString path);
};

