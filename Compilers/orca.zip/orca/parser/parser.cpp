#include <fstream>
#include <cstdlib>

#include <parser.hpp>

AstTree *buildAst(std::string path, std::string name) {
    auto tree = new AstTree(name);
    parse(path.c_str(), tree);
    return tree;
}

void printAst(AstTree *ast, std::string output) {
    auto dot = ast->writeDot();
    
    std::ofstream writer(output + ".dot");
    writer << dot << std::endl;
    writer.close();
    
    std::string cmd = "dot " + output + ".dot -Tpng -o " + output + ".png";
    system(cmd.c_str());
}
