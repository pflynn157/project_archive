#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <stack>

#include <bytecode.hh>

#include "vm.hh"

//Reads our binary
void VM::load(const char *path) {
	std::ifstream reader(path, std::ios::binary);
	
	if (!reader.is_open()) {
		std::cout << "Fatal: Unable to open input!" << std::endl;
		std::exit(1);
	}
	
	//Check the header
	char head[5];
	reader.read(head, 5);
	
	for (int i = 0; i<5; i++) {
		if ((unsigned char)head[i] != header[i]) {
			std::cout << "Fatal: Invalid header" << std::endl;
			std::cout << "Symbol: " << head[i] << std::endl;
			std::exit(2);
		}
	}
	
	//First, load the file
	char buf[2];
	char sbuf[100];
	int n;
	
	for (int i = 0; i<100; i++) {
		sbuf[i] = '\0';
	}
	
	while (reader) {
		reader.read(buf, 2);
		auto cmd = (unsigned char)buf[0];
		auto type = (unsigned char)buf[1];
		
		reader.read(reinterpret_cast<char *>(&n), sizeof(int));
		std::string sop = "";
		
		if (cmd == ByteCode::LBL) {
			branches[n] = counter;
		} else if (cmd == ByteCode::S_LOAD) {
			reader.read(sbuf, n);
			sop = std::string(sbuf);
			
			for (int i = 0; i<n; i++) {
				sbuf[i] = '\0';
			}
		}
		
		Instruction i;
		i.opcode = cmd;
		i.type = type;
		i.operand = n;
		i.s_operand = sop;
		instructions.push_back(i);
		
		counter++;
	}
	
	reader.close();
}

void VM::run() {	
	//Now run
	std::stack<int> runtime;
	std::vector<int> ivars;
	std::stack<std::string> s_runtime;
	int cmp_result = 0;						//0- equal; -1- less, 1, greater
	int programCounter = 0;
	
	while (programCounter < counter) {
		auto instr = instructions.at(programCounter);
		
		if (instr.type == ByteCode::TYPE_DEC) {
			std::cout << "DEC!" << std::endl;
			programCounter++;
			continue;
		}
		
		switch (instr.opcode) {
			//Integer load
			case ByteCode::I_LOAD: {
				runtime.push(instr.operand);
			} break;
			 
			//Integer add
			case ByteCode::I_ADD: {
				int n1 = runtime.top();
				runtime.pop();
					
				int n2 = runtime.top();
				runtime.pop();
					
				int answer = n1+n2;
				runtime.push(answer);
			} break;
			
			//Integer subtraction
			case ByteCode::I_SUB: {
				int n1 = runtime.top();
				runtime.pop();
					
				int n2 = runtime.top();
				runtime.pop();
					
				int answer = n1-n2;
				runtime.push(answer);
			} break;
			
			//Integer multiplication
			case ByteCode::I_MUL: {
				int n1 = runtime.top();
				runtime.pop();
					
				int n2 = runtime.top();
				runtime.pop();
					
				int answer = n1*n2;
				runtime.push(answer);
			} break;
			
			//Integer division
			case ByteCode::I_DIV: {
				int n1 = runtime.top();
				runtime.pop();
					
				int n2 = runtime.top();
				runtime.pop();
					
				int answer = n1/n2;
				runtime.push(answer);
			} break;
			
			//Integer modulus
			case ByteCode::I_MOD: {
				int n1 = runtime.top();
				runtime.pop();
					
				int n2 = runtime.top();
				runtime.pop();
					
				int answer = n1%n2;
				runtime.push(answer);
			} break;
			
			//Integer print
			case ByteCode::I_PRINT: {
				int n = runtime.top();
				std::cout << n << std::endl;
			} break;
			
			//Integer input
			case ByteCode::I_INPUT: {
				int n = 0;
				std::cin >> n;
				runtime.push(n);
			} break;
			
			//Integer variable declaration
			case ByteCode::I_VAR: {
				ivars.push_back(0);
			} break;
			
			//Integer storage
			case ByteCode::I_STORE: {
				int n = runtime.top();
				runtime.pop();
				ivars[instr.operand] = n;
			} break;
			
			//Integer loading to stack
			case ByteCode::I_LOAD_VAR: {
				int n = ivars.at(instr.operand);
				runtime.push(n);
			} break;
			
			//String load
			case ByteCode::S_LOAD: {
				s_runtime.push(instr.s_operand);
			} break;
			
			//String print
			case ByteCode::S_PRINT: {
				auto str = s_runtime.top();
				std::cout << str << std::endl;
			} break;
			
			//Label
			case ByteCode::LBL: {
			} break;
			
			//Unconditional jump
			case ByteCode::JMP: {
				programCounter = branches[instr.operand];
			} break;
			
			//Jump on equality
			case ByteCode::JE: {
				if (cmp_result == 0) {
					programCounter = branches[instr.operand];
				}
			} break;
			
			//Jump on inequality
			case ByteCode::JNE: {
				if (cmp_result != 0) {
					programCounter = branches[instr.operand];
				}
			} break;
			
			//Compare integers
			case ByteCode::I_CMP: {
				int n = runtime.top();
				
				if (n == instr.operand) {
					cmp_result = 0;	
				} else if (n > instr.operand) {
					cmp_result = 1;
				} else if (n < instr.operand) {
					cmp_result = -1;
				}
			} break;
			
			//VM exit
			case ByteCode::EXIT: {
				std::exit(0);
			} break;
			
			//Unknown opcode
			default:
				std::cout << "What??" << std::endl;
		}
		
		programCounter++;
	}
}

