package main

import "fmt"

func main() {
	msg := "Hello!"
	fmt.Println("The message:", msg)
	
	for _, c := range msg {
		fmt.Printf("%c\n",c)
	}
}
