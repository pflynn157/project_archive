#include <cstdlib>

#include <parser.hpp>
#include <amd64/amd64.hpp>

#include <ltac_build.hpp>

#include "compiler.hpp"

// Generate an AST
AstTree *getAstTree(std::string input, std::string unitName) {
    auto ast = buildAst(input, unitName);
    return ast;
}

// Generate an LTAC file from the AST
LtacFile *getLtacFile(AstTree *input, std::string unitName) {
    auto file = new LtacFile(unitName + ".asm");
    
    auto builder = new LtacBuilder(file);
    builder->buildLtac(input);
    
    return file;
}

// Translate LTAC to Assembly
void compile(LtacFile *input) {
    auto asmGen = new Amd64(input);
    asmGen->assemble();
}

// Translate the assembly to binary
void assemble(std::string path, std::string output) {
    std::string cmd = "asmx86 " + path + " -o " + output;
    system(cmd.c_str());
}

// Link the object
void link(std::string path, std::string output, std::vector<std::string> libs, bool useStdlib) {
    std::string cmd = "ld " + path + " -o " + output + " ";
    
    if (useStdlib) {
        cmd += "/usr/lib/crti.o ";
        cmd += "/usr/lib/crtn.o ";
        cmd += "/usr/lib/crt1.o ";
        cmd += "-lc -dynamic-linker /lib64/ld-linux-x86-64.so.2 ";
    }
    
    for (auto lib : libs)
        cmd += lib;
    
    system(cmd.c_str());
}
