#include <iostream>
#include <cctype>

#include "conf_lex.hpp"

namespace Config {

// The token debug function
Token::Token() {
    type = EmptyToken;
    id_val = "";
    i32_val = 0;
}

// The scanner functions
Scanner::Scanner(std::string input) {
    reader = std::ifstream(input.c_str());
    if (!reader.is_open()) {
        std::cout << "Unknown input file: " << input << std::endl;
        error = true;
    }
}

Scanner::~Scanner() {
    reader.close();
}

void Scanner::rewind(Token token) {
    token_stack.push(token);
}

// The main scanning function
Token Scanner::getNext() {
    if (token_stack.size() > 0) {
        Token top = token_stack.top();
        token_stack.pop();
        return top;
    }

    Token token;
    if (reader.eof()) {
        token.type = Eof;
        return token;
    }
    
    for (;;) {
        char next = reader.get();
        if (reader.eof()) {
            token.type = Eof;
            break;
        }
        
        rawBuffer += next;
        
        /*if (next == '#') {
            while (next != '\n' && !reader.eof()) {
                next = reader.get();
                rawBuffer += next;
            }
            ++currentLine;
        }*/
        
        // TODO: This needs some kind of error handleing
        if (next == '\'') {
            char c = reader.get();
            rawBuffer += c;
            if (c == '\\') {
                c = reader.get();
                if (c == 'n') {
                    c = '\n';
                    rawBuffer += c;
                }
            }
        
            Token charL;
            charL.i8_val = c;
            charL.type = CharL;
            
            next = reader.get();
            rawBuffer += next;
            return charL;
        }
        
        if (next == '\"') {
            if (inQuote) {
                Token str;
                str.type = String;
                str.id_val = buffer;
                
                buffer = "";
                inQuote = false;
                return str;
            } else {
                inQuote = true;
                continue;
            }
        }
        
        if (inQuote) {
            if (next == '\\') {
                next = reader.get();
                rawBuffer += next;
                switch (next) {
                    case 'n': buffer += '\n'; break;
                    case 't': buffer += '\t'; break;
                    default: buffer += '\\' + next;
                }
            } else {
                buffer += next;
            }
            continue;
        }
        
        if (next == ' ' || next == '\n' || isSymbol(next)) {
            if (buffer.length() == 0) {
                if (isSymbol(next)) {
                    Token sym;
                    sym.type = getSymbol(next);
                    return sym;
                }
                continue;
            }
            
            // Check if we have a symbol
            // Here, we also check to see if we have a floating point
            if (next == '.') {
                if (isInt()) {
                    buffer += ".";
                    continue;
                } else {
                    Token sym;
                    sym.type = getSymbol(next);
                    token_stack.push(sym);
                }
            } else if (isSymbol(next)) {
                Token sym;
                sym.type = getSymbol(next);
                token_stack.push(sym);
            }
            
            // Now check the buffer
            token.type = getKeyword();
            if (token.type != EmptyToken) {
                buffer = "";
                break;
            }
            
            if (isInt()) {
                token.type = Int32;
                token.i32_val = std::stoi(buffer);
            } else {
                token.type = Id;
                token.id_val = buffer;
            }
            
            // Reset everything
            buffer = "";
            break;
        } else {
            buffer += next;
        }
    }
    
    return token;
}

std::string Scanner::getRawBuffer() {
    std::string ret = rawBuffer;
    rawBuffer = "";
    return ret;
}

bool Scanner::isSymbol(char c) {
    switch (c) {
        case '{':
        case '}':
        case ':':
        case ';': return true;
    }
    return false;
}

TokenType Scanner::getKeyword() {
    if (buffer == "router") return Router;
    else if (buffer == "generator") return Generator;
    else if (buffer == "singleFile") return SingleFile;
    else if (buffer == "on") return On;
    else if (buffer == "off") return Off;
    return EmptyToken;
}

TokenType Scanner::getSymbol(char c) {
    switch (c) {
        case '{': return LBrace;
        case '}': return RBrace;
        case ':': return Colon;
        case ';': return SemiColon;
    }
    return EmptyToken;
}

bool Scanner::isInt() {
    for (char c : buffer) {
        if (!isdigit(c)) return false;
    }
    return true;
}

/////////////////////////////////////////////
// The debug function
void Token::print() {
    switch (type) {
        case Eof: std::cout << "END" << std::endl; break;
        case Router: std::cout << "router" << std::endl; break;
        case Generator: std::cout << "generator" << std::endl; break;
        case SingleFile: std::cout << "singleFile" << std::endl; break;
        case On: std::cout << "on" << std::endl; break;
        case Off: std::cout << "off" << std::endl; break;
        case Id: std::cout << "id(" << id_val << ")" << std::endl; break;
        case String: std::cout << "str(" << id_val << ")" << std::endl; break;
        case CharL: std::cout << "char" << std::endl; break;
        case Int32: std::cout << "int(" << i32_val << ")" << std::endl; break;
        case LBrace: std::cout << "{" << std::endl; break;
        case RBrace: std::cout << "}" << std::endl; break;
        case Colon: std::cout << ":" << std::endl; break;
        case SemiColon: std::cout << ";" << std::endl; break;
        default: std::cout << "??" << std::endl;
    }
}

}