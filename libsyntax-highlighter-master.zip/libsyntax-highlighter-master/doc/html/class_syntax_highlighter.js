var class_syntax_highlighter =
[
    [ "SyntaxHighlighter", "class_syntax_highlighter.html#af3f5920d0692fdb6c1cebeba5e3e29a9", null ],
    [ "getCurrentFile", "class_syntax_highlighter.html#a3b589c2a912d66332fd79b5f36e4c249", null ],
    [ "getCurrentName", "class_syntax_highlighter.html#a757237abb846f5fe630f8c50ab50bc6c", null ],
    [ "highlightBlock", "class_syntax_highlighter.html#a2633163bedde0a890f27d4d47614f1ad", null ]
];