#!/bin/bash

if [[ ! -d ./build ]] ; then
    mkdir ./build
fi

FLAGS="`pkg-config --cflags --libs gtk+-3.0` `pkg-config --cflags --libs gtksourceview-4` -g"

gcc $FLAGS -c src/main.c -o build/main.o
gcc $FLAGS -c src/window.c -o build/window.o
gcc $FLAGS -c src/tabpane.c -o build/tabpane.o
gcc $FLAGS -c src/actions.c -o build/actions.o
gcc $FLAGS -c src/editor.c -o build/editor.o

gcc $FLAGS build/*.o -o build/codepad

