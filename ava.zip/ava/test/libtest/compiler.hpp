#pragma once

#include <ava/compiler/Compiler.hpp>
#include <ava/ast.hpp>

class TestCompiler : public Compiler {
public:
    explicit TestCompiler(AstTree *tree, CFlags flags) : Compiler(tree, flags) {}
protected:
    Value *compileExtendedValue(AstExpression *expr, bool isAssign = false);
};

