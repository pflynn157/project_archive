#include <cstdio>

int output1_size() {
    return 12;
}

// Outputs the following:
// mov rax, 60
// mov rdi, 5
// syscall
void output1(FILE *file) {
    int op1 = 60;
    int op2 = 5;

    fputc(0xB8, file);
    fwrite(&op1, sizeof(int), 1, file);
    
    fputc(0xBF, file);
    fwrite(&op2, sizeof(int), 1, file);
    
    fputc(0x0f, file);
    fputc(0x05, file);
}

// Outputs the following
void output2(FILE *file) {

}

 
