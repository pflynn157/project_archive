//
// Copyright 2021 Patrick Flynn
// This file is part of uds-wordpad.
// uds-wordpad is licensed under the BSD-3 license. See the COPYING file for more information.
//
#include <QPixmap>

#include <menubar/filemenu.hpp>

FileMenu::FileMenu() {
    this->setTitle("File");
    
    newFile = new QAction(QPixmap(":/icons/document-new.svg"), "New", this);
    openFile = new QAction(QPixmap(":/icons/document-open.svg"), "Open", this);
    saveFile = new QAction(QPixmap(":/icons/document-save.svg"), "Save", this);
    saveFileAs = new QAction(QPixmap(":/icons/document-save-as.svg"), "Save As", this);
    saveAll = new QAction(QPixmap(":/icons/document-save-all.svg"), "Save All", this);
    print = new QAction(QPixmap(":/icons/document-print.svg"), "Print", this);
    printPdf = new QAction(QPixmap(":/icons/pdf.svg"), "Print PDF", this);
    quit = new QAction(QPixmap(":/icons/window-close.svg"), "Quit", this);
    
    actions = new Actions;
    connect(newFile, &QAction::triggered, actions, &Actions::newFile);
    connect(openFile, &QAction::triggered, actions, &Actions::openFile);
    connect(saveFile, &QAction::triggered, actions, &Actions::saveFile);
    connect(saveFileAs, &QAction::triggered, actions, &Actions::saveFileAs);
    connect(saveAll, &QAction::triggered, actions, &Actions::saveAll);
    connect(print, &QAction::triggered, actions, &Actions::printCurrent);
    connect(printPdf, &QAction::triggered, actions, &Actions::exportCurrentPDF);
    
    this->addAction(newFile);
    this->addAction(openFile);
    this->addAction(saveFile);
    this->addAction(saveFileAs);
    this->addAction(saveAll);
    this->addSeparator();
    this->addAction(print);
    this->addAction(printPdf);
    this->addSeparator();
    this->addAction(quit);
}

FileMenu::~FileMenu() {
    delete newFile;
    delete openFile;
    delete saveFile;
    delete saveFileAs;
    delete saveAll;
    delete print;
    delete printPdf;
    delete quit;
}

