#include <iostream>

#include "cpu.hpp"

void CPU::printRegisters() {
    std::cout << "=============================" << std::endl;
    for (int i = 0; i<9; i++) {
        //std::cout << "r" << i << ": " << registers[i] << std::endl;
        printf("r%d: %d\n", i, registers[i]);
    }
    std::cout << "-----------------------------" << std::endl;
    printf("CMP Reg: %x\n", cmp_reg);
    std::cout << "=============================" << std::endl;
}

