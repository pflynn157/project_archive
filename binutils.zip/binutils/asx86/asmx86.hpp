#pragma once

#include <stdio.h>

typedef enum
{
    RAX,
    RBX,
    RCX,
    RDX,
    RSP,
    RBP,
    RSI,
    RDI,
    
    R8,
    R9,
    R10,
    R11,
    R12,
    R13,
    R14,
    R15
} Reg64;

typedef enum
{
    EAX,
    EBX,
    ECX,
    EDX,
    ESP,
    EBP,
    ESI,
    EDI,
    
    R8D,
    R9D,
    R10D,
    R11D,
    R12D,
    R13D,
    R14D,
    R15D
} Reg32;

typedef enum
{
    AL,
    BL,
    CL,
    DL,
    
    AH,
    BH,
    CH,
    DH
} Reg8;

typedef enum
{
    JMP,
    JE,
    JNE,
    JG,
    JL,
    JGE,
    JLE
} Jmp;

// The code generation functions
void amd64_mov32_imm(Reg32 dest, int imm, FILE *file);

void amd64_prefix(bool size64, bool dest64, bool src64, FILE *file);
void amd64_syscall(FILE *file);

