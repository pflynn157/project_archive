## VHDL

These are some simple programs I'm using to learn VHDL and to help me in my ECGR 2181 class.

This is my current program lineup:
* adder -> A simple interactive 8-bit adder
* prime-no -> Takes 4 numbers as inputs and returns whether they represent a prime number

