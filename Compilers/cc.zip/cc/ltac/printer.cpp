#include <iostream>
#include <fstream>
#include <string>

#include <ltac_build.hpp>
#include <ltac/math.hpp>
#include <ltac/struct.hpp>
#include <ltac/types.hpp>
#include <ltac/var.hpp>

// The main printing function for the entire file
void ltacPrint(LtacFile *file) {
    std::ofstream writer(file->getName());
    
    for (auto data : file->getData()) {
        writer << data->printData() << std::endl;
    }
    
    writer << std::endl;
    
    for (auto code : file->getCode()) {
        writer << code->printInstr() << std::endl;
    }
    
    writer.close();
}

// The individual print functions for the instructions

//========================================================
// String values (data section)

std::string LtacStringVal::printData() {
    return name + " .string \"" + val + "\"";
}

//========================================================
// Labels

std::string LtacLabel::printInstr() {
    return name + ":";
}

//========================================================
// Functions

std::string LtacFunc::printInstr() {
    std::string content = name + ":\n";
    content += "  setup " + std::to_string(stackSize) + "\n";
    return content;
}

//========================================================
// Externs

std::string LtacExtern::printInstr() {
    return "extern " + name;
}

//========================================================
// Function argument loads

std::string LtacLdArg::printInstr() {
    std::string content = "  ";
    
    switch (this->type) {
        case LtacType::LdBArg: content += "ldb_arg"; break;
        case LtacType::LdWArg: content += "ldw_arg"; break;
        case LtacType::LdDwArg: content += "lddw_arg"; break;
        case LtacType::LdQwArg: content += "ldqw_arg"; break;
        default: content += "ldarg";
    }
    
    content += " " + std::to_string(this->pos);
    return content;
}

//========================================================
// Function calls

std::string LtacFuncCall::printInstr() {
    std::string content = "";

    for (auto arg : args) {
        switch (arg->getType()) {
            case LtacType::Int: {
                content += "  pusharg_i " + arg->printInstr() + "\n";
            } break;
            
            case LtacType::String: {
                content += "  pusharg_s " + arg->printInstr() + "\n";
            } break;
            
            case LtacType::Var32: {
                content += "  pusharg_v32 " + arg->printInstr() + "\n";
            } break;
            
            case LtacType::Ptr: {
                content += "  pusharg_ptr " + arg->printInstr() + "\n";
            } break;
            
            case LtacType::Ref: {
                content += "  pusharg_ref " + arg->printInstr() + "\n";
            } break;
        }
    }
    
    content += "  call " + name + "\n";
    return content;
}

//========================================================
// Returns

std::string LtacVRet::printInstr() {
    return "  ret\n";
}

std::string LtacI32Ret::printInstr() {
    switch (strType) {
        case StrType::Const: return "  i32.ret " + std::to_string(val) + "\n"; break;
        case StrType::Mem: return "  i32.ret [bp-" + std::to_string(val) + "]\n"; break;
        case StrType::Reg: return "  i32.ret r" + std::to_string(val) + "\n"; break;
    }
    return "  i32.ret\n";
}

//========================================================
// System calls

std::string LtacSyscall::printInstr() {
    std::string content = "";

    for (auto arg : args) {
        switch (arg->getType()) {
            case LtacType::Int: {
                content += "  pushkarg_i " + arg->printInstr() + "\n";
            } break;
            
            case LtacType::String: {
                content += "  pushkarg_s " + arg->printInstr() + "\n";
            } break;
            
            case LtacType::Var32: {
                content += "  pushkarg_v32 " + arg->printInstr() + "\n";
            } break;
            
            case LtacType::Ptr: {
                content += "  pushkarg_ptr " + arg->printInstr() + "\n";
            } break;
        }
    }
    
    content += "  syscall\n";
    return content;
}

//========================================================
// Variables

std::string LtacVar32::printInstr() {
    return "[bp-" + std::to_string(pos) + "]";
}

std::string LtacPtr::printInstr() {
    return "[bp-" + std::to_string(pos) + "]";
}

std::string LtacRef::printInstr() {
    return "[bp-" + std::to_string(pos) + "]"; 
}

std::string LtacMovI32::printInstr() {
    std::string content = "";
    std::string instr = "i32.mov";

    if (ptr) {
        instr = "i32.ptr.mov";
    }
    
    content = "  " + instr + " [bp-" + std::to_string(pos);
    content += "], " + std::to_string(val) + "\n";
    
    return content;
}

std::string LtacMovV32::printInstr() {
    std::string content = "  mov [bp-" + std::to_string(dest);
    content += "], ";
    content += "[bp-" + std::to_string(src) + "]\n";
    
    return content;
}

std::string LtacLdI32::printInstr() {
    if (pos == -1) {
        return "  i32.push " + std::to_string(val);
    } else {
        return "  i32.mov r" + std::to_string(pos) + ", " + std::to_string(val);
    }
}

std::string LtacLdV32::printInstr() {
    if (pos == -1) {
        return "  i32.push [bp-" + std::to_string(val) + "]";
    } else {
        std::string content = "  i32.mov r" + std::to_string(pos);
        content += ", [bp-" + std::to_string(val) + "]";
        return content;
    }
}

std::string LtacLdPtr32::printInstr() {
    return "  i32.ptr.ld(" + std::to_string(val) 
            + ") r" + std::to_string(reg)
            + ", [bp-" + std::to_string(pos) + "]";
}

std::string LtacStrI32::printInstr() {
    if (pos == -1) {
        return "  i32.pop [bp-" + std::to_string(dest) + "]\n";
    } else {
        return "  i32.mov [bp-" + std::to_string(dest) 
            + "], r" + std::to_string(pos)
            + "\n";
    }
}

std::string LtacStrRef::printInstr() {
    std::string content = "  ldref r0, [bp-" + std::to_string(src) + "]\n";
    content += "  ptr.mov [bp-" + std::to_string(dest) + "]\n";
    return content;
}

//========================================================
// Integer math

std::string LtacI32Math::printInstr() {
    std::string content = "";
    
    if (r1 == -1 || r2 == -1) {
        content = "  i32.pop\n";
        content += "  i32.pop\n";
        content += "  i32." + op;
    } else {
        content = "  i32." + op + " ";
        content += "r" + std::to_string(r1);
        content += ", ";
        content += "r" + std::to_string(r2);
    }
    
    return content;
}
