#include <iostream>
#include <string>

#include <ava/ast.hpp>
#include <tlc/parser.hpp>

int main(int argc, char *argv[]) {
    if (argc == 1) {
        std::cerr << "Error: No input file." << std::endl;
        return 2;
    }
    
    std::string input = argv[1];
    std::cout << "Reading: " << input << std::endl;
    
    Parser parser(input);
    AstTree *tree = parser.getTree();
    int code = 0;
    
    if (tree->verify()) {
        std::cout << "Verification passed!" << std::endl;
    } else {
        std::cout << "Verification failed!" << std::endl;
        code = 1;
    }
    
    delete tree;
    
    return code;
}

