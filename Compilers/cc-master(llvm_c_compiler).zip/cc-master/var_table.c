#include <stdlib.h>
#include <string.h>

#include "var_table.h"

VarTable *var_table_create()
{
    VarTable *table = malloc(sizeof(VarTable));
    table->entries = malloc(sizeof(VarEntry *) * 10);
    table->count = 0;
    table->max = 10;
}

// TODO: Realloc check
void var_table_add(VarTable *table, VarEntry *entry)
{
    table->entries[table->count] = entry;
    table->count += 1;
}

LLVMValueRef var_table_get(VarTable *table, char *name)
{
    for (int i = 0; i<table->count; i++)
    {
        VarEntry *current = table->entries[i];
        
        if (strcmp(name, current->name) == 0)
        {
            return current->var;
        }
    }
    
    return NULL;
}

LLVMTypeRef var_table_get_type(VarTable *table, char *name)
{
    for (int i = 0; i<table->count; i++)
    {
        VarEntry *current = table->entries[i];
        
        if (strcmp(name, current->name) == 0)
        {
            return current->var_type;
        }
    }
    
    return NULL;
}

void var_table_clear(VarTable *table)
{
    for (int i = 0; i<table->count; i++)
    {
        VarEntry *current = table->entries[i];
        
        if (!current) continue;
        
        if (current->name) free(current->name);
        free(current);
    }
    
    free(table->entries);
    free(table);
}
