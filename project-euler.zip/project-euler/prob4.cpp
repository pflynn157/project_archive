#include <iostream>
#include <string>

bool check(int num) {
    std::string num1 = std::to_string(num);
    std::string num_back = "";
    
    for (int i = num1.length() - 1; i >= 0; i--)
        num_back += num1[i];
        
    return num1 == num_back;
}

int main() {
    int result = 0;
    int i, j;
    
    for (i = 999; i>=100; i--) {
        for (j = 999; j>=100; j--) {
            int current_result = i*j;
            if (check(current_result) && current_result > result) {
                result = current_result;
            }
        }
    }
    end:
    
    std::cout << "i: " << i << " | j: " << j << std::endl;
    std::cout << "Result: " << result << std::endl;

    return 0;
}
