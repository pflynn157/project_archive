#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <Kokkos_Core.hpp>

const size_t SIZE = 8;

void dump(Kokkos::View<int**> matrix) {
    for (int i = 0; i<SIZE; i++) {
        for (int j = 0; j<SIZE; j++) {
            printf("%d ", matrix(i, j));
        }
        puts("");
    }
}

int main(int argc, char **argv) {
    Kokkos::initialize(argc, argv);
    
    // Init arrays
    Kokkos::View<int**> numbers("numbers", SIZE,SIZE);
    Kokkos::View<int**> result1("result1", SIZE,SIZE);
    Kokkos::View<int**> result2("result2", SIZE,SIZE);
    
    Kokkos::parallel_for("Init", Kokkos::MDRangePolicy<Kokkos::Rank<2>>({0,0},{SIZE,SIZE}),
        KOKKOS_LAMBDA(int i, int j) {
            numbers(i, j) = rand() % 9;
        }
    );
    
    dump(numbers);
    
    // Serial
    for (int i = 0; i<SIZE; i++) {
        for (int j = 0; j<SIZE; j++) {
            result1(i,j) = numbers(i,j) * 2;
        }
    }
    
    //Kokkos
    Kokkos::parallel_for("x2", Kokkos::MDRangePolicy<Kokkos::Rank<2>>({0,0},{SIZE,SIZE}),
        KOKKOS_LAMBDA(int i, int j) {
            result2(i,j) = numbers(i, j) * 2;
        }
    );
    
    puts("============================================");
    puts("");
    puts("Serial:");
    dump(result1);
    puts("");
    puts("Parallel");
    dump(result2);
    
    return 0;
}

