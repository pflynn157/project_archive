function solve2() {
	var t1 = 1;
	var t2 = 2;
	
	var termList = [];
	var evenTerms = [];
	var rangeSize = 4000000;	//4,000,000
	var answer = 0;
	
	termList.push(t1);
	termList.push(t2);
	
	/*for (var i = 0; i<rangeSize-2; i++) {
		var newT = t1+t2;
		t1 = t2;
		t2 = newT;
		
		termList.push(t2);
	}*/
	
	while (true) {
		var newT = t1+t2;
		t1 = t2;
		t2 = newT;
		
		if (newT>=rangeSize) {
			break;
		}
		
		termList.push(t2);
	}
	
	for (var i = 0; i<termList.length; i++) {
		var current = termList[i];
		console.log(current);
		if (current%2==0) {
			evenTerms.push(current);
		}
	}
	
	for (var i = 0; i<evenTerms.length; i++) {
		answer+=Number(evenTerms[i]);
	}
	
	setOutput(answer);
}
