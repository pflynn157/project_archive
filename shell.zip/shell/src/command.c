#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <list.h>
#include <job.h>

// Parses a command
StrList *parse(const char *command)
{
    StrList *list = str_list_create_empty();
    
    int len = strlen(command);
    char *buf = malloc(sizeof(char)*len);
    int index = 0;
    
    for (int i = 0; i<=len; i++)
    {
        if (command[i] == ' ' || i == len)
        {
            char *buf2 = malloc(sizeof(char)*index);
            for (int j = 0; j<index; j++)
            {
                buf2[j] = buf[j];
                buf[j] = 0;
            }
            
            str_list_add(list, buf2);

            index = 0;
            free(buf2);
        }
        else
        {
            buf[index] = command[i];
            ++index;
        }
    }

    free(buf);

    return list;
}

// The main shell loop
char *get_line()
{
    char *ln = malloc(sizeof(char)*10);
    char c = 0;
    
    int index = 0;
    int size = 10;

    for (;;)
    {
        c = fgetc(stdin);

        if (index >= size)
        {
            size += 5;
            ln = realloc(ln, sizeof(char)*size);
        }

        if (c == '\n' || c == EOF)
        {
            ln[index] = '\0';
            break;
        }
        else
        {
            ln[index] = c;
            ++index;
        }
    }

    fflush(stdin);
    return ln;
}

void run_shell()
{
    for (;;)
    {
        printf("> ");
        
        char *ln = get_line();
        char *ln2 = strdup(ln);

        if (strcmp(ln2, "exit") == 0)
        {
            break;
        }
        else
        {
            StrList *cmd = parse(ln);
            run_job(cmd);
            free(cmd);
        }
    }
}
