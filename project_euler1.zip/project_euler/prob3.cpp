#include <iostream>
#include <cmath>

bool isPrime(long no) {
	if (no%2==0 || no%3==0 || no%5 == 0 || no%7==0) {
		return false;
	} else {
		long sqr = sqrt(no);
		for (long i = 5; i<sqr; i+=6) {
			if (no%i==0 || no%(i+2)==0) {
				return false;
			}
		}
		return true;
	}
}

int main() {
	//We use the commented-out start for testing
	//long start = 13195;
	long start = 600851475143;
	long answer = 0;
	
	long sqr = sqrt(start);
	for (long i = sqr+1; i>0; i-=2) {
		std::cout << i << std::endl;
		//Our number must be divisible by the current index
		//If not, then it isn't a factor, and not a consideration
		if (start%i==0) {
			if (isPrime(i)) {
				answer = i;
				break;
			}
		}
	}
	
	std::cout << "Answer: " << answer << std::endl;
	return 0;
}
