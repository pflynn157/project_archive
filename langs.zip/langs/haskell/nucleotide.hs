-- nucleotide.hs
-- Counts how many of each nucleotide is in a give DNA strand
-- Nucleotides: A, C, G, T
module Main(main) where

count_char :: String -> Char -> Int -> Int
count_char [] _ n = n
count_char (s:str) c n
    | s == c = count_char str c (n+1)
    | otherwise = count_char str c n

main = do
    let dna = "AACCGGTTACGTTTGG"
    let ac = count_char dna 'A' 0
    let cc = count_char dna 'C' 0
    let gc = count_char dna 'G' 0
    let tc = count_char dna 'T' 0
    
    putStrLn $ "DNA: " ++ dna
    putStrLn $ "A Count: " ++ (show ac)
    putStrLn $ "C Count: " ++ (show cc)
    putStrLn $ "G Count: " ++ (show gc)
    putStrLn $ "T Count: " ++ (show tc)
