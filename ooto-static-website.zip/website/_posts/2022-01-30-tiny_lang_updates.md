---
layout: post
title:  "Tiny Lang: Updates"
date:   2022-01-30
categories: updates "tiny lang"
---

This is actually more about updates to the reference implementation than the language itself. I was working on a new compiler project that I forked from Tiny Lang, and I was very happy with the changes (they were much needed to-do list items anyway…), so I decided to add them back to the Tiny codebase. Its not a huge update, but its worth noting.

The first update is an optional semantic change to the way structures are handled (this only affects compiled implementations). Originally, structures were allocated within the stack, and passed by copy to other functions. This is poor design and a pain for obvious reasons. To make things easier, structures are allocated on the heap and passed by reference everywhere else. This change only affects the compiled LLVM implementation. At the time of writing, I haven’t made any changes to the LLIR implementation.

The second update is within the frontend. I finally did a much needed rewrite of the expression parser. Rather than the overly complicated set of parameters, it takes fewer parameters and returns an expression object, which is more portable across use cases. I also made a change to statement and function call AST objects. All statements only have one expression object. For function calls and potentially any other statements that require an expression list, an object called the AstExprList is used.

Finally, the boolean operators AND (`&&`) and OR (`||`) are now fully supported in the compilers- both the LLIR and the LLVM versions. The LLVM originally had a version that implemented this, but they relied on the newer LLVM 13 API. The new solution works just as well with existing APIs, and can be used within LLIR.

Don’t hesitate to send any suggestions for the project!

