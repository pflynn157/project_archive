#pragma once

#include <vm_file.h>

// Load-based functions
void vm_load(VM *vm, const char *input);

// Debug functions
void vm_debug(VM *vm);

// VM-based functions
void vm_run(VM *vm);

