package co.patrickflynn.notetaker.ui.creator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.Toast
import co.patrickflynn.notetaker.CWD
import co.patrickflynn.notetaker.R
import java.io.File

class ItemCreator : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_item_creator)
        title = "New Item"

        // Get current working directory
        val cwd = intent.getStringExtra(CWD)

        // Load all the widgets
        val nameEntry = findViewById<EditText>(R.id.nameEntry)
        val fileOptionRB = findViewById<RadioButton>(R.id.fileOptionRB)
        val checklistOptionRB = findViewById<RadioButton>(R.id.checklistOptionRB)
        val folderOptionRB = findViewById<RadioButton>(R.id.folderOptionRB)

        fileOptionRB.isChecked = true

        // Handles the create button click
        val createButton = findViewById<Button>(R.id.createButton)
        createButton.setOnClickListener { view ->
            val nameEntryStr = nameEntry.text.toString()
            var path = nameEntryStr
            if (cwd != "") {
                path = cwd + "/" + nameEntryStr
            }

            if (fileOptionRB.isChecked) {
                val file = File(view.context.filesDir, path)
                file.createNewFile()
            } else if (checklistOptionRB.isChecked) {

            } else if (folderOptionRB.isChecked) {
                val file = File(view.context.filesDir, path)
                file.mkdir()
            }

            setResult(1)
            finish()
        }
    }
}