#include <iostream>

#include "cpu.hpp"

int main(int argc, char **argv) {
    CPU *cpu = new CPU;
    cpu->run();
    cpu->printRegisters();

    return 0;
}

