
use crate::ast;
use crate::ast::*;
use crate::lex::{Token, Lex, create_lex, init_lex};

use crate::ast_func::*;
use crate::ast_utils::*;

// The AST building function
pub fn build_ast(path : String, name : String) -> AstTree {   
    let mut tree = AstTree {
        file_name : name,
        functions : Vec::new(),
    };
    
    let mut scanner = create_lex();
    init_lex(path, &mut scanner);
    
    let mut token = scanner.get_token();
    
    while token != Token::Eof {
        match token {
            Token::Extern => build_extern(&mut scanner, &mut tree),
            Token::Func => build_func(&mut scanner, &mut tree),
            _ => println!("Error: {:?}", token),
        }
        
        token = scanner.get_token();
    }
    
    tree
}

pub fn build_block(scanner : &mut Lex, block : &mut Vec<AstStmt>) {
    let mut token = scanner.get_token();
    
    // TODO: Error out on EOF
    while token != Token::End && token != Token::Eof {
        match token {
            Token::Return => build_return(scanner, block),
            Token::Int => build_i32var_dec(scanner, block),
            Token::Id(ref val) => build_id(scanner, block, val.to_string()),
            _ => println!("Error (block): {:?}", token),
        }
        
        token = scanner.get_token();
    }
}

// Builds an integer variable declaration
fn build_i32var_dec(scanner : &mut Lex, block : &mut Vec<AstStmt>) {
    let mut var_dec = ast::create_stmt(AstStmtType::VarDec);
    var_dec.data_type = DataType::Int;
    
    // Gather information
    // The first token should be the name
    let mut token = scanner.get_token();
    
    // TODO: Better syntax error
    match token {
        Token::Id(ref val) => var_dec.name = val.to_string(),
        _ => println!("Error: Invalid variable name-> {:?}", token),
    }
    
    // The next token should be the assign operator
    token = scanner.get_token();
    
    // TODO: Better syntax error
    match token {
        Token::Assign => {},
        _ => println!("Error: Missing assignment"),
    }
    
    // Build the remaining arguments
    build_args(scanner, &mut var_dec, Token::SemiColon);

    // Add the declaration
    block.push(var_dec);
}

// Handles cases when an identifier is the first token
fn build_id(scanner : &mut Lex, block : &mut Vec<AstStmt>, id_val : String) {
    // If the next token is an assignment, we have a variable assignment
    // If the next token is a parantheses, we have a function call
    let token = scanner.get_token();
    
    // TODO: Better assignment
    match token {
        Token::Assign => {},
        Token::LParen => build_func_call(scanner, block, id_val),
        _ => println!("Invalid declaration or assignment"),
    }
}
