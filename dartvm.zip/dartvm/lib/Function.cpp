#include <iostream>

#include <Function.hpp>

void Function::dump() {
    std::cout << "func " << name << " {" << std::endl;

    for (Block *block : blocks) {
        block->dump();
    }

    std::cout << "}" << std::endl;
    std::cout << std::endl;
}

Function *Function::Create(Unit *unit, std::string name) {
    Function *function = new Function(name);
    unit->AddFunction(function);

    return function;
}
