module LtacBuilder(generate, scanCode, initFile,
    generateData, compile) where

import System.IO
import System.Process

import Ltac
import X64.X64
import I386.I386
import X86.X86

-- Decodes a tree and translates
-- Intel x86-64
decodeX64 writer x
    | t == Func = x64Func x writer
    | t == Ret = x64Ret x writer
    | t == PushArg = x64PushArg x writer
    | t == Call = x64Call x writer
    | t == IVar = return()
    | t == IStoreI = x64IStoreI x writer
    | t == ILdrI = x64ILdrI x writer
    | t == ILdrV = x64ILdrV x writer
    | t == IStr = x64IStr x writer
    | t == IMathRR = x64IMathRR x writer
    | otherwise = putStrLn "Unknown instruction!"
    where
        t = instr x
        
-- Intel i386 (x86 32-bit)
decodeI386 writer x
    | t == Func = i386Func x writer
    | t == Ret = i386Ret x writer
    | t == PushArg = i386PushArg x writer
    | t == Call = i386Call x writer
    | t == IVar = return()
    | t == IStoreI = i386IStoreI x writer
    | t == ILdrI = i386ILdrI x writer
    | t == ILdrV = i386ILdrV x writer
    | t == IStr = i386IStr x writer
    | t == IMathRR = i386IMathRR x writer
    | otherwise = putStrLn "Unknown instruction!"
    where
        t = instr x
        
decode writer x arch
    | arch == "x86-64" = decodeX64 writer x
    | arch == "i386" = decodeI386 writer x
    | otherwise = putStrLn ("Unknown arch: " ++ arch)
        
generate2 writer [] arch = hClose writer
generate2 writer (x:xs) arch = do
    decode writer x arch
    generate2 writer xs arch
    
generate writer code arch = do
    hPutStrLn writer ""
    hPutStrLn writer ".text"
    hPutStrLn writer ".global main"
    hPutStrLn writer ""
    generate2 writer code arch
    
-- Performs any platform-specific code operations and initializations
scanCode code arch
    | arch == "x86-64" = code
    | arch == "i386" = i386FixFc code
    | otherwise = code
    
initFile arch writer
    | arch == "x86-64" = x86Init writer
    | arch == "i386" = x86Init writer
    | otherwise = return()
    
--Decodes data
decodeData writer x
    | t == String = do
        let line = "\t" ++ (arg1 x) ++ ": .string \"" ++ (arg2 x) ++ "\""
        hPutStrLn writer line
    | t == Float = return()
    | otherwise = putStrLn "Unknown data!"
    where
        t = instr x

generateData2 writer [] = return ()
generateData2 writer (x:xs) = do
    decodeData writer x
    generateData2 writer xs
    
generateData writer code = do
    hPutStrLn writer ".data"
    generateData2 writer code
    
-- Compile
compileX64 = do
    callCommand "as /tmp/out.asm -o /tmp/out.o"
    callCommand "gcc /tmp/out.o -o out -no-pie"
    
compileI386 = do
    callCommand "as -g --32 /tmp/out.asm -o /tmp/out.o"
    callCommand "gcc -g -m32 /tmp/out.o -o out -no-pie"

compile arch
    | arch == "x86-64" = compileX64
    | arch == "i386" = compileI386
    | otherwise = putStrLn ("Unknown arch: " ++ arch)
    
