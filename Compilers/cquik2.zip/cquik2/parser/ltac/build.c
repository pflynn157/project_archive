#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <ast.h>
#include <ltac/ltac.h>
#include <ltac/build.h>

// Various control variables
DataType current_func_type = T_Void;
int str_index = 0;

// Builds a string data element
const char *ltac_build_string(LtacFile *file, AstNode *node)
{
    char num[5];
    sprintf(num, "%d", str_index);
    ++str_index;

    char *name = malloc(sizeof(char)*10);
    strcat(name, "STR");
    strcat(name, num);
    const char *name_final = strdup(name);

    LtacData *str = ltac_create_string(name, node->str_val1);
    ltac_add_data(file, str);

    return name_final;
}

// Builds a function call
void ltac_build_func_call(LtacFile *file, AstNode *node)
{
    // Start with arguments
    for (int i = 0; i<node->children->loco; i++)
    {
        AstNode *current = node->children->elements[i];

        switch (current->type)
        {
            case String:
            {
                const char *name = ltac_build_string(file, current);
                LtacInstr *instr = ltac_create_pusharg(T_NameAddr);
                instr->str_val2 = name;
                ltac_add_code(file, instr);
            } break;

            //TODO: The rest
        }
    }

    // Build the call
    LtacInstr *call = ltac_create_func_call(node->str_val1);
    ltac_add_code(file, call);
}

// Builds a return statement
void ltac_build_return(LtacFile *file, AstNode *node)
{
    if (current_func_type != T_Void && node->children->loco == 0)
    {
        //TODO: Better syntax handeling
        puts("Error: Expected return value.");
        exit(1);
    }

    if (current_func_type == T_Void)
    {
        if (node->children->loco > 0)
        {
            //TODO: Better syntax handeling
            puts("Error: Unexpected return value in void function.");
            exit(1);
        }

        LtacInstr *ret = ltac_create_ret(OP_None);
        ltac_add_code(file, ret);

        return;
    }

    // Note: When we get math, this will need to be expanded
    AstNode *value = node->children->elements[0];

    switch (value->type)
    {
        case Int:
        {
            LtacInstr *ret = ltac_create_ret(OP_Imm);
            ret->int_val2 = value->int_val1;
            ltac_add_code(file, ret);
        } break;

        //TODO: Add rest
    }
}

// Builds an integer variable operation
void ltac_build_ivar(LtacFile *file, AstNode *node)
{
    if (node->children->loco == 1)
    {
        AstNode *value = node->children->elements[0];

        if (value->type == Int)
        {
            LtacInstr *instr = ltac_assign_int_var(node->str_val1, OP_Imm);
            instr->int_val2 = value->int_val1;
            ltac_add_code(file, instr);
        }
        else
        {
            //TODO: Other variables
        }
    }
    else
    {
        //TODO: More complicated expressions
    }
}

// The main AST to LTAC loop
void ltac_build(LtacFile *file, AstNode *tree)
{
    for (int i = 0; i<tree->children->loco; i++)
    {
        AstNode *element = tree->children->elements[i];
        int build_children = 0;

        switch (element->type)
        {
            case FuncDec:
            {
                LtacInstr *fd = ltac_create_func(element->str_val1);
                ltac_add_code(file, fd);

                current_func_type = element->int_val1;
                build_children = 1;
            } break;

            case FuncCall: ltac_build_func_call(file, element); break;
            case Return: ltac_build_return(file, element); break;

            case Var:
            {
                if (element->int_val2)
                {
                    LtacInstr *vd = ltac_create_var(element->str_val1,
                                                    element->int_val1);
                    ltac_add_code(file, vd);
                }

                switch (element->int_val1)
                {
                    case T_Int: ltac_build_ivar(file, element); break;
                    case T_Float: break;
                    case T_String: break;
                    default: puts("[ltac_build] Error: Unknown datatype.");
                }
            } break;

            default: puts("[ltac_build] Error: Unknown type.");
        }

        if (build_children)
        {
            if (element->children->loco > 0)
                ltac_build(file, element);
        }
    }
}
