#include <iostream>
#include <thread>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <string.h>

void server_loop(int new_socketd) {
    std::string msg = "Welcome!\n";
    write(new_socketd, msg.c_str(), msg.length());
    
    char buffer[1024];
    int len = 1023;
    
    while (true) {
        int code = recv(new_socketd, buffer, 1024, 0);
        if (!code) {
            std::cout << "Lost connection." << std::endl;
            break;
        }
        buffer[code-2] = '\0';
        
        std::string input = std::string(buffer);
        len = input.length();
        for (int i = 0; i<len+1; i++) buffer[i] = '\0';
    
        std::cout << input << std::endl;
        if (input == "exit") break;
    }
    
    msg = "Goodbye!\n";
    write(new_socketd, msg.c_str(), msg.length());
    
    close(new_socketd);
}

int main(int argc, char **argv) {
    int socketd = socket(AF_INET, SOCK_STREAM, 0);
    if (socketd == -1) {
        std::cerr << "Error: Unable to create socket." << std::endl;
        return 1;
    }
    
    struct sockaddr_in server;
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons(8182);
    
    int one = 1;
    setsockopt(socketd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
    
    // Bind
    if (bind(socketd, (struct sockaddr *)&server, sizeof(server)) < 0) {
        std::cerr << "Error: Unable to bind." << std::endl;
        return 1;
    }
    
    // Listen
    listen(socketd, 3);
    
    // Accept any incoming connections
    std::cout << "Listening on port 8182..." << std::endl;
    
    struct sockaddr_in client;
    int c = sizeof(struct sockaddr_in);
    int new_socketd;

    while ((new_socketd = accept(socketd, (struct sockaddr *)&client, (socklen_t*)&c))) {
        std::thread thread(server_loop, new_socketd);
        thread.detach();
    }
    
    if (new_socketd < 0) {
        std::cerr << "Unable to accept connection." << std::endl;
        return 1;
    }
    
    return 0;
}