package co.patrickflynn.notetaker

import android.view.*
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.io.File

class MainListAdaptor(private val dataSet: Array<String?>, private val basePath : File, private val currentDir : String)
    : RecyclerView.Adapter<MainListAdaptor.ViewHolder>() {

    interface ItemClickListener {
        fun onItemClick(view: View?, position: Int)
    }

    lateinit var itemClickListener : ItemClickListener
    private var position = 0

    class ViewHolder(view : View) : RecyclerView.ViewHolder(view),
        View.OnClickListener, View.OnCreateContextMenuListener {

        val label : TextView
        var icon : ImageView
        lateinit var itemClickListener : ItemClickListener

        init {
            label = view.findViewById(R.id.listTextView)
            icon = view.findViewById(R.id.itemIcon)
            view.setOnClickListener(this)
            view.setOnCreateContextMenuListener(this)
        }

        override fun onClick(item: View?) {
            itemClickListener.onItemClick(item, adapterPosition)
        }

        override fun onCreateContextMenu(menu: ContextMenu?, p1: View?,
            p2: ContextMenu.ContextMenuInfo?
        ) {
            menu!!.add(Menu.NONE, R.id.rename_item,
                Menu.NONE, R.string.menu_rename)
            menu!!.add(Menu.NONE, R.id.delete_item,
                Menu.NONE, R.string.menu_delete)
        }
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(viewGroup.context)
            .inflate(R.layout.main_list_item, viewGroup, false)

        var vh = ViewHolder(view)
        vh.itemClickListener = itemClickListener
        return vh
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        var path = dataSet[position]
        if (currentDir != "") {
            path = currentDir + "/" + path
        }

        if (File(basePath, path).isDirectory) {
            holder.icon.setImageResource(R.drawable.ic_folder_icon)
        } else {
            holder.icon.setImageResource(R.drawable.ic_file_icon)
        }

        holder.label.text = dataSet[position]

        holder.itemView.setOnLongClickListener {
            setPosition(holder.adapterPosition)
            false
        }
    }

    override fun getItemCount(): Int {
        return dataSet.size
    }

    fun getItem(id: Int): String? {
        return dataSet.get(id)
    }

    fun getPosition(): Int {
        return position
    }

    fun setPosition(position: Int) {
        this.position = position
    }

    // allows clicks events to be caught
    fun setClickListener(itemClickListener: ItemClickListener) {
        this.itemClickListener = itemClickListener
    }

    override fun onViewRecycled(holder: ViewHolder) {
        holder.itemView.setOnLongClickListener(null)
        super.onViewRecycled(holder)
    }
}
