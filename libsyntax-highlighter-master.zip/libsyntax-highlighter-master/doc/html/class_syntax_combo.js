var class_syntax_combo =
[
    [ "SyntaxCombo", "class_syntax_combo.html#a5d7d13f9a4b847460415cf7b0e87e111", null ]
];