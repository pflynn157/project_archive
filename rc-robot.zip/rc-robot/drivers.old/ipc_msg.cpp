#include <iostream>
#include <string>

#include "ipc.hh"

int main() {
	std::cout << "MSG Test" << std::endl;
	std::string ln = "";
	
	int key = ipc_gen_key("led");
	
	while (true) {
		std::cout << "[LED] ";
		std::cin >> ln;
		
		ipc_write(ln, key);
		if (ln == "exitd") {
			break;
		}
	}
	
	return 0;
}
