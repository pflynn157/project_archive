#include <iostream>

int main() {
	int answer = 0;
	
	int a, b, c = 0;
	for (a = 0; a<501; a++) {
		for (b = a+1; b<501; b++) {
			for (c = b+1; c<501; c++) {
				if (a+b+c==1000) {
					if ((a*a)+(b*b)==(c*c)) {
						goto end;
					}
				}
			}
		}
	}
	
	end:
		std::cout << "a " << a << std::endl;
		std::cout << "b " << b << std::endl;
		std::cout << "c " << c << std::endl;
		answer = a*b*c;
	
	std::cout << answer << std::endl;
	return 0;
}
