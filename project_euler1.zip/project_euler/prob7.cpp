#include <iostream>
#include <cmath>

bool isPrime(long no) {
	if (no==1) {
		return false;
	} else if (no==2 || no==3 || no==5 || no==7) {
		return true;
	} else if (no%2==0 || no%3==0 || no%5 == 0 || no%7==0) {
		return false;
	} else {
		long sqr = sqrt(no);
		for (long i = 5; i<=sqr; i+=6) {
			if (no%i==0 || no%(i+2)==0) {
				return false;
			}
		}
		return true;
	}
}

int main() {
	long answer = 0;
	long stop = 10001;
	//long stop = 6;
	long noPrimes = 0;
	long index = 0;
	
	while (noPrimes<stop) {
		if (isPrime(index)) {
			answer = index;
			noPrimes++;
		}
		index++;
	}
	
	std::cout << "Answer: " << answer << std::endl;
	return 0;
}
