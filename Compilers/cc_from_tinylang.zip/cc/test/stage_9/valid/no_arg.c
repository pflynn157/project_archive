int three(){
    return 3;
}

int main() {
    return three();
}