// This tests iterating through a 3D array
#include <cstdio>
#include <Kokkos_Core.hpp>

const unsigned int NUM = 500;

int main (int argc, char* argv[]) {

  int *num1 = (int *)malloc(sizeof(int)*NUM*NUM*NUM);
  int *num2 = (int *)malloc(sizeof(int)*NUM*NUM*NUM);
  int *result1 = (int *)malloc(sizeof(int)*NUM*NUM*NUM);
  int *result2 = (int *)malloc(sizeof(int)*NUM*NUM*NUM);
  
  for (int i = 0; i<NUM; i++) {
    for (int j = 0; j<NUM; j++) {
      for (int k = 0; k<NUM; k++) {
        num1[i*NUM*j+k] = k;
        num2[i*NUM*j+k] = i*j*k;
        result1[i*NUM*j+k] = num1[i*NUM*j+k] + num2[i*NUM*j+k];
        result2[i*NUM*j+k] = 0;
      }
    }
  }

  Kokkos::initialize (argc, argv);

  {
    Kokkos::parallel_for("loop1", Kokkos::MDRangePolicy<Kokkos::Rank<3>>({0,0,0},{NUM,NUM,NUM}),
      KOKKOS_LAMBDA(const int i, const int j, const int k) {
        result2[i*NUM*j+k] = num1[i*NUM*j+k] + num2[i*NUM*j+k];
    });
  }
  
  int errors = 0;
  for (int i = 0; i<NUM; i++) {
    for (int j = 0; j<NUM; j++) {
      for (int k = 0; k<NUM; k++) {
        if (result1[i*NUM*j+k] != result2[i*NUM*j+k]) ++errors;
      }
    }
  }
  
  printf("Errors: %d\n", errors);
  
  Kokkos::finalize ();
  return 0;
}
