#!/usr/bin/python3
# This is the code for the regular drive function
import time
import threading
import pigpio
import drivers.PWM as PWM
import os

class Logger:
	def __init__(self, prog, name):
		self.prog = prog
		self.name = name
		self.contents = []
		
		path = "./records/" + str(self.prog)
		if not os.path.exists(path):
			os.makedirs(path)
		
	def record(self, item):
		self.contents.append(item)
		
	def write_out(self):
		path = "./records/" + str(self.prog)
		path += "/" + str(self.name) + ".txt"
		with open(path, "x") as writer:
			for i in self.contents:
				writer.write(str(i)+"\n")
				
		
class Servo(threading.Thread):
	def __init__(self, pi, mPin, ctrlPin, tm, logger):
		super(Servo, self).__init__()
		self.pi = pi
		self.mPin = mPin
		self.ctrlPin = ctrlPin
		self.tm = tm
		self.logger = logger

	def run(self):
		mPin = self.mPin
		ctrlPin = self.ctrlPin

		monitor = PWM.monitor(self.pi, mPin)

		self.pi.set_mode(ctrlPin, pigpio.OUTPUT)
		self.pi.set_servo_pulsewidth(ctrlPin, 1500)
		
		lastPwm = 1500
		lastTime = time.time()

		start = time.time()
		while (time.time() - start) < int(self.tm):
			pw = monitor.pulse_width()
			if pw != lastPwm:
				tm = time.time() - lastTime
				self.logger.record("pw="+str(pw))
				self.logger.record("time="+str(tm))
				lastTime = time.time()
				lastPwm = pw
				
			self.pi.set_servo_pulsewidth(ctrlPin, pw)
			
		self.pi.set_servo_pulsewidth(ctrlPin, 1500)
		self.logger.write_out()
		monitor.cancel()
		
def run(prog, tm):
	pi = pigpio.pi()
	
	esc_log = Logger(prog, "esc")
	steer_log = Logger(prog, "steering")
	
	esc = Servo(pi, 14, 15, tm, esc_log)
	esc.start()
	
	steer = Servo(pi, 3, 4, tm, steer_log)
	steer.start()
	
if __name__ == "__main__": run()
