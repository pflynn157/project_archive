#pragma once

#include <fstream>

#include <ltac/struct.hpp>

class Amd64 {
public:
    explicit Amd64(LtacFile *file);
    void assemble();
    
    void buildExtern(LtacInstr *instr);
    void buildFunc(LtacInstr *instr);
    void buildLdBArg(LtacInstr *instr);
    void buildLdWArg(LtacInstr *instr);
    void buildLdDwArg(LtacInstr *instr);
    void buildLdQwArg(LtacInstr *instr);
    void buildSyscall(LtacInstr *instr);
    void buildFuncCall(LtacInstr *instr);
    
    void buildVRet(LtacInstr *instr);
    void buildI32Ret(LtacInstr *instr);
    
    void buildMovI32(LtacInstr *instr);
    void buildMovV32(LtacInstr *instr);
    void buildLdI32(LtacInstr *instr);
    void buildLdV32(LtacInstr *instr);
    void buildLdPtr32(LtacInstr *instr);
    void buildStrI32(LtacInstr *instr);
    void buildStrRef(LtacInstr *instr);
    
    void buildI32Math(LtacInstr *instr, std::string op);
private:
    LtacFile *file;
    std::ofstream writer;
};

// Register definitions
static std::string op_regs[] = {
    "rax",
    "rbx",
    "rcx",
    "rdx"
};

static std::string op_regs32[] = {
    "eax",
    "ebx",
    "ecx",
    "edx"
};
