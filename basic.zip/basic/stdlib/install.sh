#!/bin/bash
mkdir -p /usr/local/include/basic
cp ./*.bs /usr/local/include/basic
