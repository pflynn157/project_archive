// Copyright 2019 Patrick Flynn
//
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, 
//	this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, this 
//	list of conditions and the following disclaimer in the documentation and/or 
//	other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors may 
//	be used to endorse or promote products derived from this software 
//	without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#include <iostream>

#include "funcs.hh"
#include "vars.hh"
#include "array.hh"
#include "interpreter.hh"
#include "error.hh"

#include <strutils.hh>
#include <functions.hh>

//Holds all functions for the current program
std::vector<Func> functions;

//Loads all functions into structures
void func_load(std::vector<String> contents) {
	functions = load_funcs(contents);
}

//Calls and runs a function
void func_invoke(std::string name) {
	//Find the function
	Func funcs;
	std::string nm = func_name(name);
	
	for (Func f : functions) {
		if (f.name == nm) {
			funcs = f;
			break;
		}
	}
	
	bool global = false;
	if (nm == "MAIN") {
		global = true;
	}
	
	//Load arguments
	// 1) First, get list
	std::string args_str = func_args(name);
	std::vector<std::string> args;
	std::string current = "";
	
	for (char c : args_str) {
		if (c == ',') {
			args.push_back(current);
			current = "";
		} else {
			current += c;
		}
	}
	
	if (current != "") args.push_back(current);
	
	// 2) Parse the values and match them to the structures arg list
	std::vector<Var> vars;
	
	for (int i = 0; i<args.size(); i++) {
		auto s = args.at(i);
		auto type = get_datatype(s);
		Var v = funcs.args.at(i);
		
		if (type == DataType::NONE) {
			v.val = var_val(s);
		} else {
			v.val = s;
		}
		
		vars.push_back(v);
	}
	
	// 3) Merge the variables with the local vars list
	for (Var v : vars) {
		local_vars.push_back(v);
	}
	
	//Invoke the function
	for (String s : funcs.contents) {
		interpret(s, global);
	}
	
	//Clear local variables to reset the scope
	local_vars.clear();
	local_arrs.clear();
}

