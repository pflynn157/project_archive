#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "display.hh"
#include "vga.hh"
#include "keyboard.hh"
#include "string.hh"
#include "ioasm.hh"

void init_pic() {
	//Send ICW1
	outb(0x20, 0x11);
	outb(0xA0, 0x11);
	
	//Send ICW2
	outb(0x20 + 1, 0x20);
	outb(0xA0 + 1, 0x28);
	
	//Send ICW3
	outb(0x20 + 1, 4);
	outb(0xA0 + 1, 2);
	
	//Send ICW4
	outb(0x20 + 1, 0x01);
	outb(0xA0 + 1, 0x01);
	
	//Disable all IRQs
	outb(0x20 +1, 0xFF);
}

extern "C" {
void kernel_main(void) 
{
	//Initialize the display driver
	terminal_initialize();

	//Print opening messages
	printf("The Display driver has started.\n\n");
	printf("Welcome to CompactOS!\n");
	printf("CompactOS was written by Patrick Flynn.\n\n");
	
	//Start the PICs
	init_pic();
	
	//Make sure we use scancode set 2
	outb(0x60, 0xF0);
	outb(0x60, 0x02);
	
	//Test the keyboard
	char input[50];
	
	while (true) {
		printf("> ");
		clearArray(input,50);
		getline(input);
		
		if (strcmp(input,"cls") == 0) {
			terminal_initialize();
		} else if (strcmp(input,"about") == 0) {
			printf("You are running CompactOS.\n");
			printf("This system was written by Patrick Flynn.\n");
		} else if (strcmp(input,"black") == 0) {
			terminal_setcolor(vga_entry_color(VGA_COLOR_WHITE,VGA_COLOR_BLACK));
		} else if (strcmp(input,"exit") == 0) {
			break;
		} else {
			printf("Unknown command: ");
			printf(input);
			printf("\n");
		}
	}
	
	printf("Done");
} 
}
