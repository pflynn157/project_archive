int main() {
    int a = 1;
    do {
        a = a * 2;
    } while(a < 11);

    return a;
}