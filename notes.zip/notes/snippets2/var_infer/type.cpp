#include <string>
#include <cctype>
#include <climits>
#include <iostream>

#include "type.hh"

//Checks to see if a string starts and ends with a certain character
bool starts_ends(std::string ln, char c) {
	int end = ln.length()-1;
	
	if (ln[0] == c && ln[end] == c) {
		return true;
	}
	
	return false;
}

//Checks to see if we have an int
bool is_int(std::string ln) {
	//First, get rid of the minus sign if we have one
	if (ln[0] == '-') {
		std::string old = ln;
		ln = "";
		
		for (int i = 1; i<old.length(); i++) {
			ln += old[i];
		}
	}

	//Now check each digit
	for (char c : ln) {
		if (!isdigit(c)) {
			return false;
		}
	}
	
	//If everything passes, we need to make sure the number
	// isn't too big. We will use the C++ definition of
	// integer size.
	//
	// First, get the max and the number of digits
	int max = INT_MAX;
	int count = 0;
	do {
		max /= 10;
		count++;
	} while (max != 0);
	
	//Check for number of digits
	if (ln.length() > count) {
		return false;
	}
	
	//If they are the same length, make sure no digit is greater
	// than the max
	if (ln.length() == count) {
		max = INT_MAX;
		int index = 0;
		
		int digits[count];
		int digits_old[count];
		
		//Break down the max number into an array of digits
		do {
			digits_old[index] = max % 10;
			max /= 10;
			index++;
		} while (max != 0);
		
		index = 0;
		
		//The numbers are backwards, so flip it the other way
		for (int i = count-1; i>=0; i--) {
			digits[index] = digits_old[i];
			index++;
		}
		
		//Now compare
		for (int i = 0; i<ln.length(); i++) {
			int n = ln[i] - '0';
			int nd = digits[i];
			
			if (n>nd) return false;
		}
	}
	
	return true;
}

//Check to see if we havea  float
bool is_float(std::string ln) {
	//First, see if we have a decimal and only one
	int dcount = 0;
	for (char c : ln) {
		if (c == '.') {
			dcount++;
		}
	}
	
	if (dcount != 1) return false;
	
	//Now see if we have a sign, and if so, remove it
	if (ln[0] == '-') {
		auto old = ln;
		ln = "";
		
		for (int i = 1; i<old.length(); i++) {
			ln += old[i];
		}
	}
	
	//Now make sure all parts of the string are numbers
	for (char c : ln) {
		if (c == '.') continue;
		else if (!isdigit(c)) return false;
	}
	
	//Check the size of our value
	try {
		std::stod(ln);
	//} catch (const std::out_of_range& e) {
	} catch (std::exception &e) {
		return false;
	}

	return true;
}

//Check to see if we have a boolean
// Generally, its either 'true' or 'false'.
// However, if its either '0' or '1' we will 
// return true.
bool is_bool(std::string ln) {
	if (ln == "true" || ln == "false") {
		return true;
	}
	
	if (ln == "1" || ln == "0") {
		return true;
	}
	
	return false;
}

//Check to see if we have a string
// A string can be any character, so basically if starts
// and ends with double quotes, its a string
bool is_string(std::string ln) {
	int end = ln.length() - 1;
	if (ln[0] == '\"' && ln[end] == '\"') {
		return true;
	}

	return false;
}

//Check to see if we have a character
bool is_char(std::string ln) {
	int end = ln.length() - 1;
	if (ln[0] != '\'' || ln[end] != '\'') {
		return false;
	}
	
	if (ln.length() > 3) {
		return false;
	}
	
	return true;
}

//Main type inference function
DataType inferType(std::string ln) {
	if (is_int(ln)) {
		return DataType::INT;
	} else if (is_float(ln)) {
		return DataType::DEC;
	} else if (is_bool(ln)) {
		return DataType::BOOL;
	} else if (is_string(ln)) {
		return DataType::STR;
	} else if (is_char(ln)) {
		return DataType::CHAR;
	}
	
	return DataType::NONE;
}
