public class Test_Test001 {
    public static void main(String[] args) {
        System.out.println("Hello!");
        System.out.println("Printing a number:");
        System.out.println(33);
    }
}
