### Testing

TODO: This needs to be updated

There are a lot of tests (at the time of writing, I think over 180). In order to make sure I don't break things, I use a unit-test approach, which basically is a bunch of very small programs that test a certain construct. The tests are divided among the different data types and features. To run, simply run the "./test.sh" script. 
