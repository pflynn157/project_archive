#pragma once

#include "ltac.hpp"

// A generic 32-bit variable
class LtacVar32 : public LtacInstr {
public:
    explicit LtacVar32(int pos) : LtacInstr(LtacType::Var32) {
        this->pos = pos;
    }
    
    int getPos() { return pos; }
    std::string printInstr();
private:
    int pos = 0;
};

// A pointer
class LtacPtr : public LtacInstr {
public:
    explicit LtacPtr(int pos) : LtacInstr(LtacType::Ptr) {
        this->pos = pos;
    }
    
    int getPos() { return pos; }
    std::string printInstr();
private:
    int pos = 0;
};

// Stores a 32-bit integer immediate to a variable
class LtacMovI32 : public LtacInstr {
public:
    LtacMovI32(int pos, int val) : LtacInstr(LtacType::MovI32) {
        this->pos = pos;
        this->val = val;
    }
    
    int getPos() { return pos; }
    int getVal() { return val; }
    
    std::string printInstr();
private:
    int pos = 0;
    int val = 0;
};

// Stores 32-bit var to a variable
class LtacMovV32 : public LtacInstr {
public:
    LtacMovV32(int dest, int src) : LtacInstr(LtacType::MovV32) {
        this->dest = dest;
        this->src = src;
    }
    
    int getDest() { return dest; }
    int getSrc() { return src; }
    
    std::string printInstr();
private:
    int dest = 0;
    int src = 0;
};
