#!/usr/bin/python3
import RPi.GPIO as GPIO

#Set our constants
yellowLed = 3
greenLed = 5
redLed = 7
btn = 40

count = 1

#The button callback
def btn_pressed(channel):
    global count
    print("Button pressed")
    
    if count == 1:
        GPIO.output(yellowLed, GPIO.LOW)
        GPIO.output(greenLed, GPIO.HIGH)
        GPIO.output(redLed, GPIO.HIGH)
    elif count == 2:
        GPIO.output(yellowLed, GPIO.HIGH)
        GPIO.output(greenLed, GPIO.LOW)
        GPIO.output(redLed, GPIO.HIGH)
    elif count == 3:
        GPIO.output(yellowLed, GPIO.HIGH)
        GPIO.output(greenLed, GPIO.HIGH)
        GPIO.output(redLed, GPIO.LOW)

    if count == 3:
        count = 1
    else:
        count += 1

#Set up GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD)

#Setup the button
GPIO.setup(btn, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
GPIO.add_event_detect(btn, GPIO.RISING, callback=btn_pressed)

#Setup the LED
GPIO.setup(yellowLed, GPIO.OUT)
GPIO.setup(greenLed, GPIO.OUT)
GPIO.setup(redLed, GPIO.OUT)

GPIO.output(yellowLed, GPIO.HIGH)
GPIO.output(greenLed, GPIO.HIGH)
GPIO.output(redLed, GPIO.HIGH)

msg = input("Press any key to quit\n\n")
GPIO.cleanup()
