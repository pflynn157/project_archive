package co.patrickflynn.notetaker

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.view.ContextMenu
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import co.patrickflynn.notetaker.databinding.ActivityMainBinding
import co.patrickflynn.notetaker.ui.creator.ItemCreator
import java.io.File
import androidx.appcompat.view.menu.ActionMenuItem
import co.patrickflynn.notetaker.ui.editor.EditorActivity

const val CWD = "co.patrickflynn.notetaker.CWD"

class MainActivity : AppCompatActivity(), MainListAdaptor.ItemClickListener {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding
    private lateinit var mainListAdaptor : MainListAdaptor

    private var currentDir : String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.appBarMain.toolbar)

        binding.appBarMain.newItem.setOnClickListener { view ->
            val intent = Intent(this, ItemCreator::class.java).apply {
                putExtra(CWD, currentDir)
            }
            startActivityForResult(intent, 1)
        }

        // Make sure we can use the context menu
        val mainList : RecyclerView = findViewById(R.id.main_list)
        registerForContextMenu(mainList)

        // Init the list view
        initFileList()
    }

    fun initFileList() {
        val items : ArrayList<String> = ArrayList()
        val file : File = File(applicationContext.filesDir, currentDir)
        for (item in file.list()) {
            items.add(item)
        }

        val itemsRaw = arrayOfNulls<String>(items.size)
        items.toArray(itemsRaw)
        mainListAdaptor = MainListAdaptor(itemsRaw, applicationContext.filesDir, currentDir)
        mainListAdaptor.itemClickListener = this
        val mainList : RecyclerView = findViewById(R.id.main_list)
        mainList.layoutManager = LinearLayoutManager(this)
        mainList.adapter = mainListAdaptor
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.fragment_main)
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }

    override fun onItemClick(view: View?, position: Int) {
        val item = mainListAdaptor.getItem(position)
        var dir = currentDir
        if (item != null) {
            if (dir == "") {
                dir = item
            } else {
                dir += "/" + item
            }
        }
        val file = File(applicationContext.filesDir, dir)
        if (file.isDirectory) {
            currentDir = dir
            initFileList()
        } else {
            val intent = Intent(this, EditorActivity::class.java).apply {
                putExtra(CWD, dir)
            }
            startActivity(intent)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == 1) {
            initFileList()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_nav_up -> {
                if (currentDir == "") return true
                if (!currentDir.contains('/')) {
                    currentDir = ""
                    initFileList()
                    return true
                }
                currentDir = currentDir.substringBeforeLast('/')
                initFileList()
                true
            }

            R.id.action_settings -> {

                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        val position = mainListAdaptor.getPosition()

        if (item.itemId == R.id.rename_item) {
            var inputLine = EditText(this)
            var renameDialog = AlertDialog.Builder(this)
            renameDialog.setTitle("Rename File")
            renameDialog.setMessage("Enter New Name:")
            renameDialog.setView(inputLine)
            renameDialog.setPositiveButton("OK", DialogInterface.OnClickListener {
                    dialogInterface: DialogInterface, i: Int ->
                val inputText = inputLine.text.toString()

                var path1 = currentDir
                if (path1.length == 0) path1 = mainListAdaptor.getItem(position).toString()
                else path1 = currentDir + "/" + mainListAdaptor.getItem(position).toString()

                var path2 = inputText
                if (currentDir.length > 0) path2 = currentDir + "/" + inputText

                val file1Path = File(applicationContext.filesDir, path1)
                val file2Path = File(applicationContext.filesDir, path2)
                file1Path.renameTo(file2Path)

                initFileList()
            })
            renameDialog.setNegativeButton("Cancel", null)
            val dialog = renameDialog.create()
            dialog.show()

        } else if (item.itemId == R.id.delete_item) {
            var path = currentDir
            if (path.length == 0) path = mainListAdaptor.getItem(position).toString()
            else path = currentDir + "/" + mainListAdaptor.getItem(position).toString()

            val file = File(applicationContext.filesDir, path)
            if (file.isDirectory) {
                file.deleteRecursively()
            } else {
                file.delete()
            }

            initFileList()
        }

        return super.onContextItemSelected(item)
    }
}