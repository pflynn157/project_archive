#include "elf.hpp"

#include <elf.h>

// In case we need more...
ElfFile::ElfFile(std::string file_name) {
    this->file_name = file_name;
}

// Add a section to the list
void ElfFile::addSection(ElfSection *section) {
    int pos = sections.size() + 2;
    
    switch (section->getSecType()) {
        case ElfSectionType::Text:
        case ElfSectionType::Data: symtab->addSectionSymbol(pos); break;
        case ElfSectionType::Symtab: {
            symtab = static_cast<ElfSymTab *>(section); 
        } break;
        case ElfSectionType::Strtab: {
            strtab = static_cast<ElfStrTab *>(section);
        } break;
    }
    
    sections.push_back(section);
}

// Adds a function symbol to the symbol table
void ElfFile::addFunction(std::string name, int pos) {
    int name_pos = strtab->getSize();
    strtab->addString(name);
    
    int sec_pos = 2;
    for (auto section : sections) {
        if (section->getSecType() == ElfSectionType::Text) {
            break;
        }
        
        ++sec_pos;
    }
    
    symtab->addGlobalSymbol(name_pos, pos, sec_pos);
}

// Writes all sections to the file
void ElfFile::write(FILE *file) {
    // First, collect information on the section names
    std::vector<std::string> sec_names;
    std::string shstrtab = ".shstrtab";
    
    int string_size = 2 + shstrtab.length();
    sec_names.push_back(shstrtab);
    
    for (auto section : sections) {
        auto str = section->getName();
        sec_names.push_back(str);
        string_size += str.length() + 1;
    }
    
    int offset = sizeof(Elf64_Ehdr);
    offset += sizeof(Elf64_Shdr) * (sections.size() + 2);

    // Now, write the default needed headers
    writeDefaultHeaders(file);
    writeShStrtab(file,  string_size, offset);
    
    offset += string_size;
    
    // Write all the headers
    for (auto section : sections) {
        Elf64_Shdr header;
        
        // Name position
        int name_pos = 1;
        for (auto str : sec_names) {
            if (str == section->getName()) {
                break;
            }
            
            name_pos += str.length() + 1;
        }
        
        // Link if needed
        int link = 0;
        
        if (section->getLink().length() > 0) {
            int index = 2;
            
            for (auto sec2 : sections) {
                if (sec2->getName() == section->getLink()) {
                    link = index;
                    break;
                }
                
                ++index;
            }
        }
        
        // Offset and size
        int size = section->getSize();

        header.sh_name = name_pos;		                // Section name (string tbl index)
        header.sh_type = section->getType();		    // Section type
        header.sh_flags = section->getFlags();	        // Section flags
        header.sh_addr = 0;		                        // Section virtual addr at execution
        header.sh_offset = offset;		                // Section file offset
        header.sh_size = size;                          // Section size in bytes
        header.sh_link = link;	                        // Link to another section
        header.sh_info = section->getInfo();            // Additional section information
        header.sh_addralign = section->getAlign();		// Section alignment
        header.sh_entsize = section->getEntrySize();    // Entry size if section holds table
    
        offset += size;
        fwrite(&header, sizeof(header), 1, file);
    }
    
    // Write the string table
    fputc(0, file);
    
    for (auto str : sec_names) {
        const char *c_str = str.c_str();
        fputs(c_str, file);
        fputc(0, file);
    }
    
    // Write the data
    for (auto section : sections) {
        section->writeContent(file);
    }
}

// Writes the header, NULL header, and section string table header
void ElfFile::writeDefaultHeaders(FILE *file) {
    // Write the header
    Elf64_Ehdr header;
   
    // Start with the magic number and other info
    header.e_ident[EI_MAG0] = ELFMAG0;
    header.e_ident[EI_MAG1] = ELFMAG1;
    header.e_ident[EI_MAG2] = ELFMAG2;
    header.e_ident[EI_MAG3] = ELFMAG3;
    
    header.e_ident[4] = 2;    //64-bit objects
    header.e_ident[5] = 1;    //Little endian
    header.e_ident[6] = EV_CURRENT;
    header.e_ident[7] = ELFOSABI_LINUX;
    header.e_ident[8] = 1;
    
    for (int i = 9; i<EI_NIDENT; i++) header.e_ident[i] = 0;

    header.e_type = ET_REL;
    header.e_machine = EM_X86_64;        //Architecture
    header.e_version = 1;                //Current version
    header.e_entry = 0;
    header.e_phoff = 0;                 //Program header offset
    header.e_shoff = 64;                //Section header offset
    header.e_flags = 0;                 //No flags
    header.e_ehsize = 64;               //Header size
    header.e_phentsize = 0;             //Program header size
    header.e_phnum = 0;                 //1 program header
    header.e_shentsize = 64;
    header.e_shnum = sections.size() + 2;
    header.e_shstrndx = 1;
    
    fwrite(&header, sizeof(header), 1, file);
    
    // Write the null section
    Elf64_Shdr nullh;

    nullh.sh_name = 0;		        /* Section name (string tbl index) */
    nullh.sh_type = SHT_NULL;		/* Section type */
    nullh.sh_flags = 0;		        /* Section flags */
    nullh.sh_addr = 0;		        /* Section virtual addr at execution */
    nullh.sh_offset = 0;		    /* Section file offset */
    nullh.sh_size = 0;		        /* Section size in bytes */
    nullh.sh_link = 0;		        /* Link to another section */
    nullh.sh_info = 0;		        /* Additional section information */
    nullh.sh_addralign = 0;		    /* Section alignment */
    nullh.sh_entsize = 0;		    /* Entry size if section holds table */

    fwrite(&nullh, sizeof(nullh), 1, file);
}

// Write the section header string table to the file
void ElfFile::writeShStrtab(FILE *file, int size, int offset) {
    Elf64_Shdr header;

    header.sh_name = 1;                 // Section name (string tbl index)
    header.sh_type = SHT_STRTAB;		// Section type
    header.sh_flags = 0;		        // Section flags
    header.sh_addr = 0;		            // Section virtual addr at execution
    header.sh_offset = offset;	        // Section file offset
    header.sh_size = size;		        // Section size in bytes
    header.sh_link = 0;		            // Link to another section
    header.sh_info = 0;		            // Additional section information
    header.sh_addralign = 1;		    // Section alignment
    header.sh_entsize = 0;		        // Entry size if section holds table

    fwrite(&header, sizeof(header), 1, file);
}

