#include <QScrollArea>

#include "canvas_bg.hh"
#include "canvas.hh"

CanvasBg::CanvasBg()
    : layout(new QVBoxLayout)
{
    this->setStyleSheet("background-color:grey");

    layout->setContentsMargins(0,0,0,0);
    this->setLayout(layout);

    canvas = new Canvas;
    QScrollArea *scroller = new QScrollArea;
    scroller->setWidget(canvas);

    layout->addWidget(scroller,0,Qt::AlignCenter);
}

CanvasBg::~CanvasBg() {
    delete layout;
}

Canvas *CanvasBg::getCanvas() {
    return canvas;
}

void CanvasBg::newImage(int width, int height) {
    delete canvas;
    canvas = new Canvas;
    canvas->setFixedSize(width,height);
    layout->addWidget(canvas,0,Qt::AlignCenter);
}

void CanvasBg::newImage() {
    delete canvas;
    canvas = new Canvas;
    layout->addWidget(canvas,0,Qt::AlignCenter);
}
