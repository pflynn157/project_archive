#pragma once

size_t check_env(char *buf);
void run_cd(char *input, int size);
void run_set(char *input, int size);

