#pragma once

#include <llvm-c/Core.h>

typedef struct
{
    char *name;
    LLVMValueRef var;
    LLVMTypeRef var_type;
} VarEntry;

typedef struct
{
    VarEntry **entries;
    int count;
    int max;
} VarTable;

VarTable *var_table_create();
void var_table_add(VarTable *table, VarEntry *entry);
LLVMValueRef var_table_get(VarTable *table, char *name);
LLVMTypeRef var_table_get_type(VarTable *table, char *name);
void var_table_clear(VarTable *table);
