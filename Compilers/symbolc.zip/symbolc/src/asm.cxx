// Copyright 2018 Patrick Flynn
//
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, 
//	this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, this 
//	list of conditions and the following disclaimer in the documentation and/or 
//	other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors may 
//	be used to endorse or promote products derived from this software 
//	without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#include <fstream>
#include <cstdlib>

#include "asm.hh"

AsmGenerator::AsmGenerator(std::string in_file, Pass2Result result) {
	input_file = "";
	
	//Get the base file name
	for (int i = 0; i<in_file.length(); i++) {
		if (in_file[i]=='/') {
			input_file = "";
			continue;
		}
		input_file+=in_file[i];
	}
	
	//Remove the extension
	std::string tmp = input_file;
	input_file = "";
	
	for (int i = 0; i<tmp.length(); i++) {
		if (tmp[i]=='.') {
			break;
		}
		input_file+=tmp[i];
	}

	contents.push_back("global _start");
	
	contents.push_back("section .data");
	for (int i = 0; i<result.section_data.size(); i++) {
		contents.push_back(result.section_data.at(i));
	}
	
	contents.push_back("section .bss");
	for (int i = 0; i<result.section_bss.size(); i++) {
		contents.push_back(result.section_bss.at(i));
	}
	
	contents.push_back("section .text");
	for (int i = 0; i<result.section_text.size(); i++) {
		contents.push_back(result.section_text.at(i));
	}
}

void AsmGenerator::write() {
	asm_file = "./"+input_file+".asm";

	std::ofstream writer;
	writer.open(asm_file);
	
	for (int i = 0; i<contents.size(); i++) {
		writer << contents.at(i) << std::endl;
	}
	
	writer.close();
}

//TODO: Fix this to get rid of the system calls
void AsmGenerator::compile() {
	std::string cmd1 = "nasm -f elf64 "+asm_file+" -o ./"+input_file+".o";
	std::string cmd2 = "ld -g ./"+input_file+".o -o ./"+input_file;

	system(cmd1.c_str());
	system(cmd2.c_str());
}
