
## Codepad

This is a simple text editor written in C. It uses Gtk for the GUI, and Gtk Source View for the editor widget.

Currently, basic functionality is supported, but it is still in the very early stages of development.

### Resources

https://developer.gnome.org/gtk3/stable/gtk-getting-started.html

https://developer.gnome.org/gtk3/3.24/

https://developer.gnome.org/gtksourceview/stable/


