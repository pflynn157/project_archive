//
// Copyright 2021 Patrick Flynn
// This file is part of uds-wordpad.
// uds-wordpad is licensed under the BSD-3 license. See the COPYING file for more information.
//
#pragma once

#include <QToolBar>
#include <QToolButton>
#include <QComboBox>

#include <actions.hpp>

class FormatToolbar : public QToolBar {
    Q_OBJECT
public:
    FormatToolbar();
    ~FormatToolbar();
    
    void updateFormat(bool isBold, bool isItalic, bool isUnderline);
private:
    Actions *actions;
    QComboBox *textStyle;
    QToolButton *textColor;
    QToolButton *bold, *italic, *underline;
private slots:
    void onCurrentChanged(QString item);
};

