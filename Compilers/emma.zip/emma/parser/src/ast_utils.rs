
use crate::ast;
use crate::ast::*;
use crate::lex::{Token, Lex};

// A common function for building statement arguments
pub fn build_args(scanner : &mut Lex, stmt : &mut AstStmt, end : Token) {
    let mut output : Vec<AstArg> = Vec::new();
    let mut op_stack : Vec<AstArg> = Vec::new();

    let mut token = scanner.get_token();
    
    while token != end {
        match token {
            Token::IntL(val) => {
                let arg = ast::create_int(val);
                output.push(arg);
            },
            
            Token::StringL(ref val) => {
                let arg = ast::create_string(val.to_string());
                output.push(arg);
            },
            
            Token::Id(ref val) => {
                let mut arg = ast::create_arg(AstArgType::Id);
                arg.str_val = val.to_string();
                output.push(arg);
            },
            
            Token::OpAdd => {
                let arg = ast::create_arg(AstArgType::OpAdd);
                op_stack.push(arg);
            },
            
            Token::OpMul => {
                let arg = ast::create_arg(AstArgType::OpMul);
                op_stack.push(arg);
            },
            
            Token::OpEq => {
                let arg = ast::create_arg(AstArgType::OpEq);
                op_stack.push(arg);
            },
            
            Token::Comma => {},
            
            // TODO: Better syntax error
            _ => println!("Invalid expression argument: {:?}", token),
        }
    
        token = scanner.get_token();
    }
    
    while op_stack.len() > 0 {
        let mut op = op_stack.pop().unwrap();
        op.rval = Some(Box::new(output.pop().unwrap()));
        op.lval = Some(Box::new(output.pop().unwrap()));
        
        output.push(op);
    }
    
    let arg = output.pop().unwrap();
    stmt.args.push(arg);
}

