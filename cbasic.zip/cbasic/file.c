// file
// A library to make handeling files easier in C
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <stdlib.h>

#include "file.h"
#include "strutils.h"

//Counts the number of lines in a file
int line_count(const char *path)
{
	int count = 0;
	int c;
	
	FILE *file = fopen(path, "r");
	while ((c = fgetc(file)) != EOF)
	{
		if (c == '\n')
			count++;
	}
	
	fclose(file);
	
	return count;
}

//Load the lines into a string (2D) array
char **load_lines(const char *path, int lines)
{
	//Init the array
	char **array = malloc(sizeof(char *) * lines);
	
	for (int i = 0; i<lines; i++)
		array[i] = malloc(101);
		
	//Open the file and load from it
	FILE *file = fopen(path, "r");
	int index = 0;
	int c_index = 0;
	int c;
	char buf[100];
	
	while ((c = fgetc(file)) != EOF)
	{
		if (c == '\n') {
			buf[c_index] = '\0';
			strcpy(array[index], buf);
			
			c_index = 0;
			index++;
			if (index >= lines)
				break;
			
			for (int i = 0; i<100; i++)
				buf[i] ='\0';
		} else {
			buf[c_index] = c;
			c_index++;
		}
	}
	
	fclose(file);
	
	return array;
}
