module Code(AsmCode(..), codeSize, codeType) where

import Utils

-- Instructions
data AsmCode = Syscall
        | AddRR | SubRR | AddRI | AddRI64 | SubRI | SubRI64
        | Jmp | Jg | Jl
        | CmpRR | CmpRR64 | CmpRI
        | MovRI | MovRR
        | Label
        | None
        deriving (Show, Eq)

-- Returns the size of an instruction
codeSize instr
    | instr == Syscall = 2
    | (instr == AddRR) || (instr == SubRR) = 2
    | (instr == AddRI) || (instr == SubRI) = 3
    | (instr == AddRI64) || (instr == SubRI64) = 4
    | instr == Jmp = 2
    | instr == Jg = 2
    | instr == Jl = 2
    | instr == CmpRR = 2
    | instr == CmpRR64 = 3
    | instr == MovRI = 5
    | instr == MovRR = 2
    | instr == Label = 0
    | otherwise = 0
    
-- Returns the instruction type from strings
codeType parts
    | instr == "syscall" = Syscall
    | instr == "add" = addType parts
    | instr == "sub" = subType parts
    | instr == "jmp" = Jmp
    | instr == "jg" = Jg
    | instr == "jl" = Jl
    | instr == "cmp" = cmpType parts
    | instr == "mov" = movType parts
    | (last instr) == ':' = Label
    | otherwise = None
    where
        instr = head parts
        
-- Returns the type of add instruction
addType parts
    | (isRegister op1) && (isInt op2) = do
        if (head op1) == 'r'
            then AddRI64
            else AddRI
    | (isRegister op1) && (isRegister op2) = AddRR
    | otherwise = None
    where
        op1 = parts !! 1
        op2 = parts !! 2
        
-- Returns the type of sub instruction
subType parts
    | (isRegister op1) && (isInt op2) = do
        if (head op1) == 'r'
            then SubRI64
            else SubRI
    | (isRegister op1) && (isRegister op2) = SubRR
    | otherwise = None
    where
        op1 = parts !! 1
        op2 = parts !! 2
        
-- Returns the type of cmp instruction
cmpType parts
    | (isRegister op1) && (isInt op2) = CmpRI
    | (isRegister op1) && (isRegister op2) = do
        if (head op1) == 'r'
            then CmpRR64
            else CmpRR
    | otherwise = None
    where
        op1 = parts !! 1
        op2 = parts !! 2
    
-- Returns the type of move
movType parts
    | (isRegister op1) && (isInt op2) = MovRI
    | (isRegister op1) && (isRegister op2) = MovRR
    | (isRegister op1) = MovRI
    | otherwise = None
    where
        op1 = parts !! 1
        op2 = parts !! 2

