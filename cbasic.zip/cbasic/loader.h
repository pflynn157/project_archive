#ifndef LOADER_H
#define LOADER_H

void run(char **contents, int lines);

#endif
