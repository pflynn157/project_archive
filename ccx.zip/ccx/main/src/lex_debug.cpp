#include <iostream>

#include "lex.hpp"

void Token::print() {
    switch (this->type) {
        case EmptyToken: std::cout << "???" << std::endl; break;
        case Eof: std::cout << "EOF" << std::endl; break;
        
        case Func: std::cout << "func" << std::endl; break;
        case Return: std::cout << "return" << std::endl; break;
        case Syscall: std::cout << "syscall" << std::endl; break;
        case Var: std::cout << "var" << std::endl; break;
        case Array: std::cout << "array" << std::endl; break;
        case While: std::cout << "while" << std::endl; break;
        case For: std::cout << "for" << std::endl; break;
        case Break: std::cout << "break" << std::endl; break;
        case Continue: std::cout << "continue" << std::endl; break;
        case If: std::cout << "if" << std::endl; break;
        case Elif: std::cout << "elif" << std::endl; break;
        case Else: std::cout << "else" << std::endl; break;
        case True: std::cout << "true" << std::endl; break;
        case False: std::cout << "false" << std::endl; break;
        case U8: std::cout << "u8" << std::endl; break;
        case I8: std::cout << "i8" << std::endl; break;
        case U16: std::cout << "u16" << std::endl; break;
        case I16: std::cout << "i16" << std::endl; break;
        case U32: std::cout << "u32" << std::endl; break;
        case I32: std::cout << "i32" << std::endl; break;
        case U64: std::cout << "u64" << std::endl; break;
        case I64: std::cout << "i64" << std::endl; break;
        case U128: std::cout << "u128" << std::endl; break;
        case I128: std::cout << "i128" << std::endl; break;
        case W1: std::cout << "w1" << std::endl; break;
        case W2: std::cout << "w2" << std::endl; break;
        case W4: std::cout << "w4" << std::endl; break;
        case W8: std::cout << "w8" << std::endl; break;
        case Long: std::cout << "long" << std::endl; break;
        case LParen: std::cout << "(" << std::endl; break;
        case RParen: std::cout << ")" << std::endl; break;
        case LCBrace: std::cout << "{" << std::endl; break;
        case RCBrace: std::cout << "}" << std::endl; break;
        case LBracket: std::cout << "[" << std::endl; break;
        case RBracket: std::cout << "]" << std::endl; break;
        case Colon: std::cout << ":" << std::endl; break;
        case Assign: std::cout << ":=" << std::endl; break;
        case SemiColon: std::cout << ";" << std::endl; break;
        case Comma: std::cout << "," << std::endl; break;
        case Plus: std::cout << "+" << std::endl; break;
        case Minus: std::cout << "-" << std::endl; break;
        case Mul: std::cout << "*" << std::endl; break;
        case Div: std::cout << "/" << std::endl; break;
        case Mod: std::cout << "%" << std::endl; break;
        case And: std::cout << "&" << std::endl; break;
        case Or: std::cout << "|" << std::endl; break;
        case Xor: std::cout << "^" << std::endl; break;
        case Eq: std::cout << "=" << std::endl; break;
        case Not: std::cout << "!" << std::endl; break;
        case Ne: std::cout << "!=" << std::endl; break;
        case Gt: std::cout << ">" << std::endl; break;
        case Ge: std::cout << ">=" << std::endl; break;
        case Lt: std::cout << "<" << std::endl; break;
        case Le: std::cout << "<=" << std::endl; break;
        
        case Id: std::cout << "ID(" << id_val << ")" << std::endl; break;
        case String: std::cout << "STR(" << id_val << ")" << std::endl; break;
        case CharL: std::cout << "CHAR(" << i8_val << ")" << std::endl; break;
        case Int32: std::cout << "INT(" << i32_val << ")" << std::endl; break;
    }
}

