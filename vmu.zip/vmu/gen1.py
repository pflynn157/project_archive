#!/usr/bin/python3

import struct
from array import array

def chr(input):
    return int(input.encode('utf-8').hex(), 16)

content = bytearray([
    0xA1, 0xA2,      # The signature
    0x01, 0x00,      # Major, minor version (1.0)
    0x01,            # Constant pool length
    chr('m'), chr('a'), chr('i'), chr('n'), 0x00,
    0x00,            # Length of library list
    #NULL lib list
    0x01,           # One function
    
    # Function main
    0x01,           # function name @ index 1
    0x0D,           # length of code (length = 13)
    0xA0, 0x00, 0x00, 0x00, 0x02,       # pushc 2
    0xA0, 0x00, 0x00, 0x00, 0xA0,       # pushc 10
    0xA2,                               # iadd
    0xAB,                               # iprint
    0xB2,                               # retvoid
    
    0x00    #end of file
])

print(content)

with open("first.bin", "wb") as f:
    for b in content:
        f.write(struct.pack('<B', b))
    #f.write(struct.pack('<H', 0xA1A2))
    #.write(array(content).byteswap())
    
print("Done!")

