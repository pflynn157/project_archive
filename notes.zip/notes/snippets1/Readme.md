## Snippets

This contains various code snippets on how to do some useful (and maybe not so useful) things. The content is in various programming languages (although C++ is the main one).

I put this up mainly for my conceptual benefit. That being said, there could very likely be some bad code in it. That's not my problem; if you want to use something, go for it, you may just have to fix it up a bit.

### Licensing

Unless otherwise noted (and "otherwise noted" means in the subdirectory), everything here is public domain. Use and be happy.
