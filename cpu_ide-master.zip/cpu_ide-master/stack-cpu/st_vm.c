#include <stdio.h>

int main(int argc, char *argv[])
{
    puts("Stack VM");
    return 0;
}
