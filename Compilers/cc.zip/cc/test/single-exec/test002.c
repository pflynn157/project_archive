//OUTPUT
//END

//RET 0

int
main()
{
	return 3-3;
}
