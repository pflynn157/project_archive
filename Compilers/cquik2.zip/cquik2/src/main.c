#include <stdio.h>
#include <string.h>

#include <ast.h>
#include <ltac/ltac.h>
#include <ltac/build.h>
#include <compiler.h>

extern void parse(const char *path, AstNode *top);

int main(int argc, char *argv[]) {
	if (argc <= 1)
	{
        puts("Error: No input specified.");
        return 1;
	}

	int print_ast = 0;
	int print_ltac = 0;

	if (argc == 3)
	{
        if (strcmp(argv[2], "--ast") == 0)
        {
            print_ast = 1;
        }
        else if (strcmp(argv[2], "--ltac") == 0)
        {
            print_ltac = 1;
        }
	}

	AstNode *top = ast_create_node(Scope);
	parse(argv[1], top);

    //Ast testing
    if (print_ast)
    {
	    ast_print(top, 0);
	    return 0;
    }

	//Ltac test
	LtacFile *file = ltac_create_file("out.asm");
    ltac_build(file, top);

    if (print_ltac)
    {
	    ltac_print_file(file);
	    return 0;
    }

	//The compiler
	compiler_init(Amd64);
	compiler_run(file);
	compiler_build();

	return 0;
}
