
export JAVA_HOME=/usr/lib/jvm/java-1.8.0-openjdk
export LD_LIBRARY_PATH=$JAVA_HOME/jre/lib/amd64/server:$LD_LIBRARY_PATH

export REX_ROOT=$HOME/passlab
export LD_LIBRARY_PATH=$REX_ROOT/rex_install/lib:$REX_ROOT/llvm-project/openmp/build/runtime/src:$LD_LIBRARY_PATH
export PATH=$REX_ROOT/rex_install/bin:$PATH

