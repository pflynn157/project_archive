// Copyright 2018 Patrick Flynn
//
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, 
//	this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, this 
//	list of conditions and the following disclaimer in the documentation and/or 
//	other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors may 
//	be used to endorse or promote products derived from this software 
//	without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#include <string>
#include <cstdlib>
#include <iostream>

#include "pass2.hh"
#include "string_utils.hh"
#include "parse_utils.hh"

Pass2::Pass2(Pass1Result p1_result) {
	result.section_data = p1_result.section_data;
	result.section_bss = p1_result.section_bss;
	
	funcs = p1_result.functions;
}

void Pass2::trans_funcs() {
	std::vector<std::string> text;
	
	for (int i = 0; i<funcs.size(); i++) {
		Function f = funcs.at(i);
		text.push_back(f.name);
		
		if (f.is_asm) {
			for (int j = 0; j<f.content.size(); j++) {
				text.push_back(f.content.at(j));
			}
			continue;
		}
		
		for (int j = 0; j<f.content.size(); j++) {
			std::string line = f.content.at(j);
			std::string ln = "";
			
			std::string first = first_part(line);
			if (first==";") {
				std::string print = "mov rax, 1\n";
				print+="mov rbx, 1\n";
				print+="int 0x80\n";
				
				ln = print;
			} else if (first=="^") {
				ln = "ret\n";
			} else if (line[0]=='i' || line[1]=='f') {
				BuiltFunction f = ParseUtils::build(line,funcs.at(i).vars);
				ln = f.ln;
				
				for (int k = 0; k<f.section_data.size(); k++) {
					result.section_data.push_back(f.section_data.at(k));
				}
			} else if (first_part(line)=="loop") {
				BuiltFunction f = ParseUtils::build_loop(line,funcs.at(i).vars);
				ln = f.ln;
				
				for (int k = 0; k<f.section_data.size(); k++) {
					result.section_data.push_back(f.section_data.at(k));
				}
			} else {
				BuiltFunction f = ParseUtils::build_function(line,funcs.at(i).vars);
				ln = f.ln;
				
				for (int k = 0; k<f.section_data.size(); k++) {
					result.section_data.push_back(f.section_data.at(k));
				}
			}
			
			text.push_back(ln);
		}
	}
	
	result.section_text = text;
}

Pass2Result Pass2::get_result() {
	return result;
}
