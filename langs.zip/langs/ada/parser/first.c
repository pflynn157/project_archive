int main() {
	int x = 20;
	int y = 30;
	
	return 7;
}
