## Ncurses

These are some simple programs that I used to learn a little NCurses (which I haven't touched since then- although it was kind of cool).

Please note that this was from a while back, so I think some of the examples may have been copied and pasted from a tutorial online. No copyright infringement is intended, if you see something, let me know and I'll take it down.
