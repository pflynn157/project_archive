package main

import (
	"os"
	//"fmt"
)

func main() {
	if len(os.Args) <= 1 {
		println("Error: No input file specified.")
		os.Exit(1)
	}
	
	path := os.Args[1]
	
	//Start loading
	var reader ByteReader
	reader.Setup(path)
	
	//Get the first byte after the signature
	b1 := reader.ReadByte()
	
	var strpool StringPool
	strpool.Setup()
	
	if b1 == 0xF3 {
		var current string
		
		for true {
			b := reader.ReadByte()
			if b == 0xF4 || b == 0 {
				break
			}
			
			if b == 0xF5 {
				strpool.Write(current)
				current = ""
			} else {
				current += string(b)
			}
		}
	}
	
	var interpreter Interpreter
	
	for true {
		word := reader.ReadWord()
		if word[0] == 0xB0 {
			break
		}
		
		interpreter.Run(word)
	}
	
	//Close and exit
	reader.Finish()
}
