int main() {
    int a = 1;
    int b = 0;
    if (a)
        b = 1;
    else if (b)
        b = 2;
    return b;
}
