// Copyright 2017 Patrick Flynn
//
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, 
//	this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, this 
//	list of conditions and the following disclaimer in the documentation and/or 
//	other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors may 
//	be used to endorse or promote products derived from this software 
//	without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#pragma once

#include <QString>
#include <QStringList>

namespace CppLib {

class KeyParser {
public:
    //Constructors
    //Load all lines of a specified file; preserve whitespace if true
    explicit KeyParser(QString file, bool preserveWhitespace);
    //Load all lines of a specified file; do not preserve whitespace
    explicit KeyParser(QString file);
    //The destructor
    //By default, when it is called, the specified file is simply rewritten.
    //It can be overriddened by default.
    virtual ~KeyParser() {
        this->write();
    }
    //Write all changes to the file.
    void write();
    //Add a key to the file.
    void addKey(QString keyName, QString keyContent);
    //Edit an existing key.
    //If the key does not exist, addKey will be called.
    void editKey(QString keyName, QString keyContent);
    //Delete the specified key.
    void deleteKey(QString keyName);
    //Get the value of a key.
    QString value(QString keyName);
    //Get all available keys.
    QStringList *allKeys();
    //Check to see if a key exists.
    bool keyExists(QString keyName);
protected:
    //Get all content of a line before the equals sign.
    QString firstHalf(QString line);
    //Get all content of a line after the equals sign.
    QString secondHalf(QString line);
private:
    QString fileName; //The name of the file we are parsing.
    bool pWhitespace; //Whether to parser whitespace/
    QStringList *content; //The vector containing all lines in a file.
};

}
