#!/bin/bash

#Check for build folders
if [ ! -d ./build ] ; then
	mkdir build
fi

#Build the library
echo "Building the library..."
g++ -fPIC -shared lib/socketd.cpp -o build/libsocketd.so -std=c++11
echo "Done"

#Install the library
echo "Installing the library..."
sudo cp build/libsocketd.so /usr/local/lib
sudo cp lib/socketd.hh /usr/local/include
sudo ldconfig
echo "Done"

#Build the test file
echo "Building the test file..."
g++ lib/main.cpp -o build/test_main -lsocketd -lpthread -std=c++11
echo "Done"

#Build the example chat program
echo "Building chat program..."
g++ chat/chat.cpp -o build/chat -lsocketd -lpthread -std=c++11
echo "Done"

