package main

import (
	"fmt"
	"errors"
)

//The stack code
type Stack struct {
	top int
	sz int
	elements []int
}

//The init function
func (s* Stack) init(size int) {
	s.top = 0
	s.sz = size
	s.elements = make([]int, size)
}

//The push function
func (s* Stack) push(no int) {
	s.elements[s.top] = no
	s.top += 1
}

//The pop function
func (s* Stack) pop() (int, error) {
	if (s.top-1) < 0 {
		return -1, errors.New("Cannot pop from empty stack.")
	}

	s.top--
	val := s.elements[s.top]
	s.elements[s.top] = 0
	return val, nil
}

//The peek function
func (s* Stack) peek() (int, error) {
	if (s.top-1) < 0 {
		return -1, errors.New("Cannot peek from empty stack.")
	}
	
	val := s.elements[s.top-1]
	return val, nil
}

//Returns the size of the stack
func (s *Stack) size() int {
	return s.top
}

//Prints the stack
func (s* Stack) print() {
	for x := 0; x<s.top; x++ {
		fmt.Printf("DB: %d\n", s.elements[x])
	}
}

//The main, test function
func main() {
	var stack Stack
	stack.init(20)
	
	for x := 1; x<5; x++ {
		stack.push(x)
	}
	
	stack.print()
	
	p1, _ := stack.peek()
	fmt.Printf("Peek: %d\n", p1)
	
	size := stack.size()
	fmt.Printf("Size: %d\n", size)
	
	v1, _ := stack.pop()
	v2, _ := stack.pop()
	
	size = stack.size()
	fmt.Printf("Size: %d\n", size)
	
	p2, _ := stack.peek()
	fmt.Printf("Peek: %d\n", p2)
	
	stack.pop()
	stack.pop()
	_, err := stack.pop()
	
	if err != nil {
		fmt.Println("Error: ", err)
	}
	
	_, err = stack.peek()
	
	if err != nil {
		fmt.Println("Error: ", err)
	}
	
	println("")
	fmt.Printf("v1: %d\n", v1)
	fmt.Printf("v2: %d\n", v2)
	
	size = stack.size()
	fmt.Printf("Size: %d\n", size)
	
	println("")
	stack.print()
}

