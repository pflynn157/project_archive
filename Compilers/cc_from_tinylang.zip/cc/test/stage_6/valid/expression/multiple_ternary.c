int main() {
    int a = 1 > 2 ? 3 : 4;
    int b = 1 > 2 ? 5 : 6;
    return a + b;
}