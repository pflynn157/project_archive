//OUTPUT
//END

//RET 75

int
main()
{
	int x;
	int *p;
	int **pp;
    int ***ppp;
    
    x = 15;
	p = &x;
	pp = &p;
    ppp = &pp;
    
    int y = ***ppp;
    int z = y * 4 + **pp;
    
    return z;
}
