#include <gtk/gtk.h>
#include <gtksourceview/gtksource.h>

static void build_window(GtkApplication *app, gpointer user_data)
{
    GtkWidget *window, *mainLayout;
    GtkWidget *editor;
    
    window = gtk_application_window_new(app);
    gtk_window_set_title(GTK_WINDOW(window), "Win1");
    gtk_window_set_default_size(GTK_WINDOW(window), 600, 400);
    
    mainLayout = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
    gtk_container_add(GTK_CONTAINER(window), mainLayout);
    
    // The editor
    editor = gtk_source_view_new();
    gtk_source_view_set_show_line_numbers(GTK_SOURCE_VIEW(editor), 1);
    
    GtkTextBuffer *buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(editor));
    
    GtkSourceLanguageManager *manager = gtk_source_language_manager_new();
    GtkSourceLanguage *lang = gtk_source_language_manager_get_language(manager, "c");
    gtk_source_buffer_set_language(GTK_SOURCE_BUFFER(buffer), lang);
    
    // The scrollbar
    GtkWidget *editorWin = gtk_scrolled_window_new(NULL, NULL);
    gtk_container_add(GTK_CONTAINER(editorWin), editor);
    gtk_box_pack_start(GTK_BOX(mainLayout), editorWin, 1, 1, 1);
    
    gtk_widget_show_all(window);
}

int main(int argc, char **argv)
{
    GtkApplication *app;
    int status;
    
    gtk_source_init();
    
    app = gtk_application_new("org.gtk.example", G_APPLICATION_FLAGS_NONE);
    g_signal_connect(app, "activate", G_CALLBACK(build_window), NULL);
    status = g_application_run(G_APPLICATION(app), argc, argv);
    g_object_unref(app);
    
    gtk_source_finalize();

    return status;
}
