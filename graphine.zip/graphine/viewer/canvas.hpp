#pragma once

#include <QFrame>
#include <QPainter>
#include <vector>

#include <dom.hpp>

class Canvas : public QFrame {
    Q_OBJECT
public:
    Canvas();
    ~Canvas();
    
    void setElements(std::vector<Element *> elements) {
        this->elements = elements;
    }
protected:
    int getLargestSize(Block *block);
    int getTotalSize(Block *block);
    
    void addElement(Element *element, Block *parent = nullptr);
    void renderCanvas(QPainter &painter, std::vector<Element *> toDraw);
    void paintEvent(QPaintEvent *);
private:
    std::vector<Element *> elements;
    int xPos = 0;
    int yPos = 0;
};
