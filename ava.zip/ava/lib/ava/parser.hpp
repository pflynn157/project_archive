#pragma once

#include <string>
#include <map>
#include <vector>
#include <stack>

#include <ava/ast.hpp>
#include <ava/lex.hpp>
#include <ava/utils/ErrorManager.hpp>

class BaseParser {
public:
    explicit BaseParser(std::string input, BaseScanner *scanner);
    ~BaseParser();
    
    AstTree *getTree() { return tree; }
    
protected:
    struct ExprContext {
        std::stack<AstExpression *> output;
        std::stack<AstOp *> opStack;
        AstDataType *varType;
        bool lastWasOp = true;
    };
    
    //
    // Expression builders
    //
    bool buildOperator(Token token, ExprContext *ctx);
    bool applyHigherPred(ExprContext *ctx);
    bool applyAssoc(ExprContext *ctx);
    AstExpression *checkExpression(AstExpression *expr, AstDataType *varType);
    AstExpression *buildExpression(AstDataType *currentType, int stopToken, bool isConst = false, bool buildList = false);

    //
    // Functions a derived parser must implement
    //
    virtual bool isEofToken(int token) { return false; }
    virtual bool isOperator(int token) { return false; }
    virtual bool isConstLiteral(int token) { return false; }
    virtual bool isIdentifier(int token) { return false; }
    virtual bool isSubExprStart(int token) { return false; }
    virtual bool isSubExprStop(int token) { return false; }
    virtual bool isListItemSeparator(int token) { return false; }
    virtual int getSubExprStop() { return 0; }
    virtual AstOp *buildAstOperator(int token, bool lastWasOp) { return nullptr; }
    virtual AstExpression *buildConstExpr(Token token) { return nullptr; }
    virtual bool buildIDExpr(Token token, ExprContext *ctx) { return false; }

    //
    // Functions
    //
    int isConstant(std::string name);
    bool isVar(std::string name);
    bool isFunc(std::string name);
    
    //
    // Variables
    //
    std::string input = "";
    BaseScanner *scanner;
    AstTree *tree;
    ErrorManager *syntax;
    
    // Needed maps
    // TODO: Make private, turn into functions
    std::map<std::string, AstDataType *> typeMap;
    std::map<std::string, std::pair<AstDataType *, AstExpression*>> globalConsts;
    std::map<std::string, std::pair<AstDataType *, AstExpression*>> localConsts;
    std::vector<std::string> vars;
    std::vector<std::string> funcs;
};

