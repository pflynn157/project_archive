#pragma once

#include "ast.h"

void run_backend(AstTree *tree, int print);
void assemble();
void run_link();

