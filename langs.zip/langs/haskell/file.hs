--file.hs
module Main(main) where

import System.IO

getCmd :: String -> IO()
getCmd cmd
    | cmd == "print" = putStrLn "Print!!"
    | cmd == "println" = putStrLn "Print Line!"
    | cmd == "add" = putStrLn "Add"
    | cmd == "var" = putStrLn "Var"
    | cmd == "arr" = putStrLn "Array"
    | otherwise = putStrLn "Unknown command!"

interpret :: String -> IO()
interpret ln = do
    let parts = words ln
    let cmd = head parts
    getCmd cmd
    return ()
    
run [] = putStr ""
run [x] = interpret x
run (x:xs) = do
    let element = x
    interpret element
    run xs

main :: IO()
main = do
    lns <- readFile "file.txt"
    let contents = lines lns
    run contents
    return ()
    
