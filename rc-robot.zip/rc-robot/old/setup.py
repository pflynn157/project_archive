#!/usr/bin/python3
import RPi.GPIO as GPIO
import time
import esc
from servo import Servo

class Setup:
	btnPin = 11
	redLed = 13
	greenLed = 15

	def init(self):
		GPIO.setmode(GPIO.BOARD)

		GPIO.setup(self.btnPin, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
		GPIO.setup(self.redLed, GPIO.OUT)
		GPIO.setup(self.greenLed, GPIO.OUT)

		e = esc.Esc()
		e.init_d()
		e.init()
		e.calibrate1()

		GPIO.output(self.greenLed, 0)
		GPIO.output(self.redLed, 1)

		while True:
			if GPIO.input(self.btnPin) == 1:
				GPIO.output(self.redLed, 0)
				e.calibrate2()
				break
		
		GPIO.output(self.greenLed, 1)
	
	def stop(self):
		GPIO.cleanup()
