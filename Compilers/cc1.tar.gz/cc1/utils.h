#pragma once

#include "ast.h"

typedef struct
{
    ExprNode **stack;
    int pos;
    int max;
} NodeStack;

NodeStack *node_stack_create();
void node_stack_push(NodeStack *stack, ExprNode *node);
ExprNode *node_stack_pop(NodeStack *stack);
void node_stack_destroy(NodeStack *stack);

typedef struct
{
    char **stack;
    int pos;
    int max;
} StringStack;

StringStack *string_stack_create();
void string_stack_push(StringStack *stack, char *str);
char *string_stack_pop(StringStack *stack);
void string_stack_destroy(StringStack *stack);

