#include <cstdlib>

#include <parser.hpp>
#include <amd64/amd64.hpp>

#include <ltac_build.hpp>

#include "compiler.hpp"

// Generate an AST
AstTree *getAstTree(std::string input, std::string unitName) {
    auto ast = buildAst(input, unitName);
    return ast;
}

// Generate an LTAC file from the AST
LtacFile *getLtacFile(AstTree *input, std::string unitName) {
    auto file = new LtacFile(unitName + ".asm");
    
    auto builder = new LtacBuilder(file);
    builder->buildLtac(input);
    
    return file;
}

// Translate LTAC to Assembly
void compile(LtacFile *input) {
    auto asmGen = new Amd64(input);
    asmGen->assemble();
}

// Translate the assembly to binary
void assemble(std::string path) {
    std::string cmd = "ocas " + path;
    system(cmd.c_str());
}
