//OUTPUT
//X: 31
//Y: 20
//Answer: 71
//END

//RET 0

extern void printf(char *str, ...);

int main() 
{
    int x = 5 + 3 * 10 - 4;
    printf("X: %d\n", x);
    
    int y = 20;
    printf("Y: %d\n", y);
    
    int answer = x + y * 2;
    printf("Answer: %d\n", answer);
    
    return 0;
}
