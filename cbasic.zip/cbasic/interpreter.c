#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <stdlib.h>

#include "interpreter.h"
#include "strutils.h"

void print_out(char *msg, int nl)
{
	int len = strlen(msg);
	char buf[len];
	
	for (int i = 0; i<len; i++) {
		buf[i] = msg[i];
	}
	
	if (buf[0] == '\"' && buf[len-1] == '\"') {
		char buf2[len-1];
		
		for (int i = 1; i<len-1; i++) {
			buf2[i-1] = buf[i];
		}
		buf2[len-2] = '\0';
		
		printf("%s",buf2);
		if (nl)
			puts("");
	} else {
		puts("VAR!");
	}
}

int interpret(char *line)
{
	int code = 0;

	char *first = str_first(line);
	char *second = str_second(line);
	
	if (strcmp(first, "print") == 0) {
		print_out(second, 0);
	} else if (strcmp(first, "println") == 0) {
		print_out(second, 1);
	} else if (strcmp(first, "exit") == 0) {
		code = 1;
	} else {
		puts("Error: Unknown command:");
		printf("** %s **\n", line);
	}
	
	free(first);
	free(second);
	
	return code;
}
