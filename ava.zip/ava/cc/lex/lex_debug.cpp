#include <iostream>

#include "lex.hpp"

void Token::print() {
    switch (this->type) {
        case EmptyToken: std::cout << "???" << std::endl; break;
        case Eof: std::cout << "EOF" << std::endl; break;
        
        case Auto: std::cout << "auto" << std::endl; break;
        case Break: std::cout << "break" << std::endl; break;
        case Case: std::cout << "case" << std::endl; break;
        case Char: std::cout << "char" << std::endl; break;
        case Const: std::cout << "const" << std::endl; break;
        case Continue: std::cout << "continue" << std::endl; break;
        case Default: std::cout << "default" << std::endl; break;
        case Do: std::cout << "do" << std::endl; break;
        case Double: std::cout << "double" << std::endl; break;
        case Else: std::cout << "else" << std::endl; break;
        case Enum: std::cout << "enum" << std::endl; break;
        case Extern: std::cout << "extern" << std::endl; break;
        case Float: std::cout << "float" << std::endl; break;
        case For: std::cout << "for" << std::endl; break;
        case Goto: std::cout << "goto" << std::endl; break;
        case If: std::cout << "if" << std::endl; break;
        case Int: std::cout << "int" << std::endl; break;
        case Long: std::cout << "long" << std::endl; break;
        case Register: std::cout << "register" << std::endl; break;
        case Return: std::cout << "return" << std::endl; break;
        case Short: std::cout << "short" << std::endl; break;
        case Signed: std::cout << "signed" << std::endl; break;
        case Sizeof: std::cout << "sizeof" << std::endl; break;
        case Static: std::cout << "static" << std::endl; break;
        case Struct: std::cout << "struct" << std::endl; break;
        case Switch: std::cout << "switch" << std::endl; break;
        case Typedef: std::cout << "typedef" << std::endl; break;
        case Union: std::cout << "union" << std::endl; break;
        case Unsigned: std::cout << "unsigned" << std::endl; break;
        case Void: std::cout << "void" << std::endl; break;
        case Volatile: std::cout << "volatile" << std::endl; break;
        case While: std::cout << "while" << std::endl; break;
        case SemiColon: std::cout << ";" << std::endl; break;
        case Assign: std::cout << "=" << std::endl; break;
        case Eq: std::cout << "==" << std::endl; break;
        case LParen: std::cout << "(" << std::endl; break;
        case RParen: std::cout << ")" << std::endl; break;
        case LCBrace: std::cout << "{" << std::endl; break;
        case RCBrace: std::cout << "}" << std::endl; break;
        case Add: std::cout << "+" << std::endl; break;
        case AddEq: std::cout << "+=" << std::endl; break;
        case Inc: std::cout << "++" << std::endl; break;
        case Sub: std::cout << "-" << std::endl; break;
        case SubEq: std::cout << "-=" << std::endl; break;
        case Dec: std::cout << "--" << std::endl; break;
        case Arrow: std::cout << "->" << std::endl; break;
        case Mul: std::cout << "*" << std::endl; break;
        case MulEq: std::cout << "*=" << std::endl; break;
        case Div: std::cout << "/" << std::endl; break;
        case DivEq: std::cout << "/=" << std::endl; break;
        case Mod: std::cout << "%" << std::endl; break;
        case ModEq: std::cout << "%=" << std::endl; break;
        case And: std::cout << "&" << std::endl; break;
        case AndEq: std::cout << "&=" << std::endl; break;
        case LAnd: std::cout << "&&" << std::endl; break;
        case Or: std::cout << "|" << std::endl; break;
        case OrEq: std::cout << "|=" << std::endl; break;
        case LOr: std::cout << "||" << std::endl; break;
        case Xor: std::cout << "^" << std::endl; break;
        case XorEq: std::cout << "^=" << std::endl; break;
        case Lsh: std::cout << "<<" << std::endl; break;
        case LshEq: std::cout << "<<=" << std::endl; break;
        case Lt: std::cout << "<" << std::endl; break;
        case Le: std::cout << "<=" << std::endl; break;
        case Rsh: std::cout << ">>" << std::endl; break;
        case RshEq: std::cout << ">>=" << std::endl; break;
        case Gt: std::cout << ">" << std::endl; break;
        case Ge: std::cout << ">=" << std::endl; break;
        case Ne: std::cout << "!=" << std::endl; break;
        case Not: std::cout << "!" << std::endl; break;
        case Colon: std::cout << ":" << std::endl; break;
        case QMark: std::cout << "?" << std::endl; break;
        case Dot: std::cout << "." << std::endl; break;
        case LBracket: std::cout << "[" << std::endl; break;
        case RBracket: std::cout << "]" << std::endl; break;
        
        case Id: std::cout << "ID(" << id_val << ")" << std::endl; break;
        case String: std::cout << "STR(" << id_val << ")" << std::endl; break;
        case CharL: std::cout << "CHAR(" << i8_val << ")" << std::endl; break;
        case Int32: std::cout << "INT(" << i32_val << ")" << std::endl; break;
    }
}

