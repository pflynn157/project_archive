import os

from drivers.led import *
import regular_drive
import reader

# Get the first part of a string
def get_first(ln):
	ret = ""
	for c in ln:
		if c == ' ':
			break
		else:
			ret += c
	return ret
	
# Get the second part of a string
def get_second(ln):
	ret = ""
	found = False
	
	for c in ln:
		if c == ' ':
			if found:
				ret += c
			else:
				found = True
		else:
			if found:
				ret += c
	
	return ret

# Parse our input
def interpret(ln):
	code = "0"
	
	cmd = get_first(ln)
	args = get_second(ln)
	
	# Handles the LED
	if cmd == "led":
		if args == "on":
			led_toggle(1)
		elif args == "off":
			led_toggle(0)
		else:
			first = get_first(args)
			second = get_second(args)
			
			if first == "blink":
				count = get_first(second)
				dur = get_second(second)
				
				led_blink(int(count), int(dur))
			else:
				code = "1"
				
	# Handles the user-drive command
	if cmd == "user-drive":
		prog = get_first(args)
		time = get_second(args)
		
		regular_drive.run(prog, int(time))
		
	# Handles the car-drive command
	if cmd == "car-drive":
		prog = "./records/" + args + "/"
		if os.path.exists(prog):
			reader.run(prog)
		else:
			code = "1"
	
	return code
