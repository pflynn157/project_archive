int main() {
    int i = 0;
    {
        int a = 2;
    }
    int b = 3;
    return b;
}