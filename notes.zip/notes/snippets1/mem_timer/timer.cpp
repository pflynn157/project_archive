#include <iostream>
#include <chrono>
#include <thread>
#include <functional>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>

void timer_start(std::function<void(void)> func, unsigned int interval)
{
  std::thread([func, interval]()
  { 
    while (true)
    { 
      auto x = std::chrono::steady_clock::now() + std::chrono::milliseconds(interval);
      func();
      std::this_thread::sleep_until(x);
    }
  }).detach();
}

void do_something()
{
	key_t key = ftok("shmfile", 65);
	int shmid = shmget(key, 1024, 0666|IPC_CREAT);
	
	char *str = (char*)shmat(shmid, (void*)0, 0);
	if (strlen(str) > 0) {
		std::cout << str << std::endl;
		shmctl(shmid, IPC_RMID, NULL);
	}
	
	shmdt(str);
}

int main()
{
  timer_start(do_something, 1000);
  while (true)
    ;
}
