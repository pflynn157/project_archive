//
// Copyright 2021 Patrick Flynn
// This file is part of uds-wordpad.
// uds-wordpad is licensed under the BSD-3 license. See the COPYING file for more information.
//
#include <QPixmap>

#include <main_toolbar.hpp>
#include <actions.hpp>

MainToolbar::MainToolbar() {
    newFile = new QToolButton();
    openFile = new QToolButton();
    saveFile = new QToolButton();
    saveFileAs = new QToolButton();
    cut = new QToolButton;
    copy = new QToolButton;
    paste = new QToolButton;
    undo = new QToolButton;
    redo = new QToolButton;
    
    newFile->setIcon(QPixmap(":/icons/document-new.svg"));
    openFile->setIcon(QPixmap(":/icons/document-open.svg"));
    saveFile->setIcon(QPixmap(":/icons/document-save.svg"));
    saveFileAs->setIcon(QPixmap(":/icons/document-save-as.svg"));
    cut->setIcon(QPixmap(":/icons/edit-cut.svg"));
    copy->setIcon(QPixmap(":/icons/edit-copy.svg"));
    paste->setIcon(QPixmap(":/icons/edit-paste.svg"));
    undo->setIcon(QPixmap(":/icons/edit-undo.svg"));
    redo->setIcon(QPixmap(":/icons/edit-redo.svg"));
    
    actions = new Actions;
    connect(newFile, &QToolButton::clicked, actions, &Actions::newFile);
    connect(openFile, &QToolButton::clicked, actions, &Actions::openFile);
    connect(saveFile, &QToolButton::clicked, actions, &Actions::saveFile);
    connect(saveFileAs, &QToolButton::clicked, actions, &Actions::saveFileAs);
    connect(cut, &QToolButton::clicked, actions, &Actions::cut);
    connect(copy, &QToolButton::clicked, actions, &Actions::copy);
    connect(paste, &QToolButton::clicked, actions, &Actions::paste);
    connect(undo, &QToolButton::clicked, actions, &Actions::undo);
    connect(redo, &QToolButton::clicked, actions, &Actions::redo);
    
    this->addWidget(newFile);
    this->addWidget(openFile);
    this->addWidget(saveFile);
    this->addWidget(saveFileAs);
    this->addSeparator();
    this->addWidget(cut);
    this->addWidget(copy);
    this->addWidget(paste);
    this->addSeparator();
    this->addWidget(undo);
    this->addWidget(redo);
}

MainToolbar::~MainToolbar() {
    delete actions;
    delete newFile;
    delete openFile;
    delete saveFile;
    delete saveFileAs;
    delete cut;
    delete copy;
    delete paste;
    delete undo;
    delete redo;
}

