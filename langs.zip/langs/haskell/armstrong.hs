-- armstrong.hs
-- Example: 153 = 1^3 + 5^3 + 3^3 = 1 + 125 + 27 = 153
module Main(main) where

break_up :: Int -> [Int] -> [Int]
break_up 0 numbers = numbers
break_up no numbers = do
    let next = no `div` 10
    let rem = no `mod` 10
    let nos = rem : numbers
    break_up next nos
    
raise_all :: [Int] -> Int -> [Int]
raise_all [] _ = []
raise_all (n:ns) exp = (n ^ exp) : raise_all ns exp

add_all :: [Int] -> Int -> Int
add_all [] sum = sum
add_all (n:ns) sum = add_all ns (sum+n)

is_armstrong :: Int -> Bool
is_armstrong n = do
    let numbers = break_up n []
    let t = last(numbers)
    let r_nos = raise_all numbers t
    let all = add_all r_nos 0
    
    if all == n
        then True
        else False

main = do
    --let no = 153
    let no = 210
    putStrLn $ "Our number: " ++ (show no)
    
    let b = is_armstrong no
    if b == True
        then putStrLn "Armstrong!!"
        else putStrLn "Not armstrong"
