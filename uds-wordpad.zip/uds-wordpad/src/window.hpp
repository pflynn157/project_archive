//
// Copyright 2021 Patrick Flynn
// This file is part of uds-wordpad.
// uds-wordpad is licensed under the BSD-3 license. See the COPYING file for more information.
//
#pragma once

#include <QMainWindow>
#include <QMenuBar>
#include <QStatusBar>
#include <QLabel>
#include <QCloseEvent>

#include <main_toolbar.hpp>
#include <format_toolbar.hpp>
#include <tabwidget.hpp>
#include <menubar/filemenu.hpp>
#include <menubar/editmenu.hpp>
#include <menubar/helpmenu.hpp>

class Window : public QMainWindow {
    Q_OBJECT
public:
    Window();
    ~Window();
    
    void setCurrentFile(QString path);
    void setCurrentSaved(bool saved);
    
    TabWidget *getTabWidget() { return tabwidget; }
    FormatToolbar *getFormatToolbar() { return format_toolbar; }
protected:
    void closeEvent(QCloseEvent *event);
private:
    void initMenuBar();
    void initStatusBar();

    MainToolbar *main_toolbar;
    FormatToolbar *format_toolbar;
    TabWidget *tabwidget;
    
    QMenuBar *menubar;
    FileMenu *file_menu;
    EditMenu *edit_menu;
    HelpMenu *help_menu;
    
    QStatusBar *statusbar;
    QLabel *currentFile, *currentStatus;
};

