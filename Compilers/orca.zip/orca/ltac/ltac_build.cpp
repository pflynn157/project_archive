#include <ltac_build.hpp>
#include <ltac/struct.hpp>

#include <config.hpp>

LtacBuilder::LtacBuilder(LtacFile *file) {
    this->file = file;
}

// The Ast -> LTAC translation function
// For now at least, syntax and schematics are not checked here. We
// only do straight translation.
void LtacBuilder::buildLtac(AstNode *top) {
    for (auto child : top->getChildren()) {
        switch (child->getType()) {
            case AstType::Scope: buildLtac(child); break;
            case AstType::Func: buildFunc(child); break;
            
            case AstType::FuncCall: {
                auto astFc = static_cast<AstFuncCall *>(child);
                
                if (astFc->getName() == "syscall") {
                    buildFuncCall(astFc, true);
                } else {
                    buildFuncCall(astFc, false);
                }
            } break;
            
            case AstType::Ret: buildRet(child); break;
            
            // Variables
            case AstType::Var: {
                auto var = static_cast<AstVar *>(child);
                
                if (var->isDeclaration()) 
                    buildVarDec(var);
                else
                    buildVarAssign(var);
            } break;
        }
    }
}

// Translate a function declaration
void LtacBuilder::buildFunc(AstNode *child) {
    auto astFunc = static_cast<AstFunc *>(child);
    auto func = new LtacLabel(astFunc->getName());
    file->addCode(func);
                
    auto funcElements = astFunc->getChildren();
    auto scope = funcElements[0];
    
    // Arguments
    if (funcElements.size() == 2) {
        auto args = funcElements[1];
        
        for (auto argNode : args->getChildren()) {
            auto arg = static_cast<AstArg *>(argNode);
            int pos = buildVarDec(arg->getName(), arg->getDataType());
            
            auto ldarg = new LtacLdArg(pos, LtacType::LdArg);
            file->addCode(ldarg);
        
            switch (arg->getDataType()) {
                case DataType::Byte: ldarg->setType(LtacType::LdBArg); break;
                case DataType::Char: ldarg->setType(LtacType::LdBArg); break;
                case DataType::Octal: ldarg->setType(LtacType::LdBArg); break;
                case DataType::Int: ldarg->setType(LtacType::LdDwArg); break;
                case DataType::Float: ldarg->setType(LtacType::LdDwArg); break;
                case DataType::String: ldarg->setType(LtacType::LdQwArg); break;
            }
        }
    }
    
    buildLtac(astFunc);
}

// Translate either a function call or system call
void LtacBuilder::buildFuncCall(AstFuncCall *astFc, bool syscall) {
    auto fc = new LtacFuncCall;
    if (!syscall) fc = new LtacFuncCall(astFc->getName());
    else fc = new LtacSyscall;
    
    file->addCode(fc);
                    
    for (auto arg : astFc->getChildren()) {
        switch (arg->getType()) {
            case AstType::Int: {
                auto i = static_cast<AstInt *>(arg);
                fc->addIArg(i->getVal());
            } break;
                            
            case AstType::String: {
                auto str = static_cast<AstString *>(arg);
                auto name = buildString(str->getVal());
                fc->addSArg(name);
            } break;
            
            case AstType::Id: {
                auto id = static_cast<AstId *>(arg);
                int pos = vars[id->getVal()];
                auto type = varTypes[id->getVal()];
                
                switch (type) {
                    case DataType::Byte: break;
                    case DataType::Char: break;
                    case DataType::Octal: break;
                    case DataType::Int: fc->addVar32(pos); break;
                    case DataType::Float: break;
                    case DataType::String: fc->addPtr(pos); break;
                }
            } break;
        }
    }
}

// Translates a return statement
void LtacBuilder::buildRet(AstNode *child) {
    auto ret = new LtacRet;
    file->addCode(ret);
}

std::string LtacBuilder::buildString(std::string val) {
    std::string name = "STR" + std::to_string(strIndex);
    ++strIndex;

    auto str = new LtacStringVal(name, val);
    file->addData(str);
    
    return name;
}
