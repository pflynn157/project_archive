#include <stdio.h>

#include "parser.h"

//
// Parses an expression
//
typedef struct {
    AstExpression *op_stack[10];
    int op_stack_top;
    
    AstExpression *output_stack[10];
    int output_stack_top;
    
    AstExpression *expr_list;
} ExprBuilder;

void process_expression(ExprBuilder *builder) {
    // Build operators
    while (builder->op_stack_top > 0) {
        builder->op_stack_top -= 1;
        AstExpression *op = builder->op_stack[builder->op_stack_top];
        
        builder->output_stack_top -= 1;
        op->rval = (struct AstExpression *)builder->output_stack[builder->output_stack_top];
        builder->output_stack_top -= 1;
        op->lval = (struct AstExpression *)builder->output_stack[builder->output_stack_top];
        
        builder->output_stack[builder->output_stack_top] = op;
        builder->output_stack_top += 1;
    }
}

AstExpression *parse_expression(Parser *parser, Token terminator) {
    ExprBuilder *builder = malloc(sizeof(ExprBuilder));
    builder->op_stack_top = 0;
    builder->output_stack_top = 0;
    builder->expr_list = NULL;
    
    Token token = lex_get_next(parser->scanner);
    while (token != terminator && token != Eof) {
        switch (token) {
            case IntL: {
                AstExpression *expr = ast_expr_create(AST_IntL);
                int val = lex_get_int_buffer(parser->scanner);
                expr->int_literal = val;
                
                builder->output_stack[builder->output_stack_top] = expr;
                builder->output_stack_top += 1;
            } break;
            
            case Id: {
                char *name1 = lex_get_buffer(parser->scanner);
                char *name = malloc(sizeof(char)*strlen(name1));
                strcpy(name, name1);
                
                AstExpression *expr = ast_expr_create(AST_Id);
                expr->name = name;
                
                builder->output_stack[builder->output_stack_top] = expr;
                builder->output_stack_top += 1;
            } break;
            
            case Plus: {
                AstExpression *expr = ast_expr_create(AST_Add);
                builder->op_stack[builder->op_stack_top] = expr;
                builder->op_stack_top += 1;
            } break;
            
            case Comma: {
                if (!builder->expr_list) {
                    builder->expr_list = ast_expr_create(AST_ExprList);
                    builder->expr_list->list_size = 0;
                }
                
                process_expression(builder);
                AstExpression *expr = builder->output_stack[0];
                builder->output_stack_top = 0;
                
                builder->expr_list->list[builder->expr_list->list_size] = (struct AstExpression *)expr;
                builder->expr_list->list_size += 1;
            } break;
            
            default: {
                fprintf(stderr, "Unexpected token in expression.\n");
                lex_debug(token, parser->scanner);
            }
        }
        
        token = lex_get_next(parser->scanner);
    }
    
    process_expression(builder);
    
    if (builder->expr_list) {
        AstExpression *expr = builder->output_stack[0];
        builder->expr_list->list[builder->expr_list->list_size] = (struct AstExpression *)expr;
        builder->expr_list->list_size += 1;
    }
    
    // Return final result
    AstExpression *expr;
    if (builder->expr_list) expr = builder->expr_list;
    else expr = builder->output_stack[0];
    free(builder);
    return expr;
}

//
// Parses a variable declaration
//
void parse_var_dec(Parser *parser, AstBlock *block) {
    // Name token
    Token token = lex_get_next(parser->scanner);
    char *name1 = lex_get_buffer(parser->scanner);
    char *name = malloc(sizeof(char)*strlen(name1));
    strcpy(name, name1);
    if (token != Id) {
        fprintf(stderr, "Expected variable name.\n");
        lex_debug(token, parser->scanner);
    }
    
    // Next token should be a colon
    token = lex_get_next(parser->scanner);
    if (token != Colon) {
        fprintf(stderr, "Expected \':\' in variable declaration.\n");
        lex_debug(token, parser->scanner);
    }
    
    // Make sure the next token is a data type
    // TODO: Fix: Just consume for right now
    token = lex_get_next(parser->scanner);
    
    // Make sure the next token is an assignment token
    token = lex_get_next(parser->scanner);
    if (token != Assign) {
        fprintf(stderr, "Expected \':=\' in variable declaration.\n");
        lex_debug(token, parser->scanner);
    }
    
    // Build the expression
    AstExpression *expr = parse_expression(parser, SemiColon);
    AstExpression *id_expr = ast_expr_create(AST_Id);
    id_expr->name = name;
    
    AstExpression *assign_expr = ast_expr_create(AST_Assign); 
    assign_expr->lval = (struct AstExpression *)id_expr;
    assign_expr->rval = (struct AstExpression *)expr;
    
    // Finally, add the statement
    AstStatement *stmt = ast_statement_create(AST_VarDec);
    ast_set_expr(stmt, assign_expr);
    ast_add_statement(block, stmt);
}

//
// Parses a variable assignment
//
void parse_var_assign(Parser *parser, AstBlock *block, char *name) {
    // Build the expression
    AstExpression *expr = parse_expression(parser, SemiColon);
    AstExpression *id_expr = ast_expr_create(AST_Id);
    id_expr->name = name;
    
    AstExpression *assign_expr = ast_expr_create(AST_Assign);
    assign_expr->lval = (struct AstExpression *)id_expr;
    assign_expr->rval = (struct AstExpression *)expr;
    
    // Create the statement
    AstStatement *stmt = ast_statement_create(AST_VarAssign);
    ast_set_expr(stmt, assign_expr);
    ast_add_statement(block, stmt);
}

//
// Parses a block of code
//
void parse_block(Parser *parser, AstBlock *block) {
    Token token = lex_get_next(parser->scanner);
    
    while (token != RCBrace && token != Eof) {
        switch (token) {
            case Var: parse_var_dec(parser, block); break;
            
            case Id: {
                // First, get the name buffer
                char *name1 = lex_get_buffer(parser->scanner);
                char *name = malloc(sizeof(char)*strlen(name1));
                strcpy(name, name1);
                
                // Now, get the next token to see what kind of statement we have
                token = lex_get_next(parser->scanner);
                if (token == Assign) {
                    parse_var_assign(parser, block, name);
                } else {
                    fprintf(stderr, "Unexpected token in ID expression.\n");
                    lex_debug(token, parser->scanner);
                }
            } break;
        
            // Build a return statement
            case Return: {
                AstStatement *stmt = ast_statement_create(AST_Return);
                AstExpression *expr = parse_expression(parser, SemiColon);
                ast_set_expr(stmt, expr);
                ast_add_statement(block, stmt);
            } break;
            
            default: {
                fprintf(stderr, "Unexpected token in block.\n");
                lex_debug(token, parser->scanner);
            }
        }
    
        token = lex_get_next(parser->scanner);
    }
}

//
// Parses function signatures
//
void parse_function(Parser *parser) {
    Token token = lex_get_next(parser->scanner);
    char *name1 = lex_get_buffer(parser->scanner);
    char *name = malloc(sizeof(char)*strlen(name1));
    strcpy(name, name1);
    if (token != Id) {
        fprintf(stderr, "Expected function name.\n");
        lex_debug(token, parser->scanner);
    }
    
    // Function arguments
    token = lex_get_next(parser->scanner);
    if (token != LParen) {
        fprintf(stderr, "Expected function arguments (No \'(\').\n");
        lex_debug(token, parser->scanner);
    }
    token = lex_get_next(parser->scanner);
    while (token != RParen && token != Eof)
        token = lex_get_next(parser->scanner);
        
    // Function type OR the block name
    token = lex_get_next(parser->scanner);
    
    if (token == Colon) {
        token = lex_get_next(parser->scanner);
        // TODO: Type check
        
        token = lex_get_next(parser->scanner);
    }
    
    if (token != LCBrace) {
        fprintf(stderr, "Expected either block start or type name in function.\n");
    }
    
    // Create the AST function object
    AstFunction *func = ast_function_create(name);
    parser->currentFunc = func;
    
    // Parse the block
    parse_block(parser, func->block);
    
    // Add the function
    ast_add_function(parser->file, func);
}

//
// This parses the global context
// Global context includes:
//      * Functions
//      * Structures
//      * Constants
//      * Enums
//
void parse_global(Parser *parser) {
    Token token = lex_get_next(parser->scanner);
    while (token != Eof) {
        switch (token) {
            case Func: parse_function(parser); break;
            
            default: {
                fprintf(stderr, "Invalid token in global context.\n");
                return;
            }
        }
    
        token = lex_get_next(parser->scanner);
    }
}

//
// This is the "global" visible function in charge of parsing the whole file.
//
AstFile *parse_file(char *name) {
    // Create the file
    AstFile *file = ast_file_create(name);
    
    // Create the context
    Parser parser;
    parser.scanner = malloc(sizeof(Scanner));
    parser.file = file;
    parser.currentFunc = NULL;
    
    // Init the scanner
    lex_init(name, parser.scanner);
    
    // Start running!
    parse_global(&parser);
    
    // Clean up
    lex_destroy(parser.scanner);
    
    // Return the file
    return file;
}

