#pragma once

#include <vector>
#include <types.hh>

void end_check(std::vector<String> contents);
void cmd_check(std::vector<String> contents);
