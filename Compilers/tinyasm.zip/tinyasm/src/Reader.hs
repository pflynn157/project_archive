module Reader(readByte) where

import System.IO
import Data.Int
import Data.Char
import Data.Binary as B
import qualified Data.ByteString.Lazy as BL
import qualified Data.ByteString as BS
import qualified Data.ByteString.UTF8 as BSU
import qualified Data.Binary.Get as B

-- Read a byte from the file
readByte reader = do
    byte <- hGetChar reader
    return byte

-- Reads an integer from the file
readInt reader = do
    b1 <- hGetChar reader
    b2 <- hGetChar reader
    b3 <- hGetChar reader
    b4 <- hGetChar reader
    let no_str = BSU.fromString [b1, b2, b3, b4] :: BS.ByteString
    let no_str_l = BL.fromStrict no_str
    let no = B.decode no_str_l :: Int32
    return ()
    return no
    
-- Reads a 64-bit integer from the file
readInt64 reader = do
    b1 <- hGetChar reader
    b2 <- hGetChar reader
    b3 <- hGetChar reader
    b4 <- hGetChar reader
    b5 <- hGetChar reader
    b6 <- hGetChar reader
    b7 <- hGetChar reader
    b8 <- hGetChar reader
    let no_str = BSU.fromString [b1, b2, b3, b4, b5, b6, b7, b8] :: BS.ByteString
    let no_str_l = BL.fromStrict no_str
    let no = B.decode no_str_l :: Int64
    return ()
    return no
    
-- Reads a string from a file
buildStr str reader 0 = return (reverse str)
buildStr str reader i = do
    c <- hGetChar reader
    buildStr (c : str) reader (i - 1)
    
readStr reader len = do
    s <- buildStr [] reader len
    return s
    
----------------------TEST------------------------------------
-- Print bytes
printByte b
    | b == (chr 0xA1) = putStrLn "A1"
    | b == (chr 0xA2) = putStrLn "A2"
    | otherwise = putStrLn "Idk"

-- Main function
main = do
    reader <- openBinaryFile "out.bin" ReadMode
    
    --Bytes
    b1 <- readByte reader
    b2 <- readByte reader
    
    printByte b1
    printByte b2
    
    --Ints
    i32 <- readInt reader
    putStrLn $ "Int32: " ++ (show i32)
    
    i64 <- readInt64 reader
    putStrLn $ "Int64: " ++ (show i64)
    
    --Strings
    len <- readInt reader
    str <- readStr reader len
    putStrLn $ "Str: " ++ str
    
    hClose reader
