#pragma once

#include <QFrame>
#include <QVBoxLayout>
#include <QToolBar>
#include <QToolButton>
#include <QTableWidget>

class AccountsWidget : public QFrame {
    Q_OBJECT
public:
    AccountsWidget();
    ~AccountsWidget();
private:
    QVBoxLayout *layout;
    QToolBar *toolbar;
    QToolButton *addAccount, *save;
    QTableWidget *accounts;
private slots:
    void onAddAccountClicked();
};