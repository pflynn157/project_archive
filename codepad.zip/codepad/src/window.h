#pragma once

#include <gtk/gtk.h>

#include "editor.h"

typedef struct
{
    GtkWidget *window;
    GtkWidget *tabs;
    
    Editor **tabContent;
    int tabCount;
    int currentTab;
} Window;

void build_window(GtkApplication *app, gpointer user_data);

