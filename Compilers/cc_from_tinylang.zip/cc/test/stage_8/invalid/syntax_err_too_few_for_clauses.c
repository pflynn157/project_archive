int main() {
    for (int i = 2; i < 3)
        3;
    return 0;
}