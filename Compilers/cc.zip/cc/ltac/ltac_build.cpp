#include <ltac_build.hpp>
#include <ltac/struct.hpp>

#include <config.hpp>

LtacBuilder::LtacBuilder(LtacFile *file) {
    this->file = file;
}

// The Ast -> LTAC translation function
// For now at least, syntax and schematics are not checked here. We
// only do straight translation.
void LtacBuilder::buildLtac(AstNode *top) {
    for (auto child : top->getChildren()) {
        switch (child->getType()) {
            case AstType::Scope: buildLtac(child); break;
            case AstType::Func: buildFunc(child); break;
            
            case AstType::FuncCall: {
                auto astFc = static_cast<AstFuncCall *>(child);
                
                if (astFc->getName() == "syscall") {
                    buildFuncCall(astFc, true);
                } else {
                    buildFuncCall(astFc, false);
                }
            } break;
            
            case AstType::Ret: buildRet(child); break;
            
            // Variables
            case AstType::Var: {
                auto var = static_cast<AstVar *>(child);
                
                if (var->isDeclaration()) 
                    buildVarDec(var);
                else
                    buildVarAssign(var);
            } break;
        }
    }
}

std::string LtacBuilder::buildString(std::string val) {
    std::string name = "STR" + std::to_string(strIndex);
    ++strIndex;

    auto str = new LtacStringVal(name, val);
    file->addData(str);
    
    return name;
}
