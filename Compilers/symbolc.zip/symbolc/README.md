## symbolc

### Introduction
So, what exactly is this? This is a compiler. Okay, its not really a full compiler; it just does the first half of the work (converting our language into assembly language). Once the assembly is generated, it is fed into an assembler (in our case, nasm). What does this program compile? A language called symbol.

### What is symbol?
Symbol is a very, very simplistic programming language. As its name may imply, symbol tries to make use of symbols rather than words as much as possible. At this point, symbol is too simplistic to be useful. All it supports is some basic control and printing strings to the console. See the "test.sym" file to see the complete programming language. For an explanation of the language, see the "lang.md" file.

### How do I use the compiler?
Simple. Just call symbol, and feed in a file. No command line arguments are currently accepted.

### How the compiler works:
1) Enter the main function, make sure we have a file.   
2) Load the text of the file.   
3) Go through pass 1   
	* First, strip all comments from the file   
	* Second, create an array of functions   
	* Third, create an array of .data variables (mainly string). These will be translated to assembly.   
	* Fourth, create an array of .bss variables. These too will be translated to assembly.   
	* Return   
4) Go through pass 2   
	* Parse each function and translate it to assembly   
	* Create an array containing a complete assembly function translation   
	* Merge all arrays into a single section .text array   
	* Return   
5) By now, we should have a completed assembly program. Output all this into an assembly file.   
