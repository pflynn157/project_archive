#pragma once

#include <string>

enum DataType {
	NONE = 0,
	INT = 1,
	DEC = 2,
	BOOL = 3,
	CHAR = 4,
	STR = 5
};

DataType inferType(std::string ln);
