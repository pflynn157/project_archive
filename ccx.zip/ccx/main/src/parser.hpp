#pragma once

#include <string>
#include <map>

#include "lex.hpp"
#include "ast.hpp"
#include "error.hpp"

class Parser {
public:
    explicit Parser(std::string path);
    ~Parser();
    AstFile *parseFile();
private:
    Scanner *scanner;
    AstFile *file;
    ErrorManager *err;
    
    // Parser-specific variables
    std::map<std::string, DataType> funcTypeMap;
    std::map<std::string, DataType> typeMap;
    std::map<std::string, DataType> arrayTypeMap;
    std::string currentFunc = "";
    
    // Functions
    void buildFunction();
    void buildBlock(AstBlock *block);
    void buildVarDec(AstBlock *block);
    void buildVarAssign(AstBlock *block, std::string name);
    void buildArrayDec(AstBlock *block);
    void buildArrayAssign(AstBlock *block, std::string name);
    void buildFuncCallStmt(AstBlock *block, std::string name);
    void buildSyscall(AstBlock *block);
    void buildWhileLoop(AstBlock *block);
    void buildForLoop(AstBlock *block);
    void buildCondStmt(AstBlock *block);
    void processExpression(std::stack<AstExpression *> &stack, std::stack<AstExpression *> &opStack);
    AstExpression *buildExpression(TokenType endToken = SemiColon, bool isList = false);
    DataType getDataType(TokenType type);
};

