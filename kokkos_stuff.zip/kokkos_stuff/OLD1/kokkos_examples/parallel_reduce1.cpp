#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <Kokkos_Core.hpp>

const size_t SIZE = 16;

int main(int argc, char **argv) {
    Kokkos::initialize(argc, argv);
    
    int *numbers = (int *)malloc(sizeof(int)*SIZE);

    // Fill the array
    Kokkos::parallel_for(SIZE, KOKKOS_LAMBDA(const int i) {
        printf("%d ", i);
        numbers[i] = i;
    });
    puts("");
    
    // Dump
    for (int i = 0; i<32; i++) printf("-");
    puts("");
    for (int i = 0; i<SIZE; i++) printf("%d ", numbers[i]);
    puts("");
    
    // Add the numbers (serial)
    int result1 = 0;
    for (int i = 0; i<SIZE; i++) result1 += numbers[i];
    
    // Add the numbers (parallel)
    int result2 = 0;
    
    Kokkos::parallel_reduce("Label", SIZE, KOKKOS_LAMBDA(const size_t i, int& j) {
        j += numbers[i];
    }, result2);
    
    printf("Result1 (serial): %d\n", result1);
    printf("Result2 (kokkos): %d\n", result2);

    free(numbers);
    return 0;
}

