module Pass1(getData, getCode, runData1, runPass1) where

import Data.Int

import Utils
import Code

-- Gets the data portion of the Assembly file
getData [] contents found = reverse contents
getData (x:xs) contents found = do
    if x == "section text"
        then reverse contents
        else if x == "section data"
            then getData xs contents True
            else getData xs (x : contents) True

-- Gets the code portion of the Assembly file
getCode [] contents found = reverse contents
getCode (x:xs) contents found = do
    if x == "section data"
        then getCode xs contents False
        else if x == "section text"
            then getCode xs contents True
            else if found == True
                then getCode xs (x : contents) found
                else getCode xs contents found
                
-- Returns the size from a data element
dataSize parts
    | pType == "string" = (length (parts !! 2)) - 2
    | otherwise = 0
    where
        pType = parts !! 1
                
-- The pass 1 function for the data section
runData1 :: [String] -> [(String, Int)] -> Int -> ([(String, Int)], Int64)
runData1 [] symbols lc = do
    let lc64 = fromIntegral lc :: Int64
    (symbols, lc64)
runData1 (x:xs) symbols lc = do
    let parts = parse x
    let name = init (head parts)
    let size = dataSize parts
    
    runData1 xs ((name, lc) : symbols) (lc + size)

-- The pass 1 function for the code section
runPass1 :: [String] -> [(String, Int)] -> Int -> [(String, Int)]
runPass1 [] symbols lc = symbols
runPass1 (x:xs) symbols lc = do
    let parts = parse x
    let cType = codeType parts
    let size = codeSize cType
    
    if cType == Label
        then do
            let name = init (head parts)
            runPass1 xs ((name, lc) : symbols) lc
        else runPass1 xs symbols (lc + size)
