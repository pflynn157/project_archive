---
layout: page
title: About
permalink: /about/
---

Welcome to OOTO! This page will tell you more about this project, its purpose, and our goals.

### What is OOTO?

OOTO began as a larger umbrella project around some personal projects I was working on through 2021, and new projects since then.

Let me back up.

I do a lot of side projects, largely for learning purposes and exploration. When you are learning a skill, the learning process begins with just learning- largely duplicating existing work to understand how things are done. Maybe some people can read a book and still get the same results, but for me and many others creating scaled down versions of something is the best way to learn how something works. Eventually, your skills will reach the point where you are not just learning, but you begin to understand the field well enough to look around and see either problems and/or areas for improvement. I certainly have plenty to learn, but my computer skills have largely reached the point where I'm able to look around and do work rather than just learning how something works.

Over covid, I began taking my skills from these projects and experiences from my various jobs at that point, and I began thinking about areas where I saw some shortcomings, and I began to do experimental projects in those areas. For a while, these were tied to my personal accounts and projects, but as I began to move more into projects that actually had a real purpose, I decided to create a separate umbrella project for these projects.

And so OOTO was born. OOTO is my research lab of sorts, and functions as the base for non-trivial, exploratory research projects. That said, OOTO is not an official research project or a business. It's a private project that I work on independently (at the moment...) in my free time.

### What Are the Goals?

The most immediate goal behind this is to have a one-stop-shop for my projects, but I do have a few specific goals I wish to pursue with this:
1. Explore new ideas and concepts
2. Challenge norms
3. Create simple tools without bloat and large overheads
4. Educate and showcase

Points 1 and 2 largely run together, and it builds on a belief I have that is not often held by the larger research community (for reasons I completely understand): it's okay to re-invent the wheel.

I know some people will cringe when they see that, especially those in computer science. In many cases, the advice "don't reinvent the wheel" is good advice, especially when you're in a context (especially a business context) when you need to build and ship a product. But this can also be bad advice, especially in the research world. First of all, it stifles creativity and innovation. When we're telling everyone to use such and such framework or technology and not to question it, eventually the majority of people are going to lose the ability to build and maintain something from scratch. Which leads to point 2: bloat. And there's the hidden cost of learning curves and relying on frameworks that could go away at any point.

Just because a certain technology has been used for X number of years by Y number of people doesn't mean its a good idea. Sometimes a technology is used for a long time because it's the best of available solutions, not because it is _the_ solution.

Points 3 and 4 are largely self-explanatory. Software has become enormously bloated today... once again because we are screamed at not to re-invent the wheel. In the process of any project, I have a goal of creating something that will be usable and maintainable, and not filled with 100 million features that no one will use. When you create a project like this, you have the secondary benefit of being able to educate people with it.

### Authors and Affiliations

This project is run by Patrick Flynn, a graduate student at the University of North Carolina Charlotte. Despite my affiliation with the University as a research assistant, and my summer internships at various research organizations, this project is not in any way affiliated with any institution that I work at.

This project is solely a free time project. I neither make money nor receive funding from it. The work and the goals behind it are my own, and do not reflect the work of any employer, past, present, or future.

If you're interested in the project, you are very welcome! Simply send me an email and we can talk.

