#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <vm_file.h>
#include <opcodes.h>

#include "vm.h"

void vm_run_function(Function *func) {
    // Integer Stack -> limited by 10 elements
    int stack[10];
    int stack_pos = 0;
    
    // The program counter
    int pc = 0;
    
    // Run
    while (pc < func->code_length) {
        uint8_t opcode = func->code[pc];
        
        switch (opcode) {
            case PUSHC: {
                ++pc;
                int arg = (func->code[pc] << 24) | (func->code[pc+1] << 16)
                             | (func->code[pc+2] << 8) | func->code[pc+3];
                pc += 4;
                
                stack[stack_pos] = arg;
                ++stack_pos;
            } break;
            
            case IADD: {
                int val1 = stack[stack_pos - 1];
                int val2 = stack[stack_pos - 2];
                stack_pos -= 2;
                
                stack[stack_pos] = val1 + val2;
                ++stack_pos;
                
                ++pc;
            } break;
            
            case IPRINT: {
                printf("%d\n", stack[stack_pos - 1]);
                ++pc;
            } break;
            
            case RETVOID: return;
            
            case EXIT: {
                //TODO
                return;
            } break;
            
            default: {
                printf("Error: Unknown opcode.\n");
                printf("--> %x\n", opcode);
                pc = func->code_length + 1;
            }
        }
    }
}

void vm_run(VM *vm) {
    // Find the main function
    Function *mainFunc = NULL;
    
    // Get the position of the "main" function name
    int namePos = -1;
    
    for (int i = 0; i<vm->const_pool_length; i++) {
        ConstPoolItem *item = (ConstPoolItem *)vm->const_pool[i];
        
        if (item->item_type == 0xA0) {
            char *name = (char *)item->data;
            if (strcmp(name, "main") == 0) {
                namePos = i;
                break;
            }
        }
    }
    
    for (int i = 0; i<vm->func_count; i++) {
        Function *current = vm->functions[i];
        if (current->name_index == namePos) {
            mainFunc = current;
            break;
        }
    }
    
    if (mainFunc == NULL) {
        printf("Error: Main function not found.\n");
        return;
    } else {
        vm_run_function(mainFunc);
    }
}

