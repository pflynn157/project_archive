// Copyright 2019 Patrick Flynn
//
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, 
//	this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, this 
//	list of conditions and the following disclaimer in the documentation and/or 
//	other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors may 
//	be used to endorse or promote products derived from this software 
//	without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#include <iostream>
#include <string>
#include <cctype>

#include "vars.hh"
#include "strutils.hh"
#include "math.hh"
#include "error.hh"
#include "funcs.hh"
#include "interpreter.hh"
#include "array.hh"

#include <types.hh>

std::vector<Var> global_vars;
std::vector<Var> local_vars;

//Adds an element to an array and checks to make sure there are no duplicates.
void manage_array(std::vector<Var> *arr, Var v, bool rm) {
	for (int i = 0; i<arr->size(); i++) {
		Var c = arr->at(i);
		if (c.name == v.name) {
			arr->erase(arr->begin() + i);
		}
	}
	
	if (!rm) {
		arr->push_back(v);
	}
}

//Add a new variable to the appropriate array
void add_var(Var v, bool global) {
	if (global) {
		manage_array(&global_vars, v, false);
	} else {
		manage_array(&local_vars, v, false);
	}
}

//Removes a variable from an array
void rm_var(Var v, bool global) {
	if (global) {
		manage_array(&global_vars, v, true);
	} else {
		manage_array(&local_vars, v, true);
	}
}

//Infers and assigns a variable's type
Var var_infer(Var v, String value) {
	std::string val = value.str;
	v.val = val;
	//v.type = get_datatype(val);
	
	//Check to see if we are assigning the result of a function
	if (contains(val, '[') && contains(val, ']')) {
		func_invoke(val);
		
		v.val = func_mem;
		v.type = get_datatype(v.val);
		
		/*String fm;
		fm.str = func_mem;
		Var v2 = var_infer(v, fm);
		v.val = v2.val;
		v.type = v2.type;*/
		
		return v;
	}
	
	//Check to see if math is involved
	if (is_math(val)) {
		if (v.type == DataType::STR) {
			v.val = solve_str(val);
		} else if (v.type == DataType::INT || 
				v.type == DataType::DEC) {
			v = solve_exp(v);
		} else if (v.type == DataType::NONE) {
			if (is_no_math(val)) {
				v = solve_exp(v);
			} else {
				v.type = DataType::STR;
				v.val = solve_str(val);
			}
		}
		
		return v;
	}
	
	//Check to see if we are referencing another variable
	Var v2 = get_var(val);
	if (v2.name != "") {
		v.val = v2.val;
		v.type = v2.type;
		return v;
	}
	
	//Check to see if we are referencing an array
	//First see if we are trying to get array length
	if (contains(val, '$') && val[val.length()-1] == '$') {
		std::string name = get_first(val, '$');
		Array arr = get_arr(name);
		
		if (arr.name == "") {
			err_extra = "Note: The \'$\' Operator may only be used with arrays.";
			rt_err(value, "Cannot reference an undeclared array.");
		}
		
		int len = arr.contents.size();
		v.val = std::to_string(len);
		v.type = DataType::INT;
		
		return v;
	}
	
	//Second, see if we are trying to access an array element
	if (contains(val, '@')) {
		std::string name = get_first(val, '@');
		Array arr = get_arr(name);
		
		if (arr.name != "") {
			int index = 0;
		
			//First, determine the index and convert to an integer
			std::string s_index = get_second(val, '@');
			index = get_index(s_index, value);
			
			//Make sure the index is not greater than the length of the array
			if (index >= arr.contents.size()) {
				rt_err(value, "Index out of bounds.");
			}
			
			//If we make it here, we can get the element
			std::string element = arr.contents.at(index);
			v.val = element;
			
			//Now determine the appropriate datatype of the variable
			if (arr.type == DataType::STR) {
				v.type = DataType::CHAR;
			} else {
				v.type = arr.type;
			}
			
			return v;
		}
	}
	
	//Third, see if we are trying to use the indexOf function
	if (contains(val, '?')) {
		std::string name = get_first(val, '?');
		Array arr = get_arr(name);
		
		if (arr.name != "") {
			//First determine the value
			std::string char_at = get_second(val, '?');
			DataType type = get_datatype(char_at);
			
			if (type == DataType::CHAR || type == DataType::STR) {
				char_at = rm_first_last(char_at);
			} else if (type == DataType::NONE) {
				Var v2 = get_var(char_at);
				
				if (v.name != "") {
					char_at = var_val(char_at);
				} else {
					rt_err(value, "Unknown variable or value specified.");
				}
			}
			
			//See if its in an array
			int index = -1;
			
			for (int i = 0; i<arr.contents.size(); i++) {
				if (arr.contents.at(i) == char_at) {
					index = i;
					break;
				}
			}
			
			v.type = DataType::INT;
			v.val = std::to_string(index);
		}
	}
	
	return v;
}

//Creates a new variable
void var_create(String line, bool global) {
	std::string ln = clr_spaces(line.str);
	
	std::string name = get_first(ln, '=');
	std::string val = get_second(ln, '=');
	
	Var v;
	v.name = name;
	
	String line2;
	line2.str = val;
	line2.ln_no = line.ln_no;
	
	v.type = get_datatype(val);
	v = var_infer(v, line2);
	if (v.type == DataType::NONE) {
		err_unknown_type(line);
	}
	
	add_var(v, global);
}

//Re-assigns an existing variable
void var_assign(String line, bool global) {
	std::string ln = clr_spaces(line.str);
	std::string name = get_first(ln, '=');
	std::string val = get_second(ln, '=');

	Var v = get_var(name);
	if (v.name == "") {
		rt_err(line, "Cannot assign value to undeclared variable.");
	}
	
	String ln2;
	ln2.str = val;
	ln2.ln_no = line.ln_no;
	
	v = var_infer(v, ln2);
	add_var(v, global);
}

//Returns a variable based on name
Var get_var(std::string name) {
	Var ret;
	
	//Check local variables first
	for (Var v : local_vars) {
		if (v.name == name) {
			return v;
		}
	}
	
	//Check global variables
	for (Var v : global_vars) {
		if (v.name == name) {
			return v;
		}
	}
	
	return ret;
}

//Checks to see if such a variable exists
bool is_var(std::string name) {
	Var v = get_var(name);
	if (v.name == "") {
		return false;
	}
	return true;
}

//Returns the value of a var
std::string var_val(std::string name) {
	Var v = get_var(name);
	if (v.name == "") {
		return "";
	}
	
	if (is_var(v.val)) {
		return var_val(v.val);
	}
	
	return v.val;
}

