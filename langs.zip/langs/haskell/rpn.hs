module Main(main) where

-- Reverse arrays
rvs2 [] new = new
rvs2 (x:xs) new = do
    let n2 = x : new
    rvs2 xs n2
    
rvs xs = rvs2 xs []

-- Removes quotes
rm_quotes [] new = new
rm_quotes (x:xs) new
    | x == '\'' = rm_quotes xs new
    | otherwise = rm_quotes xs (x : new)

-- Parse a comma separated string
parse [] objects current = rvs objects
parse (x:xs) objects current
    | x == ',' = parse xs ((rm_quotes current []) : objects) ""
    | otherwise = do
        let str2 = current ++ (show x)
        parse xs objects str2

breakUp ln = parse ln [] ""

-- The main calculator
calc [] stack = stack
calc (x:xs) stack
    | x == "+" = calc xs ((show (no1+no2)) : stack)
    | x == "-" = calc xs ((show (no1-no2)) : stack)
    | x == "*" = calc xs ((show (no1*no2)) : stack)
    | x == "/" = calc xs ((show (no1 `div` no2)) : stack)
    | otherwise = calc xs (x : stack)
    where
        no1 = read (stack !! 1) :: Integer
        no2 = read (head stack) :: Integer
        
-- A run function
run 5 = return ()
run x = do
    putStrLn ""
    putStr "> "
    prob <- getLine
    let parts = breakUp prob
    let result = calc parts []
    putStrLn ("Result: " ++ (head result))
    run (x+1)

-- The main function
main = do
    putStrLn "RPN Calculator"
    putStrLn ""
    putStrLn "Enter your problem (separated by commas, ended with commas):"
    
    run 0
