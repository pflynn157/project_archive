#pragma once

#include <string>

#include <ava/ast.hpp>
#include <ava/parser.hpp>
#include "../lex/lex.hpp"

class Parser : public BaseParser {
public:
    explicit Parser(std::string input);
    ~Parser();
    bool parse();
    
private:
    bool buildFunction(Token startToken);
    bool buildBlock(AstBlock *block);
    bool buildVariableDec(AstBlock *block, Token startToken);
    bool buildReturn(AstBlock *block);
    AstDataType *buildDataType(Token token);
    
    // expression.cpp
    bool isEofToken(int token) override;
    bool isOperator(int token) override;
    bool isConstLiteral(int token) override;
    bool isIdentifier(int token) override;
    bool isSubExprStart(int token) override;
    bool isSubExprStop(int token) override;
    bool isListItemSeparator(int token) override;
    int getSubExprStop() override;
    AstOp *buildAstOperator(int token, bool lastWasOp) override;
    AstExpression *buildConstExpr(Token token) override;
    bool buildIDExpr(Token token, ExprContext *ctx) override;
};

