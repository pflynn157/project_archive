#pragma once

#include <string>

// Represents the LtacInstr type
enum class LtacType {
    None,
    
    Label,
    FuncCall,
    Ret,
    
    LdArg,
    LdBArg,        // Byte argument (1 byte)
    LdWArg,        // Word argument (2 bytes)
    LdDwArg,       // Double-word argument (4 bytes)
    LdQwArg,       // Qword argument (8 bytes)
    
    Syscall,
    
    MovI32,
    MovV32,
    
    Int,
    String,
    Var32,
    Var64,
    Ptr
};

// Represents data element types
enum class LtacDType {
    None,
    String
};

// The base class for all LTAC instructions
class LtacInstr {
public:
    explicit LtacInstr() {}
    explicit LtacInstr(LtacType type) {
        this->type = type;
    }
    
    LtacType getType() { return type; }
    
    virtual std::string printInstr() {
        return "";
    }
protected:
    LtacType type = LtacType::None;
};

// The base class for LTAC data elements
class LtacData {
public:
    explicit LtacData() {}
    explicit LtacData(LtacDType type) {
        this->type = type;
    }
    
    LtacDType getType() { return type; }
    
    virtual std::string printData() {
        return "";
    }
private:
    LtacDType type = LtacDType::None;
};
