#include <fs.h>
#include <io.h>

#define O_RDWR 2
#define PERM_RW 420

FILE open(char *input) {
    return sc_open(input, O_RDWR, PERM_RW);
}

