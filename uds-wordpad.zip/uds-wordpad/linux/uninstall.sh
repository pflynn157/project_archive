#!/bin/bash
echo "Uninstalling..."

rm /opt/uds/bin/uds-player
rm /opt/uds/icons/apps/uds-player.svg
rm /usr/share/applications/uds-player.desktop

update-desktop-database

echo "Done" 

