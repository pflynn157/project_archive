#include <iostream>
#include <string>

#include <amd64/amd64.hpp>

#include <ltac/struct.hpp>
#include <ltac/types.hpp>
#include <ltac/var.hpp>

// The constructor- sets everything up and opens the writer
Amd64::Amd64(LtacFile *file) {
    this->file = file;
    
    std::string path = "/tmp/" + file->getName();
    writer = std::ofstream(path);
}

// The main assembly loop
void Amd64::assemble() {
    // The data
    for (auto ln : file->getData()) {
        switch (ln->getType()) {
            case LtacDType::String: {
                auto str = static_cast<LtacStringVal *>(ln);
                writer << str->getName() << " .string \"" << str->getVal() << "\"" << std::endl;
            } break;
        }
    }
    
    // I like things pretty...
    writer << std::endl;

    // The code
    for (auto ln : file->getCode()) {
        switch (ln->getType()) {
            case LtacType::Label: buildFunc(ln); break;
            
            case LtacType::LdBArg: buildLdBArg(ln); break;
            case LtacType::LdWArg: buildLdWArg(ln); break;
            case LtacType::LdDwArg: buildLdDwArg(ln); break;
            case LtacType::LdQwArg: buildLdQwArg(ln); break;
            
            case LtacType::Syscall: buildSyscall(ln); break;
            case LtacType::FuncCall: buildFuncCall(ln); break;
            case LtacType::Ret: buildRet(ln); break;
            
            case LtacType::MovI32: buildMovI32(ln); break;
            case LtacType::MovV32: buildMovV32(ln); break;
        }
    }

    writer.close();
}

