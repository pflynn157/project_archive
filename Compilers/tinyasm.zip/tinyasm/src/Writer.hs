module Writer(writeByte, writeWord8, writeShort, writeInt, writeInt64, writeStr) where

import System.IO
import Data.Char
import Data.Int
import Data.Binary
import Data.Binary.Put
import qualified Data.ByteString.Lazy as BL
import qualified Data.ByteString.UTF8 as BSU
import qualified Data.ByteString as BS

-- Writes a single byte
writeByte writer byte = hPutChar writer (chr byte)

-- Write an 8-bit unsigned int
encodeWord8 :: Word8 -> Put
encodeWord8 n = do
    putWord8 n

writeWord8 writer no = do
    let i_bin1 = runPut (encodeWord8 no)
    let i_bin2 = BL.toStrict i_bin1
    BS.hPut writer i_bin2

-- Write a short
encodeShort :: Word16 -> Put
encodeShort n = do
    putWord16le n

writeShort writer no = do
    let i_bin1 = runPut (encodeShort no)
    let i_bin2 = BL.toStrict i_bin1
    BS.hPut writer i_bin2

-- Write an integer
encodeInt :: Int32 -> Put
encodeInt n = do
    putInt32le n

writeInt writer no = do
    let i_bin1 = runPut (encodeInt no)
    let i_bin2 = BL.toStrict i_bin1
    BS.hPut writer i_bin2
    
-- Write a 64-bit integer
encodeInt64 :: Int64 -> Put
encodeInt64 n = do
    putInt64le n

writeInt64 writer no = do
    let i_bin1 = runPut (encodeInt64 no)
    let i_bin2 = BL.toStrict i_bin1
    BS.hPut writer i_bin2
    
-- Writes a string
writeStr writer str = do
    let s_bin = BSU.fromString str
    BS.hPut writer s_bin


