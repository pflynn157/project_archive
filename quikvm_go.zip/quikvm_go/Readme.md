## Quik VM

This is the assembler and virtual machine for our Quik bytecode implementation. Eventually, we will merge this with the main Quik source tree, but until the project is further along, we will keep it separate. The plans/case studies are outlined on my personal website, currently in blog section; see patrickflynn.co/blog/.
