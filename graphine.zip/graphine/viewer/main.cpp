#include <QApplication>
#include <iostream>

#include <window.hpp>
#include <reader.hpp>

int main(int argc, char **argv) {
    if (argc <= 1) {
        std::cerr << "Error: No input" << std::endl;
        return 1;
    }
    
    QApplication app(argc, argv);
    
    Window window;
    window.show();
    
    BinParser parser(argv[1]);
    parser.parse();
    window.setCanvas(parser.getElements());
    
    return app.exec();
}
