#!/bin/bash

APP_NAME=uds_app

if [ ! -d ./build ] ; then
    echo "Error: The application does not seem to be built."
    exit 1
fi

cd build

if [ -d ./linux_bin ]; then
    rm -rf ./linux_bin
fi

mkdir linux_bin

cp src/$APP_NAME linux_bin
cp ../src/icons/$APP_NAME.svg linux_bin
cp ../linux/* linux_bin
cp ../COPYING* linux_bin

tar -czvf "$APP_NAME"_bin_linux.tar.gz linux_bin/*

