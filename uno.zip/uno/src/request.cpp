#include <iostream>

#include "server.hpp"

//Parses an HTTP request
Request Server::parse_request(std::string request) {
	Request ret;
	
	//Get the first line
	std::string ln1 = "";
	
	for (char c : request) {
		if (c == '\n') {
			break;
		}
		ln1 += c;
	}
	
	//Break down the first line
	int part = 1;
	
	for (char c : ln1) {
		if (c == ' ') {
			part++;
			continue;
		}
		
		if (part == 1) {
			ret.type += c;
		} else if (part == 2) {
			ret.path += c;
		} else if (part == 3) {
			ret.protocol += c;
		}
	}
	
	return ret;
}
