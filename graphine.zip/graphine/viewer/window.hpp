#pragma once

#include <QMainWindow>
#include <vector>

#include <canvas.hpp>
#include <dom.hpp>

class Window : public QMainWindow {
    Q_OBJECT
public:
    Window();
    ~Window();
    void setCanvas(std::vector<Element *> elements);
private:
    Canvas *canvas = nullptr;
};
