//stack.go
package main

var stack [20]string
var current int

//Push to the stack
func push(item string) {
	if (current >= 20) {
		return
	}
	
	current++
	stack[current] = item
}

//Pop from the stack
func pop() string {
	if (current < 0) {
		return ""
	}
	
	item := stack[current]
	stack[current] = ""
	current--
	
	return item
}

//Setup the stack
func setup() {
	current = 0
}
