
## Ida Examples

This folder contains examples of program written in the Ida programming language. The main purpose of these are to help me see what I need to add to the language, what works and what doesn't, and just to show overall capabilities of the language.

