#include <stdio.h>

// Write a single byte
void write_byte(unsigned char byte, FILE *writer) 
{
    fputc(byte, writer);
}

// Write a short
void write_short(short val, FILE *writer)
{
    fwrite(&val, sizeof(short), 1, writer);
}

// Write an integer
void write_int(int val, FILE *writer)
{
    fwrite(&val, sizeof(int), 1, writer);
}

// Write a string
void write_str(const char *str, FILE *writer)
{
    fputs(str, writer);
}

