// Copyright 2019 Patrick Flynn
//
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, 
//	this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, this 
//	list of conditions and the following disclaimer in the documentation and/or 
//	other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors may 
//	be used to endorse or promote products derived from this software 
//	without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>

#include "interpreter.hh"
#include "io.hh"
#include "funcs.hh"
#include "vars.hh"
#include "array.hh"
#include "loop.hh"
#include "condition.hh"

#include <strutils.hh>
#include <types.hh>
#include <error.hh>

//Holds info on the body type so when we get to "END",
//we can run the loop correctly
enum BdType {
	NONE = 0,
	CONDITION = 1,
	WHILE = 2,
	FOR = 3,
	LOOP = 4
};

//State variables
bool in_body = false;
int layer = 1;
std::vector<String> body;
BdType type = BdType::NONE;

//This holds whatever is returned from a function
std::string func_mem = "";

//Mode variables
// Modes let us enable/disable certain checks, which
// can speed up execution
bool mode_math = false;

//The mode interpreter
void handle_mode(String line, bool enable) {
	auto second = get_second(line.str, ' ');
	
	if (second == "math") {
		mode_math = enable;
	} else {
		syntax_err(line, "Unknown mode specified.");
	}
}

//The main interpreter program
void interpret(String line, bool global) {
	std::string ln = line.str;
	auto cmd = get_first(ln, ' ');
	auto args = get_second(ln, ' ');
	
	String s_args;
	s_args.str = args;
	s_args.ln_no = line.ln_no;
	
	//First, see if we are in a loop or conditional
	if (in_body) {
		if (cmd == "end" && layer == 1) {
			in_body = false;
		} else if (cmd == "end" && layer > 1) {
			layer--;
			body.push_back(line);
			return;
		} else if (cmd == "if" || cmd == "while"
			|| cmd == "for" || cmd == "loop") {
			layer++;
			body.push_back(line);
			return;
		} else {
			body.push_back(line);
			return;
		}
	}
	
	//Second, check for keywords
	//Mode keywords
	if (cmd == "enable") {
		handle_mode(line, true);
	} else if (cmd == "disable") {
		handle_mode(line, false);
	
	//IO keywords
	} else if (cmd == "print") {
		int c = print(args, false);
		if (c == 1) {
			syntax_err(line, "Invalid string or unknown variable specified.");
		}
	} else if (cmd == "println") {
		int c = print(args, true);
		if (c == 1) {
			syntax_err(line, "Invalid string or unknown variable specified.");
		}
	} else if (cmd == "input") {
		input(line, global);
	} else if (cmd == "exit") {
		if (args == "") {
			std::exit(0);
		}
	
		try {
			int code = std::stoi(args);
			std::exit(code);
		} catch (std::exception &e) {
			syntax_err(line, "Unable to convert exit code to valid integer.");
		}
	
	//Variable keywords
	} else if (cmd == "var") {
		var_create(s_args, global);
	} else if (cmd == "arr") {
		arr_create(s_args, global);
		
	//Conditional keywords
	} else if (cmd == "if") {
		in_body = true;
		body.push_back(line);
		type = BdType::CONDITION;
	} else if (cmd == "elif") {
		syntax_err(line, "Cannot have elif without previous if.");
	} else if (cmd == "else") {
		syntax_err(line, "Cannot have elif without previous if.");
		
	//Loop keywords
	} else if (cmd == "loop") {
		in_body = true;
		body.push_back(line);
		type = BdType::LOOP;
	} else if (cmd == "while") {
		in_body = true;
		body.push_back(line);
		type = BdType::WHILE;
	} else if (cmd == "for") {
		in_body = true;
		body.push_back(line);
		type = BdType::FOR;
		
	//Loop-specific keywords
	} else if (cmd == "stop") {
		lp_stop = true;
	} else if (cmd == "continue") {
		lp_continue = true;
		
	//The end keyword
	} else if (cmd == "end") {
		in_body = false;
		layer = 1;
		
		auto cp = body;
		body.clear();
		
		if (type == BdType::LOOP) {
			lp_loop(cp, global);
		} else if (type == BdType::WHILE) {
			lp_while(cp, global);
		} else if (type == BdType::FOR) {
			lp_for(cp, global);
		} else if (type == BdType::CONDITION) {
			parse_condition(cp, global);
		}
		
		type = BdType::NONE;
		
	//The return keyword
	} else if (cmd == "ret") {
		auto type = get_datatype(args);
		
		//If there is no type, its a var
		if (type == DataType::NONE) {
			func_mem = var_val(args);
		} else {
			func_mem = args;
		}

	//If we reached this point, then have other work to do
	} else {
		//First check to see if we have a function call
		if (contains(ln, '[') && contains(ln, ']')) {
			func_invoke(ln);
			return;
		}
		
		//Now check to see if we have a variable re-assignment
		if (contains(ln, '=') && cmd != "var") {
			ln = clr_spaces(ln);
			var_assign(line, global);
			return;
		}
		
		//Check to see if we have an array assignment
		if (contains(ln, '+')) {
			arr_add_item(line, global);
			return;
		}
		
		//Check if we have an array removal
		if (contains(ln, '-')) {
			int ret = arr_remove(line, global);
			if (ret == 0) {
				return;
			}
		}
		
		//If we make it to this point, we have an invalid function
		syntax_err(line, "Unknown command, variable, or array specified.");
	}
}

