import time
import pigpio

class servo:

    gpio = 21

    def __init__(self, pi_inst, pin):
        self.gpio = pin

        self.pi = pi_inst
        self.pi.set_mode(self.gpio, pigpio.OUTPUT)
        self.pi.set_servo_pulsewidth(self.gpio, 0)

    def control(self, pwm):
        self.pi.set_servo_pulsewidth(self.gpio, pwm)

    def stop(self):
        self.pi.set_mode(self.gpio, pigpio.OUTPUT)
        self.pi.write(self.gpio, 0)

if __name__ == "__main__":
    import time
    import Servo
    import PWM

    pi = pigpio.pi()
    monitor = PWM.monitor(pi, 3)
    sv = Servo.servo(pi, 4)

    contents = []
    last = 0

    start = time.time()
    while (time.time() - start) < 10:
        pw = monitor.pulse_width()
        sv.control(pw)
        #if pw != last:
        #last = pw
        print("PW: "+str(pw))
        contents.append(pw)

    monitor.cancel()

    print("Data logged.")
    print("Hit any key to continue...")
    input()

    print("Length: "+str(len(contents)))

    for i in contents:
        print("PW: "+str(i))
        sv.control(i)

    sv.stop()
    pi.stop()
