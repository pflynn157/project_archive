module Main(main) where

collatz :: (Int, Int) -> (Int, Int)
collatz (1, steps) = (1, steps)
collatz (n, steps)
    | (n `mod` 2) == 0 = do
            let x = n `div` 2
            let s = steps+1
            collatz (x,s)
    | otherwise = do
            let x = (3*n)+1
            let s = steps+1
            collatz (x,s)
            
getNo :: Int -> Int
getNo n = 
    let
        (_, steps) = collatz (n, 0)
    in steps

main :: IO()            
main = do
    putStrLn "Hello!"
    let x = getNo 12
    putStrLn $ "Steps: " ++ (show x)
    return ()
