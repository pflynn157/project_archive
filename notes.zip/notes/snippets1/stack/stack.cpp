#include <iostream>
#include <cstdlib>

#include "stack.hh"

//Our constructor- sets up the stack
// s-> The maximum size of the stack
Stack::Stack(int s) {
	sz = s;						//Set the maximum size of the stack
	top = 0;					//Set the top of the stack to 0
	stack = new int[sz];		//Create a new array of the specified size
}

//Add an item to the stack
void Stack::push(int no) {
	//If the top is greater than or equal to the max size, fail
	if (top >= sz) {
		std::cout << "Error: Stack overflow!!" << std::endl;
		std::exit(1);
	}
	
	//Add the element to stack and increase the top value
	stack[top] = no;
	top++;
}

//Removes and returns the top element in the stack
int Stack::pop() {
	//If the top value is at 0, the stack is empty
	if (top-1 < 0) {
		std::cout << "Error: Cannot pop from empty stack." << std::endl;
		std::exit(1);
	}
	
	//Get the element just below top (because top represents the next place to add)
	int element = stack[top-1];
	
	//Decrement the stack and return
	top--;
	return element;
}

//Returns the top element in the stack without removing it
int Stack::peek() {
	//If the top value is at 0, the stack is empty
	if (top-1 < 0) {
		std::cout << "Error: Cannot peek from empty stack." << std::endl;
		std::exit(1);
	}

	//Get the element top most element (which is one less than the top value)	
	int element = stack[top-1];
	return element;
}

//Return the size of the stack
// We return the full value of top because the array starts at 0
int Stack::size() {
	return top;
}
