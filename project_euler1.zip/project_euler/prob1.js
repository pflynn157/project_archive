//prob1.js
function solve1() {
	var firstList = [];

	for (var i = 0; i<1000; i++) {
		if (i%3==0) {
			firstList.push(i);
		} else if (i%5==0) {
			firstList.push(i);
		}
	}
	
	var no = 0;
	for (var i = 0; i<firstList.length; i++) {
		no+=Number(firstList[i]);
	}
	
	//Displays the answer on an HTML page using
	//a function that I have in another file
	setOutput(no);
}
