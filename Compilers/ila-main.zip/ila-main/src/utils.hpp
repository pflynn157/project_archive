#pragma once

#include <string>

std::string get_path(std::string input);
std::string get_name(std::string input);

