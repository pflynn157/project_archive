#pragma once

#include <string>

void file_command(std::string line);
void file_read(std::string line);
void file_write(std::string line);
