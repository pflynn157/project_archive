#pragma once

#include <fstream>

#include <ltac/struct.hpp>

class Amd64 {
public:
    explicit Amd64(LtacFile *file);
    void assemble();
    
    void buildFunc(LtacInstr *instr);
    void buildLdBArg(LtacInstr *instr);
    void buildLdWArg(LtacInstr *instr);
    void buildLdDwArg(LtacInstr *instr);
    void buildLdQwArg(LtacInstr *instr);
    void buildSyscall(LtacInstr *instr);
    void buildFuncCall(LtacInstr *instr);
    void buildRet(LtacInstr *instr);
    
    void buildMovI32(LtacInstr *instr);
    void buildMovV32(LtacInstr *instr);
private:
    LtacFile *file;
    std::ofstream writer;
};
