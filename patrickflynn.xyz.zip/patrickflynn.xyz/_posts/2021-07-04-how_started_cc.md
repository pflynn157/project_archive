---
layout: post
title:  "How I Started With Compilers"
date:   2021-07-04
categories: experience
---

If you have any interest in compilers, you may be wondering how to get started. Writing a compiler can be a daunting task if you have never done it before. Today, I’m going to share how I got started with compilers and what my learning journey looked like. I’m not implying, however, that this is the only path. Hopefully it will give you an idea if you are interested.

Before diving in, I want to give a context of time. Writing compilers is not a beginner’s task. Even interpreters beyond something like a simple BASIC interpreter isn’t easy at first. I’ve been programming for seven years now, and I’ve been doing compilers for the last three of those. However, I’m not saying you need four years of programming experience before diving in. It’s solely depends on how comfortable you are with your programming knowledge and skills.


### My First Compilers

I remember my first compiler. I wrote it back in the summer of 2018 in the free time I had while working at my first job. I actually still have the source. The source is awful, and the code it generates is even worse, but its a trip down memory lane.

After trying my hand at writing that first compiler, I took a step back, and wrote a very simple BASIC interpreter (which is another trip down memory lane). For those wondering what an interpreter is, an interpreter is a program that runs but does not compile a programming language. There are many more fine details that go into this, which I’ll save for the next post. But suffice it to say that writing an interpreter is a little easier than a compiler since you are not going to generate assembly code.

Over my first school year and during my little free time in the summer after, I wrote a few more interpreters. The next was another BASIC interpreter, this time written in Rust. After that, I began making my own programming languages, starting with an interpreter for Quik.


### Quik and My First Job

I eventually stayed with my Quik language for about it a year, which was fun journey watching it evolve. Eventually, it had three iterations. The first was the interpreter I wrote about above. The second was what would become my first compiler. This first Quik compiler was awful- even then I thought it was awful. But it ended up landing me my first computer science job, which in turn has led to all my jobs since.

The following December (December 2019- just before covid19), I rewrote Quik from scratch, this time creating an AST modeled after the compiler I was working on at the time in my research job. I ended up staying with this for about four months or so. But it was a fun project. It became my first compiler to go through the full process of parsing -> AST -> lowering -> codegen, and it generated rather good code.


### Compilers Today

After Quik, I created a fork that became a simple C compiler. In hindsight, that project was kind of a flop, though it did teach me a lot. Nevertheless, it was enough of a flop to make me take a step back for a few months. I was working my first internship at the time anyway, so it was because I was busy.

Near the end of summer, I got going again by writing my first assembler. I began a compiler to go with it, but I was rather tired of C++ by that point. The details are a little hazy to me because last fall, especially the early part, is a suppressed memory to me. But I did begin working on Ida in September. That carried through to January, and after a few month pause, I began working on a new compiler to help me learn LLVM (its not released yet).


### To Summarize…

Hopefully I didn’t bore you to death with this. The purpose is to show evolution. My first projects were awful, but they worked and taught me something. Each one afterwards became a little better, and helped me learn a little more. Of course, its important to understand that there’s no “endpoint”. My goal is never to write a perfect compiler, but to write one that’s better than the last.

This post was a big long story to basically tell you this: If you’re interested in compilers, sure you need to read and learn a little first, but the best way to learn is to dive in and get your hands dirty. Start with a simple interpreter. Write something that can parse an expression (ie, parse “int x = 10”. If you’ve never done it before, its harder than you think). Then turn that into something that can parse a whole program- a whole list of expressions. If you stay with it, it will eventually turn into assembly.

Over the next few weeks, I’m going to continue talking about the core concepts to compilers. Eventually, I will start writing actual examples to help you understand the concepts.

Stay tuned, and thanks for reading!

