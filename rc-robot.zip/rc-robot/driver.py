#!/usr/bin/python3
import os
import time
import subprocess
import RPi.GPIO as GPIO

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD)

GPIO.setup(36, GPIO.OUT)
GPIO.output(36, 0)

GPIO.setup(37, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

while True:
	if GPIO.input(37) == 1:
		print("Push!!")
		break

GPIO.output(36, 1)
subprocess.call("python3 regular-drive.py", shell=True)

while True:
	if GPIO.input(37) == 1:
		print("Push!!")
		break
	
GPIO.output(36, 0)

subprocess.call("python3 reader.py", shell=True)
