#include <QIcon>
#include <QStringList>
#include <QHeaderView>
#include <QInputDialog>
#include <QTableWidgetItem>

#include <accounts.hpp>

AccountsWidget::AccountsWidget() 
    : layout(new QVBoxLayout),
      toolbar(new QToolBar),
      addAccount(new QToolButton),
      save(new QToolButton),
      accounts(new QTableWidget)
{
    layout->setContentsMargins(0,0,0,0);
    this->setLayout(layout);
    
    layout->addWidget(toolbar, 0, Qt::AlignTop);
    layout->addWidget(accounts);
    
    // Setup the toolbar
    addAccount->setIcon(QIcon::fromTheme("list-add"));
    save->setIcon(QIcon::fromTheme("document-save"));
    
    connect(addAccount, &QToolButton::clicked, this, &AccountsWidget::onAddAccountClicked);
    
    toolbar->addWidget(addAccount);
    toolbar->addWidget(save);
    
    // Setup the accounts table
    accounts->setColumnCount(3);
    accounts->setHorizontalHeaderLabels(QStringList() << "Name" << "Balance" << "Min Balance");
    accounts->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
}

AccountsWidget::~AccountsWidget() {
    delete layout;
    delete toolbar;
    delete accounts;
}

void AccountsWidget::onAddAccountClicked() {
    QString str = QInputDialog::getText(this, "Create Account", "Enter account name:");
    if (str == "")
        return;
        
    int row = accounts->rowCount();

    auto name = new QTableWidgetItem(str);
    auto balance = new QTableWidgetItem("");
    auto minBalance = new QTableWidgetItem("");
    
    accounts->insertRow(row);
    accounts->setItem(row, 0, name);
    accounts->setItem(row, 1, balance);
    accounts->setItem(row, 2, minBalance);
}
