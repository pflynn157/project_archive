#include <string>
#include <iostream>
#include <cstdlib>

#include "syntax.hh"

#include <strutils.hh>
#include <types.hh>
#include <functions.hh>

//A list of all built-in keywords
std::string commands[] = {
	"func", "include", "end", "if", "for", "while", "loop",
	"enable", "disable", "print", "println", "input", "exit",
	"var", "arr", "elif", "else", "stop", "continue", "ret"
};

//Returns true if we have block keyword
bool is_block(std::string cmd) {
	if (cmd == "func" || cmd == "if" || cmd == "for"
			|| cmd == "while" || cmd == "loop") {
		return true;		
	}
	return false;
}

//Checks to see if a string is a command
bool is_keyword(std::string keyword) {
	for (int i = 0; i<20; i++) {
		if (commands[i] == keyword) {
			return true;
		}
	}
	
	return false;
}

//The end check runs through and makes sure that there are matching
// beginning-end statements
void end_check(std::vector<String> contents) {
	bool in_statement = false;
	int layer = 0;
	
	for (auto s : contents) {
		std::string cmd = get_first(s.str, ' ');
		
		if (is_block(cmd)) {
			in_statement = true;
			layer++;
		} else if (cmd == "end") {
			if (in_statement) {
				layer--;
				if (layer == 0) {
					in_statement = false;
				}
			} else {
				std::cout << "Error: End without matching opening statement." << std::endl;
				std::cout << "\tLine " << s.ln_no << ": " << s.str << std::endl;
				std::exit(1);
			}
		}
	}
	
	//If this value is true, we have a block without a closing 'end'
	// TODO: Try to find it and inform the user
	if (in_statement) {
		std::cout << "Error: You have declared a block without closing it." << std::endl;
		std::exit(1);
	}
}

//The CMD check checks to make sure we have valid keywords
// To run, it first loads and caches all variables, functions, and arrays
// Then it runs through the file to make sure all commands are correct
void cmd_check(std::vector<String> contents) {
	std::vector<String> lines;
	
	//Arrays to hold objects
	std::vector<std::string> vars;
	std::vector<std::string> arrays;
	std::vector<std::string> funcs;
	
	//First, run through and collect vars, arrays, and funcs
	for (auto s : contents) {
		std::string first = get_first(s.str, ' ');
		std::string second = get_second(s.str, ' ');
		second = clr_spaces(second);
		
		if (first == "var") {
			std::string name = get_first(second, '=');
			vars.push_back(name);
		} else if (first == "arr") {
			std::string name = get_first(second, '=');
			arrays.push_back(name);
		} else if (first == "func") {
			std::string name = func_name(second);
			funcs.push_back(name);
		} else {
			lines.push_back(s);
		}
	}
	
	//Now iterate through the list and make sure we have valid
	// keywords, functions, vars, etc...
	for (auto ln : lines) {
		std::string first = get_first(ln.str, ' ');
		
		//First, check for generic program keywords
		if (is_keyword(first)) {
			continue;
		}
		
		//Check for variables
		if (contains(ln.str, '=')) {
			std::string ln2 = clr_spaces(ln.str);
			std::string name = get_first(ln2, '=');
			bool found = false;
			
			for (auto v : vars) {
				if (v == name) {
					found = true;
					break;
				}
			}
			
			if (found) continue;
		}
		
		//Check for arrays
		//TODO: Add this logic
		
		//If we hit this point, we have an invalid keyword
		std::cout << "Error: Invalid keyword, function, variable, or array specified." << std::endl;
		std::cout << "\tLine: " << ln.ln_no << ": " << ln.str << std::endl;
		std::exit(1);
	}
}
