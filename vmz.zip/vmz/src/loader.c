#include <stdio.h>
#include <stdlib.h>

#include <vm_file.h>

#include "vm.h"

void vm_load(VM *vm, const char *input) {
    FILE *file = fopen(input, "rb");
    vm->error_state = 0;
    
    // Verify the file
    uint16_t signature = 0;
    fread(&signature, sizeof(uint16_t), 1, file);
    
    if (signature != 0xA1A2) {
        printf("Fatal: Invalid signature (%x)\n", signature);
        vm->error_state = 1;
        return;
    }
    
    // Load version info
    uint8_t major_version = 0;
    fread(&major_version, sizeof(uint8_t), 1, file);
    
    uint8_t minor_version = 0;
    fread(&minor_version, sizeof(uint8_t), 1, file);
    
    vm->major_version = major_version;
    vm->minor_version = minor_version;
    
    // Constant pool length
    uint32_t const_pool_length = 0;
    fread(&const_pool_length, sizeof(uint32_t), 1, file);
    vm->const_pool_length = const_pool_length;
    
    vm->const_pool = malloc(sizeof(ConstPoolItem *) * const_pool_length);
    
    for (uint32_t i = 0; i<const_pool_length; i++) {
        uint8_t item_type = 0;
        fread(&item_type, sizeof(uint8_t), 1, file);
        
        switch (item_type) {
            case 0xA0: {
                uint8_t str_size = 0;
                fread(&str_size, sizeof(uint8_t), 1, file);
                
                char *str = malloc(sizeof(char)*str_size);
                for (int i = 0; i<str_size; i++) {
                    str[i] = fgetc(file);
                }
            
                ConstPoolItem *item = malloc(sizeof(ConstPoolItem));
                item->item_type = item_type;
                item->data_length = str_size;
                item->data = str;
                vm->const_pool[i] = item;
            } break;
            
            default: {
                printf("Fatal: Invalid const pool item <%x>\n", item_type);
                vm->error_state = 1;
                return;
            }
        }
    }
    
    // Consume the library list for right now
    uint8_t lib_list = 0;
    fread(&lib_list, sizeof(uint8_t), 1, file);
    
    // Now, the function list
    uint32_t func_count = 0;
    fread(&func_count, sizeof(uint32_t), 1, file);
    vm->func_count = func_count;
    
    vm->functions = malloc(sizeof(Function *) * func_count);
    
    for (uint32_t i = 0; i<func_count; i++) {
        uint16_t name_index = 0;
        fread(&name_index, sizeof(uint16_t), 1, file);
        
        uint16_t code_length = 0;
        fread(&code_length, sizeof(uint16_t), 1, file);
    
        Function *func = malloc(sizeof(Function));
        func->name_index = name_index;
        func->code_length = code_length;
        
        func->code = malloc(sizeof(uint8_t) * code_length);
        fread(func->code, sizeof(uint8_t), code_length, file);
        
        vm->functions[i] = func;
    }
    
    // Close the file
    fclose(file);
}

