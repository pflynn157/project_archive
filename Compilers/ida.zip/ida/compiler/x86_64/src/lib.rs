//
// Copyright 2021 Patrick Flynn
// This file is part of the Ida compiler.
// Ida is licensed under the BSD-3 license. See the COPYING file for more information.
//

use std::io;
use std::io::prelude::*;
use std::io::BufWriter;
use std::fs::File;

use parser::ltac::{LtacFile, LtacData, LtacDataType, LtacType, LtacInstr};

// Import and use local modules
mod asm;
mod call;
mod func;
mod instr;

use asm::*;
use call::*;
use func::*;
use instr::*;

// The entry point
pub fn compile(ltac_file : &LtacFile, pic : bool) -> io::Result<()> {
    // First, translate
    let mut x86_code : Vec<X86Instr> = Vec::new();
    translate_code(&mut x86_code, &ltac_file.code, pic);
    
    // Write it out
    let mut name = "/tmp/".to_string();
    name.push_str(&ltac_file.name);
    name.push_str(".asm");
    
    let file = File::create(&name)?;
    let mut writer = BufWriter::new(file);
    
    //GNU AS specific
    writer.write(b".intel_syntax noprefix\n")
        .expect("[AMD64_setup] Write failed.");
    
    write_data(&mut writer, &ltac_file.data, pic);
    write_code(&mut writer, &x86_code);
    
    Ok(())
}

// Writes the .data section
fn write_data(writer : &mut BufWriter<File>, data : &Vec<LtacData>, pic : bool) {
    let mut line = String::new();
    
    if !pic {
        line.push_str(".data\n");
    }

    for data in data.iter() {
        match &data.data_type {
            LtacDataType::StringL => {
                line.push_str(&data.name);
                line.push_str(": .string \"");
                line.push_str(&data.val);
                line.push_str("\"\n");
            },
            
            LtacDataType::FloatL => {
                line.push_str(&data.name);
                line.push_str(": .long ");
                line.push_str(&data.val);
                line.push_str("\n");
            },
            
            LtacDataType::DoubleL => {
                line.push_str(&data.name);
                line.push_str(": .quad ");
                line.push_str(&data.val);
                line.push_str("\n");
            },
        }
    }
    
    line.push_str("\n");
    
    writer.write(&line.into_bytes())
        .expect("[AMD64_data] Write failed in .data");
}

// Translates the LTAC code section to x86 code
fn translate_code(x86_code : &mut Vec<X86Instr>, code : &Vec<LtacInstr>, is_pic : bool) {
    for code in code.iter() {
        match &code.instr_type {
            LtacType::Extern => amd64_build_extern(x86_code, &code),
            LtacType::Label => amd64_build_label(x86_code, &code),
            LtacType::Func => amd64_build_func(x86_code, &code, is_pic),
            LtacType::Ret => amd64_build_ret(x86_code),
            
            LtacType::LdArgI8 | LtacType::LdArgU8 => amd64_build_ldarg(x86_code, &code, is_pic),
            LtacType::LdArgI16 | LtacType::LdArgU16 => amd64_build_ldarg(x86_code, &code, is_pic),
            LtacType::LdArgI32 | LtacType::LdArgU32 => amd64_build_ldarg(x86_code, &code, is_pic),
            LtacType::LdArgI64 | LtacType::LdArgU64 => amd64_build_ldarg(x86_code, &code, is_pic),
            //LtacType::LdArgF32 => amd64_build_ldarg_float(writer, &code),
            //LtacType::LdArgF64 => amd64_build_ldarg_float(writer, &code),
            LtacType::LdArgPtr => amd64_build_ldarg(x86_code, &code, is_pic),
            
            // TODO: Combine this to reduce lines
            LtacType::Br => amd64_build_jump(x86_code, &code),
            LtacType::Be | LtacType::Bne => amd64_build_jump(x86_code, &code),
            LtacType::Bl | LtacType::Ble => amd64_build_jump(x86_code, &code),
            LtacType::Bfl | LtacType::Bfle => amd64_build_jump(x86_code, &code),
            LtacType::Bg | LtacType::Bge => amd64_build_jump(x86_code, &code),
            LtacType::Bfg | LtacType::Bfge => amd64_build_jump(x86_code, &code),
            
            LtacType::PushArg => amd64_build_pusharg(x86_code, &code, false, is_pic),
            LtacType::KPushArg => amd64_build_pusharg(x86_code, &code, true, is_pic),
            LtacType::Call => amd64_build_call(x86_code, &code),
            LtacType::Syscall => amd64_build_syscall(x86_code),
            
            LtacType::StrCmp => amd64_build_strcmp(x86_code),
            
            LtacType::I8Mul | LtacType::U8Mul => amd64_build_byte_mul(x86_code, &code, is_pic),
            LtacType::I8Div | LtacType::I8Mod |
            LtacType::U8Div | LtacType::U8Mod => amd64_build_div(x86_code, &code, is_pic),
            
            LtacType::I16Div | LtacType::I16Mod |
            LtacType::U16Div | LtacType::U16Mod => amd64_build_div(x86_code, &code, is_pic),
            
            LtacType::I32Div | LtacType::U32Div => amd64_build_div(x86_code, &code, is_pic),
            LtacType::I32Mod | LtacType::U32Mod => amd64_build_div(x86_code, &code, is_pic),
            
            LtacType::I64Div | LtacType::U64Div => amd64_build_div(x86_code, &code, is_pic),
            LtacType::I64Mod | LtacType::U64Mod => amd64_build_div(x86_code, &code, is_pic),
            
            // Everything else uses the common build instruction function
            _ => amd64_build_instr(x86_code, &code, is_pic),
        }
    }
}

// Writes the .text section
fn write_code(writer : &mut BufWriter<File>, code : &Vec<X86Instr>) {
    let line = ".text\n".to_string();
    writer.write(&line.into_bytes())
        .expect("[AMD64_code] Write failed");

    for code in code.iter() {
        match &code.instr_type {
            X86Type::Extern | X86Type::Global
            | X86Type::Type | X86Type::Label
            | X86Type::Jmp
            | X86Type::Je | X86Type::Jne
            | X86Type::Jl | X86Type::Jle
            | X86Type::Jg | X86Type::Jge
            | X86Type::Ja | X86Type::Jae
            | X86Type::Jb | X86Type::Jbe
            | X86Type::Call => amd64_write_named(writer, &code),
            
            X86Type::Leave | X86Type::Ret 
            | X86Type::Syscall => amd64_write_instr(writer, &code, 0),
            
            X86Type::Push
            | X86Type::IMul8 | X86Type::Mul8
            | X86Type::IDiv | X86Type::Div => amd64_write_instr(writer, &code, 1),
            
            _ => amd64_write_instr(writer, &code, 2),
        }
    }
}

// Writes a named directive
// These would be externs, globals, labels, and calls
fn amd64_write_named(writer : &mut BufWriter<File>, code : &X86Instr) {
    let mut line = String::new();
    
    match code.instr_type {
        X86Type::Extern => line.push_str(".extern "),
        X86Type::Global => line.push_str("\n.global "),
        X86Type::Type => line.push_str(".type "),
        X86Type::Call => line.push_str("  call "),
        
        X86Type::Jmp => line.push_str("  jmp "),
        X86Type::Je => line.push_str("  je "),
        X86Type::Jne => line.push_str("  jne "),
        X86Type::Jl => line.push_str("  jl "),
        X86Type::Jle => line.push_str("  jle "),
        X86Type::Jg => line.push_str("  jg "),
        X86Type::Jge => line.push_str("  jge "),
        X86Type::Ja => line.push_str("  ja "),
        X86Type::Jae => line.push_str("  jae "),
        X86Type::Jb => line.push_str("  jb "),
        X86Type::Jbe => line.push_str("  jbe "),
        
        _ => {},
    }
    
    line.push_str(&code.name);
    
    if code.instr_type == X86Type::Label {
        line.push_str(":");
    } else if code.instr_type == X86Type::Type {
        line.push_str(", @function");
    }
    
    line.push_str("\n");
    
    writer.write(&line.into_bytes())
        .expect("[AMD64_build_extern] Write failed.");
}

// Writes an x86-instruction
fn amd64_write_instr(writer : &mut BufWriter<File>, code : &X86Instr, op_count : i32) {
    let mut line = "  ".to_string();
    
    match code.instr_type {
        X86Type::Leave => line.push_str("leave"),
        X86Type::Ret => line.push_str("ret\n"),
        X86Type::Syscall => line.push_str("syscall"),
        
        X86Type::Push => line.push_str("push"),
        X86Type::Lea => line.push_str("lea"),
        X86Type::Mov => line.push_str("mov"),
        X86Type::MovZX => line.push_str("movzx"),
        X86Type::MovSX => line.push_str("movsx"),
        
        X86Type::Add => line.push_str("add"),
        X86Type::Sub => line.push_str("sub"),
        X86Type::IMul | X86Type::IMul8 => line.push_str("imul"),
        X86Type::Mul | X86Type::Mul8 => line.push_str("mul"),
        X86Type::IDiv => line.push_str("idiv"),
        X86Type::Div => line.push_str("div"),
        
        X86Type::And => line.push_str("and"),
        X86Type::Or => line.push_str("or"),
        X86Type::Xor => line.push_str("xor"),
        X86Type::Shl => line.push_str("shl"),
        X86Type::Shr => line.push_str("shr"),
        
        X86Type::Cmp => line.push_str("cmp"),
        
        _ => {},
    }
    
    if op_count == 1 {
        line.push_str(" ");
        let op = amd64_write_operand(&code.arg1);
        line.push_str(&op);
    } else if op_count == 2 {
        let op1 = amd64_write_operand(&code.arg1);
        let op2 = amd64_write_operand(&code.arg2);
        
        line.push_str(" ");
        line.push_str(&op1);
        line.push_str(", ");
        line.push_str(&op2);
    }
    
    line.push_str("\n");
    
    writer.write(&line.into_bytes())
        .expect("[AMD64_write_instr] Write failed.");
}

// A utility function to write a memory operand
fn amd64_write_mem(prefix : String, reg : &X86Reg, pos : i32, is_pic : bool) -> String {
    let mut line = String::new();
    let reg_str = reg2str(&reg, 64);
    
    line.push_str(&prefix);
    
    if prefix.len() > 0 {
        line.push_str(" ");
    }
    
    if is_pic {
        if pos < 0 {
            let val = pos * -1;
            line.push_str(&val.to_string());
        } else {
            line.push_str("-");
            line.push_str(&pos.to_string());
        }
        
        line.push_str("[");
        line.push_str(&reg_str);
    } else {
        line.push_str("[");
        line.push_str(&reg_str);
        
        if pos < 0 {
            let val = pos * -1;
            line.push_str("+");
            line.push_str(&val.to_string());
        } else {
            line.push_str("-");
            line.push_str(&pos.to_string());
        }
    }
    
    line.push_str("]");
    line
}

// Writes an x86 operand
fn amd64_write_operand(arg : &X86Arg) -> String {
    let mut line = String::new();
    
    match &arg {
        X86Arg::Reg8(reg) => {
             let reg_str = reg2str(&reg, 8);
             line.push_str(&reg_str);
        },
        
        X86Arg::Reg16(reg) => {
             let reg_str = reg2str(&reg, 16);
             line.push_str(&reg_str);
        },
        
        X86Arg::Reg32(reg) => {
             let reg_str = reg2str(&reg, 32);
             line.push_str(&reg_str);
        },
        
        X86Arg::Reg64(reg) => {
             let reg_str = reg2str(&reg, 64);
             line.push_str(&reg_str);
        },
        
        X86Arg::Imm32(val) => line.push_str(&val.to_string()),
        X86Arg::Imm64(val) => line.push_str(&val.to_string()),
        
        X86Arg::Mem(reg, pos, pic) => {
            let mem = amd64_write_mem("".to_string(), reg, *pos, *pic);
            line.push_str(&mem);
        },
        
        X86Arg::BwordMem(reg, pos, pic) => {
            let mem = amd64_write_mem("BYTE PTR".to_string(), reg, *pos, *pic);
            line.push_str(&mem);
        },
        
        X86Arg::WordMem(reg, pos, pic) => {
            let mem = amd64_write_mem("WORD PTR".to_string(), reg, *pos, *pic);
            line.push_str(&mem);
        },
        
        X86Arg::DwordMem(reg, pos, pic) => {
            let mem = amd64_write_mem("DWORD PTR".to_string(), reg, *pos, *pic);
            line.push_str(&mem);
        },
        
        X86Arg::QwordMem(reg, pos, pic) => {
            let mem = amd64_write_mem("QWORD PTR".to_string(), reg, *pos, *pic);
            line.push_str(&mem);
        },
        
        X86Arg::LclMem(ref val, is_pic) => {
            if *is_pic {
                line.push_str(&val);
                line.push_str("[rip]");
            } else {
                line.push_str("OFFSET FLAT:");
                line.push_str(&val);
            }
        },
        
        X86Arg::ScaleMem(base, reg, scale, is_pic) => {
            let reg_str = reg2str(&reg, 64);
            
            if *is_pic {
                line.push_str("0");
            }
            
            line.push_str("[");
            line.push_str(&base.to_string());
            line.push_str("+");
            line.push_str(&reg_str);
            line.push_str("*");
            line.push_str(&scale.to_string());
            line.push_str("]");
        },
        
        _ => {},
    }
    
    line
}

