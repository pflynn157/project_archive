### Ida on Windows

I would not be opposed to getting it to work on Windows, but Windows is architecturally completely different from Linx/MacOS/FreeBSD/etc, so I think this would require a little more work. If you use the Mingw64 toolchain, the work may be a lot less.

This is a "nice-to-have" for me, so don't count on it anytime soon. If you do it, create a pull request and I will give you credit.

