#pragma once

class Actions {
public:
    static void newFile();
    static void openFile();
    static void saveFile();
    static void saveFileAs();
};
