var hierarchy =
[
    [ "QComboBox", null, [
      [ "CppLib::SyntaxCombo", "class_cpp_lib_1_1_syntax_combo.html", null ]
    ] ],
    [ "QSyntaxHighlighter", null, [
      [ "CppLib::SyntaxHighlighter", "class_cpp_lib_1_1_syntax_highlighter.html", null ]
    ] ],
    [ "CppLib::Repository", "class_cpp_lib_1_1_repository.html", null ]
];