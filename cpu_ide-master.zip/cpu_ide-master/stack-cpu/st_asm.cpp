#include <iostream>
#include <fstream>
#include <string>
#include <cstdio>

int main(int argc, char *argv[]) {
    if (argc == 1) {
        std::cerr << "Fatal: No input specified." << std::endl;
        return 1;
    }

    std::string input = argv[1];

    std::ifstream reader(input);
    if (!reader.is_open()) {
        std::cerr << "Fatal: Unable to open input." << std::endl;
        return 1;
    }

    std::string line = "";

    while (std::getline(reader, line)) {
        if (line.length() == 0) continue;
        line = line.erase(0, line.find_first_not_of(" \t"));
        line = line.erase(line.find_last_not_of(" \t") + 1);
        std::cout << line << std::endl;
    }

    return 0;
}
