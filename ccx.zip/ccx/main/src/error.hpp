#pragma once

#include <vector>
#include <string>

#include "lex.hpp"

struct Error {
    std::string message;
    std::string details;
    int location;
};

class ErrorManager {
public:
    explicit ErrorManager(Scanner *scanner);
    ~ErrorManager();
    void addSyntaxError(std::string message);
    void print();
private:
    Scanner *scanner;
    std::vector<Error> errors;
};

