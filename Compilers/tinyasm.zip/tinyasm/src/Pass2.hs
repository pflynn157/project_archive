module Pass2(assembleData, assemble) where

import Data.Int
import Data.Char
import Data.List
import Data.Word
import Text.Read
import Data.Map (Map)
import qualified Data.Map as Map

import Writer
import Utils
import Code

-- Writes the data section
assembleData [] writer = return()
assembleData (x:xs) writer
    | dType == "string" = do
        let str = init (tail value)
        writeStr writer str
        assembleData xs writer
    | otherwise = assembleData xs writer
    where
        parts = parse x
        dType = parts !! 1
        value = parts !! 2
    
-- The Assembly functions
encodeReg reg
    | (reg == "eax") || (reg == "rax") = "000"
    | (reg == "ecx") || (reg == "rcx") = "001"
    | (reg == "edx") || (reg == "rdx") = "010"
    | (reg == "ebx") || (reg == "rbx") = "011"
    | (reg == "esp") || (reg == "rsp") = "100"
    | (reg == "ebp") || (reg == "rbp") = "101"
    | (reg == "esi") || (reg == "rsi") = "110"
    | (reg == "edi") || (reg == "rdi") = "111"
    | otherwise = "000"

encodeStr :: String -> Int
encodeStr = foldl' (\acc x -> acc * 2 + digitToInt x) 0

buildRR writer op parts = do
    let reg1 = parts !! 1
    let reg2 = parts !! 2

    let word = "11" ++ (encodeReg reg2) ++ (encodeReg reg1)
    let byte = fromIntegral (encodeStr word) :: Word8
    
    writeByte writer op
    writeWord8 writer byte
    
-- Build the Add/Subract Immediate-> register instruction
encodeAddSubRI writer reg isAdd
    -- Check for addition first
    | ((reg == "eax") || (reg == "rax")) && isAdd = writeByte writer 0xC0
    | ((reg == "ecx") || (reg == "rcx")) && isAdd = writeByte writer 0xC1
    | ((reg == "edx") || (reg == "rdx")) && isAdd = writeByte writer 0xC2
    | ((reg == "ebx") || (reg == "rbx")) && isAdd = writeByte writer 0xC3
    | ((reg == "esp") || (reg == "rsp")) && isAdd = writeByte writer 0xC4
    | ((reg == "ebp") || (reg == "rbp")) && isAdd = writeByte writer 0xC5
    | ((reg == "esi") || (reg == "rsi")) && isAdd = writeByte writer 0xC6
    | ((reg == "edi") || (reg == "rdi")) && isAdd = writeByte writer 0xC7
    
    -- Check for subtraction next
    | ((reg == "eax") || (reg == "rax")) && isAdd == False = writeByte writer 0xE8
    | ((reg == "ecx") || (reg == "rcx")) && isAdd == False = writeByte writer 0xE9
    | ((reg == "edx") || (reg == "rdx")) && isAdd == False = writeByte writer 0xEA
    | ((reg == "ebx") || (reg == "rbx")) && isAdd == False = writeByte writer 0xEB
    | ((reg == "esp") || (reg == "rsp")) && isAdd == False = writeByte writer 0xEC
    | ((reg == "ebp") || (reg == "rbp")) && isAdd == False = writeByte writer 0xED
    | ((reg == "esi") || (reg == "rsi")) && isAdd == False = writeByte writer 0xEE
    | ((reg == "edi") || (reg == "rdi")) && isAdd == False = writeByte writer 0xEF
    | otherwise = return()

buildAddSubRI writer parts isAdd = do
    writeByte writer 0x83

    let op1 = parts !! 1
    let op2 = parts !! 2
    encodeAddSubRI writer op1 isAdd
    
    let i = read op2 :: Int32
    let byte = fromIntegral i :: Word8
    writeWord8 writer byte

-- Builds the move instruction
buildMovI writer reg int
    | (reg == "eax") || (reg == "rax") = do
        writeByte writer 0xB8
        writeInt writer int
    | (reg == "ecx") || (reg == "rcx") = do
        writeByte writer 0xB9
        writeInt writer int
    | (reg == "edx") || (reg == "rdx") = do
        writeByte writer 0xBA
        writeInt writer int
    | (reg == "ebx") || (reg == "rbx") = do
        writeByte writer 0xBB
        writeInt writer int
    | (reg == "esp") || (reg == "rsp") = do
        writeByte writer 0xBC
        writeInt writer int
    | (reg == "ebp") || (reg == "rbp") = do
        writeByte writer 0xBD
        writeInt writer int
    | (reg == "esi") || (reg == "rsi") = do
        writeByte writer 0xBE
        writeInt writer int
    | (reg == "edi") || (reg == "rdi") = do
        writeByte writer 0xBF
        writeInt writer int
    | otherwise = putStrLn "Fatal: Unknown register!"
    
-- Builds the jmp instruction
buildJmp writer loco symbols lc = do
    let lbl_loco = symbols Map.! loco
    let size = lbl_loco - (lc + 2)
    
    if size < 0
        then do
            let byte = lbl_loco - lc - 2
            let byte2 = fromIntegral byte :: Word8
            writeWord8 writer byte2
        else do
            let byte = fromIntegral size :: Word8
            writeWord8 writer byte

-- Builds the syscall instruction
buildSyscall writer = do
    writeByte writer 0x0F
    writeByte writer 0x05

-- The main parser
assemble writer parts symbols size
    | cType == Syscall = do
        buildSyscall writer
        return (codeSize cType)
        
    -- Addition
    | cType == AddRR = do
        buildRR writer 0x01 parts
        return (codeSize cType)
        
    | cType == AddRI = do
        buildAddSubRI writer parts True
        return (codeSize cType)
        
    | cType == AddRI64 = do
        writeByte writer 0x48
        buildAddSubRI writer parts True
        return (codeSize cType)
     
    -- Subtraction
    | cType == SubRR = do
        buildRR writer 0x29 parts
        return (codeSize cType)
        
    | cType == SubRI = do
        buildAddSubRI writer parts False
        return (codeSize cType)
        
    | cType == SubRI64 = do
        writeByte writer 0x48
        buildAddSubRI writer parts False
        return (codeSize cType)
        
    -- Jumps
    | cType == Jmp = do
        writeByte writer 0xEB
        let loco = parts !! 1
        buildJmp writer loco symbols size
        return (codeSize cType)
        
    | cType == Jg = do
        writeByte writer 0x7F
        let loco = parts !! 1
        buildJmp writer loco symbols size
        return (codeSize cType)
        
    | cType == Jl = do
        writeByte writer 0x7C
        let loco = parts !! 1
        buildJmp writer loco symbols size
        return (codeSize cType)
        
    -- Comparisons
    | cType == CmpRR = do
        buildRR writer 0x39 parts
        return (codeSize cType)
        
    -- Moves
    | cType == MovRI = do
        let op1 = parts !! 1
        let op2 = parts !! 2
        
        if (isInt op2)
            then do
                buildMovI writer op1 (read op2 :: Int32)
                return (codeSize cType)
            else do
                let l = (symbols Map.! op2) + 4194424
                buildMovI writer op1 (fromIntegral l :: Int32)
                return (codeSize cType)
        
    | cType == MovRR = do
        buildRR writer 0x89 parts
        return (codeSize cType)
        
    | cType == Label = return 0
    | otherwise = do
        putStrLn "Unknown instruction!"
        return 0
    where
        cType = codeType parts
    
