#include <iostream>

#include <Instruction.hpp>
#include <Value.hpp>

void Instruction::dump() {
    if (opcode == NOP) {
        std::cout << "nop" << std::endl;
        return;
    }

    if (canReturn) {
        std::cout << "$" << name << " = ";
    }

    switch (opcode) {
        case NOP:break;

        case RET: std::cout << "ret"; break;
        case RETVOID: std::cout << "ret.void"; break;
    }

    if (arg1 != nullptr) {
        std::cout << " ";
        arg1->dump();
    }
    
    if (arg2 != nullptr) {
        std::cout << ", ";
        arg2->dump();
    }

    std::cout << std::endl;
}
