package main

import (
	"fmt"
)

func main() {
	setup()

	//problem := "2 5 + 7 + 3 + 1 - "
	//problem := "2 3 * 5 + 5 + "
	problem := "1 1 + 3 * 5 + 5 + "
	fmt.Println("Problem:", problem)
	
	answer := solve_rpn(problem)
	fmt.Printf("Answer: %d\n", answer)
}
