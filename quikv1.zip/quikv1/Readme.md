## Quik

#### What is it?
Quik is a simple programming language. Quik is designed with speed, simplicity, and portability in mind. We are trying to make the interpreter as simple as possible and eliminate as much unneccessary code as possible. The actual language is extremely simple and small. Having a small language helps make interpretation even faster. The interpreter is written in C++ using only the standard library, so you should be able to run it on most operating systems. Most development was done on Linux, but I also did some on FreeBSD and Solaris. See below for more platform information.

#### How far along are we?
Quik is pretty much fully complete as far as the language goes. The only keyword not supported is "import". At this point, we are primarily fixing things and adding features to make programming easier and similar to what you would expect in other lanaguages. I've also started on writing a small standard library.

#### Compiler
I recently started writing a compiler for Quik. At this point, only very simple programs (printing strings, and calling functions that print strings) is supported. Also, the compiler can only generate Intel x86 32-bit executables at this point (actually, it generates assembly files, then calss NASM). To get an overview of what is supported, take a look at the tests folder.

#### Contributing and Testing
Contributions, especially in the form of testing, are much appreciated. The issues tab contains a list of things known to be broken or features that we need to add. If you feel comfortable adding the features, by all means do so. Otherwise, if you are testing and find something buggy or something that you want implemented, you are free to open an issue.

A note on issues: First, before you open one, make sure you actually have an issue. The interpreter is not always good about pointing out syntax errors, so there are times that synax errors are not detected, and weird behavior results. So please make sure of this. Also, please include a code snippet with your bug or feature report so we know what you are talking about and how to replicate it.

Also note that the aim of this language is speed, simplicity, and portability. That means I want to keep the language small and simple, so keep these goals in mind when you file a feature request. I am not planning on adding things like object oriented programming and other advanced features.

#### Platform Support
While it should run on most platforms, Quik has been designed on built on UNIX-like platforms, and in some cases, uses a few UNIX-specific libraries like sys/stat.h. I did most development on Linux, with a lesser amount on FreeBSD and Solaris.

Note that on BSD and Solaris, you need to install and use GNU Make to build the program. Each platform's own Make program does not work. Also, the makefile is configured to use Clang, so if you wish to use a different program, run 'make CXX=g++' or something like that. On Solaris and FreeBSD, you will likely be using the 'gmake' command.

#### Licensing
This program is licensed under the BSD-3 license. All examples written in Quik are in the public domain.
