---
layout: post
title:  "New Application: Wordpad"
date:   2021-06-24
categories: "Project Updates"
---

![](/images/wordpad.png)

I recently pushed a new desktop application to Github: [https://github.com/patrickf2000/uds-wordpad](https://github.com/patrickf2000/uds-wordpad).

UDS-Wordpad is a simple rich text editor- a mini word processor if you will. It is capable of editing rich text files, plain text files, and if you have a recent version of Qt5, Markdown files. Here is a list of some of the features:

* Multi-document interface
* Font styles- bold, italics, and underline
* Font color (rich text files only)
* Text styles- paragraph blocks, different heading sizes, etc
* Print support
* Export to PDF support
* Fully cross-platform- tested on Linux and Windows

The application itself is written in C++ and uses the Qt5 libraries. Please note that since this is the first version, there are bugs. I am aware of some of them, but I’m sure there are others I’m not. Since this is a hobby app, don’t expect it to be perfect.

Wordpad is actually my first desktop application completely written from scratch in quite a while. It was a lot of fun for a change, and has been a useful application for me. Hopefully it will be for you as well!
