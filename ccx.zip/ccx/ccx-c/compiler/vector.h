#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

typedef struct {
    struct vector_item *next;
    void *data;
} vector_item;

typedef struct {
    vector_item *first;
    size_t size;
} vector;

vector *vector_init();
void vector_push_back(vector *vec, void *data, size_t data_size);
void *vector_get_at(vector *vec, size_t pos);
void vector_destroy(vector *vec);

