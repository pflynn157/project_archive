## jc

### Introduction
This is the base of a very simple Java bytecode compiler. Currently, all it can do are a few very simple programs. It is currently a mess, so I will be working to clean it up and refine it to make it fairly easy to generate to use.

Please note that this is not a true compiler. If anything, it is more of an assembler. My plan is to eventually include it as a backend in my extcc compiler. I may maintain this as a seperate project, depending on how things go.


### Useful links
For those wondering how I did this, these resources are helpful:
https://medium.com/@davethomas_9528/writing-hello-world-in-java-byte-code-34f75428e0ad   
https://docs.oracle.com/javase/specs/jvms/se8/html/jvms-4.html    
https://en.wikipedia.org/wiki/Java_bytecode_instruction_listings   

The javap program is also very useful.
