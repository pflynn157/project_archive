#include <stdio.h>
#include <malloc.h>

extern void dbl(float *x, int n);

void print_numbers(float *x, int n) {
	for (int i = 0; i<n; i++)
    	printf("%f ", x[i]);
    puts("");
}

void main() {
	float numbers[4] = {1.1, 2.2, 3.3, 4.4};
	
    print_numbers(numbers, 4);
    puts("");
    
    dbl(numbers, 4);
    
    print_numbers(numbers, 4);
    puts("");
    
    dbl(numbers, 4);
    
    print_numbers(numbers, 4);
    puts("");
}
