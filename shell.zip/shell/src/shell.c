#include <stdio.h>

#include <list.h>
#include <command.h>

int main(int argc, char *argv[])
{
    run_shell();

    return 0;
}
