#pragma once

#include "window.h"

void action_open_file(Window *win);

