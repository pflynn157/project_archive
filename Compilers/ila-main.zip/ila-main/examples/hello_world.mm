
program main is
begin
    println("Hello!");
end

