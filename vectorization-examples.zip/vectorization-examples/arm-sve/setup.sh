export PATH="/opt/arm/arm-instruction-emulator-20.1_Generic-AArch64_Ubuntu-16.04_aarch64-linux/bin64:$PATH"
