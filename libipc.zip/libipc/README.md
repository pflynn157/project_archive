## libipc

libipc is a simple library for interprocess communication. It can be used to communicate with multiple instances of a running application, or it can be used to limit the number of instances of an application and send data to it. You can also use this library to send data to other applications using this library.

#### Building
Building is simple. Simply run "qmake" and "make". We highly recommend that you build it in a separate build directory.