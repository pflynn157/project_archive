//
// Copyright 2021 Patrick Flynn
// This file is part of uds-wordpad.
// uds-wordpad is licensed under the BSD-3 license. See the COPYING file for more information.
//
#include <QApplication>
#include <QMessageBox>
#include <QPixmap>
#include <QApplication>

#include <menubar/helpmenu.hpp>

HelpMenu::HelpMenu() {
    this->setTitle("Help");
    
    about = new QAction(QPixmap(":/icons/help-about.svg"), "About", this);
    aboutQt = new QAction("About Qt", this);
    
    connect(about, &QAction::triggered, this, &HelpMenu::onAboutClicked);
    connect(aboutQt, &QAction::triggered, qApp, &QApplication::aboutQt);
    
    this->addAction(about);
    this->addAction(aboutQt);
}

HelpMenu::~HelpMenu() {
    delete about;
    delete aboutQt;
}

void HelpMenu::onAboutClicked() {
    QMessageBox msg;
    msg.setWindowTitle("About Wordpad");
    msg.setText("Wordpad\n"
                "A simple rich text editor for the Universal Desktop System.\n\n"
                "Wordpad was written by Patrick Flynn, and is licensed under BSD-3.\n");
    msg.setStandardButtons(QMessageBox::Ok);
    msg.exec();
}

