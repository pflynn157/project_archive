#include <iostream>
#include <string>

#include <ava/ast.hpp>
#include <ava/compiler/Compiler.hpp>

#include "parser/parser.hpp"

int main(int argc, char *argv[]) {
    if (argc == 1) {
        std::cerr << "Error: No input file specified!" << std::endl;
        return 1;
    }
    
    std::string input = argv[1];
    
    Parser parser(input);
    parser.parse();
    
    AstTree *tree = parser.getTree();
    tree->print();
    
    CFlags flags;
    flags.name = "a.out";
    flags.objects.push_back("/usr/lib/x86_64-linux-gnu/crt1.o");
    flags.objects.push_back("/usr/lib/x86_64-linux-gnu/crti.o");
    flags.objects.push_back("/usr/lib/x86_64-linux-gnu/crtn.o");
    flags.libs.push_back("c");
    
    Compiler compiler(tree, flags);
    compiler.compile();
    
    puts("------------------------------");
    compiler.debug();
    puts("------------------------------");
    
    compiler.writeAssembly();
    compiler.assemble();
    compiler.link();

    return 0;
}

