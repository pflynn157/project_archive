#pragma once

void elf_write_header(FILE *file, int start);
void elf_write_pheader(FILE *file, int start);
