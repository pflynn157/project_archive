package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

func trim(str string) string {
	str = strings.Trim(str, string(' '))
	str = strings.Trim(str, string('\t'))
	str = strings.Trim(str, string('\n'))
	return str
}

func main() {
	println("Enter some text:")
	
	for x := 0; x<5; x++ {
		reader := bufio.NewReader(os.Stdin)
		fmt.Print("> ")
		text, _ := reader.ReadString('\n')
		text = trim(text)
		fmt.Println(text)
	}
}
