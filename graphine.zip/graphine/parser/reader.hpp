#pragma once

#include <string>
#include <fstream>
#include <vector>

#include <dom.hpp>

class BinParser {
public:
    explicit BinParser(std::string input);
    void parse(Block *parent = nullptr);
    std::vector<Element *> getElements();
private:
    std::ifstream reader;
    std::vector<Element *> elements;
};