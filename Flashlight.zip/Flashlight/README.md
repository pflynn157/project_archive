## Flashlight

This is a very simple flashlight app for Android. All it has is an on/off switch with the code to turn the camera flash light on and off. This is perfect for those who simply want a simple flash light with no ads or anything else. It is licensed under BSD-3. 
