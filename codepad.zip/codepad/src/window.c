#include <stdlib.h>
#include <stdio.h>

#include <gtk/gtk.h>

#include "window.h"
#include "tabpane.h"
#include "editor.h"
#include "actions.h"

void file_menu_new_item(GtkWidget *widget, gpointer *data)
{
    Window *win = (Window *)data;
    tabpane_add_empty_tab(win);
}

void file_menu_open_item(GtkWidget *widget, gpointer *data)
{
    Window *win = (Window *)data;
    action_open_file(win);
}

void file_menu_save_item(GtkWidget *widget, gpointer *data)
{
    Window *win = (Window *)data;
    tabpane_save_current_tab(win);
}

GtkWidget *get_menubar(Window *win)
{
    GtkWidget *menubar;
    menubar = gtk_menu_bar_new();
    
    // File menu
    GtkWidget *fileMenuShell;
    GtkWidget *fileMenu;
    GtkWidget *newFile, *openFile, *saveFile, *saveFileAs, *quit;
    
    fileMenuShell = gtk_menu_new();
    fileMenu = gtk_menu_item_new_with_label("File");
    
    newFile = gtk_menu_item_new_with_label("New");
    openFile = gtk_menu_item_new_with_label("Open");
    saveFile = gtk_menu_item_new_with_label("Save");
    saveFileAs = gtk_menu_item_new_with_label("Save As");
    quit = gtk_menu_item_new_with_label("Quit");
    
    gtk_menu_item_set_submenu(GTK_MENU_ITEM(fileMenu), fileMenuShell);
    gtk_menu_shell_append(GTK_MENU_SHELL(fileMenuShell), newFile);
    gtk_menu_shell_append(GTK_MENU_SHELL(fileMenuShell), openFile);
    gtk_menu_shell_append(GTK_MENU_SHELL(fileMenuShell), saveFile);
    gtk_menu_shell_append(GTK_MENU_SHELL(fileMenuShell), saveFileAs);
    gtk_menu_shell_append(GTK_MENU_SHELL(fileMenuShell), quit);
    gtk_menu_shell_append(GTK_MENU_SHELL(menubar), fileMenu);
    
    g_signal_connect(G_OBJECT(newFile), "activate", G_CALLBACK(file_menu_new_item), (gpointer *)win);
    g_signal_connect(G_OBJECT(openFile), "activate", G_CALLBACK(file_menu_open_item), (gpointer *)win);
    g_signal_connect(G_OBJECT(saveFile), "activate", G_CALLBACK(file_menu_save_item), (gpointer *)win);
    
    return menubar;
}

void build_window(GtkApplication *app, gpointer user_data)
{
    GtkWidget *window, *mainLayout, *menubar;
    GtkWidget *tabs;
    
    window = gtk_application_window_new(app);
    gtk_window_set_title(GTK_WINDOW(window), "Codepad");
    gtk_window_set_default_size(GTK_WINDOW(window), 600, 400);
    
    mainLayout = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
    gtk_container_add(GTK_CONTAINER(window), mainLayout);
    
    tabs = gtk_notebook_new();
    
    // Create the window structure
    Window *win = (Window *)malloc(sizeof(Window));
    win->window = window;
    win->tabs = tabs;
    win->tabContent = (Editor **)malloc(sizeof(Editor *) * 10);      // Default to 10 tabs so hopefully we won't have to re-allocate for a bit
    win->tabCount = 1;
    win->currentTab = 0;
    
    // Add the initial editor
    tabpane_add_empty_tab(win);
    
    // Add the menubar
    menubar = get_menubar(win);
    
    // Add everything to the layout
    g_signal_connect(G_OBJECT(tabs), "switch-page", G_CALLBACK(tabpane_tab_changed), (gpointer *)win);
    
    gtk_box_pack_start(GTK_BOX(mainLayout), menubar, 0, 0, 0);
    gtk_box_pack_start(GTK_BOX(mainLayout), tabs, 1, 1, 1);
    
    gtk_widget_show_all(window);
}

