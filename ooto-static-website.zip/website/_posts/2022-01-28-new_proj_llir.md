---
layout: post
title:  "New Project: LLIR"
date:   2022-01-28
categories: updates
---

Hello everyone! Today, I’m announcing a new project: LLIR.

LLIR is a compiler midend/backend framework with a similar design and purpose to LLVM. It was created in response to me wanting a hackable and easy-to-work with backend that I could do experiments on. While LLVM is great for easily writing compilers, its too big to do certain things with.

To learn more about the project, and to see the documentation and source code, see [here](/projects/llir).


