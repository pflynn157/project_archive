#include "compiler.hpp"
#include "ast.hpp"

#include <llir/llir.hpp>
#include <llir/irbuilder.hpp>

using namespace LLIR;

//
// The constructor
// Here, we init everything we need
//
Compiler::Compiler(AstFile *file) {
    this->file = file;
    this->mod = new Module(file->getName());
    this->builder = new IRBuilder(mod);
}

Compiler::~Compiler() {
    delete builder;
    delete mod;
}

//
// Builds the IR
//
void Compiler::compile() {
    for (size_t i = 0; i<file->getFunctionCount(); i++) {
        AstFunction *ast_func = file->getFunction(i);
        
        Type *type = translateType(ast_func->getType());
        Function *func = Function::Create(ast_func->getName(), Linkage::Global, type);
        mod->addFunction(func);
        builder->setCurrentFunction(func);
        builder->createBlock("entry");
        
        compileBlock(ast_func->getBlock());
    }
}

//
// Prints the LLIR output to the console
//
void Compiler::print() {
    mod->print();
}

//
// Generates assembly, compiles, and links
//
void Compiler::assemble() {
    mod->transform();
    
    Amd64Writer *writer = new Amd64Writer(mod);
    writer->compile();
    writer->writeToFile("/tmp/first.s");
    system("gcc /tmp/first.s -o ./first.bin");
    
    delete writer;
}

//
// -- Private functions --
//

// Compiles a block of statements
void Compiler::compileBlock(AstBlock *block) {
    for (size_t i = 0; i<block->getStatementCount(); i++) {
        AstStatement *stmt = block->getStatement(i);
        
        switch (stmt->getType()) {
            case AstType::Return: compileReturn(stmt); break;
            case AstType::VarDec: compileVarDec(stmt); break;
            case AstType::VarAssign: compileVarAssign(stmt); break;
            case AstType::FuncCall: break;
            case AstType::Syscall: break;
            case AstType::ArrayDec: break;
            case AstType::ArrayAssign: break;
            case AstType::While: break;
            case AstType::For: break;
            case AstType::Break: break;
            case AstType::Continue: break;
            case AstType::If: break;
            
            default: {}
        }
    }
}

void Compiler::compileReturn(AstStatement *stmt) {
    if (stmt->hasExpression()) {
        Type *type = builder->getCurrentFunction()->getDataType();
        Operand *o = compileExpression(stmt->getExpression(), type);
        builder->createRet(type, o);
    } else {
        builder->createRetVoid();
    }
}

void Compiler::compileVarDec(AstStatement *stmt) {
    // First, create the alloca
    Type *type = translateType(stmt->getDataType());
    Reg *reg = builder->createAlloca(type);
    
    // Now, the assignment
    AstBinaryOp *assign = static_cast<AstBinaryOp *>(stmt->getExpression());
    AstId *id = static_cast<AstId *>(assign->getLVal());
    
    // Set all the proper types
    alloca_table[id->getValue()] = reg;
    type_table[id->getValue()] = type;
    
    // Generate LLIR
    Operand *op = compileExpression(assign->getRVal(), type);
    builder->createStore(type, op, reg);
}

void Compiler::compileVarAssign(AstStatement *stmt) {
    AstBinaryOp *assign = static_cast<AstBinaryOp *>(stmt->getExpression());
    AstId *id = static_cast<AstId *>(assign->getLVal());
    
    Reg *dest = alloca_table[id->getValue()];
    Type *type = type_table[id->getValue()];
    
    Operand *op = compileExpression(assign->getRVal(), type);
    builder->createStore(type, op, dest);
}

// Compiles an expression
Operand *Compiler::compileExpression(AstExpression *expr, Type *type) {
    switch (expr->getType()) {
        case AstType::Id: {
            AstId *id = static_cast<AstId *>(expr);
            Reg *reg = alloca_table[id->getValue()];
            Type *type = type_table[id->getValue()];
            return builder->createLoad(type, reg);
        }
        
        case AstType::ArrayAccess: break;
        
        case AstType::IntL: {
            AstInt *i = static_cast<AstInt *>(expr);
            return builder->createI32(i->getValue());
        }
        
        case AstType::StringL: break;
        case AstType::CharL: break;
        
        // Operators
        case AstType::Add:
        case AstType::Sub:
        case AstType::Mul:
        case AstType::Div:
        case AstType::Mod:
        case AstType::And:
        case AstType::Or:
        case AstType::Xor:
        case AstType::Eq:
        case AstType::Ne:
        case AstType::Gt:
        case AstType::Lt:
        case AstType::Le:
        case AstType::Ge: {
            AstBinaryOp *op = static_cast<AstBinaryOp *>(expr);
            Operand *lval = compileExpression(op->getLVal(), type);
            Operand *rval = compileExpression(op->getRVal(), type);
            
            if (expr->getType() == AstType::Add)
                return builder->createAdd(type, lval, rval);
            else if (expr->getType() == AstType::Sub)
                return builder->createSub(type, lval, rval);
            else if (expr->getType() == AstType::Mul)
                return builder->createSMul(type, lval, rval);
            else if (expr->getType() == AstType::Div)
                return builder->createSDiv(type, lval, rval);
            else if (expr->getType() == AstType::Mod)
                return nullptr; // TODO
            else if (expr->getType() == AstType::And)
                return builder->createAnd(type, lval, rval);
            else if (expr->getType() == AstType::Or)
                return builder->createOr(type, lval, rval);
            else if (expr->getType() == AstType::Xor)
                return builder->createXor(type, lval, rval);
                
            // TODO: Comparison operators
        }
        
        default: {}
    }
    
    return nullptr;
}

