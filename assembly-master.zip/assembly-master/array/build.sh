#!/bin/bash
gcc main.c -c
nasm -felf64 print.asm
gcc main.o print.o -o flt -no-pie
