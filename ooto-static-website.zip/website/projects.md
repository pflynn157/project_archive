---
layout: page
title: Projects
permalink: /projects
---

Welcome to the projects page! This contains a list of all the projects currently part of OOTO. Each project has its own page with information, documentation, and so forth.

All source code can be found here: [https://gitlab.com/ootoproject](https://gitlab.com/ootoproject). Note that many are mirrored to my [personal Github profile](https://github.com/patrickf2000) as well.

### Languages and Compilers

* [__Tiny Lang__ ](/projects/tiny-lang) -> A simple compiler/programming language designed to be a base for other projects.
* [__Orka__](/projects/orka) -> A compiler/programming language utilizing the LLVM backend. Features modern constructs such as foreach, loops, structures, enums, classes, and so forth.
* [__Espresso__](/projects/espresso) -> An experimental JVM-based programming language. Features a handwritten Java Class file generator.
* [__LLIR__](/projects/llir) -> An LLVM-like backend code generator. Features a mid-level IR, which can be easily integrated with existing frontends and lowered to machine code.

### Hardware

* [__RISC-V CPU__](/projects/riscv_cpu) -> A 32-bit RISC-V CPU core written in VHDL for easy hardware experimentation. Implements the entire RV32I instruction set.

### Alpha Projects

These are new projects currently in development, but not fully workable or suitable to a particular purpose. However, they are proof-of-concept in some way and workable at a basic level. Source code for alpha projects can be found here: [https://gitlab.com/ootoalpha](https://gitlab.com/ootoalpha).

* [__as__](/alpha/as) -> An assembler for the x86-64 platform. Capable of generating linkable ELF objects.
* [__ccx__](/alpha/ccx) -> A hypothetical language meant to be a replacement of C. Language itself has been designed, but the compilers are not quite ready.
