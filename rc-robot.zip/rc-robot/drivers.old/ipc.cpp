#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <string.h>

#include "ipc.hh"

int ipc_gen_key(std::string key) {
	key_t k = ftok(key.c_str(), 747);
	int shmid = shmget(k, 1024, 0666|IPC_CREAT);
	return shmid;
}

void ipc_write(std::string data, int key) {
	char *str = (char *)shmat(key, (void*)0, 0);
	strcpy(str, data.c_str());
	
	shmdt(str);
}

std::string ipc_read(int key) {
	char *str = (char*) shmat(key,(void*)0,0);
	std::string data = std::string(str);
	
	shmdt(str);
	return data;
}

void ipc_cleanup(int key) {
	shmctl(key, IPC_RMID, NULL);
}

