gcc `pkg-config --cflags gtk+-3.0` -o win1 win1.c `pkg-config --libs gtk+-3.0` `pkg-config --cflags --libs gtksourceview-4`

