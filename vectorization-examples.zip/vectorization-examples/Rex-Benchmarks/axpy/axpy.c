//axpy.c
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/timeb.h>
#include <malloc.h>

#define N_RUNS 1000
#define N 120000

// read timer in second
double read_timer() {
    struct timeb tm;
    ftime(&tm);
    return (double) tm.time + (double) tm.millitm / 1000.0;
}

//Create a matrix and a vector and fill with random numbers
void init(float *X, float *Y) {
    for (int i = 0; i<N; i++) {
        X[i] = (float)rand()/(float)(RAND_MAX/10.0);
        Y[i] = (float)rand()/(float)(RAND_MAX/10.0);
    }
}

// Debug functions
void axpy(float *X, float *Y, float a) {
    for (int i = 0; i<N; i++) {
        Y[i] += a * X[i];
    }
}

int main(int argc, char **argv) {
    //Set everything up
    float *X = malloc(sizeof(float)*N);
    float *Y = malloc(sizeof(float)*N);
    float a = 3.14;
    
    srand(time(NULL));
    init(X, Y);
    
    double start = read_timer();
    for (int i = 0; i<N_RUNS; i++)
        axpy(X, Y, a);
    double t = (read_timer() - start);
    
    double gflops_serial = ((2.0 * N) * N * N_RUNS) / (1.0e9 * t);
    
    printf("==================================================================\n");
    printf("Performance:\t\tRuntime (s)\t GFLOPS\n");
    printf("------------------------------------------------------------------\n");
    printf("AXPY (Serial):\t\t%4f\t%4f\n", t, gflops_serial);
    
    free(X);
    free(Y);
    
    return 0;    
}

