module X86.X86(x86Init) where

import System.IO

-- Specific to the GNU Assembler
x86Init writer = do
    hPutStrLn writer ".intel_syntax noprefix"
