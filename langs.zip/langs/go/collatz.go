package main

import "fmt"

func collatz(n, steps int) (int,int) {
	if n != 1 {
		if (n % 2) == 0 {
			n /= 2;
		} else {
			n = (3*n) + 1
		}
		
		n, steps = collatz(n, steps+1)
	}
	
	return n, steps
}

func main() {
	_, steps := collatz(27, 0)
	fmt.Printf("Steps: %d\n", steps)
}
