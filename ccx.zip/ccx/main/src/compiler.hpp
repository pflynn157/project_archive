#pragma once

#include <string>
#include <map>

#include <llir/llir.hpp>
#include <llir/irbuilder.hpp>
#include <llir/amd64/amd64.hpp>

#include "ast.hpp"

class Compiler {
public:
    explicit Compiler(AstFile *file);
    ~Compiler();
    void compile();
    void print();
    void assemble();
private:
    AstFile *file;
    LLIR::Module *mod;
    LLIR::IRBuilder *builder;
    
    std::map<std::string, LLIR::Reg*> alloca_table;
    std::map<std::string, LLIR::Type*> type_table;
    
    // Private functions
    void compileBlock(AstBlock *block);
    void compileReturn(AstStatement *stmt);
    void compileVarDec(AstStatement *stmt);
    void compileVarAssign(AstStatement *stmt);
    LLIR::Operand *compileExpression(AstExpression *expr, LLIR::Type *type);
    
    // compiler_utils.cpp
    LLIR::Type *translateType(DataType type);
};

