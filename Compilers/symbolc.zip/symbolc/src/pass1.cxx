// Copyright 2018 Patrick Flynn
//
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, 
//	this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice, this 
//	list of conditions and the following disclaimer in the documentation and/or 
//	other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors may 
//	be used to endorse or promote products derived from this software 
//	without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#include <iostream>
#include <fstream>

#include "pass1.hh"
#include "string_utils.hh"

Pass1::Pass1(std::string content) {
	std::string line = "";
	for (int i = 0; i<content.length(); i++) {
		if (content[i]=='\n') {
			file.push_back(line);
			line = "";
		} else {
			line+=content[i];
		}
	}
}

void Pass1::rm_comments() {
	std::vector<std::string> new_file;
	
	for (int i = 0; i<file.size(); i++) {
		std::string line = file.at(i);
		line = str_trim(line);
		
		if (line.length()==0) {
			continue;
		}
		
		if (line[0]=='@') {
			continue;
		} else {
			new_file.push_back(line);
		}
	}
	
	file = new_file;
}

void Pass1::find_includes() {
	std::vector<std::string> new_file;
	
	for (int i = 0; i<file.size(); i++) {
		std::string line = file.at(i);
		line = str_trim(line);
		
		if (line.length()==0) {
			continue;
		}
		
		if (line[0]=='/') {
			bool found = false;
			std::string i_line = "";
			
			for (int j = 0; j<line.size(); j++) {
				if (line[j]==' ' && !found) {
					found = true;
					continue;
				}
				
				if (found) {
					i_line+=line[j];
				}
			}
			
			std::string ic_line = "/usr/local/share/symbolc/lib/";
			ic_line+=i_line+".sym";
				
			std::ifstream reader(ic_line);
			if (reader.is_open()) {
				std::string line = "";
				while (std::getline(reader,line)) {
					new_file.push_back(line);
				}
				reader.close();
			}
			
			continue;
		} else {
			new_file.push_back(line);
		}
	}
	
	file = new_file;	
}

void Pass1::combine_conditionals() {
	std::vector<std::string> new_file;
	bool in_if = false;
	
	for (int i = 0; i<file.size(); i++) {
		std::string line = file.at(i);
		line = str_trim(line);
		
		if (line.length()==0) {
			continue;
		}
		
		//TODO: Come up with something better
		if (line[0]=='i' && line[1]=='f') {
			in_if = true;
			std::string content = line;
			
			for (int j = i+1; j<file.size(); j++) {
				content+=file.at(j);
				if (file.at(j)=="endif;") {
					break;
				}
			}
			
			new_file.push_back(content);
			continue;
		} else if (line=="endif;") {
			in_if = false;
			continue;
		} else {
			if (!in_if) {
				new_file.push_back(line);
			}
		}
	}
	
	file = new_file;
}

void Pass1::combine_loops() {
	std::vector<std::string> new_file;
	
	for (int i = 0; i<file.size(); i++) {
		std::string line = file.at(i);
		line = str_trim(line);
		std::string first = first_part(line);
		
		if (line.length()==0) {
			continue;
		}
		
		if (first=="loop") {
			std::string ln = line;
			
			for (int j = i+1; j<file.size(); j++) {
				std::string ln2 = file.at(j);
				if (ln2[0]==':') {
					ln+=ln2;
				} else {
					i = j;
					break;
				}
			}
			
			new_file.push_back(ln);
		} else {
			new_file.push_back(line);
		}
	}
	
	file = new_file;
}

void Pass1::create_functions() {
	std::vector<Function> funcs;
	
	bool found_func = false;
	bool is_asm = false;
	std::string name = "";
	std::vector<std::string> content;
	std::vector<Var> vars;
	
	for (int i = 0; i<file.size(); i++) {
		std::string line = file.at(i);
		
		//First, get the function name
		if (line[0]=='$') {
			found_func = true;
			
			if (line[1]=='~') {
				name = "_start:";
			} else if (first_part(line)=="$asm") {
				name = "";
				is_asm = true;
			} else {
				for (int j = 1; j<line.length(); j++) {
					if (line[j]==' ' || line[j]=='{') {
						break;
					} else {
						name+=line[j];
					}
				}
				name+=":";
			}
			
			continue;
		}
		
		//If we have found a function, start parsing
		if (!found_func) {
			continue;
		}
	
		std::string ln = "";
		for (int j = 0; j<line.length(); j++) {
			if (line[j]=='{') {
				continue;
			} else if (line[j]=='}') {
				found_func = false;
				break;
			} else {
				ln+=line[j];
			}
		}
		
		ln = str_trim(ln);
		
		if (ln.size()!=0 && ln[0]!='#') {
			content.push_back(ln);
		} else if (ln[0]=='#') {
			Var v;
			
			//First, we want to remove all whitespace
			std::string ln2 = "";
			for (int k = 0; k<ln.length(); k++) {
				if (ln[k]==' ') {
					continue;
				}
				ln2+=ln[k];
			}
			
			//Now, we can parse
			//Vars take this format:
			//#name<val;
			bool fs = false;
			
			for (int k = 0; k<ln2.length(); k++) {
				if (ln2[k]=='#') {
					continue;
				} else if (ln2[k]==';') {
					break;
				} else if (ln2[k]=='<') {
					fs = true;
				} else {
					if (fs) {
						v.val+=ln2[k];
					} else {
						v.name+=ln2[k];
					}
				}
			}
			
			vars.push_back(v);
		}
		
		if (!found_func) {
			Function f;
			f.name = name;
			f.content = content;
			f.vars = vars;
			f.is_asm = is_asm;
			funcs.push_back(f);
			
			name = "";
			is_asm = false;
			content.clear();
			vars.clear();
		}
	}
	
	result.functions = funcs;
}

Pass1Result Pass1::get_result() {
	return result;
}
