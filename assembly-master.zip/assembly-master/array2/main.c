#include <stdio.h>
#include <malloc.h>

extern float add(float *x, int n);

/*void print_numbers(float *x, int n) {
	for (int i = 0; i<n; i++)
    	printf("%f ", x[i]);
    puts("");
}*/

void main() {
	float numbers[22] = {1, 2, 3, 4, 5, 6, 7, 8, 9,
		10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22};
	
    float x = add(numbers, 22);
    printf("Sum: %f\n", x);
}
