#!/usr/bin/python3
def isSameReverse(no):
	new = ""
	index = len(str(no))-1

	while index>=0:
		new+=str(no)[index]
		index-=1;
	
	if (int(new)==no):
		return True
	return False
	
answer = 0

for i in range(1001):
	for j in range(1001):
		x = i*j;
		if (isSameReverse(x)):
			if (x>answer):
				answer = x

print(answer)
