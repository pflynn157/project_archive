#include <stddef.h>
#include <string.h>

#include <ltac/builder.h>
#include <ltac/ltac.h>

// Translates an AST function declaration to LTAC function declaration
void ltac_build_funcdec(AstNode *current, LtacFile *file)
{
    LtacNode *fd = ltac_create_node(LT_FuncDec);
    fd->i_val1 = current->i_val1;
    fd->str_val1 = strdup(current->str_val1);
    ltac_add_code(fd, file);
}

// Translates an AST syscall to an LTAC syscall
// Process:
// 1) Iterate through children-> These are kernel arguments
// 2) Build syscall command
//
void ltac_build_syscall(AstNode *current, LtacFile *file)
{
    // Arguments
    struct AstListNode *child = current->children->head;
    
    while (child != NULL)
    {
        AstNode *child_element = child->element;
        
        switch (child_element->type)
        {
            case IntL:
            {
                LtacNode *karg = ltac_create_node(LT_KArg_I);
                karg->i_val1 = child_element->i_val1;
                ltac_add_code(karg, file);
            } break;
            
            //TODO: The rest
        }
        
        child = child->next;
    }
    
    // The system call command
    LtacNode *syscall = ltac_create_node(LT_Syscall);
    ltac_add_code(syscall, file);
}

// The main loop for translating AST to LTAC
void ltac_assemble(AstNode *tree, LtacFile *file)
{
    struct AstListNode *current = tree->children->head;
    
    while (current != NULL)
    {
        AstNode *element = current->element;
    
        switch (element->type)
        {
            case FuncDec: 
            {
                ltac_build_funcdec(element, file);
                ltac_assemble(element, file);
            } break;
            
            case Syscall: ltac_build_syscall(element, file); break;
        }
        
        current = current->next;
    }
}
