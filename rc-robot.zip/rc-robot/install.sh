#!/bin/bash
echo "Sending files..."
scp *.py pi@raspberrypi://robot

cd drivers
scp ./* pi@raspberrypi://robot/drivers

echo "Done"
