## Tests

This folder contains files we use to test the compiler and the interpreter. You can use these to understand the language, but the examples folder contains a more complete reference.
