# Coffee Maker

This is a simple library for generating Java class files. This is not a stand-alone program; it is designed to be used with a compiler frontend. This is written completely from scratch; there are no 3rd party libraries to generate the class files.

Please note that this project is a little incomplete in two ways. First, I forked it out into my Espresso compiler, so the version of Coffee Maker there is more complete. Secondly, in terms of the Java VM, most instructions are missing. I think many of the integer- and function-related ones area here, but that's about it (if they are not here, they are in the Espresso project).
