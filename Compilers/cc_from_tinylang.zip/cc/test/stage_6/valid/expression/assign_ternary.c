int main() {
    int a = 0;
    a = 1 ? 2 : 3;
    return a;
}