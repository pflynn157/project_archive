#!/bin/bash

if [[ -d ./build ]] ; then
    rm -rf ./build
fi

mkdir build

idac coreutils/cat.ida -o build/cat2
idac coreutils/echo.ida -o build/echo2
idac coreutils/pwd.ida -o build/pwd2
idac coreutils/wc.ida -o build/wc2

idac examples/cd.ida -o build/cd2
idac examples/fork1.ida -o build/fork1
idac examples/fork2.ida -o build/fork2
#idac examples/shell.ida -o build/shell

