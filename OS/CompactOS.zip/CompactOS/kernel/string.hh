#pragma once

#include <stddef.h>

size_t strlen(const char* str);
char *strcpy(char *s1, const char *s2);
char *strcat(char *s1, const char *s2);
int strcmp(const char *s1, const char *s2);
void clearArray(char *arr, int len);
