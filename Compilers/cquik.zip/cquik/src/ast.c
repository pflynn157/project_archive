#include <stdio.h>
#include <stdlib.h>

#include <ast.h>

AstNode *ast_create_node(AstType type)
{
    AstNode *node = malloc(sizeof(AstNode));
    node->children = malloc(sizeof(AstLinkedList));
    node->type = type;
    return node;
}

AstNode *ast_create_func(const char *name)
{
    AstNode *fd = ast_create_node(FuncDec);
    fd->str_val1 = name;
    return fd;
}

AstNode *ast_create_int(int val)
{
    AstNode *node = ast_create_node(IntL);
    node->i_val1 = val;
    return node;
}

void ast_add_child(AstNode *child, AstNode *parent)
{
    struct AstListNode *node = malloc(sizeof(struct AstListNode));
    node->element = child;
    
    if (parent->children->head == NULL) 
    {
        parent->children->head = node;
    } 
    else 
    {
        struct AstListNode *current = parent->children->head;
        while (current->next != NULL) current = current->next;
        current->next = node;
    }
}

// Print the abstract syntax tree
void ast_print(AstNode *tree, int indent)
{
    for (int i = 0; i<indent; i++) printf(" ");

    switch (tree->type) 
    {
        case Scope: puts("Scope"); break;
        case FuncDec: printf("Func %s\n", tree->str_val1); break;
        case Syscall: puts("Syscall"); break;
        case IntL: printf("%d\n", tree->i_val1); break;
        default: puts("Idk");
    }
    
    struct AstListNode *current = tree->children->head;
    
    while (current != NULL) 
    {
        ast_print(current->element, indent+2);
        current = current->next;
    }
}

