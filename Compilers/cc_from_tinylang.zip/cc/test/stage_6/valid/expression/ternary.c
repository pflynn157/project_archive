int main() {
    int a = 0;
    return a > -1 ? 4 : 5;
}