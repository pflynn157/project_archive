
/*
Actor {
    name: "",
    pronoun: "",
    adjectives: [],
    desc_nouns: []
}
*/

const context = {
    actors: []
};

exports.testInit = function testInit() {
    var actor1 = {
        name: "Bob",
        pronoun: "he",
        adjectives: [],
        desc_nouns: []
    };
    context.actors.push(actor1);
}

// TODO: We need more sophisticated pronoun handling
function containsActor(inActor) {
    var found = null;
    
    context.actors.forEach(actor => {
        if (inActor.type === "pronoun") {
            if (actor.pronoun === inActor.name) {
                found = actor;
             } 
        } else {
            if (actor.name === inActor.name) {
                found = actor;
            }
        }
    });
    
    return found;
}

exports.respond = function respond(sentence) {
    var answer = "";
    
    // First, we need to see if we know what actor the user is talking about
    // Usually, this is the first subject in the sentence
    if (sentence.subject.length == 0) {
        return "I do not understand your sentence.";
    }
    
    var actor = sentence.subject[0];
    if (containsActor(actor) != null) {
        answer = "Who is ";
        if (actor.type === "noun") {
            answer += actor.article + " ";
        }
        answer += actor.name + "?";
        return answer;
    }

    return answer;
}