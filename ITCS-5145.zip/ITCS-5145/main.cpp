#include <iostream>
#include <cmath>
#include <cstdlib>
#include <chrono>

#ifdef __cplusplus
extern "C" {
#endif

float f1(float x, int intensity);
float f2(float x, int intensity);
float f3(float x, int intensity);
float f4(float x, int intensity);

#ifdef __cplusplus
}
#endif

  
int main (int argc, char* argv[]) {

  if (argc < 6) {
    std::cerr<<"usage: "<<argv[0]<<" <functionid> <a> <b> <n> <intensity>"<<std::endl;
    return -1;
  }
  
  // First, convert the arguments we need
  int fid = 0;
  sscanf(argv[1], "%d", &fid);
  
  double a, b;
  sscanf(argv[2], "%lf", &a);
  sscanf(argv[3], "%lf", &b);
  
  int64_t n;
  sscanf(argv[4], "%ld", &n);
  
  int intensity;
  sscanf(argv[5], "%d", &intensity);
  
  // The the clock
  auto start = std::chrono::steady_clock::now();
  
  // Now do math
  // Compute (b-a)/n
  float imm = (b - a) / n;
  
  // The summation
  float sum = 0.0;
  for (int64_t i = 0; i<n; i++) {
      // Compute: a + (i + 0.5) * imm
      float imm2 = a + (i + 0.5) * imm;
  
      // The function call
      switch (fid) {
          case 1: sum += f1(imm2, intensity); break;
          case 2: sum += f2(imm2, intensity); break;
          case 3: sum += f3(imm2, intensity); break;
          case 4: sum += f4(imm2, intensity); break;
          default: {}
      }
  }
  
  // Final computation
  float final = sum * imm;
  
  // Stop clocking and compute runtime
  auto end = std::chrono::steady_clock::now();
  auto time = std::chrono::duration_cast<std::chrono::seconds>(end - start).count();
  
  // Print everthing out
  std::cout << final << std::endl;
  std::cerr << time << std::endl;
  
  return 0;
}
