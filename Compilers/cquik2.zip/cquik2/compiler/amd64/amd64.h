#pragma once

#include <ltac/ltac.h>

void amd64_assemble(LtacFile *file);
void amd64_build(const char *file_name);
