#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void main(void)
{
	char *msg = "Hello!";
	int len = strlen(msg);
	
	printf("Writing...\n");
	
	FILE *writer;
	writer = fopen("test.bin", "wb");
	fwrite(msg, sizeof(msg), 1, writer);
	fclose(writer);
	
	printf("Reading...\n");
	
	char buf[len];
	writer = fopen("test.bin", "rb");
	fread(buf, sizeof(buf), 1, writer);
	fclose(writer);
	
	for (int i = 0; i<len; i++) {
		printf("%c", buf[i]);
	}
	printf("\n");
}
