#ifndef FILE_H
#define FILE_H

int line_count(const char *path);
char **load_lines(const char *path, int lines);

#endif
