int main() {
    int a = 0;
    if (0)
        if (0)
            a = 3;
        else
            a = 4;
    else
        a = 1;

    return a;
}