#pragma once

#include <string>
#include <vector>
#include <stack>

#include <ast.hpp>

class AstBuilder {
public:
    explicit AstBuilder(std::string name);
    AstTree *getTree();
    
    void incPtr();
    int getPtrLevel();
    
    void setFuncType(DataType type);
    void addFuncArg(std::string name, DataType type);
    void buildFuncDec(std::string name, bool isExtern = false);
    void addRet();
    
    void setVarType(DataType type);
    void addVarDec(std::string name, bool setLast = false);
    void addVarAssign(std::string name);
    
    void addFuncCall(std::string name);
    
    void addCond();
    void addCondStatement(AstType type);
    
    void addArgument(AstNode *node);
    void pushCurrentBlock();
protected:
    AstTree *tree;
    AstScope *top;
    
    // Global information
    std::vector<AstNode *> currentBlock;
    std::vector<AstNode *> currentArgs;
    std::stack<std::vector<AstNode *>> blockStack;
    int ptrLevel = 0;
    
    // Function-related information
    std::vector<AstNode *> currentFuncArgs;
    DataType funcType = DataType::Void;
    int funcTypeFlags = None;
    
    // Variable-related information
    DataType varType = DataType::None;
    int varTypeFlags = None;
};