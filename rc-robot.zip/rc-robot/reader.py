#!/usr/bin/python3
import time
import threading
import pigpio

def get_part2(ln):
	equ = ln.find('=')+1
	ln = ln[equ:len(ln)]
	return ln

def replay(name, pin):
	contents = []
	
	pi = pigpio.pi()
	pi.set_mode(pin, pigpio.OUTPUT)
	pi.set_servo_pulsewidth(pin, 1500)

	with open(str(name), "r") as reader:
		for ln in reader:
			contents.append(ln.strip())
			
	pws = []
	times = []
	
	for i in range(0, len(contents), 2):
		pws.append(contents[i])
		
	for i in range(1, len(contents), 2):
		times.append(contents[i])
		
	for i in range(0, len(pws)):
		pw = get_part2(pws[i])
		pi.set_servo_pulsewidth(pin, float(pw))
		
		tm = get_part2(times[i])
		time.sleep(float(tm))
	
	pi.set_servo_pulsewidth(pin, 1500)	
	pi.stop()
		
def run(path):
	steering_thr = threading.Thread(target=replay, args=(path + "steering.txt", 4,))
	steering_thr.start()
	
	esc_thr = threading.Thread(target=replay, args=(path + "esc.txt", 15,))
	esc_thr.start()
