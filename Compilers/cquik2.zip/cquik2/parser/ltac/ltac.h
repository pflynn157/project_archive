#pragma once

#include <ast.h>

// Represents the type of an LTAC instruction
// LD_* is data
// LT_* is code
// OP_* are operation sub-types
typedef enum
{
    LT_None,

    LD_String,
    LD_Float,

    OP_None,
    OP_Imm,
    OP_Var,
    OP_Reg,

    LT_Func,
    LT_PushArg,
    LT_FuncCall,
    LT_Return,

    LT_VarDec,
    LT_IVarAssign,

    T_Const,
    T_Addr,
    T_NameAddr,
    T_Reg
} LtacType;

// Represents an LTAC data element
// On most architectures, strings and floats must go here
typedef struct
{
    LtacType type;
    const char *name;
    const char *value;
} LtacData;

// Represents an LTAC instruction
typedef struct
{
    LtacType type;

    const char *str_val1;
    const char *str_val2;
    const char *str_val3;

    int int_val1;
    int int_val2;
    int int_val3;
} LtacInstr;

// Represents an LTAC file
typedef struct
{
    LtacData **data;
    LtacInstr **code;

    int data_loco;
    int data_max;

    int code_loco;
    int code_max;

    const char *file_name;
} LtacFile;

//File functions
LtacFile *ltac_create_file(const char *name);
void ltac_add_data(LtacFile *file, LtacData *data);
void ltac_add_code(LtacFile *file, LtacInstr *instr);

// Data segment functions
LtacData *ltac_create_data(LtacType type);
LtacData *ltac_create_string(const char *name, const char *val);

// Code segment functions
LtacInstr *ltac_create_instr(LtacType type);
LtacInstr *ltac_create_func(const char *name);
LtacInstr *ltac_create_pusharg(LtacType type);
LtacInstr *ltac_create_func_call(const char *name);
LtacInstr *ltac_create_ret(LtacType type);
LtacInstr *ltac_create_var(const char *name, DataType type);
LtacInstr *ltac_assign_int_var(const char *name, int type);

//Debug functions
void ltac_print_file(LtacFile *file);
