int main() {
    return 4 / 2;
}