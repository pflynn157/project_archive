LTAC Assembly Documentation
===========================

This is the documentation for LTAC Assembly. LTAC Assembly is a textual representation of the LTAC IR. LTAC IR is basically pseudo-assembly; it is designed to be easy to translate to multiple architectures. At the same time though, we want LTAC to be easy to use for compiler frontends.

The Assembly version is primarily meant for development. However, you can use it to write CPU-agnostic Assembly code.

Please note that this document does not cover the LTAC IR, but only the Assembly. However, we intend for the LTAC Assembly to have a direct correlation with the IR, so using the Assembly is a good way to familiarize yourself with the IR, much in the same way that using LLVM IR Assembly helps you to understand LLVM as a whole.

1. Program Structure
--------------------

LTAC programs have two sections: the data section and the code section. The data section is denoted by ``section data`` and the code section by ``section text``. Please note that the data section must come first. Also, even if you have no data, you still must include the line ``section data``.

2. Datatypes
------------

Before proceeding, it is important that you understand the various datatypes. While computers and Assembly itself has no inherent concept of datatypes, there is a correlation between the conventions of certain datatypes and certain Assembly instructions (on x86 especially). LTAC IR/Assembly is a typed language, so there it does have the concept of datatypes.

These are the datatypes currently supported:

* string -> Represents an array of characters (a string)
* int -> Represents an integer constant
* i.var/i. -> Represents an integer variable

2.1 Strings
~~~~~~~~~~~

String constants must be declared in the data section. A string declaration has this syntax:

``string <name> <value>``

With an example being:

``string myStr "Hello!"``

In the code section, you can use strings by referencing the string name. In most cases, the individual instructions require a datatype; in that case you simply use "string", followed by the string name.

3. Instructions
---------------

This section covers the Assembly instructions available for use, and their syntax. Please note that this will change rapidly. However, I will attempt to keep from changing instruction syntax; at the most, I will add to it, but again, I will try not to change.

NOTE on registers: LTAC IR is designed to give you fairly good control over the registers. Instructions with a register operand take an integer greater than 0 (so starting at one). The max depends on your platform; however, you should be careful about going up too far because they may collide with registers generally used for other purposes (ie, function parameter registers).

``func`` - Function declaration
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
``func <name>``: Declares a new function of a particular name.

``pusharg`` - Add a function parameter
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
``pusharg <type> <value>``: This prepares a variable or value to be used as a function parameter. 

``call`` - Call a function
~~~~~~~~~~~~~~~~~~~~~~~~~~
``call <name>``: Calls a function. If it has parameters, make sure you use ``pusharg`` calls before this command.

``ret`` - Return from a function
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
``ret``: This currently takes no parameters. Regardless, it does allow you to return from a function.

``i.var`` - Create integer variable
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
``i.var <name>``: Creates a new integer variable with a given name. Note that this does not result in any code being generated; it simply assigns the variable a position on the stack.

``i.store_i`` - Store constant to integer variable
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
``i.store_i <name> <const32>``: Stores a constant integer value to a variable. You cannot use this instruction for assigning one variable to another.

``i.ldr_i`` - Load constant to integer register
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
``i.ldr_i <reg> <const32>``: Stores an integer constant to an integer register.

``i.ldr_v`` - Load integer variable to register
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
``i.ldr_v <reg> <name>``: Loads an integer variable to an integer register.

``i.str`` - Store register constant to memory
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
``i.str <reg> <name>``: Stores the contents of an integer register to an integer memory location.

Integer register-register math
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
``i.<instr> <reg> <reg>``: Performs integer math on two register values. The math instruction may be be:

* ``i.add_rr`` - Addition
* ``i.sub_rr`` - Subtraction
* ``i.mul_rr`` - Multiplication
* ``i.div_rr`` - Division
* ``i.mod_rr`` - Modulus
