#include <ltac_build.hpp>
#include <ltac/var.hpp>

#include <config.hpp>

// Variable declarations
int LtacBuilder::buildVarDec(std::string name, DataType dataType) {
    int size = 0;

    switch (dataType) {
        case DataType::Byte: size = BYTE_SIZE; break;
        case DataType::Char: size = CHAR_SIZE; break;
        case DataType::Octal: size = OCTAL_SIZE; break;
        case DataType::Int: size = INT_SIZE; break;
        case DataType::Float: size = FLOAT_SIZE; break;
        case DataType::String: size = PTR_SIZE; break;
        default: size = 0;
    }
    
    stackPos += size;
    
    vars[name] = stackPos;
    varTypes[name] = dataType;
    
    return stackPos;
}

void LtacBuilder::buildVarDec(AstVar *var) {
    buildVarDec(var->getName(), var->getDataType());
    buildVarAssign(var);
}

// Variable assignments
void LtacBuilder::buildVarAssign(AstVar *var) {
    if (var->getChildren().size() > 1) {
        //TODO
        return;
    }
    
    auto first = var->getChildren()[0];
    
    // Build it
    switch (first->getType()) {
        // Integers
        case AstType::Int: {
            auto i = static_cast<AstInt *>(first);
            int val = i->getVal();
            int pos = vars[var->getName()];
            
            auto instr = new LtacMovI32(pos, val);
            file->addCode(instr);
        } break;
        
        // Other variables
        case AstType::Id: {
            auto id = static_cast<AstId *>(first);
            
            int srcPos = vars[id->getVal()];
            int destPos = vars[var->getName()];
            
            auto srcType = varTypes[id->getVal()];
            switch (srcType) {
                case DataType::Byte: break;
                case DataType::Char: break;
                case DataType::Octal: break;
                
                case DataType::Int: {
                    auto instr = new LtacMovV32(destPos, srcPos);
                    file->addCode(instr);
                 } break;
                 
                case DataType::Float: break;
                case DataType::String: break;
            }
        } break;
    }
}
