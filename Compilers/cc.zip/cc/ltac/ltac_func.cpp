#include <ltac_build.hpp>
#include <ltac/struct.hpp>

#include <iostream>

// Translate a function declaration
void LtacBuilder::buildFunc(AstNode *child) {
    auto astFunc = static_cast<AstFunc *>(child);
    
    if (astFunc->getTypeFlags() & Extern) {
        auto func = new LtacExtern(astFunc->getName());
        file->addCode(func);
        return;
    }
    
    auto func = new LtacFunc(astFunc->getName());
    file->addCode(func);
                
    auto funcElements = astFunc->getChildren();
    auto scope = funcElements[0];
    
    // Arguments
    if (funcElements.size() == 2) {
        auto args = funcElements[1];
        
        for (auto argNode : args->getChildren()) {
            auto arg = static_cast<AstArg *>(argNode);
            //TODO: Change pointer level
            int pos = buildVarDec(arg->getName(), arg->getDataType(), arg->getTypeFlags(), 0);
            
            auto ldarg = new LtacLdArg(pos, LtacType::LdArg);
            file->addCode(ldarg);
        
            switch (arg->getDataType()) {
                case DataType::Char: {
                    if (arg->getTypeFlags() & Ptr)
                        ldarg->setType(LtacType::LdQwArg);
                    else
                        ldarg->setType(LtacType::LdBArg); 
                } break;
                
                case DataType::Int: ldarg->setType(LtacType::LdDwArg); break;
                case DataType::Float: ldarg->setType(LtacType::LdDwArg); break;
            }
        }
    }
    
    buildLtac(astFunc);
    
    int stackSize = 0;
    if (stackPos > 0) {
        while (stackSize < (stackPos + 1))
            stackSize += 16;
    }
    
    func->setStackSize(stackSize);
}

// Translate either a function call or system call
void LtacBuilder::buildFuncCall(AstFuncCall *astFc, bool syscall) {
    auto fc = new LtacFuncCall;
    if (!syscall) fc = new LtacFuncCall(astFc->getName());
    else fc = new LtacSyscall;
    
    file->addCode(fc);
                    
    for (auto arg : astFc->getChildren()) {
        switch (arg->getType()) {
        
            case AstType::Int: {
                auto i = static_cast<AstInt *>(arg);
                fc->addIArg(i->getVal());
            } break;
                            
            case AstType::String: {
                auto str = static_cast<AstString *>(arg);
                auto name = buildString(str->getVal());
                fc->addSArg(name);
            } break;
            
            case AstType::Id: {
                auto id = static_cast<AstId *>(arg);
                Var v = vars[id->getVal()];
                int pos = v.pos;
                
                switch (v.type) {
                    case DataType::Char: {
                        if (v.ptrLevel > 0) {
                            fc->addPtr(pos);
                        } else {
                            //TODO
                        }
                     } break;
                     
                    case DataType::Int: fc->addVar32(pos); break;
                    case DataType::Float: break;
                }
            } break;
            
            case AstType::Ref: {
                auto ref = static_cast<AstRef *>(arg);
                int pos = vars[ref->getVal()].pos;
                fc->addRef(pos);
            } break;
        }
    }
}

// Translates a return statement
void LtacBuilder::buildRet(AstNode *ret) {
    auto children = ret->getChildren();
    
    if (children.size() == 0) {
        auto ret = new LtacVRet;
        file->addCode(ret);
        
    } else if (children.size() == 1) {
        auto child = children[0];
        
        switch (child->getType()) {
        
            case AstType::Int: {
                auto i = static_cast<AstInt *>(child);
                auto ret = new LtacI32Ret(i->getVal(), StrType::Const);
                file->addCode(ret);
            } break;
            
            case AstType::Ptr: {
                auto p = static_cast<AstPtr *>(child);
                int pos = vars[p->getVal()].pos;
                
                auto ld = new LtacLdPtr32(pos, p->getPtr());
                file->addCode(ld);
                
                auto ret = new LtacI32Ret(0, StrType::Reg);
                file->addCode(ret);
            } break;
            
            case AstType::Id: {
                auto id = static_cast<AstId *>(child);
                int pos = vars[id->getVal()].pos;
                
                auto ret = new LtacI32Ret(pos, StrType::Mem);
                file->addCode(ret);
            } break;
            
            //TODO: Add rest
        }
    
    } else {
        // TODO: We need type detection
        buildIVarMath(ret);
        
        auto ret = new LtacI32Ret(0, StrType::Reg);
        file->addCode(ret);
    }
}
