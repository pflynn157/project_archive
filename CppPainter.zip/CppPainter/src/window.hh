#pragma once

#include <QMainWindow>

#include "canvas_bg.hh"
#include "drawing_bar.hh"
#include "menubar/filemenu.hh"

class Window : public QMainWindow {
    Q_OBJECT
public:
    Window();
    ~Window();
    static CanvasBg *canvasBg;
private:
    DrawingBar *drawBar;
    FileMenu *fileMenu;
};
