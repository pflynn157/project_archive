#!/bin/bash
if [ ! -d ./build/lib ] ; then
	echo "Error: You must build the program before installing."
	exit 1
fi
cd build/lib
cp ./libkeyparser.so /usr/local/lib
cp ./libkeyparser.so.1 /usr/local/lib
cp ./libkeyparser.so.1.0 /usr/local/lib
cp ./libkeyparser.so.1.0.0 /usr/local/lib
cd ../..
mkdir -p /usr/local/include/cpplib
cp lib/*.hh /usr/local/include/cpplib
ldconfig
echo "Done!"
