import { getAuth, createUserWithEmailAndPassword } from 'https://www.gstatic.com/firebasejs/9.2.0/firebase-auth.js';

export function signUp() {
    var email = "test@test.com";
    var password = "P@ssword1";

    const auth = getAuth();
    createUserWithEmailAndPassword(auth, email, password)
        .then(userCredential => {
            const user = userCredential.user;
            console.log(user);
        })
        .catch(error => {
            console.log("An error occurred in sign up.");
            console.log(error);
        });
}