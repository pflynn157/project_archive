--rna
--This provides an RNA transcription for a DNA string
{-
	DNA		RNA
	G		C
	C		G
	T		A
	A		U
-}
module Main(main) where

getOpp :: Char -> Char
getOpp c
    | c == 'G' = 'C'
    | c == 'C' = 'G'
    | c == 'T' = 'A'
    | c == 'A' = 'U'
    | otherwise = '?'

transcribe :: String -> String
transcribe [] = []
transcribe (s:str) = getOpp s : transcribe str

main :: IO()
main = do
    let dna = "GCCTTAAGACC"
    let rna = transcribe dna
    
    putStrLn "DNA -> RNA"
    putStrLn $ "DNA: " ++ dna
    putStrLn $ "RNA: " ++ rna
    return ()
