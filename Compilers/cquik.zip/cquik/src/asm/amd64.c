#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>

#include <asm/amd64.h>
#include <ltac/ltac.h>

// Control variables
int current_karg = 1;

void amd64_write_kargi(int val, FILE *writer)
{
    fputs("  mov ", writer);

    switch (current_karg)
    {
        case 1: fputs("eax, ", writer); break;
        case 2: fputs("edi, ", writer); break;
        case 3: fputs("esi, ", writer); break;
        case 4: fputs("edx, ", writer); break;
        case 5: fputs("r10d, ", writer); break;
        case 6: fputs("r8d, ", writer); break;
        case 7: fputs("r9d, ", writer); break;
        default: puts("ERROR");
    }
    
    fprintf(writer, "%d\n", val);
    ++current_karg;
}

// The main code loop
void amd64_build_text(FILE *writer, LtacList *code)
{
    fputs(".text\n\n", writer);
    
    struct LtacListNode *node = code->head;
    LtacNode *element;
    
    while (node != NULL)
    {
        element = node->element;
        
        switch (element->type)
        {
            // Function declarations/labels
            case LT_FuncDec:
            {
                if (element->i_val1 == 1)
                {
                    fputs(".globl ", writer);
                    fputs(element->str_val1, writer);
                    fputs("\n", writer);
                }
                
                fputs(element->str_val1, writer);
                fputs(":\n", writer);
            } break;
            
            // Kernel arguments
            case LT_KArg_I: amd64_write_kargi(element->i_val1, writer); break;
            
            // System calls
            case LT_Syscall: 
            {
                fputs("  syscall\n\n", writer);
                current_karg = 1;
            } break;
            
            //blah blah
        }
        
        node = node->next;
    }
}

void amd64_generate(LtacFile *file)
{
    FILE *writer = fopen(file->file_name, "w");
    
    fputs(".intel_syntax noprefix\n", writer);
    
    amd64_build_text(writer, file->text);
    
    fclose(writer);
}

void amd64_build(LtacFile *file)
{
    pid_t pid = fork();
    int wstatus;
    
    if (pid > 0)    //Parent
    {
        waitpid(pid, &wstatus, 0);
        return;
    }
    else if (pid == 0) //Child
    {
        execlp("as", "", file->file_name, "-o", "/tmp/out.o", (char *)NULL);
    }
    else //Error
    {
        puts("Fatal Error: Unable to fork process to execute command. (Assembly failed)");
        exit(1);
    }
}

void amd64_link(LtacFile *file)
{
    pid_t pid = fork();
    int wstatus;
    
    if (pid > 0)    //Parent
    {
        waitpid(pid, &wstatus, 0);
        chmod("./out", 0777);
        return;
    }
    else if (pid == 0)  //Child
    {
        execlp("ld", "", "/tmp/out.o", "-o", "out", (char *)NULL);
    }
    else
    {
        puts("Fatal Error: Unabled to fork process to execute command. (Link failed)");
        exit(1);
    }
}


