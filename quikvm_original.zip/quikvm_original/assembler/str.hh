#pragma once

std::string get_first(std::string input);
std::string get_second(std::string input);
std::string get_base(std::string input);
std::string rm_quotes(std::string input);
