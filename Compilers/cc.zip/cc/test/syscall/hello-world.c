//OUTPUT
//Hello!
//END

//RET 10

void _start() {
    syscall(1, 1, "Hello!\n", 7);
    syscall(60, 10);
}
