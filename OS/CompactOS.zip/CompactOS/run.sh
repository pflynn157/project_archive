#!/bin/bash
qemu-system-x86_64 -cdrom CompactOS.iso
#qemu-system-i386 -kernel build/kernel.bin
