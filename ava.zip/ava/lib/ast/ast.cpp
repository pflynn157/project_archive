#include <ava/ast.hpp>

//
// AstBlock
//
void AstBlock::addStatement(AstStatement *stmt) {
    block.push_back(stmt);
    stmt->setParent(this);
}

//
// Verification checks
//
bool AstTree::verify() {
    for (auto stmt : global_statements) {
        if (!stmt->verify()) return false;
    }

    return true;
}

bool AstNode::verify() {
    if (parent == nullptr) {
        this->print();
        return false;
    }
    return true;
}

// Global statements
bool AstFunction::verify() {
puts("FUNC");
    if (parent == nullptr) {
        this->print();
        return false;
    }
    return block->verify();
}

