#include <stdio.h>
#include <stdlib.h>

#include "utils.h"

//////////////////////////////////////////////////////////////////////
// This is the node stack

// Create a stack
NodeStack *node_stack_create()
{
    NodeStack *stack = (NodeStack *)malloc(sizeof(NodeStack));
    stack->stack = (ExprNode **)malloc(sizeof(ExprNode *) * 10);
    stack->pos = 0;
    stack->max = 10;
    return stack;
}

// Push to the stack
void node_stack_push(NodeStack *stack, ExprNode *node)
{
    stack->stack[stack->pos] = node;
    stack->pos += 1;
}

// Pop from the stack
ExprNode *node_stack_pop(NodeStack *stack)
{
    int pos = stack->pos - 1;
    ExprNode *node = stack->stack[pos];
    stack->pos = pos;
    
    return node;
}

// Destroy the stack
void node_stack_destroy(NodeStack *stack)
{
    // TODO
}

//////////////////////////////////////////////////////////////////////
// This is the string stack
// If there are any problems, add strdup calls

// Create a stack
StringStack *string_stack_create()
{
    StringStack *stack = (StringStack *)malloc(sizeof(StringStack));
    stack->stack = (char **)malloc(sizeof(char *) * 10);
    stack->pos = 0;
    stack->max = 10;
    return stack;
}

// Push to the stack
void string_stack_push(StringStack *stack, char *str)
{
    stack->stack[stack->pos] = str;
    stack->pos += 1;
}

// Pop from the stack
char *string_stack_pop(StringStack *stack)
{
    int pos = stack->pos - 1;
    char *str = stack->stack[pos];
    stack->pos = pos;
    
    return str;
}

// Destroy the stack
void string_stack_destroy(StringStack *stack)
{
    // TODO
}

