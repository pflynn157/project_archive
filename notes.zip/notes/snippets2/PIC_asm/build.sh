#!/bin/bash
as io.asm -o io.o
ld io.o -o libio.so -shared -lc

gcc prog.c -o prog -L./ -lio -g
