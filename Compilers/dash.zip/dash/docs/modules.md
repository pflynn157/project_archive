## Modules

The Dash module system is very simple. A module can be relative to the current directory, or system-wide in /usr/lib/dash. A Dash module is simple a header file (.di) with all the declarations. They are in the folder path specified by the user's file.

