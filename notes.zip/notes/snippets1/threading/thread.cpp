#include <iostream>
#include <unistd.h>
#include <thread>

//The sleep function- calls the Linux usleep function
void sleep(int sec) {
	sec *= 1000000;
	usleep(sec);
}

//The function for the first thread
void run1() {
	for (int i = 0; i<5; i++) {
		std::cout << "Thread 1!" << std::endl;
		sleep(2);
	}
}

//The function for the second thread
void run2() {
	for (int i = 0; i<5; i++) {
		std::cout << "Thread2!" << std::endl;
		sleep(5);
	}
}

void run3(int no) {
	std::cout << "No: " << no << std::endl;
	sleep(3);
}

//Our main function
int main() {
	std::cout << "Starting the threads..." << std::endl << std::endl;
	
	std::thread thread1(run1);
	std::thread thread2(run2);
	std::thread thread3(run3, 66);
	
	thread1.join();
	thread2.join();
	thread3.join();
	
	std::cout << "Done" << std::endl;
	return 0;
}

