#include <stdio.h>

extern float mulvec(float *numbers, float *vector, int size);
extern float add(float *numbers, int size);

void main() {
	const int size = 23;
	
	float numbers[size];
	float vector[size];
	
	for (int i = 1; i<(size+1); i++) {
		numbers[i-1] = (float)i;
		vector[i-1] = (float)(i*5);
	}
	
	//db
	for (int i = 0; i<size; i++) {
		printf("%.2f ", numbers[i]);
	}
	puts("\nx");
	for (int i = 0; i<size; i++) {
		printf("%.2f ", vector[i]);
	}
	puts("\n");
	
	//Do the work
	mulvec(numbers, vector, size);
	
	for (int i = 0; i<size; i++) {
		printf("%.2f ", vector[i]);
	}
	puts("\n");
	
	float x = add(vector, size);
	printf("Sum: %f\n", x);
}
