//
// Copyright 2021 Patrick Flynn
// This file is part of the Tiny Lang compiler.
// Tiny Lang is licensed under the BSD-3 license. See the COPYING file for more information.
//
#include <iostream>
#include <algorithm>

#include <parser/Parser.hpp>

Parser::Parser(std::string input) {
    this->input = input;
    scanner = new Scanner(input);
    
    tree = new AstTree(input);
    syntax = new ErrorManager;
}

Parser::~Parser() {
    delete scanner;
    delete syntax;
}

bool Parser::parse() {
    Token token;
    bool isExtern = false;
    do {
        token = scanner->getNext();
        bool code = true;
        
        switch (token.type) {
            case Extern: {
                isExtern = true;
            } break;
            
            case Void:
            case Char:
            case Short:
            case Int:
            case Float:
            case Double: {
                code = buildFunction(token, isExtern);
                isExtern = false;
            } break;
            
            case Const: code = buildConst(true); break;
            case Struct: code = buildStruct(); break;
            
            case Eof:
            case Nl: break;
            
            default: {
                syntax->addError(scanner->getLine(), "Invalid token in global scope.");
                token.print();
                code = false;
            }
        }
        
        if (!code) break;
    } while (token.type != Eof);
    
    // Check for errors, and print if so
    if (syntax->errorsPresent()) {
        syntax->printErrors();
        return false;
    }
    
    syntax->printWarnings();
    return true;
}

// Builds a statement block
bool Parser::buildBlock(AstBlock *block, int stopLayer, AstIfStmt *parentBlock, bool inElif, bool inElse, bool single) {
    Token token = scanner->getNext();
    while (token.type != Eof) {
        bool code = true;
        bool end = false;
        
        switch (token.type) {
            case Char:
            case Short:
            case Int:
            case Float:
            case Double: code = buildVariableDec(block, token); break;
            case Struct: code = buildStructDec(block); break;
            case Const: code = buildConst(false); break;
            
            case Id: {
                Token idToken = token;
                token = scanner->getNext();
                
                if (token.type == Assign) {
                    code = buildVariableAssign(block, idToken);
                } else if (token.type == LBracket) {
                    code = buildArrayAssign(block, idToken);
                } else if (token.type == LParen) {
                    code = buildFunctionCallStmt(block, idToken);
                } else if (token.type == Dot) {
                    code = buildStructAssign(block, idToken);
                } else {
                    AstEmptyStmt *empty = new AstEmptyStmt;
                    if (!buildExpression(empty, DataType::Void)) return false;
                    block->addStatement(empty);
                    //syntax->addError(scanner->getLine(), "Invalid use of identifier.");
                    //return false;
                }
            } break;
            
            case Return: code = buildReturn(block); break;
            
            // Handle conditionals
            case If: code = buildConditional(block); break;
            case Else: {
                bool isElif = true;
                Token next = scanner->getNext();
                if (next.type != If) {
                    scanner->rewind(next);
                    isElif = false;
                }
            
                if (inElif) {
                    scanner->rewind(token);
                    end = true;
                } else if (isElif) {
                    code = buildElif(parentBlock);
                } else {
                    code = buildElse(parentBlock);
                    end = true;
                }
            } break;
            
            // Handle loops
            case While: code = buildWhile(block); break;
            case Break: code = buildLoopCtrl(block, true); break;
            case Continue: code = buildLoopCtrl(block, false); break;
            
            // Handle the END keyword
            // This is kind of tricky in conditionals
            case RCBrace: {
                Token next = scanner->getNext();
                if (next.type == Else) {
                    token = next;
                    continue;
                }
                scanner->rewind(next);
            
                if (inElif) {
                    scanner->rewind(token);
                    end = true;
                    break;
                }
                if (layer == stopLayer) {
                    end = true;
                }
                if (layer > 0) --layer;
            } break;
            
            case Nl: break;
            
            default: {
                scanner->rewind(token);
                AstEmptyStmt *empty = new AstEmptyStmt;
                if (!buildExpression(empty, DataType::Void)) return false;
                block->addStatement(empty);
            }
        }
        
        
        if (single) {
            token = scanner->getNext();
            scanner->rewind(token);
            if (token.type != Else) {
                break;
            } else if (token.type == Else && inElse) {
                break;
            }    
        }
        if (end) break;
        if (!code) return false;
        token = scanner->getNext();
    }
    
    return true;
}

// The debug function for the scanner
void Parser::debugScanner() {
    std::cout << "Debugging scanner..." << std::endl;
    
    Token t;
    do {
        t = scanner->getNext();
        t.print();
    } while (t.type != Eof);
}

// Checks to see if a string is a constant
int Parser::isConstant(std::string name) {
    if (globalConsts.find(name) != globalConsts.end()) {
        return 1;
    }
    
    if (localConsts.find(name) != localConsts.end()) {
        return 2;
    }
    
    return 0;
}

bool Parser::isVar(std::string name) {
    if (std::find(vars.begin(), vars.end(), name) != vars.end()) {
        return true;
    }
    return false;
}

bool Parser::isFunc(std::string name) {
    if (std::find(funcs.begin(), funcs.end(), name) != funcs.end()) {
        return true;
    }
    return false;
}
