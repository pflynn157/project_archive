#pragma once

#include <string>

std::string get_path(std::string in);
std::string get_basename(std::string in);
