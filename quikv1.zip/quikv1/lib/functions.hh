#pragma once

#include <string>
#include <vector>

#include "types.hh"

std::vector<Func> load_funcs(std::vector<String> contents);
std::string func_name(std::string sig);
std::string func_args(std::string sig);
