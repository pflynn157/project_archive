#include <stdarg.h>

#include <io.h>
#include <string.h>

void println(const char *str) {
    write(1, str, strlen(str));
    
    char n = '\n';
    write(1, &n, 1);
}

void print_int(int num) {
    // For some reason, weird things happen with just 0
    if (num == 0) {
        write(1, "0", 1);
        return;
    }
    
    if (num < 0) {
        num *= -1;
        write(1, "-", 1);
    }

    // Count the number of digits
    int size = 0;
    int num2 = num;
    while (num2 != 0) {
        num2 = num2 / 10;
        ++size;
    }
    
    // Convert to a string
    char buf1[size];
    int index = size - 1;
    num2 = num;
    
    while (num2 != 0) {
        int digit = num2 % 10;
        num2 = num2 / 10;
        buf1[index] = digit + '0';
        --index;
    }
    
    // Print
    write(1, (char *)buf1, size);
}

void print(const char *str, ...) {
    va_list arglist;
    va_start(arglist, str);
    
    size_t length = strlen(str);
    char new_str[length];
    int index = 0;
    
    for (size_t i = 0; i<length; i++) {
        if (str[i] == '%') {
            char fmt_type = str[i+1];
            
            switch (fmt_type) {
                case 'd': {
                    write(1, new_str, index);
                    for (size_t j = 0; j<index; j++) new_str[j] = 0;
                    index = 0;
                    ++i;
                    
                    int to_print = va_arg(arglist, int);
                    print_int(to_print);
                } break;
                
                case 's': {
                    write(1, new_str, index);
                    for (size_t j = 0; j<index; j++) new_str[j] = 0;
                    index = 0;
                    ++i;
                    
                    char *str2 = va_arg(arglist, char *);
                    write(1, str2, strlen(str2));
                } break;
                
                default: {
                    new_str[index] = '%';
                    new_str[index + 1] = fmt_type;
                    index += 2;
                }
            }
        } else {
            new_str[index] = str[i];
            ++index;
        }
    }
    
    if (index > 0) {
        write(1, new_str, index);
    }
}

