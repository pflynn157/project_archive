#include <iostream>
#include <cstdlib>
#include <signal.h>
#include <unistd.h>

#include "server.hpp"
#include "writer.hpp"
#include "config/config.hpp"

//Handles CTRL-C events
void on_close(int s) {
	std::cout << "Shutting down server..." << std::endl;
	close(socketd);
	std::exit(0);	
}

int main(int argc, char **argv) {    
    // Setup to listen for CTR-C events
    struct sigaction sigHandler;
	sigHandler.sa_handler = on_close;
	sigemptyset(&sigHandler.sa_mask);
	sigHandler.sa_flags = 0;
	
	sigaction(SIGINT, &sigHandler, NULL);
	
	//int port = 80;
    int port = 1234;
    std::string basePath = "./";
    
    if (argc > 1) {
        for (int i = 1; i<argc; i++) {
            std::string current = argv[i];
            if (current == "-w" || current == "--www") {
                basePath = std::string(argv[i+1]);
                ++i;
            }
        }
    }
    
    // Load the config
    ConfigParser *confParser = new ConfigParser(basePath);
    ServerConfig *config = confParser->getConfig();
    
    Server *server = new Server(port, basePath, config);
    server->run();

    return 0;
}
