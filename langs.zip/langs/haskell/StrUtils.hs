module StrUtils
( trim
, rmSpaces
) where

-- Reverses a string
rvs [] str_new = str_new
rvs (s:str) str_new = rvs str (s : str_new)

-- Removes all spaces from a string
rmSpaces [] str_new = rvs str_new []
rmSpaces (s:str) str_new = do
    if s == ' ' || s == '\t'
        then rmSpaces str str_new
        else rmSpaces str (s : str_new)
        
-- Trims the front of a string
trimFront [] strn _ = rvs strn []
trimFront (s:str) strn found = do
    if s == ' ' || s == '\t'
        then do 
            if found == True
                then trimFront str (s : strn) True
                else trimFront str strn False
        else trimFront str (s : strn) True
  
-- Trims leading and trailing whitespace
-- Basically, this trims the front, reverses it,
-- and then trims the back using the same function.      
trim str = do
    let str2 = trimFront str [] False
    let str3 = rvs str2 []
    let final = trimFront str3 [] False
    let final2 = rvs final []
    final2
