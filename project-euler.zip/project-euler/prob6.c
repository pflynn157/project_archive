#include <stdio.h>

int main() {
    int result1 = 0;
    int result2 = 0;
    
    for (int i = 1; i<=100; i++) {
        result1 += (i * i);
        result2 += i;
    }
    
    result2 = result2 * result2;
    
    int diff = result2 - result1;
    printf("%d\n", diff);

    return 0;
}
