//OUTPUT
//END

//RET 0

int
main()
{
	return 0;
}
